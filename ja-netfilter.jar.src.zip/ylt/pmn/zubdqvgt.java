package ylt.pmn;

public class zubdqvgt {
  public static final boolean G(Object paramObject1, Object paramObject2) {
    return (paramObject1 == paramObject2 || (paramObject1 instanceof String && paramObject2 instanceof String && paramObject1.equals(paramObject2)));
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\ylt\pmn\zubdqvgt.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */