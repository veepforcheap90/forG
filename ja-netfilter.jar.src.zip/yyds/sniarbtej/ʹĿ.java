package yyds.sniarbtej;

import java.lang.reflect.Method;

final class ʹĿ extends ˋץ {
  ʹĿ(Method paramMethod, int paramInt) {}
  
  public final <T> T ᐨẏ(Class<T> paramClass) {
    return (T)this.ˊ.invoke(null, new Object[] { paramClass, Integer.valueOf(this.ˍᔥ) });
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ʹĿ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */