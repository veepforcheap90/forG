package yyds.sniarbtej;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import ylt.pmn.zubdqvgt;

public abstract class ˈהּ extends ˊɼ implements ـﭔ {
  private static final Object ˊ;
  
  private static final Object ᴵʖ;
  
  private static final String ۥ = ˍɫ$יς.J("Ɪગฒꀆ횦ͩ荦旣ᜁ⣶荋Ъ控工".toCharArray(), (short)1871, (short)3, (byte)4).intern();
  
  private int י一;
  
  private String ـไ;
  
  private final boolean ʿᵉ;
  
  private boolean ʹﮃ;
  
  private List<Object> ᐨẏ;
  
  private Map<ᔪ, List<Object>> ᐨẏ;
  
  private ˈהּ(int paramInt1, ˉｓ paramˉｓ, int paramInt2, String paramString1, String paramString2) {
    super(paramInt1, paramˉｓ, paramInt2, paramString1, paramString2);
    "啩?㯯ﳡ禢䃾".toCharArray()[0] = (char)("啩?㯯ﳡ禢䃾".toCharArray()[0] ^ 0x55BD);
    this.ʿᵉ = ˉﻤ$ͺſ.v("啩?㯯ﳡ禢䃾".toCharArray(), (short)10075, 4, (short)2).equals(paramString1);
  }
  
  public final void ᴵʖ() {
    super.ᴵʖ();
    if (this.ʿᵉ) {
      this.ᐨẏ = (Map<ᔪ, List<Object>>)new ArrayList();
      this.ᐨẏ = new HashMap<>();
    } 
  }
  
  public final void ˊ(ᔪ paramᔪ) {
    super.ˊ(paramᔪ);
    List list;
    if (this.ʿᵉ && this.ᐨẏ != null && (list = this.ᐨẏ.get(paramᔪ)) != null) {
      this.ᐨẏ = (Map<ᔪ, List<Object>>)list;
      this.ʹﮃ = false;
      this.ᐨẏ.remove(paramᔪ);
    } 
  }
  
  public final void ʹﮃ(int paramInt) {
    if (this.ʿᵉ && !this.ʹﮃ) {
      ˈהּ ˈהּ1;
      int i;
      switch (paramInt) {
        case 172:
        case 173:
        case 174:
        case 175:
        case 176:
          "ⅻ滃혱釛ʗ킮蚜懆৪楋໒Ⱉ䚄⽗䫔ꁩ瞖퓭濃鋖婢藲??鈧䲳ꖾ㱰䳔".toCharArray()[18] = (char)("ⅻ滃혱釛ʗ킮蚜懆৪楋໒Ⱉ䚄⽗䫔ꁩ瞖퓭濃鋖婢藲??鈧䲳ꖾ㱰䳔".toCharArray()[18] ^ 0x39D1);
          throw new IllegalArgumentException(ᐨẏ$ᐝт.W("ⅻ滃혱釛ʗ킮蚜懆৪楋໒Ⱉ䚄⽗䫔ꁩ瞖퓭濃鋖婢藲??鈧䲳ꖾ㱰䳔".toCharArray(), (short)13910, (byte)5, (short)1));
        case 177:
          (ˈהּ1 = this).ʹﮃ = true;
          break;
        case 191:
          ᐨẏ();
          (ˈהּ1 = this).ʹﮃ = true;
          break;
        case 0:
        case 47:
        case 49:
        case 116:
        case 117:
        case 118:
        case 119:
        case 134:
        case 138:
        case 139:
        case 143:
        case 145:
        case 146:
        case 147:
        case 190:
          break;
        case 1:
        case 2:
        case 3:
        case 4:
        case 5:
        case 6:
        case 7:
        case 8:
        case 11:
        case 12:
        case 13:
        case 133:
        case 135:
        case 140:
        case 141:
          ﾞл(ᴵʖ);
          break;
        case 9:
        case 10:
        case 14:
        case 15:
          ﾞл(ᴵʖ);
          ﾞл(ᴵʖ);
          break;
        case 46:
        case 48:
        case 50:
        case 51:
        case 52:
        case 53:
        case 87:
        case 96:
        case 98:
        case 100:
        case 102:
        case 104:
        case 106:
        case 108:
        case 110:
        case 112:
        case 114:
        case 120:
        case 121:
        case 122:
        case 123:
        case 124:
        case 125:
        case 126:
        case 128:
        case 130:
        case 136:
        case 137:
        case 142:
        case 144:
        case 149:
        case 150:
        case 194:
        case 195:
          ᐨẏ();
          break;
        case 88:
        case 97:
        case 99:
        case 101:
        case 103:
        case 105:
        case 107:
        case 109:
        case 111:
        case 113:
        case 115:
        case 127:
        case 129:
        case 131:
          ᐨẏ();
          ᐨẏ();
          break;
        case 79:
        case 81:
        case 83:
        case 84:
        case 85:
        case 86:
        case 148:
        case 151:
        case 152:
          ᐨẏ();
          ᐨẏ();
          ᐨẏ();
          break;
        case 80:
        case 82:
          ᐨẏ();
          ᐨẏ();
          ᐨẏ();
          ᐨẏ();
          break;
        case 89:
          ﾞл((ˈהּ1 = this).ᐨẏ.get(ˈהּ1.ᐨẏ.size() - 1));
          break;
        case 90:
          i = this.ᐨẏ.size();
          this.ᐨẏ.add(i - 2, this.ᐨẏ.get(i - 1));
          break;
        case 91:
          i = this.ᐨẏ.size();
          this.ᐨẏ.add(i - 3, this.ᐨẏ.get(i - 1));
          break;
        case 92:
          i = this.ᐨẏ.size();
          this.ᐨẏ.add(i - 2, this.ᐨẏ.get(i - 1));
          this.ᐨẏ.add(i - 2, this.ᐨẏ.get(i - 1));
          break;
        case 93:
          i = this.ᐨẏ.size();
          this.ᐨẏ.add(i - 3, this.ᐨẏ.get(i - 1));
          this.ᐨẏ.add(i - 3, this.ᐨẏ.get(i - 1));
          break;
        case 94:
          i = this.ᐨẏ.size();
          this.ᐨẏ.add(i - 4, this.ᐨẏ.get(i - 1));
          this.ᐨẏ.add(i - 4, this.ᐨẏ.get(i - 1));
          break;
        case 95:
          i = this.ᐨẏ.size();
          this.ᐨẏ.add(i - 2, this.ᐨẏ.get(i - 1));
          this.ᐨẏ.remove(i);
          break;
        default:
          "Ꮫ肠턊矵ቼ逢鉒뒰鷊ꐪᠢ?༱䗢쨸噏".toCharArray()[5] = (char)("Ꮫ肠턊矵ቼ逢鉒뒰鷊ꐪᠢ?༱䗢쨸噏".toCharArray()[5] ^ 0x3A6B);
          throw new IllegalArgumentException(ᐨẏ$ᐝт.W("Ꮫ肠턊矵ቼ逢鉒뒰鷊ꐪᠢ?༱䗢쨸噏".toCharArray(), (short)22488, (byte)1, (short)4).intern() + paramInt);
      } 
    } 
    super.ʹﮃ(paramInt);
  }
  
  public final void ᴵʖ(int paramInt1, int paramInt2) {
    super.ᴵʖ(paramInt1, paramInt2);
    if (this.ʿᵉ && !this.ʹﮃ) {
      ˈהּ ˈהּ1;
      switch (paramInt1) {
        case 21:
        case 23:
          ﾞл(ᴵʖ);
          return;
        case 22:
        case 24:
          ﾞл(ᴵʖ);
          ﾞл(ᴵʖ);
          return;
        case 25:
          ﾞл((paramInt2 == 0) ? ˊ : ᴵʖ);
          return;
        case 54:
        case 56:
        case 58:
          ᐨẏ();
          return;
        case 55:
        case 57:
          ᐨẏ();
          ᐨẏ();
          return;
        case 169:
          (ˈהּ1 = this).ʹﮃ = true;
          return;
      } 
      "⒀ꣅ왧㍊点籘岜⢚᳙卐䋝즄溢ᡅᦎ".toCharArray()[13] = (char)("⒀ꣅ왧㍊点籘岜⢚᳙卐䋝즄溢ᡅᦎ".toCharArray()[13] ^ 0x1A3E);
      throw new IllegalArgumentException(ˏȓ$ᴵЃ.E("⒀ꣅ왧㍊点籘岜⢚᳙卐䋝즄溢ᡅᦎ".toCharArray(), (short)2850, (short)4, (short)4).intern() + ˈהּ1);
    } 
  }
  
  public final void ᐨẏ(int paramInt, String paramString1, String paramString2, String paramString3) {
    super.ᐨẏ(paramInt, paramString1, paramString2, paramString3);
    if (this.ʿᵉ && !this.ʹﮃ) {
      char c = ((c = paramString3.charAt(0)) == 'J' || c == 'D') ? '\001' : Character.MIN_VALUE;
      switch (paramInt) {
        case 178:
          ﾞл(ᴵʖ);
          if (c != '\000') {
            ﾞл(ᴵʖ);
            return;
          } 
          return;
        case 179:
          ᐨẏ();
          if (c != '\000') {
            ᐨẏ();
            return;
          } 
          return;
        case 181:
          ᐨẏ();
          ᐨẏ();
          if (c != '\000') {
            ᐨẏ();
            return;
          } 
          return;
        case 180:
          if (c != '\000') {
            ﾞл(ᴵʖ);
            return;
          } 
          return;
      } 
      "㓸≚ף?ℊয়琬䀱㑎殮閉ѕ》".toCharArray()[8] = (char)("㓸≚ף?ℊয়琬䀱㑎殮閉ѕ》".toCharArray()[8] ^ 0xDEF);
      throw new IllegalArgumentException(ᐨẏ$ᐝт.W("㓸≚ף?ℊয়琬䀱㑎殮閉ѕ》".toCharArray(), (short)23202, (byte)2, (short)0).intern() + paramInt);
    } 
  }
  
  public final void ˊ(int paramInt1, int paramInt2) {
    super.ˊ(paramInt1, paramInt2);
    if (this.ʿᵉ && !this.ʹﮃ && paramInt1 != 188)
      ﾞл(ᴵʖ); 
  }
  
  public final void ˊ(Object paramObject) {
    super.ˊ(paramObject);
    if (this.ʿᵉ && !this.ʹﮃ) {
      ﾞл(ᴵʖ);
      if (paramObject instanceof Double || paramObject instanceof Long || (paramObject instanceof ʾܪ && ((ʾܪ)paramObject).ˍɫ() == 2))
        ﾞл(ᴵʖ); 
    } 
  }
  
  public final void ˊ(String paramString, int paramInt) {
    super.ˊ(paramString, paramInt);
    if (this.ʿᵉ && !this.ʹﮃ) {
      for (byte b = 0; b < paramInt; b++)
        ᐨẏ(); 
      ﾞл(ᴵʖ);
    } 
  }
  
  public final void ᐨẏ(int paramInt, String paramString) {
    super.ᐨẏ(paramInt, paramString);
    if (this.ʿᵉ && !this.ʹﮃ && paramInt == 187)
      ﾞл(ᴵʖ); 
  }
  
  public final void ᐨẏ(int paramInt, String paramString1, String paramString2, String paramString3, boolean paramBoolean) {
    if (this.ᐨẏ < 327680 && (paramInt & 0x100) == 0) {
      super.ᐨẏ(paramInt, paramString1, paramString2, paramString3, paramBoolean);
      return;
    } 
    super.ᐨẏ(paramInt, paramString1, paramString2, paramString3, paramBoolean);
    paramInt &= 0xFFFFFEFF;
    ˊ(paramInt, paramString2, paramString3);
  }
  
  private void ˊ(int paramInt, String paramString1, String paramString2) {
    if (this.ʿᵉ && !this.ʹﮃ) {
      ˑܘ[] arrayOfˑܘ;
      int i = (arrayOfˑܘ = ˑܘ.ᐨẏ(paramString2)).length;
      for (byte b = 0; b < i; b++) {
        ˑܘ ˑܘ = arrayOfˑܘ[b];
        ᐨẏ();
        if (ˑܘ.ˍɫ() == 2)
          ᐨẏ(); 
      } 
      switch (paramInt) {
        case 182:
        case 185:
          ᐨẏ();
          break;
        case 183:
          "좂⼗꣧褍䌔ᒩ".toCharArray()[3] = (char)("좂⼗꣧褍䌔ᒩ".toCharArray()[3] ^ 0x1E25);
          if (zubdqvgt.G(object = ᐨẏ(), ˊ) && !this.ʹﮃ && paramString1.equals(ᐝᵣ$ﾞﾇ.j("좂⼗꣧褍䌔ᒩ".toCharArray(), (short)18100, 0, (short)5)))
            this.ʹﮃ = true; 
          break;
      } 
      Object object;
      if (!zubdqvgt.G(object = ˑܘ.ﾞл(paramString2), ˑܘ.ᐨẏ)) {
        ﾞл(ᴵʖ);
        if (object.ˍɫ() == 2)
          ﾞл(ᴵʖ); 
      } 
    } 
  }
  
  public final void ᐨẏ(String paramString1, String paramString2, ʹō paramʹō, Object... paramVarArgs) {
    super.ᐨẏ(paramString1, paramString2, paramʹō, paramVarArgs);
    ˊ(186, paramString1, paramString2);
  }
  
  public final void ᐨẏ(int paramInt, ᔪ paramᔪ) {
    super.ᐨẏ(paramInt, paramᔪ);
    if (this.ʿᵉ && !this.ʹﮃ) {
      ˈהּ ˈהּ1;
      switch (paramInt) {
        case 153:
        case 154:
        case 155:
        case 156:
        case 157:
        case 158:
        case 198:
        case 199:
          ᐨẏ();
          break;
        case 159:
        case 160:
        case 161:
        case 162:
        case 163:
        case 164:
        case 165:
        case 166:
          ᐨẏ();
          ᐨẏ();
          break;
        case 168:
          ﾞл(ᴵʖ);
          break;
        case 167:
          (ˈהּ1 = this).ʹﮃ = true;
          break;
      } 
      ᴵʖ(paramᔪ);
    } 
  }
  
  public final void ᐨẏ(ᔪ paramᔪ, int[] paramArrayOfint, ᔪ[] paramArrayOfᔪ) {
    super.ᐨẏ(paramᔪ, paramArrayOfint, paramArrayOfᔪ);
    if (this.ʿᵉ && !this.ʹﮃ) {
      ᐨẏ();
      ˊ(paramᔪ, paramArrayOfᔪ);
      ˈהּ ˈהּ1;
      (ˈהּ1 = this).ʹﮃ = true;
    } 
  }
  
  public final void ᐨẏ(int paramInt1, int paramInt2, ᔪ paramᔪ, ᔪ... paramVarArgs) {
    super.ᐨẏ(paramInt1, paramInt2, paramᔪ, paramVarArgs);
    if (this.ʿᵉ && !this.ʹﮃ) {
      ᐨẏ();
      ˊ(paramᔪ, paramVarArgs);
      ˈהּ ˈהּ1;
      (ˈהּ1 = this).ʹﮃ = true;
    } 
  }
  
  public final void ᐨẏ(ᔪ paramᔪ1, ᔪ paramᔪ2, ᔪ paramᔪ3, String paramString) {
    super.ᐨẏ(paramᔪ1, paramᔪ2, paramᔪ3, paramString);
    if (this.ʿᵉ && !this.ᐨẏ.containsKey(paramᔪ3)) {
      ArrayList<Object> arrayList;
      (arrayList = new ArrayList()).add(ᴵʖ);
      this.ᐨẏ.put(paramᔪ3, arrayList);
    } 
  }
  
  private void ˊ(ᔪ paramᔪ, ᔪ[] paramArrayOfᔪ) {
    ᴵʖ(paramᔪ);
    ᔪ[] arrayOfᔪ;
    int i = (arrayOfᔪ = paramArrayOfᔪ).length;
    for (byte b = 0; b < i; b++) {
      ᔪ ᔪ1 = arrayOfᔪ[b];
      ᴵʖ(ᔪ1);
    } 
  }
  
  private void ᴵʖ(ᔪ paramᔪ) {
    if (this.ᐨẏ.containsKey(paramᔪ))
      return; 
    this.ᐨẏ.put(paramᔪ, new ArrayList((Collection<?>)this.ᐨẏ));
  }
  
  private void ʽ() {
    this.ʹﮃ = true;
  }
  
  private Object ᐨẏ() {
    return this.ᐨẏ.remove(this.ᐨẏ.size() - 1);
  }
  
  private Object ˊ() {
    return this.ᐨẏ.get(this.ᐨẏ.size() - 1);
  }
  
  private void ﾞл(Object paramObject) {
    this.ᐨẏ.add(paramObject);
  }
  
  private static void ʾܪ() {}
  
  private static void ᐨم() {}
  
  static {
    ˊ = new Object();
    ᴵʖ = new Object();
  }
  
  static {
    "Ɪગฒꀆ횦ͩ荦旣ᜁ⣶荋Ъ控工".toCharArray()[2] = (char)("Ɪગฒꀆ횦ͩ荦旣ᜁ⣶荋Ъ控工".toCharArray()[2] ^ 0x3047);
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ˈהּ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */