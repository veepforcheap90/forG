package yyds.sniarbtej;

import java.lang.reflect.Field;

enum ˍぃ {
  public final String ᐨẏ(Field paramField) {
    return paramField.getName();
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ˍぃ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */