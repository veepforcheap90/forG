package yyds.sniarbtej;

import ylt.pmn.zubdqvgt;

public class ʾˤ extends ʼᵖ {
  private boolean ᴵƚ;
  
  private ʾˤ(ʼᵖ paramʼᵖ) {
    this(589824, paramʼᵖ);
    if (!zubdqvgt.G(getClass(), ʾˤ.class))
      throw new IllegalStateException(); 
  }
  
  protected ʾˤ(int paramInt, ʼᵖ paramʼᵖ) {
    super(paramInt, paramʼᵖ);
  }
  
  public final ᐨẏ ᐨẏ(String paramString, boolean paramBoolean) {
    ᴶ();
    ـｊ.ᐨẏ(49, paramString, false);
    return new ͺᖽ(super.ᐨẏ(paramString, paramBoolean));
  }
  
  public final ᐨẏ ᐨẏ(int paramInt, ˏɪ paramˏɪ, String paramString, boolean paramBoolean) {
    ᴶ();
    int i;
    if ((i = (new ʾเ(paramInt)).ˉｓ()) != 19) {
      "禯⃾㹿?쬳潘菣◴뮅뵒脶엥뤗걃䌑ꡟ꽱棚ནﵖᵴ㚾Ὠ씈ᗣ".toCharArray()[29] = (char)("禯⃾㹿?쬳潘菣◴뮅뵒脶엥뤗걃䌑ꡟ꽱棚ནﵖᵴ㚾Ὠ씈ᗣ".toCharArray()[29] ^ 0x36F4);
      throw new IllegalArgumentException(ˏȓ$ᴵЃ.E("禯⃾㹿?쬳潘菣◴뮅뵒脶엥뤗걃䌑ꡟ꽱棚ནﵖᵴ㚾Ὠ씈ᗣ".toCharArray(), (short)14737, (short)4, (short)1) + Integer.toHexString(i));
    } 
    ˉʭ.ʹō(paramInt);
    ـｊ.ᐨẏ(49, paramString, false);
    return new ͺᖽ(super.ᐨẏ(paramInt, paramˏɪ, paramString, paramBoolean));
  }
  
  public final void ᴵʖ(ᴵʖ paramᴵʖ) {
    ᴶ();
    if (paramᴵʖ == null) {
      "?环쯤魸沌佋羋篰䏋⶗齃ﺅ䶪ｙ謇᱘떂⭂ꩈ♏妹냬᪪?䘿멃򽇊瀌捕⨞".toCharArray()[25] = (char)("?环쯤魸沌佋羋篰䏋⶗齃ﺅ䶪ｙ謇᱘떂⭂ꩈ♏妹냬᪪?䘿멃򽇊瀌捕⨞".toCharArray()[25] ^ 0x12B6);
      throw new IllegalArgumentException(ˏȓ$ᴵЃ.E("?环쯤魸沌佋羋篰䏋⶗齃ﺅ䶪ｙ謇᱘떂⭂ꩈ♏妹냬᪪?䘿멃򽇊瀌捕⨞".toCharArray(), (short)8897, (short)5, (short)1));
    } 
    super.ᴵʖ(paramᴵʖ);
  }
  
  public final void ᐨẏ() {
    ᴶ();
    this.ᴵƚ = true;
    super.ᐨẏ();
  }
  
  private void ᴶ() {
    if (this.ᴵƚ) {
      "ತ鸰䤰莝璚ꆕ栆㣫ꢩŁᲯ먢샕率齄ᓉ說⨐쿴蛰᪇䝼ꕧ騏䠳௡㱡羪䆢ʊ묓藋붓ﰡ⑼䌜䬛愤병옭쬷莲褠쎇㩶呷䟿잗썠梚差ꮎ呝禉".toCharArray()[2] = (char)("ತ鸰䤰莝璚ꆕ栆㣫ꢩŁᲯ먢샕率齄ᓉ說⨐쿴蛰᪇䝼ꕧ騏䠳௡㱡羪䆢ʊ묓藋붓ﰡ⑼䌜䬛愤병옭쬷莲褠쎇㩶呷䟿잗썠梚差ꮎ呝禉".toCharArray()[2] ^ 0xB8E);
      throw new IllegalStateException(ᐝᵣ$ﾞﾇ.j("ತ鸰䤰莝璚ꆕ栆㣫ꢩŁᲯ먢샕率齄ᓉ說⨐쿴蛰᪇䝼ꕧ騏䠳௡㱡羪䆢ʊ묓藋붓ﰡ⑼䌜䬛愤병옭쬷莲褠쎇㩶呷䟿잗썠梚差ꮎ呝禉".toCharArray(), (short)18906, 0, (short)4));
    } 
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ʾˤ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */