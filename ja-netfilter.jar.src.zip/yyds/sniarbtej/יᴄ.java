package yyds.sniarbtej;

import java.util.List;

public final class יᴄ {
  private String licenseId;
  
  private String licenseeName;
  
  private String assigneeName;
  
  private String assigneeEmail;
  
  private String licenseRestriction;
  
  private boolean checkConcurrentUse;
  
  private List<ʿᒧ> products;
  
  private String metadata;
  
  private String hash;
  
  private int gracePeriodDays;
  
  private boolean autoProlongated;
  
  private boolean isAutoProlongated;
  
  public יᴄ() {
    "鴜卪ჯ⩀ꕠ嶿".toCharArray()[0] = (char)("鴜卪ჯ⩀ꕠ嶿".toCharArray()[0] ^ 0x2B50);
    this.licenseId = ˉﻤ$ͺſ.v("鴜卪ჯ⩀ꕠ嶿".toCharArray(), (short)11482, 1, (short)0);
    "㕖췈疟Ṟ嫶ᚬ瀩ⶼ≁婼쪥β䗼綋".toCharArray()[6] = (char)("㕖췈疟Ṟ嫶ᚬ瀩ⶼ≁婼쪥β䗼綋".toCharArray()[6] ^ 0x5FCE);
    this.licenseeName = ˉﻤ$ͺſ.v("㕖췈疟Ṟ嫶ᚬ瀩ⶼ≁婼쪥β䗼綋".toCharArray(), (short)16058, 4, (short)1);
    this.assigneeName = "";
    this.assigneeEmail = "";
    "웥秲뉸ɖ逨ί菉睫옢?䄙䉨䛢䇌䑈?允涸棳ꄚ?ⓦ津껤猤琒❔".toCharArray()[11] = (char)("웥秲뉸ɖ逨ί菉睫옢?䄙䉨䛢䇌䑈?允涸棳ꄚ?ⓦ津껤猤琒❔".toCharArray()[11] ^ 0x3A76);
    this.licenseRestriction = ˉﻤ$ͺſ.v("웥秲뉸ɖ逨ί菉睫옢?䄙䉨䛢䇌䑈?允涸棳ꄚ?ⓦ津껤猤琒❔".toCharArray(), (short)25674, 5, (short)1);
    "氹㺂鉡䳟샷陔㑠쉮﵅揣㟤腔蔅⸼᳤䷈႖拳窸".toCharArray()[12] = (char)("氹㺂鉡䳟샷陔㑠쉮﵅揣㟤腔蔅⸼᳤䷈႖拳窸".toCharArray()[12] ^ 0x39AB);
    this.metadata = ˉﻤ$ͺſ.v("氹㺂鉡䳟샷陔㑠쉮﵅揣㟤腔蔅⸼᳤䷈႖拳窸".toCharArray(), (short)2215, 4, (short)2);
    "ሁ误侢獯ﻆ睵".toCharArray()[3] = (char)("ሁ误侢獯ﻆ睵".toCharArray()[3] ^ 0x65FE);
    this.hash = ˉﻤ$ͺſ.v("ሁ误侢獯ﻆ睵".toCharArray(), (short)4644, 3, (short)2);
    this.gracePeriodDays = 7;
  }
  
  public final String getLicenseId() {
    return this.licenseId;
  }
  
  public final void setLicenseId(String paramString) {
    this.licenseId = paramString;
  }
  
  public final String getLicenseeName() {
    return this.licenseeName;
  }
  
  public final void setLicenseeName(String paramString) {
    this.licenseeName = paramString;
  }
  
  public final String getAssigneeName() {
    return this.assigneeName;
  }
  
  public final void setAssigneeName(String paramString) {
    this.assigneeName = paramString;
  }
  
  public final String getAssigneeEmail() {
    return this.assigneeEmail;
  }
  
  public final void setAssigneeEmail(String paramString) {
    this.assigneeEmail = paramString;
  }
  
  public final String getLicenseRestriction() {
    return this.licenseRestriction;
  }
  
  public final void setLicenseRestriction(String paramString) {
    this.licenseRestriction = paramString;
  }
  
  public final boolean isCheckConcurrentUse() {
    return this.checkConcurrentUse;
  }
  
  public final void setCheckConcurrentUse(boolean paramBoolean) {
    this.checkConcurrentUse = paramBoolean;
  }
  
  public final List<ʿᒧ> getProducts() {
    return this.products;
  }
  
  public final void setProducts(List<ʿᒧ> paramList) {
    this.products = paramList;
  }
  
  public final String getMetadata() {
    return this.metadata;
  }
  
  public final void setMetadata(String paramString) {
    this.metadata = paramString;
  }
  
  public final String getHash() {
    return this.hash;
  }
  
  public final void setHash(String paramString) {
    this.hash = paramString;
  }
  
  public final int getGracePeriodDays() {
    return this.gracePeriodDays;
  }
  
  public final void setGracePeriodDays(int paramInt) {
    this.gracePeriodDays = paramInt;
  }
  
  public final boolean isAutoProlongated() {
    return this.autoProlongated;
  }
  
  public final void setAutoProlongated(boolean paramBoolean) {
    this.autoProlongated = paramBoolean;
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\יᴄ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */