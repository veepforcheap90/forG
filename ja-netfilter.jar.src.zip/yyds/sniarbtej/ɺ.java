package yyds.sniarbtej;

final class ɺ extends ٴۉ<T1> {
  ɺ(ιᓛ paramιᓛ, Class paramClass) {}
  
  public final void ᐨẏ(Ⴡ paramჁ, T1 paramT1) {
    this.ᐨẏ.ﹳיִ.ᐨẏ(paramჁ, paramT1);
  }
  
  public final T1 ᐨẏ(יּ paramיּ) {
    if ((paramיּ = this.ᐨẏ.ﹳיִ.ᐨẏ(paramיּ)) != null && !this.ʾܪ.isInstance(paramיּ)) {
      "?믡蓍뱔쯢⎴쳀├爧厛Ṝ".toCharArray()[9] = (char)("?믡蓍뱔쯢⎴쳀├爧厛Ṝ".toCharArray()[9] ^ 0xD20);
      "닆섗ᢔ馀⽔玴ꮉ彧ઙవ".toCharArray()[6] = (char)("닆섗ᢔ馀⽔玴ꮉ彧ઙవ".toCharArray()[6] ^ 0x5500);
      throw new ՙĩ(ˍɫ$יς.J("?믡蓍뱔쯢⎴쳀├爧厛Ṝ".toCharArray(), (short)5464, (short)0, (byte)4) + this.ʾܪ.getName() + ˍɫ$יς.J("닆섗ᢔ馀⽔玴ꮉ彧ઙవ".toCharArray(), (short)4930, (short)1, (byte)0) + paramיּ.getClass().getName());
    } 
    return (T1)paramיּ;
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ɺ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */