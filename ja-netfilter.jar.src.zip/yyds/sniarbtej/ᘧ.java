package yyds.sniarbtej;

public final class ᘧ {
  private String name;
  
  private String ˎᴗ;
  
  private String ˊﮈ;
  
  private λ ᴵʖ;
  
  private λ ﾞл;
  
  private int ͺᴲ;
  
  public ᘧ(String paramString1, String paramString2, String paramString3, λ paramλ1, λ paramλ2, int paramInt) {
    this.name = paramString1;
    this.ˎᴗ = paramString2;
    this.ˊﮈ = paramString3;
    this.ᴵʖ = paramλ1;
    this.ﾞл = paramλ2;
    this.ͺᴲ = paramInt;
  }
  
  public final void ᐨẏ(ˉｓ paramˉｓ) {
    paramˉｓ.ᐨẏ(this.name, this.ˎᴗ, this.ˊﮈ, this.ᴵʖ.ﾞл(), this.ﾞл.ﾞл(), this.ͺᴲ);
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ᘧ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */