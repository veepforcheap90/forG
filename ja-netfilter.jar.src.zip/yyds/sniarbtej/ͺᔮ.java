package yyds.sniarbtej;

public abstract class ͺᔮ implements ﹳӱ {
  public final boolean ʹﮃ(String paramString) {
    return paramString.equals(ᔪ());
  }
  
  public static byte[] ᐨẏ(byte[] paramArrayOfbyte, ʹﬧ paramʹﬧ) {
    ᐨم ᐨم = new ᐨم(paramArrayOfbyte);
    ᵘ ᵘ2 = new ᵘ(458752);
    ᐨم.ᐨẏ(ᵘ2, 0);
    for (ᐧє ᐧє : ᵘ2.ᔪ)
      paramʹﬧ.invoke(ᐧє); 
    ʽ ʽ1 = new ʽ(3);
    ʽ ʽ2 = ʽ1;
    ᵘ ᵘ1;
    String[] arrayOfString = new String[(ᵘ1 = ᵘ2).ᐨم.size()];
    ᵘ1.ᐨم.toArray(arrayOfString);
    ʽ2.ᐨẏ(ᵘ1.ᔪ, ᵘ1.ᒬ, ᵘ1.name, ᵘ1.ˊﮈ, ᵘ1.ʼᐡ, arrayOfString);
    if (ᵘ1.ᴵઽ != null || ᵘ1.ᐧṙ != null)
      ʽ2.ᐨẏ(ᵘ1.ᴵઽ, ᵘ1.ᐧṙ); 
    ʽ ʽ3 = ʽ2;
    ٴﾗ ٴﾗ = ᵘ1.ᐨẏ;
    ʻล ʻล;
    if (ᵘ1.ᐨẏ != null && (ʻล = ʽ3.ᐨẏ(ٴﾗ.name, ٴﾗ.ᒬ, ٴﾗ.ˏﬤ)) != null) {
      if (ٴﾗ.ـᘢ != null)
        ʻล.ʿᵉ(ٴﾗ.ـᘢ); 
      if (ٴﾗ.ʻւ != null) {
        byte b1 = 0;
        int j = ٴﾗ.ʻւ.size();
        while (b1 < j) {
          ʻล.ʹﮃ(ٴﾗ.ʻւ.get(b1));
          b1++;
        } 
      } 
      if (ٴﾗ.ˑܘ != null) {
        byte b1 = 0;
        int j = ٴﾗ.ˑܘ.size();
        while (b1 < j) {
          ((ͺﮈ)ٴﾗ.ˑܘ.get(b1)).ᐨẏ(ʻล);
          b1++;
        } 
      } 
      if (ٴﾗ.ᐧפ != null) {
        byte b1 = 0;
        int j = ٴﾗ.ᐧפ.size();
        while (b1 < j) {
          ((ـיּ)ٴﾗ.ᐧפ.get(b1)).ᐨẏ(ʻล);
          b1++;
        } 
      } 
      if (ٴﾗ.ιˠ != null) {
        byte b1 = 0;
        int j = ٴﾗ.ιˠ.size();
        while (b1 < j) {
          ((ˈօ)ٴﾗ.ιˠ.get(b1)).ᐨẏ(ʻล);
          b1++;
        } 
      } 
      if (ٴﾗ.ˈהּ != null) {
        byte b1 = 0;
        int j = ٴﾗ.ˈהּ.size();
        while (b1 < j) {
          ʻล.ՙᗮ(ٴﾗ.ˈהּ.get(b1));
          b1++;
        } 
      } 
      if (ٴﾗ.ﹳיִ != null) {
        byte b1 = 0;
        int j = ٴﾗ.ﹳיִ.size();
        while (b1 < j) {
          ((ˋﺯ)ٴﾗ.ﹳיִ.get(b1)).ᐨẏ(ʻล);
          b1++;
        } 
      } 
    } 
    if (ᵘ1.ᗮ != null)
      ʽ2.ᐨẏ(ᵘ1.ᗮ); 
    if (ᵘ1.ᐨר != null)
      ʽ2.ˊ(ᵘ1.ᐨר, ᵘ1.ͺĹ, ᵘ1.ᴵЃ); 
    if (ᵘ1.ʾ != null) {
      byte b1 = 0;
      int j = ᵘ1.ʾ.size();
      while (b1 < j) {
        ʾא ʾא;
        (ʾא = ᵘ1.ʾ.get(b1)).ᐨẏ(ʽ2.ᐨẏ(ʾא.ˎᴗ, true));
        b1++;
      } 
    } 
    if (ᵘ1.ͺо != null) {
      byte b1 = 0;
      int j = ᵘ1.ͺо.size();
      while (b1 < j) {
        ʾא ʾא;
        (ʾא = ᵘ1.ͺо.get(b1)).ᐨẏ(ʽ2.ᐨẏ(ʾא.ˎᴗ, false));
        b1++;
      } 
    } 
    if (ᵘ1.ˍɫ != null) {
      byte b1 = 0;
      int j = ᵘ1.ˍɫ.size();
      while (b1 < j) {
        ʽ冫 ʽ冫;
        (ʽ冫 = ᵘ1.ˍɫ.get(b1)).ᐨẏ(ʽ2.ᐨẏ(ʽ冫.ٱ, ʽ冫.ˊ, ʽ冫.ˎᴗ, true));
        b1++;
      } 
    } 
    if (ᵘ1.ʽ != null) {
      byte b1 = 0;
      int j = ᵘ1.ʽ.size();
      while (b1 < j) {
        ʽ冫 ʽ冫;
        (ʽ冫 = ᵘ1.ʽ.get(b1)).ᐨẏ(ʽ2.ᐨẏ(ʽ冫.ٱ, ʽ冫.ˊ, ʽ冫.ˎᴗ, false));
        b1++;
      } 
    } 
    if (ᵘ1.ٴӵ != null) {
      byte b1 = 0;
      int j = ᵘ1.ٴӵ.size();
      while (b1 < j) {
        ʽ2.ᴵʖ(ᵘ1.ٴӵ.get(b1));
        b1++;
      } 
    } 
    if (ᵘ1.ˌ != null) {
      byte b1 = 0;
      int j = ᵘ1.ˌ.size();
      while (b1 < j) {
        ʽ2.ˊ(ᵘ1.ˌ.get(b1));
        b1++;
      } 
    } 
    if (ᵘ1.ˍ != null) {
      byte b1 = 0;
      int j = ᵘ1.ˍ.size();
      while (b1 < j) {
        ʽ2.ᴵʖ(ᵘ1.ˍ.get(b1));
        b1++;
      } 
    } 
    byte b = 0;
    int i = ᵘ1.ᴵƚ.size();
    while (b < i) {
      ((ﹱ)ᵘ1.ᴵƚ.get(b)).ᐨẏ(ʽ2);
      b++;
    } 
    if (ᵘ1.ʹō != null) {
      b = 0;
      i = ᵘ1.ʹō.size();
      while (b < i) {
        ʽ3 = ʽ2;
        ˑゞ ˑゞ = ᵘ1.ʹō.get(b);
        ʼᵖ ʼᵖ;
        if ((ʼᵖ = ʽ3.ᐨẏ(ˑゞ.name, ˑゞ.ᴵʖ, ˑゞ.ˊﮈ)) != null) {
          if (ˑゞ.ʾ != null) {
            byte b1 = 0;
            int j = ˑゞ.ʾ.size();
            while (b1 < j) {
              ʾא ʾא;
              (ʾא = ˑゞ.ʾ.get(b1)).ᐨẏ(ʼᵖ.ᐨẏ(ʾא.ˎᴗ, true));
              b1++;
            } 
          } 
          if (ˑゞ.ͺо != null) {
            byte b1 = 0;
            int j = ˑゞ.ͺо.size();
            while (b1 < j) {
              ʾא ʾא;
              (ʾא = ˑゞ.ͺо.get(b1)).ᐨẏ(ʼᵖ.ᐨẏ(ʾא.ˎᴗ, false));
              b1++;
            } 
          } 
          if (ˑゞ.ˍɫ != null) {
            byte b1 = 0;
            int j = ˑゞ.ˍɫ.size();
            while (b1 < j) {
              ʽ冫 ʽ冫;
              (ʽ冫 = ˑゞ.ˍɫ.get(b1)).ᐨẏ(ʼᵖ.ᐨẏ(ʽ冫.ٱ, ʽ冫.ˊ, ʽ冫.ˎᴗ, true));
              b1++;
            } 
          } 
          if (ˑゞ.ʽ != null) {
            byte b1 = 0;
            int j = ˑゞ.ʽ.size();
            while (b1 < j) {
              ʽ冫 ʽ冫;
              (ʽ冫 = ˑゞ.ʽ.get(b1)).ᐨẏ(ʼᵖ.ᐨẏ(ʽ冫.ٱ, ʽ冫.ˊ, ʽ冫.ˎᴗ, false));
              b1++;
            } 
          } 
          if (ˑゞ.ٴӵ != null) {
            byte b1 = 0;
            int j = ˑゞ.ٴӵ.size();
            while (b1 < j) {
              ʼᵖ.ᴵʖ(ˑゞ.ٴӵ.get(b1));
              b1++;
            } 
          } 
          ʼᵖ.ᐨẏ();
        } 
        b++;
      } 
    } 
    b = 0;
    i = ᵘ1.ᐝᵣ.size();
    while (b < i) {
      ʽ3 = ʽ2;
      ᐨ ᐨ = ᵘ1.ᐝᵣ.get(b);
      ᴵƚ ᴵƚ;
      if ((ᴵƚ = ʽ3.ᐨẏ(ᐨ.ᒬ, ᐨ.name, ᐨ.ˎᴗ, ᐨ.ˊﮈ, ᐨ.ﾞл)) != null) {
        if (ᐨ.ʾ != null) {
          byte b1 = 0;
          int j = ᐨ.ʾ.size();
          while (b1 < j) {
            ʾא ʾא;
            (ʾא = ᐨ.ʾ.get(b1)).ᐨẏ(ᴵƚ.ᐨẏ(ʾא.ˎᴗ, true));
            b1++;
          } 
        } 
        if (ᐨ.ͺо != null) {
          byte b1 = 0;
          int j = ᐨ.ͺо.size();
          while (b1 < j) {
            ʾא ʾא;
            (ʾא = ᐨ.ͺо.get(b1)).ᐨẏ(ᴵƚ.ᐨẏ(ʾא.ˎᴗ, false));
            b1++;
          } 
        } 
        if (ᐨ.ˍɫ != null) {
          byte b1 = 0;
          int j = ᐨ.ˍɫ.size();
          while (b1 < j) {
            ʽ冫 ʽ冫;
            (ʽ冫 = ᐨ.ˍɫ.get(b1)).ᐨẏ(ᴵƚ.ᐨẏ(ʽ冫.ٱ, ʽ冫.ˊ, ʽ冫.ˎᴗ, true));
            b1++;
          } 
        } 
        if (ᐨ.ʽ != null) {
          byte b1 = 0;
          int j = ᐨ.ʽ.size();
          while (b1 < j) {
            ʽ冫 ʽ冫;
            (ʽ冫 = ᐨ.ʽ.get(b1)).ᐨẏ(ᴵƚ.ᐨẏ(ʽ冫.ٱ, ʽ冫.ˊ, ʽ冫.ˎᴗ, false));
            b1++;
          } 
        } 
        if (ᐨ.ٴӵ != null) {
          byte b1 = 0;
          int j = ᐨ.ٴӵ.size();
          while (b1 < j) {
            ᴵƚ.ᴵʖ(ᐨ.ٴӵ.get(b1));
            b1++;
          } 
        } 
        ᴵƚ.ᐨẏ();
      } 
      b++;
    } 
    b = 0;
    i = ᵘ1.ᔪ.size();
    while (b < i) {
      ʽ3 = ʽ2;
      ᐧє ᐧє;
      String[] arrayOfString1 = ((ᐧє = ᵘ1.ᔪ.get(b)).ـﭔ == null) ? null : ᐧє.ـﭔ.<String>toArray(new String[0]);
      ˉｓ ˉｓ;
      if ((ˉｓ = ʽ3.ᐨẏ(ᐧє.ᒬ, ᐧє.name, ᐧє.ˎᴗ, ᐧє.ˊﮈ, arrayOfString1)) != null)
        ᐧє.ᐨẏ(ˉｓ); 
      b++;
    } 
    ʽ2.ᐨẏ();
    return ʽ1.ᐨẏ();
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ͺᔮ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */