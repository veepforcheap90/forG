package yyds.sniarbtej;

import java.util.List;

public final class ـɻ {
  private String ˏｳ;
  
  private int ᒬ;
  
  private List<String> ʹﮃ;
  
  public ـɻ(String paramString, int paramInt, List<String> paramList) {
    this.ˏｳ = paramString;
    this.ᒬ = paramInt;
    this.ʹﮃ = paramList;
  }
  
  public final void ᐨẏ(ʻล paramʻล) {
    paramʻล.ˊ(this.ˏｳ, this.ᒬ, (this.ʹﮃ == null) ? null : this.ʹﮃ.<String>toArray(new String[0]));
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ـɻ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */