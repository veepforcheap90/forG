package yyds.sniarbtej;

public interface ן {
  int ˍɫ();
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ן.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */