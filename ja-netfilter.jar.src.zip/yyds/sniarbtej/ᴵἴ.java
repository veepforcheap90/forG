package yyds.sniarbtej;

import java.util.EnumSet;
import ylt.pmn.zubdqvgt;

public final class ᴵἴ extends ـᘢ {
  private static int ʽŸ = 0;
  
  private static int ᐨʷ = 1;
  
  private static int ᓺ = 2;
  
  private static final EnumSet<ﾞᐦ> ᐨẏ;
  
  private static final EnumSet<ﾞᐦ> ˊ;
  
  private static final EnumSet<ﾞᐦ> ᴵʖ;
  
  private static final EnumSet<ﾞᐦ> ﾞл;
  
  private static final EnumSet<ﾞᐦ> ʿᵉ;
  
  private static final EnumSet<ﾞᐦ> ʹﮃ;
  
  private static final EnumSet<ﾞᐦ> ՙᗮ;
  
  private static final EnumSet<ﾞᐦ> ˍɫ;
  
  private static final String ʿḶ = ˍɫ$יς.J("갇歰䑤ꔙ࿙쩮ᩨꉯ嵅".toCharArray(), (short)15854, (short)3, (byte)3).intern();
  
  private final int ᓱ;
  
  private ﾞᐦ ᐨẏ;
  
  private boolean ˈے;
  
  private final ـᘢ ᐨẏ;
  
  private ᴵἴ(int paramInt, ـᘢ paramـᘢ) {
    this(589824, 2, paramـᘢ);
  }
  
  private ᴵἴ(int paramInt1, int paramInt2, ـᘢ paramـᘢ) {
    super(589824);
    this.ᓱ = paramInt2;
    this.ᐨẏ = (ـᘢ)ﾞᐦ.ˊ;
    this.ᐨẏ = paramـᘢ;
  }
  
  public final void ʾ(String paramString) {
    if (this.ᓱ == 2 || !ᐨẏ.contains(this.ᐨẏ))
      throw new IllegalStateException(); 
    "頑໙߶洭㔽ᖙ뗩쪥虷⯎橎厢캜⢟㷑ඡၢ蒉娱".toCharArray()[18] = (char)("頑໙߶洭㔽ᖙ뗩쪥虷⯎橎厢캜⢟㷑ඡၢ蒉娱".toCharArray()[18] ^ 0x99D);
    ᴵʖ(paramString, ᐨẏ$ᐝт.W("頑໙߶洭㔽ᖙ뗩쪥虷⯎橎厢캜⢟㷑ඡၢ蒉娱".toCharArray(), (short)11916, (byte)1, (short)0));
    this.ᐨẏ = (ـᘢ)ﾞᐦ.ᴵʖ;
    if (this.ᐨẏ != null)
      this.ᐨẏ.ʾ(paramString); 
  }
  
  public final ـᘢ ˊ() {
    if (this.ᓱ == 2 || !ˊ.contains(this.ᐨẏ))
      throw new IllegalStateException(); 
    this.ᐨẏ = (ـᘢ)ﾞᐦ.ﾞл;
    return new ᴵἴ(2, (this.ᐨẏ == null) ? null : this.ᐨẏ.ˊ());
  }
  
  public final ـᘢ ʿᵉ() {
    if (this.ᓱ == 2 || !ᴵʖ.contains(this.ᐨẏ))
      throw new IllegalStateException(); 
    return new ᴵἴ(2, (this.ᐨẏ == null) ? null : this.ᐨẏ.ʿᵉ());
  }
  
  public final ـᘢ ˍɫ() {
    if (this.ᓱ != 0 || !ﾞл.contains(this.ᐨẏ))
      throw new IllegalStateException(); 
    this.ᐨẏ = (ـᘢ)ﾞᐦ.ʿᵉ;
    return new ᴵἴ(2, (this.ᐨẏ == null) ? null : this.ᐨẏ.ˍɫ());
  }
  
  public final ـᘢ ﾞл() {
    if (this.ᓱ != 0 || !ʿᵉ.contains(this.ᐨẏ))
      throw new IllegalStateException(); 
    return new ᴵἴ(2, (this.ᐨẏ == null) ? null : this.ᐨẏ.ﾞл());
  }
  
  public final ـᘢ ʹﮃ() {
    if (this.ᓱ != 1 || !ʹﮃ.contains(this.ᐨẏ))
      throw new IllegalStateException(); 
    this.ᐨẏ = (ـᘢ)ﾞᐦ.ʹﮃ;
    return new ᴵἴ(2, (this.ᐨẏ == null) ? null : this.ᐨẏ.ʹﮃ());
  }
  
  public final ـᘢ ՙᗮ() {
    if (this.ᓱ != 1 || !ՙᗮ.contains(this.ᐨẏ))
      throw new IllegalStateException(); 
    this.ᐨẏ = (ـᘢ)ﾞᐦ.ՙᗮ;
    ᴵἴ ᴵἴ1;
    (ᴵἴ1 = new ᴵἴ(2, (this.ᐨẏ == null) ? null : this.ᐨẏ.ՙᗮ())).ˈے = true;
    return ᴵἴ1;
  }
  
  public final ـᘢ ᴵʖ() {
    if (this.ᓱ != 1 || !ˍɫ.contains(this.ᐨẏ))
      throw new IllegalStateException(); 
    return new ᴵἴ(2, (this.ᐨẏ == null) ? null : this.ᐨẏ.ᴵʖ());
  }
  
  public final void ᐨẏ(char paramChar) {
    if (this.ᓱ != 2 || !zubdqvgt.G(this.ᐨẏ, ﾞᐦ.ˊ))
      throw new IllegalStateException(); 
    if (paramChar == 'V') {
      if (!this.ˈے) {
        "䰎?㹲㱂藑黁䆗컽窶챨㻖镥఩騖ͮ᧱᷏䎽駑殛鼁鎰⥨幡ᨃᣑ櫁핦ᶎ禯".toCharArray()[24] = (char)("䰎?㹲㱂藑黁䆗컽窶챨㻖镥఩騖ͮ᧱᷏䎽駑殛鼁鎰⥨幡ᨃᣑ櫁핦ᶎ禯".toCharArray()[24] ^ 0x381A);
        throw new IllegalArgumentException(ᐝᵣ$ﾞﾇ.j("䰎?㹲㱂藑黁䆗컽窶챨㻖镥఩騖ͮ᧱᷏䎽駑殛鼁鎰⥨幡ᨃᣑ櫁핦ᶎ禯".toCharArray(), (short)10374, 5, (short)1));
      } 
    } else {
      "铖遶䇣ᮓ賉帡䨎㎤△".toCharArray()[0] = (char)("铖遶䇣ᮓ賉帡䨎㎤△".toCharArray()[0] ^ 0x470C);
      if (ᐝᵣ$ﾞﾇ.j("铖遶䇣ᮓ賉帡䨎㎤△".toCharArray(), (short)17537, 3, (short)0).indexOf(paramChar) == -1) {
        "࿄ᨈﳢ?늱ᡳ㦘艎퓙㵐卩䈅鰯?깨譝仉떻꿰㣩쐏輪Ꚃﭓ᝵葷詽?䛣䳱硛꫒瑖ῒ?땜鯎ग謔π".toCharArray()[4] = (char)("࿄ᨈﳢ?늱ᡳ㦘艎퓙㵐卩䈅鰯?깨譝仉떻꿰㣩쐏輪Ꚃﭓ᝵葷詽?䛣䳱硛꫒瑖ῒ?땜鯎ग謔π".toCharArray()[4] ^ 0x1345);
        throw new IllegalArgumentException(ᐝᵣ$ﾞﾇ.j("࿄ᨈﳢ?늱ᡳ㦘艎퓙㵐卩䈅鰯?깨譝仉떻꿰㣩쐏輪Ꚃﭓ᝵葷詽?䛣䳱硛꫒瑖ῒ?땜鯎ग謔π".toCharArray(), (short)15479, 5, (short)2));
      } 
    } 
    this.ᐨẏ = (ـᘢ)ﾞᐦ.ˍɫ;
    if (this.ᐨẏ != null)
      this.ᐨẏ.ᐨẏ(paramChar); 
  }
  
  public final void ͺо(String paramString) {
    if (this.ᓱ != 2 || !zubdqvgt.G(this.ᐨẏ, ﾞᐦ.ˊ))
      throw new IllegalStateException(); 
    "䯙ńᡟ᳓갨䎤뺗Ձ停䎡嗞".toCharArray()[9] = (char)("䯙ńᡟ᳓갨䎤뺗Ձ停䎡嗞".toCharArray()[9] ^ 0x5BCB);
    ᴵʖ(paramString, ᐝᵣ$ﾞﾇ.j("䯙ńᡟ᳓갨䎤뺗Ձ停䎡嗞".toCharArray(), (short)8581, 2, (short)2));
    this.ᐨẏ = (ـᘢ)ﾞᐦ.ˍɫ;
    if (this.ᐨẏ != null)
      this.ᐨẏ.ͺо(paramString); 
  }
  
  public final ـᘢ ᐨẏ() {
    if (this.ᓱ != 2 || !zubdqvgt.G(this.ᐨẏ, ﾞᐦ.ˊ))
      throw new IllegalStateException(); 
    this.ᐨẏ = (ـᘢ)ﾞᐦ.ˍɫ;
    return new ᴵἴ(2, (this.ᐨẏ == null) ? null : this.ᐨẏ.ᐨẏ());
  }
  
  public final void ʾܪ(String paramString) {
    if (this.ᓱ != 2 || !zubdqvgt.G(this.ᐨẏ, ﾞᐦ.ˊ))
      throw new IllegalStateException(); 
    "ꏍ쥔悑⑐뵐ｍ㱰⿋䲃崩缎".toCharArray()[7] = (char)("ꏍ쥔悑⑐뵐ｍ㱰⿋䲃崩缎".toCharArray()[7] ^ 0x1DF9);
    ˊ(paramString, ˍɫ$יς.J("ꏍ쥔悑⑐뵐ｍ㱰⿋䲃崩缎".toCharArray(), (short)10667, (short)3, (byte)1));
    this.ᐨẏ = (ـᘢ)ﾞᐦ.ʽ;
    if (this.ᐨẏ != null)
      this.ᐨẏ.ʾܪ(paramString); 
  }
  
  public final void ᐨم(String paramString) {
    if (!zubdqvgt.G(this.ᐨẏ, ﾞᐦ.ʽ))
      throw new IllegalStateException(); 
    "ꈍ쉝ࠄ듡萓虥뉭?ꂿ䮫麌쟝戺ﰾ溿沛".toCharArray()[13] = (char)("ꈍ쉝ࠄ듡萓虥뉭?ꂿ䮫麌쟝戺ﰾ溿沛".toCharArray()[13] ^ 0x558A);
    ᴵʖ(paramString, ˉﻤ$ͺſ.v("ꈍ쉝ࠄ듡萓虥뉭?ꂿ䮫麌쟝戺ﰾ溿沛".toCharArray(), (short)18995, 5, (short)5));
    if (this.ᐨẏ != null)
      this.ᐨẏ.ᐨم(paramString); 
  }
  
  public final void ʹл() {
    if (!zubdqvgt.G(this.ᐨẏ, ﾞᐦ.ʽ))
      throw new IllegalStateException(); 
    if (this.ᐨẏ != null)
      this.ᐨẏ.ʹл(); 
  }
  
  public final ـᘢ ᐨẏ(char paramChar) {
    if (!zubdqvgt.G(this.ᐨẏ, ﾞᐦ.ʽ))
      throw new IllegalStateException(); 
    "䔔摤".toCharArray()[0] = (char)("䔔摤".toCharArray()[0] ^ 0x5665);
    if (ᐨẏ$ᐝт.W("䔔摤".toCharArray(), (short)24441, (byte)1, (short)5).indexOf(paramChar) == -1) {
      "ᡃ䮏爬疥˻य़᜔垘ᤱꑕ䊬삯䣚誔뛩蝄퍪ⷃ鶜঻鸺韵Ⅽ簹菟䁪共".toCharArray()[5] = (char)("ᡃ䮏爬疥˻य़᜔垘ᤱꑕ䊬삯䣚誔뛩蝄퍪ⷃ鶜঻鸺韵Ⅽ簹菟䁪共".toCharArray()[5] ^ 0x6B83);
      throw new IllegalArgumentException(ᐨẏ$ᐝт.W("ᡃ䮏爬疥˻य़᜔垘ᤱꑕ䊬삯䣚誔뛩蝄퍪ⷃ鶜঻鸺韵Ⅽ簹菟䁪共".toCharArray(), (short)23143, (byte)3, (short)2));
    } 
    return new ᴵἴ(2, (this.ᐨẏ == null) ? null : this.ᐨẏ.ᐨẏ(paramChar));
  }
  
  public final void ᐨẏ() {
    if (!zubdqvgt.G(this.ᐨẏ, ﾞᐦ.ʽ))
      throw new IllegalStateException(); 
    this.ᐨẏ = (ـᘢ)ﾞᐦ.ʾܪ;
    if (this.ᐨẏ != null)
      this.ᐨẏ.ᐨẏ(); 
  }
  
  private static void ˊ(String paramString1, String paramString2) {
    if (paramString1 == null || paramString1.length() == 0) {
      "벒긜핻ᆅ㽉䀆潼ሕ".toCharArray()[5] = (char)("벒긜핻ᆅ㽉䀆潼ሕ".toCharArray()[5] ^ 0x2B17);
      "⾙쬪풳뎌ᠸ⋊⡝낃፮⓹ⵢ旀륭캹燶䕬兆뀁饳呓?ၲ뿓핵嚓╎펜䶄".toCharArray()[20] = (char)("⾙쬪풳뎌ᠸ⋊⡝낃፮⓹ⵢ旀륭캹燶䕬兆뀁饳呓?ၲ뿓핵嚓╎펜䶄".toCharArray()[20] ^ 0x4111);
      throw new IllegalArgumentException(ˍɫ$יς.J("벒긜핻ᆅ㽉䀆潼ሕ".toCharArray(), (short)21462, (short)0, (byte)4).intern() + paramString2 + ˍɫ$יς.J("⾙쬪풳뎌ᠸ⋊⡝낃፮⓹ⵢ旀륭캹燶䕬兆뀁饳呓?ၲ뿓핵嚓╎펜䶄".toCharArray(), (short)26883, (short)4, (byte)4));
    } 
    for (byte b = 0; b < paramString1.length(); b++) {
      "䍚䶈밣鑑됴疟".toCharArray()[2] = (char)("䍚䶈밣鑑됴疟".toCharArray()[2] ^ 0x7EE9);
      if (ˍɫ$יς.J("䍚䶈밣鑑됴疟".toCharArray(), (short)30092, (short)2, (byte)5).indexOf(paramString1.charAt(b)) != -1) {
        "覬䑡깆␝觱꛺쟩撕燫".toCharArray()[0] = (char)("覬䑡깆␝觱꛺쟩撕燫".toCharArray()[0] ^ 0x5777);
        "쫙羹?嶺◚瞮㠐餺蓜㞘ỡ硐ᆠ멀㴒㬭⡍䈡ꢻଢ଼隃╯豐鯥ﰁ섈鮮䋧⨼⥺䇗뻉ʩ㒜".toCharArray()[33] = (char)("쫙羹?嶺◚瞮㠐餺蓜㞘ỡ硐ᆠ멀㴒㬭⡍䈡ꢻଢ଼隃╯豐鯥ﰁ섈鮮䋧⨼⥺䇗뻉ʩ㒜".toCharArray()[33] ^ 0x1D44);
        throw new IllegalArgumentException(ˍɫ$יς.J("覬䑡깆␝觱꛺쟩撕燫".toCharArray(), (short)8251, (short)5, (byte)2).intern() + paramString2 + ˍɫ$יς.J("쫙羹?嶺◚瞮㠐餺蓜㞘ỡ硐ᆠ멀㴒㬭⡍䈡ꢻଢ଼隃╯豐鯥ﰁ섈鮮䋧⨼⥺䇗뻉ʩ㒜".toCharArray(), (short)5660, (short)2, (byte)3) + paramString1);
      } 
    } 
  }
  
  private static void ᴵʖ(String paramString1, String paramString2) {
    if (paramString1 == null || paramString1.length() == 0) {
      "퇶䃡︛斺ﻈ㛊⺛".toCharArray()[3] = (char)("퇶䃡︛斺ﻈ㛊⺛".toCharArray()[3] ^ 0x3185);
      "쾵鋎⧊?뙢⫖్匼渮ꈱᩍ耱䝝퓣∉徟鴘꛺棍⩬굃霗Ｓ沲".toCharArray()[17] = (char)("쾵鋎⧊?뙢⫖్匼渮ꈱᩍ耱䝝퓣∉徟鴘꛺棍⩬굃霗Ｓ沲".toCharArray()[17] ^ 0xCFE);
      throw new IllegalArgumentException(ˍɫ$יς.J("퇶䃡︛斺ﻈ㛊⺛".toCharArray(), (short)7931, (short)4, (byte)4).intern() + paramString2 + ˍɫ$יς.J("쾵鋎⧊?뙢⫖్匼渮ꈱᩍ耱䝝퓣∉徟鴘꛺棍⩬굃霗Ｓ沲".toCharArray(), (short)5171, (short)1, (byte)5));
    } 
    for (byte b = 0; b < paramString1.length(); b++) {
      "擽毱鷩曢娡鈛皽֜".toCharArray()[1] = (char)("擽毱鷩曢娡鈛皽֜".toCharArray()[1] ^ 0x6347);
      if (ˍɫ$יς.J("擽毱鷩曢娡鈛皽֜".toCharArray(), (short)5814, (short)0, (byte)2).indexOf(paramString1.charAt(b)) != -1) {
        "휻㟿棿䅤ꍬ汏긣舟⏚".toCharArray()[2] = (char)("휻㟿棿䅤ꍬ汏긣舟⏚".toCharArray()[2] ^ 0x64D0);
        "䋹궴?貙졃䛂怀䟗틮㾵馒誶ﾒⅥ굎顟ន靐䬰〬斲Ҿꖟ䦊࢛ᯯߒ潿鑨Ĺ띚⦔丬".toCharArray()[8] = (char)("䋹궴?貙졃䛂怀䟗틮㾵馒誶ﾒⅥ굎顟ន靐䬰〬斲Ҿꖟ䦊࢛ᯯߒ潿鑨Ĺ띚⦔丬".toCharArray()[8] ^ 0x7BFC);
        throw new IllegalArgumentException(ˍɫ$יς.J("휻㟿棿䅤ꍬ汏긣舟⏚".toCharArray(), (short)16977, (short)0, (byte)1).intern() + paramString2 + ˍɫ$יς.J("䋹궴?貙졃䛂怀䟗틮㾵馒誶ﾒⅥ굎顟ន靐䬰〬斲Ҿꖟ䦊࢛ᯯߒ潿鑨Ĺ띚⦔丬".toCharArray(), (short)25678, (short)2, (byte)1) + paramString1);
      } 
    } 
  }
  
  static {
    ᐨẏ = EnumSet.of(ﾞᐦ.ˊ, ﾞᐦ.ᴵʖ, ﾞᐦ.ﾞл);
    ˊ = EnumSet.of(ﾞᐦ.ᴵʖ);
    ᴵʖ = EnumSet.of(ﾞᐦ.ᴵʖ, ﾞᐦ.ﾞл);
    ﾞл = EnumSet.of(ﾞᐦ.ˊ, ﾞᐦ.ᴵʖ, ﾞᐦ.ﾞл);
    ʿᵉ = EnumSet.of(ﾞᐦ.ʿᵉ);
    ʹﮃ = EnumSet.of(ﾞᐦ.ˊ, ﾞᐦ.ᴵʖ, ﾞᐦ.ﾞл, ﾞᐦ.ʹﮃ);
    ՙᗮ = EnumSet.of(ﾞᐦ.ˊ, ﾞᐦ.ᴵʖ, ﾞᐦ.ﾞл, ﾞᐦ.ʹﮃ);
    ˍɫ = EnumSet.of(ﾞᐦ.ՙᗮ);
  }
  
  static {
    "갇歰䑤ꔙ࿙쩮ᩨꉯ嵅".toCharArray()[6] = (char)("갇歰䑤ꔙ࿙쩮ᩨꉯ嵅".toCharArray()[6] ^ 0xD78);
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ᴵἴ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */