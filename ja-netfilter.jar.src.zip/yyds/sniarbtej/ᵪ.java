package yyds.sniarbtej;

import java.util.concurrent.ConcurrentSkipListMap;

final class ᵪ implements ʿн<T> {
  ᵪ(ˍʶ paramˍʶ) {}
  
  public final T ʿᵉ() {
    return (T)new ConcurrentSkipListMap<>();
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ᵪ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */