package yyds.sniarbtej;

public interface ʻἲ {
  boolean ՙᗮ();
  
  boolean ˍɫ();
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ʻἲ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */