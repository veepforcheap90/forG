package yyds.sniarbtej;

import ylt.pmn.zubdqvgt;

public final class ڊ extends ᐧｴ {
  public static final ڊ ᐨẏ = new ڊ();
  
  private static ڊ ˊ() {
    return ᐨẏ;
  }
  
  public final int hashCode() {
    return ڊ.class.hashCode();
  }
  
  public final boolean equals(Object paramObject) {
    return (zubdqvgt.G(this, paramObject) || paramObject instanceof ڊ);
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ڊ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */