package yyds.sniarbtej;

public final class ﭠ extends ʼᵖ {
  private ᐨᘂ ᐨẏ;
  
  private ﭠ(ᐨᘂ paramᐨᘂ) {
    this(null, paramᐨᘂ);
  }
  
  public ﭠ(ʼᵖ paramʼᵖ, ᐨᘂ paramᐨᘂ) {
    super(589824, paramʼᵖ);
    this.ᐨẏ = paramᐨᘂ;
  }
  
  public final ᐨẏ ᐨẏ(String paramString, boolean paramBoolean) {
    ᐨᘂ ᐨᘂ1 = this.ᐨẏ.ᴵʖ(paramString, paramBoolean);
    return new ιๅ(super.ᐨẏ(paramString, paramBoolean), ᐨᘂ1);
  }
  
  public final ᐨẏ ᐨẏ(int paramInt, ˏɪ paramˏɪ, String paramString, boolean paramBoolean) {
    ᐨᘂ ᐨᘂ1 = this.ᐨẏ.ʿᵉ(paramInt, paramˏɪ, paramString, paramBoolean);
    return new ιๅ(super.ᐨẏ(paramInt, paramˏɪ, paramString, paramBoolean), ᐨᘂ1);
  }
  
  public final void ᴵʖ(ᴵʖ paramᴵʖ) {
    this.ᐨẏ.ʿᵉ(paramᴵʖ);
    super.ᴵʖ(paramᴵʖ);
  }
  
  public final void ᐨẏ() {
    this.ᐨẏ.ᐧṙ();
    super.ᐨẏ();
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ﭠ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */