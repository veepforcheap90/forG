package yyds.sniarbtej;

import java.lang.reflect.Method;

final class ſ extends ˋץ {
  ſ(Method paramMethod, Object paramObject) {}
  
  public final <T> T ᐨẏ(Class<T> paramClass) {
    return (T)this.ᐨẏ.invoke(this.ͺо, new Object[] { paramClass });
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ſ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */