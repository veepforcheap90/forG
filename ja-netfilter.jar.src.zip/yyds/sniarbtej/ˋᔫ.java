package yyds.sniarbtej;

import ylt.pmn.zubdqvgt;

final class ˋᔫ implements ˌ々 {
  public final <T> ٴۉ<T> ᐨẏ(ˑĴ paramˑĴ, ʸ<T> paramʸ) {
    ʸ<T> ʸ1;
    Class<? super T> clazz = (ʸ1 = paramʸ).ᐨم;
    if (!Enum.class.isAssignableFrom(clazz) || zubdqvgt.G(clazz, Enum.class))
      return null; 
    if (!clazz.isEnum())
      clazz = clazz.getSuperclass(); 
    return new ՙʜ<>(clazz);
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ˋᔫ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */