package yyds.sniarbtej;

public abstract class ʼᵖ {
  protected final int ᐨẏ;
  
  protected ʼᵖ ᐨẏ;
  
  public ʼᵖ(int paramInt) {
    this(paramInt, null);
  }
  
  public ʼᵖ(int paramInt, ʼᵖ paramʼᵖ) {
    if (paramInt != 589824 && paramInt != 524288 && paramInt != 458752 && paramInt != 393216 && paramInt != 327680 && paramInt != 262144 && paramInt != 17432576) {
      "?嶚ࣝ➸븛嗜௣?峈욼럝萆ꛬ?᱃".toCharArray()[10] = (char)("?嶚ࣝ➸븛嗜௣?峈욼럝萆ꛬ?᱃".toCharArray()[10] ^ 0xB41);
      throw new IllegalArgumentException(ᐝᵣ$ﾞﾇ.j("?嶚ࣝ➸븛嗜௣?峈욼럝萆ꛬ?᱃".toCharArray(), (short)5975, 3, (short)4) + paramInt);
    } 
    if (paramInt == 17432576)
      ᐨم.ᐨẏ(this); 
    this.ᐨẏ = paramInt;
    this.ᐨẏ = paramʼᵖ;
  }
  
  private ʼᵖ ᐨẏ() {
    return this.ᐨẏ;
  }
  
  public ᐨẏ ᐨẏ(String paramString, boolean paramBoolean) {
    return (this.ᐨẏ != null) ? this.ᐨẏ.ᐨẏ(paramString, paramBoolean) : null;
  }
  
  public ᐨẏ ᐨẏ(int paramInt, ˏɪ paramˏɪ, String paramString, boolean paramBoolean) {
    return (this.ᐨẏ != null) ? this.ᐨẏ.ᐨẏ(paramInt, paramˏɪ, paramString, paramBoolean) : null;
  }
  
  public void ᴵʖ(ᴵʖ paramᴵʖ) {
    if (this.ᐨẏ != null)
      this.ᐨẏ.ᴵʖ(paramᴵʖ); 
  }
  
  public void ᐨẏ() {
    if (this.ᐨẏ != null)
      this.ᐨẏ.ᐨẏ(); 
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ʼᵖ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */