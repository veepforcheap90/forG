package yyds.sniarbtej;

import ylt.pmn.zubdqvgt;

class ˍ {
  private static int ן = 0;
  
  private static int ʻب = 64;
  
  private static int ʼҭ = 128;
  
  private static int ͺᖽ = 247;
  
  private static int ˉʭ = 248;
  
  private static int ˊں = 251;
  
  private static int ٴǐ = 252;
  
  private static int ˋن = 255;
  
  private static int ـｊ = 0;
  
  private static int ՙᕆ = 1;
  
  private static int ﾞˠ = 2;
  
  private static int ـﾚ = 3;
  
  private static int ʋ = 4;
  
  private static int ᴵᒮ = 5;
  
  private static int ʾˤ = 6;
  
  private static int ᴵἴ = 7;
  
  private static int ﾞᐦ = 8;
  
  private static final int ᐨᘂ = 9;
  
  private static final int ძ = 10;
  
  private static final int י丶 = 11;
  
  private static final int ιๅ = 12;
  
  private static final int ʹโ = 6;
  
  private static final int ᐧȑ = 4;
  
  private static final int 丶 = 2;
  
  private static final int ﭔ = 20;
  
  private static final int ﭠ = 26;
  
  private static final int ـᐱ = 22;
  
  private static final int ˌᴉ = 20;
  
  private static final int ʻἲ = -67108864;
  
  private static final int ˊо = 62914560;
  
  private static final int ﾞɫ = 1048575;
  
  private static final int ˍぃ = 67108864;
  
  private static final int ʾﮣ = -67108864;
  
  private static final int ˈᒋ = 4194304;
  
  private static final int ʻᓻ = 8388608;
  
  private static final int ٴᒻ = 12582912;
  
  private static final int ˌэ = 16777216;
  
  private static final int ˑĴ = 20971520;
  
  private static final int ʹΐ = 25165824;
  
  private static final int ᐧϟ = 1048576;
  
  private static final int ʼᔮ = 4194304;
  
  private static final int ιʲ = 4194313;
  
  private static final int ʳ = 4194314;
  
  private static final int ˑЇ = 4194315;
  
  private static final int Ӵ = 4194316;
  
  private static final int ˍﺜ = 4194305;
  
  private static final int ܝ = 4194306;
  
  private static final int ᐝэ = 4194308;
  
  private static final int ˋℷ = 4194307;
  
  private static final int ـﾗ = 4194309;
  
  private static final int ˊᴄ = 4194310;
  
  private ᔪ ˊ;
  
  private int[] ʿᵉ;
  
  private int[] ʹﮃ;
  
  private int[] ՙᗮ;
  
  private int[] ˍɫ;
  
  private short ᐨẏ;
  
  private short ˊ;
  
  private int ᐧｴ;
  
  private int[] ʽ;
  
  ˍ(ᔪ paramᔪ) {
    this.ˊ = paramᔪ;
  }
  
  final void ᐨẏ(ˍ paramˍ) {
    this.ʿᵉ = paramˍ.ʿᵉ;
    this.ʹﮃ = paramˍ.ʹﮃ;
    this.ᐨẏ = 0;
    this.ՙᗮ = paramˍ.ՙᗮ;
    this.ˍɫ = paramˍ.ˍɫ;
    this.ˊ = paramˍ.ˊ;
    this.ᐧｴ = paramˍ.ᐧｴ;
    this.ʽ = paramˍ.ʽ;
  }
  
  static int ᐨẏ(ˌх paramˌх, Object paramObject) {
    // Byte code:
    //   0: aload_1
    //   1: instanceof java/lang/Integer
    //   4: ifeq -> 18
    //   7: ldc 4194304
    //   9: aload_1
    //   10: checkcast java/lang/Integer
    //   13: invokevirtual intValue : ()I
    //   16: ior
    //   17: ireturn
    //   18: aload_1
    //   19: instanceof java/lang/String
    //   22: ifeq -> 43
    //   25: aload_1
    //   26: checkcast java/lang/String
    //   29: invokestatic ˊ : (Ljava/lang/String;)Lyyds/sniarbtej/ˑܘ;
    //   32: invokevirtual ᴵʖ : ()Ljava/lang/String;
    //   35: astore_1
    //   36: aload_0
    //   37: aload_1
    //   38: iconst_0
    //   39: invokestatic ᐨẏ : (Lyyds/sniarbtej/ˌх;Ljava/lang/String;I)I
    //   42: ireturn
    //   43: aload_1
    //   44: checkcast yyds/sniarbtej/ᔪ
    //   47: dup
    //   48: astore_1
    //   49: getfield ᴵʖ : S
    //   52: iconst_4
    //   53: iand
    //   54: ifeq -> 71
    //   57: ldc 12582912
    //   59: aload_0
    //   60: ldc ''
    //   62: aload_1
    //   63: getfield ʻบ : I
    //   66: invokevirtual ᐨẏ : (Ljava/lang/String;I)I
    //   69: ior
    //   70: ireturn
    //   71: ldc 16777216
    //   73: aload_0
    //   74: ldc ''
    //   76: aload_1
    //   77: astore_2
    //   78: astore_1
    //   79: dup
    //   80: astore_0
    //   81: aload_2
    //   82: astore_3
    //   83: dup
    //   84: astore_2
    //   85: getfield ˊ : [Lyyds/sniarbtej/ʻւ;
    //   88: ifnonnull -> 109
    //   91: aload_2
    //   92: bipush #16
    //   94: anewarray yyds/sniarbtej/ʻւ
    //   97: putfield ˊ : [Lyyds/sniarbtej/ʻւ;
    //   100: aload_2
    //   101: bipush #16
    //   103: anewarray yyds/sniarbtej/ʻւ
    //   106: putfield ᐨẏ : [Lyyds/sniarbtej/ʻւ;
    //   109: aload_3
    //   110: invokestatic identityHashCode : (Ljava/lang/Object;)I
    //   113: istore #4
    //   115: iload #4
    //   117: aload_2
    //   118: getfield ˊ : [Lyyds/sniarbtej/ʻւ;
    //   121: dup_x1
    //   122: arraylength
    //   123: irem
    //   124: aaload
    //   125: astore #5
    //   127: aload #5
    //   129: ifnull -> 154
    //   132: aload #5
    //   134: getfield ʾ : Lyyds/sniarbtej/ᔪ;
    //   137: aload_3
    //   138: invokestatic G : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   141: ifne -> 154
    //   144: aload #5
    //   146: getfield ᐨẏ : Lyyds/sniarbtej/ʻւ;
    //   149: astore #5
    //   151: goto -> 127
    //   154: aload #5
    //   156: ifnull -> 164
    //   159: aload #5
    //   161: goto -> 392
    //   164: aload_2
    //   165: getfield ˉﮞ : I
    //   168: aload_2
    //   169: getfield ˊ : [Lyyds/sniarbtej/ʻւ;
    //   172: arraylength
    //   173: iconst_3
    //   174: imul
    //   175: iconst_4
    //   176: idiv
    //   177: if_icmple -> 281
    //   180: aload_2
    //   181: getfield ˊ : [Lyyds/sniarbtej/ʻւ;
    //   184: arraylength
    //   185: dup
    //   186: istore #6
    //   188: iconst_1
    //   189: ishl
    //   190: iconst_1
    //   191: iadd
    //   192: dup
    //   193: istore #5
    //   195: anewarray yyds/sniarbtej/ʻւ
    //   198: astore #7
    //   200: iload #6
    //   202: iconst_1
    //   203: isub
    //   204: istore #6
    //   206: iload #6
    //   208: iflt -> 275
    //   211: aload_2
    //   212: getfield ˊ : [Lyyds/sniarbtej/ʻւ;
    //   215: iload #6
    //   217: aaload
    //   218: astore #8
    //   220: aload #8
    //   222: ifnull -> 269
    //   225: aload #8
    //   227: getfield ʾ : Lyyds/sniarbtej/ᔪ;
    //   230: invokestatic identityHashCode : (Ljava/lang/Object;)I
    //   233: iload #5
    //   235: irem
    //   236: istore #9
    //   238: aload #8
    //   240: getfield ᐨẏ : Lyyds/sniarbtej/ʻւ;
    //   243: astore #10
    //   245: aload #8
    //   247: aload #7
    //   249: iload #9
    //   251: aaload
    //   252: putfield ᐨẏ : Lyyds/sniarbtej/ʻւ;
    //   255: aload #7
    //   257: iload #9
    //   259: aload #8
    //   261: aastore
    //   262: aload #10
    //   264: astore #8
    //   266: goto -> 220
    //   269: iinc #6, -1
    //   272: goto -> 206
    //   275: aload_2
    //   276: aload #7
    //   278: putfield ˊ : [Lyyds/sniarbtej/ʻւ;
    //   281: aload_2
    //   282: getfield ˉﮞ : I
    //   285: aload_2
    //   286: getfield ᐨẏ : [Lyyds/sniarbtej/ʻւ;
    //   289: arraylength
    //   290: if_icmpne -> 327
    //   293: iconst_2
    //   294: aload_2
    //   295: getfield ᐨẏ : [Lyyds/sniarbtej/ʻւ;
    //   298: arraylength
    //   299: imul
    //   300: anewarray yyds/sniarbtej/ʻւ
    //   303: astore #6
    //   305: aload_2
    //   306: getfield ᐨẏ : [Lyyds/sniarbtej/ʻւ;
    //   309: iconst_0
    //   310: aload #6
    //   312: iconst_0
    //   313: aload_2
    //   314: getfield ᐨẏ : [Lyyds/sniarbtej/ʻւ;
    //   317: arraylength
    //   318: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
    //   321: aload_2
    //   322: aload #6
    //   324: putfield ᐨẏ : [Lyyds/sniarbtej/ʻւ;
    //   327: new yyds/sniarbtej/ʻւ
    //   330: dup
    //   331: aload_2
    //   332: getfield ˉﮞ : I
    //   335: aload_3
    //   336: invokespecial <init> : (ILyyds/sniarbtej/ᔪ;)V
    //   339: astore #5
    //   341: iload #4
    //   343: aload_2
    //   344: getfield ˊ : [Lyyds/sniarbtej/ʻւ;
    //   347: arraylength
    //   348: irem
    //   349: istore #6
    //   351: aload #5
    //   353: aload_2
    //   354: getfield ˊ : [Lyyds/sniarbtej/ʻւ;
    //   357: iload #6
    //   359: aaload
    //   360: putfield ᐨẏ : Lyyds/sniarbtej/ʻւ;
    //   363: aload_2
    //   364: getfield ˊ : [Lyyds/sniarbtej/ʻւ;
    //   367: iload #6
    //   369: aload #5
    //   371: aastore
    //   372: aload_2
    //   373: getfield ᐨẏ : [Lyyds/sniarbtej/ʻւ;
    //   376: aload_2
    //   377: dup
    //   378: getfield ˉﮞ : I
    //   381: dup_x1
    //   382: iconst_1
    //   383: iadd
    //   384: putfield ˉﮞ : I
    //   387: aload #5
    //   389: aastore
    //   390: aload #5
    //   392: getfield ͺᴲ : I
    //   395: istore_2
    //   396: sipush #130
    //   399: aload_1
    //   400: iload_2
    //   401: invokestatic ᐨẏ : (ILjava/lang/String;I)I
    //   404: istore_3
    //   405: aload_0
    //   406: iload_3
    //   407: invokevirtual ᐨẏ : (I)Lyyds/sniarbtej/ιﾌ;
    //   410: astore #4
    //   412: aload #4
    //   414: ifnull -> 478
    //   417: aload #4
    //   419: getfield ᙆ : I
    //   422: sipush #130
    //   425: if_icmpne -> 468
    //   428: aload #4
    //   430: getfield ʹｨ : I
    //   433: iload_3
    //   434: if_icmpne -> 468
    //   437: aload #4
    //   439: getfield ˊ : J
    //   442: iload_2
    //   443: i2l
    //   444: lcmp
    //   445: ifne -> 468
    //   448: aload #4
    //   450: getfield ʹл : Ljava/lang/String;
    //   453: aload_1
    //   454: invokevirtual equals : (Ljava/lang/Object;)Z
    //   457: ifeq -> 468
    //   460: aload #4
    //   462: getfield ͺᴲ : I
    //   465: goto -> 500
    //   468: aload #4
    //   470: getfield ᐨẏ : Lyyds/sniarbtej/ιﾌ;
    //   473: astore #4
    //   475: goto -> 412
    //   478: aload_0
    //   479: new yyds/sniarbtej/ιﾌ
    //   482: dup
    //   483: aload_0
    //   484: getfield ʿᖨ : I
    //   487: sipush #130
    //   490: aload_1
    //   491: iload_2
    //   492: i2l
    //   493: iload_3
    //   494: invokespecial <init> : (IILjava/lang/String;JI)V
    //   497: invokevirtual ᐨẏ : (Lyyds/sniarbtej/ιﾌ;)I
    //   500: ior
    //   501: ireturn
  }
  
  static int ᐨẏ(ˌх paramˌх, String paramString) {
    return 0x800000 | paramˌх.ˍɫ(paramString);
  }
  
  private static int ᐨẏ(ˌх paramˌх, String paramString, int paramInt) {
    // Byte code:
    //   0: aload_1
    //   1: iload_2
    //   2: invokevirtual charAt : (I)C
    //   5: tableswitch default -> 434, 66 -> 126, 67 -> 126, 68 -> 135, 69 -> 434, 70 -> 129, 71 -> 434, 72 -> 434, 73 -> 126, 74 -> 132, 75 -> 434, 76 -> 138, 77 -> 434, 78 -> 434, 79 -> 434, 80 -> 434, 81 -> 434, 82 -> 434, 83 -> 126, 84 -> 434, 85 -> 434, 86 -> 124, 87 -> 434, 88 -> 434, 89 -> 434, 90 -> 126, 91 -> 161
    //   124: iconst_0
    //   125: ireturn
    //   126: ldc 4194305
    //   128: ireturn
    //   129: ldc 4194306
    //   131: ireturn
    //   132: ldc 4194308
    //   134: ireturn
    //   135: ldc 4194307
    //   137: ireturn
    //   138: aload_1
    //   139: iload_2
    //   140: iconst_1
    //   141: iadd
    //   142: aload_1
    //   143: invokevirtual length : ()I
    //   146: iconst_1
    //   147: isub
    //   148: invokevirtual substring : (II)Ljava/lang/String;
    //   151: astore_1
    //   152: ldc 8388608
    //   154: aload_0
    //   155: aload_1
    //   156: invokevirtual ˍɫ : (Ljava/lang/String;)I
    //   159: ior
    //   160: ireturn
    //   161: iload_2
    //   162: iconst_1
    //   163: iadd
    //   164: istore_3
    //   165: aload_1
    //   166: iload_3
    //   167: invokevirtual charAt : (I)C
    //   170: bipush #91
    //   172: if_icmpne -> 181
    //   175: iinc #3, 1
    //   178: goto -> 165
    //   181: aload_1
    //   182: iload_3
    //   183: invokevirtual charAt : (I)C
    //   186: tableswitch default -> 374, 66 -> 312, 67 -> 306, 68 -> 342, 69 -> 374, 70 -> 330, 71 -> 374, 72 -> 374, 73 -> 324, 74 -> 336, 75 -> 374, 76 -> 348, 77 -> 374, 78 -> 374, 79 -> 374, 80 -> 374, 81 -> 374, 82 -> 374, 83 -> 318, 84 -> 374, 85 -> 374, 86 -> 374, 87 -> 374, 88 -> 374, 89 -> 374, 90 -> 300
    //   300: ldc 4194313
    //   302: istore_0
    //   303: goto -> 425
    //   306: ldc 4194315
    //   308: istore_0
    //   309: goto -> 425
    //   312: ldc 4194314
    //   314: istore_0
    //   315: goto -> 425
    //   318: ldc 4194316
    //   320: istore_0
    //   321: goto -> 425
    //   324: ldc 4194305
    //   326: istore_0
    //   327: goto -> 425
    //   330: ldc 4194306
    //   332: istore_0
    //   333: goto -> 425
    //   336: ldc 4194308
    //   338: istore_0
    //   339: goto -> 425
    //   342: ldc 4194307
    //   344: istore_0
    //   345: goto -> 425
    //   348: aload_1
    //   349: iload_3
    //   350: iconst_1
    //   351: iadd
    //   352: aload_1
    //   353: invokevirtual length : ()I
    //   356: iconst_1
    //   357: isub
    //   358: invokevirtual substring : (II)Ljava/lang/String;
    //   361: astore_1
    //   362: ldc 8388608
    //   364: aload_0
    //   365: aload_1
    //   366: invokevirtual ˍɫ : (Ljava/lang/String;)I
    //   369: ior
    //   370: istore_0
    //   371: goto -> 425
    //   374: new java/lang/IllegalArgumentException
    //   377: dup
    //   378: new java/lang/StringBuilder
    //   381: dup
    //   382: ldc_w 'ꎌひⲩ뛴?腉迲ᄻ薫?෪⅔켠ॷ협祲㳲䊿?揿낵?㘆ฆ헳হ'
    //   385: invokevirtual toCharArray : ()[C
    //   388: dup
    //   389: dup
    //   390: iconst_3
    //   391: dup_x1
    //   392: caload
    //   393: sipush #19597
    //   396: ixor
    //   397: i2c
    //   398: castore
    //   399: sipush #147
    //   402: iconst_5
    //   403: iconst_4
    //   404: invokestatic j : (Ljava/lang/Object;SIS)Ljava/lang/String;
    //   407: invokespecial <init> : (Ljava/lang/String;)V
    //   410: aload_1
    //   411: iload_3
    //   412: invokevirtual substring : (I)Ljava/lang/String;
    //   415: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   418: invokevirtual toString : ()Ljava/lang/String;
    //   421: invokespecial <init> : (Ljava/lang/String;)V
    //   424: athrow
    //   425: iload_3
    //   426: iload_2
    //   427: isub
    //   428: bipush #26
    //   430: ishl
    //   431: iload_0
    //   432: ior
    //   433: ireturn
    //   434: new java/lang/IllegalArgumentException
    //   437: dup
    //   438: new java/lang/StringBuilder
    //   441: dup
    //   442: ldc_w '⟏头黁Ẃốꃞ選㽳轚贈驲૽??烙늌㺱'
    //   445: invokevirtual toCharArray : ()[C
    //   448: dup
    //   449: dup
    //   450: bipush #19
    //   452: dup_x1
    //   453: caload
    //   454: sipush #14841
    //   457: ixor
    //   458: i2c
    //   459: castore
    //   460: sipush #209
    //   463: iconst_4
    //   464: iconst_4
    //   465: invokestatic j : (Ljava/lang/Object;SIS)Ljava/lang/String;
    //   468: invokespecial <init> : (Ljava/lang/String;)V
    //   471: aload_1
    //   472: iload_2
    //   473: invokevirtual substring : (I)Ljava/lang/String;
    //   476: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   479: invokevirtual toString : ()Ljava/lang/String;
    //   482: invokespecial <init> : (Ljava/lang/String;)V
    //   485: athrow
  }
  
  final void ᐨẏ(ˌх paramˌх, int paramInt1, String paramString, int paramInt2) {
    this.ʿᵉ = new int[paramInt2];
    this.ʹﮃ = new int[0];
    byte b1 = 0;
    if ((paramInt1 & 0x8) == 0)
      if ((paramInt1 & 0x40000) == 0) {
        b1++;
        ˌх ˌх1;
        this.ʿᵉ[0] = 0x800000 | paramˌх.ˍɫ((String)(ˌх1 = paramˌх).ˊ);
      } else {
        b1++;
        this.ʿᵉ[0] = 4194310;
      }  
    ˑܘ[] arrayOfˑܘ;
    int i = (arrayOfˑܘ = ˑܘ.ᐨẏ(paramString)).length;
    for (byte b2 = 0; b2 < i; b2++) {
      ˑܘ ˑܘ = arrayOfˑܘ[b2];
      int j = ᐨẏ(paramˌх, ˑܘ.ᴵʖ(), 0);
      this.ʿᵉ[b1++] = j;
      if (j == 4194308 || j == 4194307)
        this.ʿᵉ[b1++] = 4194304; 
    } 
    while (b1 < paramInt2)
      this.ʿᵉ[b1++] = 4194304; 
  }
  
  final void ᐨẏ(ˌх paramˌх, int paramInt1, Object[] paramArrayOfObject1, int paramInt2, Object[] paramArrayOfObject2) {
    byte b2 = 0;
    byte b3;
    for (b3 = 0; b3 < paramInt1; b3++) {
      this.ʿᵉ[b2++] = ᐨẏ(paramˌх, paramArrayOfObject1[b3]);
      if (zubdqvgt.G(paramArrayOfObject1[b3], ـﭔ.ʿᵉ) || zubdqvgt.G(paramArrayOfObject1[b3], ـﭔ.ﾞл))
        this.ʿᵉ[b2++] = 4194304; 
    } 
    while (b2 < this.ʿᵉ.length)
      this.ʿᵉ[b2++] = 4194304; 
    b3 = 0;
    for (paramInt1 = 0; paramInt1 < paramInt2; paramInt1++) {
      if (zubdqvgt.G(paramArrayOfObject2[paramInt1], ـﭔ.ʿᵉ) || zubdqvgt.G(paramArrayOfObject2[paramInt1], ـﭔ.ﾞл))
        b3++; 
    } 
    this.ʹﮃ = new int[paramInt2 + b3];
    paramInt1 = 0;
    for (byte b1 = 0; b1 < paramInt2; b1++) {
      this.ʹﮃ[paramInt1++] = ᐨẏ(paramˌх, paramArrayOfObject2[b1]);
      if (zubdqvgt.G(paramArrayOfObject2[b1], ـﭔ.ʿᵉ) || zubdqvgt.G(paramArrayOfObject2[b1], ـﭔ.ﾞл))
        this.ʹﮃ[paramInt1++] = 4194304; 
    } 
    this.ˊ = 0;
    this.ᐧｴ = 0;
  }
  
  final int ʾܪ() {
    return this.ʹﮃ.length;
  }
  
  private int ʿᵉ(int paramInt) {
    if (this.ՙᗮ == null || paramInt >= this.ՙᗮ.length)
      return 0x1400000 | paramInt; 
    int i;
    if ((i = this.ՙᗮ[paramInt]) == 0)
      i = this.ՙᗮ[paramInt] = 0x1400000 | paramInt; 
    return i;
  }
  
  private void ᐨẏ(int paramInt1, int paramInt2) {
    if (this.ՙᗮ == null)
      this.ՙᗮ = new int[10]; 
    int i = this.ՙᗮ.length;
    if (paramInt1 >= i) {
      int[] arrayOfInt = new int[Math.max(paramInt1 + 1, 2 * i)];
      System.arraycopy(this.ՙᗮ, 0, arrayOfInt, 0, i);
      this.ՙᗮ = arrayOfInt;
    } 
    this.ՙᗮ[paramInt1] = paramInt2;
  }
  
  private void ˊ(int paramInt) {
    if (this.ˍɫ == null)
      this.ˍɫ = new int[10]; 
    int i = this.ˍɫ.length;
    if (this.ˊ >= i) {
      int[] arrayOfInt = new int[Math.max(this.ˊ + 1, 2 * i)];
      System.arraycopy(this.ˍɫ, 0, arrayOfInt, 0, i);
      this.ˍɫ = arrayOfInt;
    } 
    this.ˊ = (short)(this.ˊ + 1);
    this.ˍɫ[this.ˊ] = paramInt;
    short s;
    if ((s = (short)(this.ᐨẏ + this.ˊ)) > this.ˊ.ՙᗮ)
      this.ˊ.ՙᗮ = s; 
  }
  
  private void ᐨẏ(ˌх paramˌх, String paramString) {
    boolean bool = (paramString.charAt(0) == '(') ? ˑܘ.ʽ(paramString) : false;
    int i;
    if ((i = ᐨẏ(paramˌх, paramString, bool)) != 0) {
      ˊ(i);
      if (i == 4194308 || i == 4194307)
        ˊ(4194304); 
    } 
  }
  
  private int ᐨم() {
    return (this.ˊ > 0) ? this.ˍɫ[this.ˊ = (short)(this.ˊ - 1)] : (0x1800000 | -(this.ᐨẏ = (short)(this.ᐨẏ - 1)));
  }
  
  private void ᴵʖ(int paramInt) {
    if (this.ˊ >= paramInt) {
      this.ˊ = (short)(this.ˊ - paramInt);
      return;
    } 
    this.ᐨẏ = (short)(this.ᐨẏ - paramInt - this.ˊ);
    this.ˊ = 0;
  }
  
  private void ﾞл(String paramString) {
    char c;
    if ((c = paramString.charAt(0)) == '(') {
      ᴵʖ((ˑܘ.ᐨم(paramString) >> 2) - 1);
      return;
    } 
    if (c == 'J' || c == 'D') {
      ᴵʖ(2);
      return;
    } 
    ᴵʖ(1);
  }
  
  private void ﾞл(int paramInt) {
    if (this.ʽ == null)
      this.ʽ = new int[2]; 
    int i = this.ʽ.length;
    if (this.ᐧｴ >= i) {
      int[] arrayOfInt = new int[Math.max(this.ᐧｴ + 1, 2 * i)];
      System.arraycopy(this.ʽ, 0, arrayOfInt, 0, i);
      this.ʽ = arrayOfInt;
    } 
    this.ʽ[this.ᐧｴ++] = paramInt;
  }
  
  private int ᐨẏ(ˌх paramˌх, int paramInt) {
    if (paramInt == 4194310 || (paramInt & 0xFFC00000) == 12582912 || (paramInt & 0xFFC00000) == 16777216)
      for (byte b = 0; b < this.ᐧｴ; b++) {
        int i;
        int j = (i = this.ʽ[b]) & 0xFC000000;
        int k = i & 0x3C00000;
        int m = i & 0xFFFFF;
        if (k == 20971520) {
          i = j + this.ʿᵉ[m];
        } else if (k == 25165824) {
          i = j + this.ʹﮃ[this.ʹﮃ.length - m];
        } 
        if (paramInt == i) {
          if (paramInt == 4194310)
            return 0x800000 | paramˌх.ˍɫ((String)(paramˌх = paramˌх).ˊ); 
          paramInt &= 0xFFFFF;
          return 0x800000 | paramˌх.ˍɫ(((ˊᵃ)(paramˌх = paramˌх).ˊ[paramInt]).ʹл);
        } 
      }  
    return paramInt;
  }
  
  void ᐨẏ(int paramInt1, int paramInt2, ˊᵃ paramˊᵃ, ˌх paramˌх) {
    String str;
    int i;
    int j;
    switch (paramInt1) {
      case 0:
      case 116:
      case 117:
      case 118:
      case 119:
      case 145:
      case 146:
      case 147:
      case 167:
      case 177:
        return;
      case 1:
        ˊ(4194309);
        return;
      case 2:
      case 3:
      case 4:
      case 5:
      case 6:
      case 7:
      case 8:
      case 16:
      case 17:
      case 21:
        ˊ(4194305);
        return;
      case 9:
      case 10:
      case 22:
        ˊ(4194308);
        ˊ(4194304);
        return;
      case 11:
      case 12:
      case 13:
      case 23:
        ˊ(4194306);
        return;
      case 14:
      case 15:
      case 24:
        ˊ(4194307);
        ˊ(4194304);
        return;
      case 18:
        switch (paramˊᵃ.ᙆ) {
          case 3:
            ˊ(4194305);
            return;
          case 5:
            ˊ(4194308);
            ˊ(4194304);
            return;
          case 4:
            ˊ(4194306);
            return;
          case 6:
            ˊ(4194307);
            ˊ(4194304);
            return;
          case 7:
            "傫耽곬Ꙡ飞㹖겕䰅ㆵ䜕ꘗ阁冾⤺ዴ䙏".toCharArray()[9] = (char)("傫耽곬Ꙡ飞㹖겕䰅ㆵ䜕ꘗ阁冾⤺ዴ䙏".toCharArray()[9] ^ 0x5FAD);
            ˊ(0x800000 | paramˌх.ˍɫ(ᐝᵣ$ﾞﾇ.j("傫耽곬Ꙡ飞㹖겕䰅ㆵ䜕ꘗ阁冾⤺ዴ䙏".toCharArray(), (short)5719, 0, (short)4)));
            return;
          case 8:
            "ෙ智縟㼾棈觕脕᠝㏭㷭꫷뫠ጫ".toCharArray()[6] = (char)("ෙ智縟㼾棈觕脕᠝㏭㷭꫷뫠ጫ".toCharArray()[6] ^ 0x45B0);
            ˊ(0x800000 | paramˌх.ˍɫ(ᐝᵣ$ﾞﾇ.j("ෙ智縟㼾棈觕脕᠝㏭㷭꫷뫠ጫ".toCharArray(), (short)31429, 0, (short)2)));
            return;
          case 16:
            "쳳㴉័෤쁇ﯭ髎땳蚃ɬ͆?⨇睜僧䗽쇙殺ﮰ⹨娹ᐰꂿ퀟鲳＃惑".toCharArray()[16] = (char)("쳳㴉័෤쁇ﯭ髎땳蚃ɬ͆?⨇睜僧䗽쇙殺ﮰ⹨娹ᐰꂿ퀟鲳＃惑".toCharArray()[16] ^ 0x12BC);
            ˊ(0x800000 | paramˌх.ˍɫ(ᐝᵣ$ﾞﾇ.j("쳳㴉័෤쁇ﯭ髎땳蚃ɬ͆?⨇睜僧䗽쇙殺ﮰ⹨娹ᐰꂿ퀟鲳＃惑".toCharArray(), (short)6263, 5, (short)2)));
            return;
          case 15:
            "䴕ఱ큜鲴ᵙ鱂䡵ꉿ⦀磄Ḑ⍂㠇梙븣真枕䦓楨璘௧놱搴?箥῏".toCharArray()[12] = (char)("䴕ఱ큜鲴ᵙ鱂䡵ꉿ⦀磄Ḑ⍂㠇梙븣真枕䦓楨璘௧놱搴?箥῏".toCharArray()[12] ^ 0x777F);
            ˊ(0x800000 | paramˌх.ˍɫ(ᐝᵣ$ﾞﾇ.j("䴕ఱ큜鲴ᵙ鱂䡵ꉿ⦀磄Ḑ⍂㠇梙븣真枕䦓楨璘௧놱搴?箥῏".toCharArray(), (short)12020, 4, (short)0)));
            return;
          case 17:
            ᐨẏ(paramˌх, paramˊᵃ.ʹл);
            return;
        } 
        throw new AssertionError();
      case 25:
        ˊ(ʿᵉ(paramInt2));
        return;
      case 47:
      case 143:
        ᴵʖ(2);
        ˊ(4194308);
        ˊ(4194304);
        return;
      case 49:
      case 138:
        ᴵʖ(2);
        ˊ(4194307);
        ˊ(4194304);
        return;
      case 50:
        ᴵʖ(1);
        j = ᐨم();
        ˊ((j == 4194309) ? j : (j + -67108864));
        return;
      case 54:
      case 56:
      case 58:
        j = ᐨم();
        ᐨẏ(paramInt2, j);
        if (paramInt2 > 0)
          if ((paramInt1 = ʿᵉ(paramInt2 - 1)) == 4194308 || paramInt1 == 4194307) {
            ᐨẏ(paramInt2 - 1, 4194304);
          } else {
            if ((paramInt1 & 0x3C00000) == 20971520 || (paramInt1 & 0x3C00000) == 25165824)
              ᐨẏ(paramInt2 - 1, paramInt1 | 0x100000); 
            return;
          }  
        return;
      case 55:
      case 57:
        ᴵʖ(1);
        j = ᐨم();
        ᐨẏ(paramInt2, j);
        ᐨẏ(paramInt2 + 1, 4194304);
        if (paramInt2 > 0)
          if ((paramInt1 = ʿᵉ(paramInt2 - 1)) == 4194308 || paramInt1 == 4194307) {
            ᐨẏ(paramInt2 - 1, 4194304);
          } else {
            if ((paramInt1 & 0x3C00000) == 20971520 || (paramInt1 & 0x3C00000) == 25165824)
              ᐨẏ(paramInt2 - 1, paramInt1 | 0x100000); 
            return;
          }  
        return;
      case 79:
      case 81:
      case 83:
      case 84:
      case 85:
      case 86:
        ᴵʖ(3);
        return;
      case 80:
      case 82:
        ᴵʖ(4);
        return;
      case 87:
      case 153:
      case 154:
      case 155:
      case 156:
      case 157:
      case 158:
      case 170:
      case 171:
      case 172:
      case 174:
      case 176:
      case 191:
      case 194:
      case 195:
      case 198:
      case 199:
        ᴵʖ(1);
        return;
      case 88:
      case 159:
      case 160:
      case 161:
      case 162:
      case 163:
      case 164:
      case 165:
      case 166:
      case 173:
      case 175:
        ᴵʖ(2);
        return;
      case 89:
        j = ᐨم();
        ˊ(j);
        ˊ(j);
        return;
      case 90:
        j = ᐨم();
        paramInt1 = ᐨم();
        ˊ(j);
        ˊ(paramInt1);
        ˊ(j);
        return;
      case 91:
        j = ᐨم();
        paramInt1 = ᐨم();
        paramInt2 = ᐨم();
        ˊ(j);
        ˊ(paramInt2);
        ˊ(paramInt1);
        ˊ(j);
        return;
      case 92:
        j = ᐨم();
        paramInt1 = ᐨم();
        ˊ(paramInt1);
        ˊ(j);
        ˊ(paramInt1);
        ˊ(j);
        return;
      case 93:
        j = ᐨم();
        paramInt1 = ᐨم();
        paramInt2 = ᐨم();
        ˊ(paramInt1);
        ˊ(j);
        ˊ(paramInt2);
        ˊ(paramInt1);
        ˊ(j);
        return;
      case 94:
        j = ᐨم();
        paramInt1 = ᐨم();
        paramInt2 = ᐨم();
        i = ᐨم();
        ˊ(paramInt1);
        ˊ(j);
        ˊ(i);
        ˊ(paramInt2);
        ˊ(paramInt1);
        ˊ(j);
        return;
      case 95:
        j = ᐨم();
        paramInt1 = ᐨم();
        ˊ(j);
        ˊ(paramInt1);
        return;
      case 46:
      case 51:
      case 52:
      case 53:
      case 96:
      case 100:
      case 104:
      case 108:
      case 112:
      case 120:
      case 122:
      case 124:
      case 126:
      case 128:
      case 130:
      case 136:
      case 142:
      case 149:
      case 150:
        ᴵʖ(2);
        ˊ(4194305);
        return;
      case 97:
      case 101:
      case 105:
      case 109:
      case 113:
      case 127:
      case 129:
      case 131:
        ᴵʖ(4);
        ˊ(4194308);
        ˊ(4194304);
        return;
      case 48:
      case 98:
      case 102:
      case 106:
      case 110:
      case 114:
      case 137:
      case 144:
        ᴵʖ(2);
        ˊ(4194306);
        return;
      case 99:
      case 103:
      case 107:
      case 111:
      case 115:
        ᴵʖ(4);
        ˊ(4194307);
        ˊ(4194304);
        return;
      case 121:
      case 123:
      case 125:
        ᴵʖ(3);
        ˊ(4194308);
        ˊ(4194304);
        return;
      case 132:
        ᐨẏ(paramInt2, 4194305);
        return;
      case 133:
      case 140:
        ᴵʖ(1);
        ˊ(4194308);
        ˊ(4194304);
        return;
      case 134:
        ᴵʖ(1);
        ˊ(4194306);
        return;
      case 135:
      case 141:
        ᴵʖ(1);
        ˊ(4194307);
        ˊ(4194304);
        return;
      case 139:
      case 190:
      case 193:
        ᴵʖ(1);
        ˊ(4194305);
        return;
      case 148:
      case 151:
      case 152:
        ᴵʖ(4);
        ˊ(4194305);
        return;
      case 168:
      case 169:
        "䕗拷嵫䀑윔⢆ႛ侕Ꮯ杻鲛঳?̼Р?嵔ㅻ퐮㒈ၸ퇼?낢㎺漱먁鶐砱働丩ள径퐮譑挧媭籭䲊윊霐⩠뺿噩平䋿".toCharArray()[38] = (char)("䕗拷嵫䀑윔⢆ႛ侕Ꮯ杻鲛঳?̼Р?嵔ㅻ퐮㒈ၸ퇼?낢㎺漱먁鶐砱働丩ள径퐮譑挧媭籭䲊윊霐⩠뺿噩平䋿".toCharArray()[38] ^ 0x45DD);
        throw new IllegalArgumentException(ᐝᵣ$ﾞﾇ.j("䕗拷嵫䀑윔⢆ႛ侕Ꮯ杻鲛঳?̼Р?嵔ㅻ퐮㒈ၸ퇼?낢㎺漱먁鶐砱働丩ள径퐮譑挧媭籭䲊윊霐⩠뺿噩平䋿".toCharArray(), (short)1593, 1, (short)4));
      case 178:
        ᐨẏ(paramˌх, i.ʹл);
        return;
      case 179:
        ﾞл(i.ʹл);
        return;
      case 180:
        ᴵʖ(1);
        ᐨẏ(paramˌх, i.ʹл);
        return;
      case 181:
        ﾞл(i.ʹл);
        ᐨم();
        return;
      case 182:
      case 183:
      case 184:
      case 185:
        ﾞл(i.ʹл);
        if (paramInt1 != 184) {
          j = ᐨم();
          if (paramInt1 == 183 && i.name.charAt(0) == '<') {
            paramInt2 = j;
            ˍ ˍ1;
            if ((ˍ1 = this).ʽ == null)
              ˍ1.ʽ = new int[2]; 
            j = ˍ1.ʽ.length;
            if (ˍ1.ᐧｴ >= j) {
              int[] arrayOfInt = new int[Math.max(ˍ1.ᐧｴ + 1, 2 * j)];
              System.arraycopy(ˍ1.ʽ, 0, arrayOfInt, 0, j);
              ˍ1.ʽ = arrayOfInt;
            } 
            ˍ1.ʽ[ˍ1.ᐧｴ++] = paramInt2;
          } 
        } 
        ᐨẏ(paramˌх, i.ʹл);
        return;
      case 186:
        ﾞл(i.ʹл);
        ᐨẏ(paramˌх, i.ʹл);
        return;
      case 187:
        ˊ(0xC00000 | paramˌх.ᐨẏ(i.ʹл, paramInt2));
        return;
      case 188:
        ᐨم();
        switch (paramInt2) {
          case 4:
            ˊ(71303177);
            return;
          case 5:
            ˊ(71303179);
            return;
          case 8:
            ˊ(71303178);
            return;
          case 9:
            ˊ(71303180);
            return;
          case 10:
            ˊ(71303169);
            return;
          case 6:
            ˊ(71303170);
            return;
          case 7:
            ˊ(71303171);
            return;
          case 11:
            ˊ(71303172);
            return;
        } 
        throw new IllegalArgumentException();
      case 189:
        str = i.ʹл;
        ᐨم();
        if (str.charAt(0) == '[') {
          "⡁壝".toCharArray()[0] = (char)("⡁壝".toCharArray()[0] ^ 0x6F1A);
          ᐨẏ(paramˌх, ᐝᵣ$ﾞﾇ.j("⡁壝".toCharArray(), (short)6895, 0, (short)1) + str);
          return;
        } 
        ˊ(0x4800000 | paramˌх.ˍɫ(str));
        return;
      case 192:
        str = i.ʹл;
        ᐨم();
        if (str.charAt(0) == '[') {
          ᐨẏ(paramˌх, str);
          return;
        } 
        ˊ(0x800000 | paramˌх.ˍɫ(str));
        return;
      case 197:
        ᴵʖ(paramInt2);
        ᐨẏ(paramˌх, i.ʹл);
        return;
    } 
    throw new IllegalArgumentException();
  }
  
  private int ᐨẏ(int paramInt1, int paramInt2) {
    int i = paramInt1 & 0xFC000000;
    int j;
    if ((j = paramInt1 & 0x3C00000) == 20971520) {
      paramInt2 = i + this.ʿᵉ[paramInt1 & 0xFFFFF];
      if ((paramInt1 & 0x100000) != 0 && (paramInt2 == 4194308 || paramInt2 == 4194307))
        paramInt2 = 4194304; 
      return paramInt2;
    } 
    if (j == 25165824) {
      paramInt2 = i + this.ʹﮃ[paramInt2 - (paramInt1 & 0xFFFFF)];
      if ((paramInt1 & 0x100000) != 0 && (paramInt2 == 4194308 || paramInt2 == 4194307))
        paramInt2 = 4194304; 
      return paramInt2;
    } 
    return paramInt1;
  }
  
  final boolean ᐨẏ(ˌх paramˌх, ˍ paramˍ, int paramInt) {
    boolean bool = false;
    int i = this.ʿᵉ.length;
    int j = this.ʹﮃ.length;
    if (paramˍ.ʿᵉ == null) {
      paramˍ.ʿᵉ = new int[i];
      bool = true;
    } 
    int k;
    for (k = 0; k < i; k++) {
      int m;
      if (this.ՙᗮ != null && k < this.ՙᗮ.length) {
        int n;
        if ((n = this.ՙᗮ[k]) == 0) {
          m = this.ʿᵉ[k];
        } else {
          m = ᐨẏ(n, j);
        } 
      } else {
        m = this.ʿᵉ[k];
      } 
      if (this.ʽ != null)
        m = ᐨẏ(paramˌх, m); 
      bool |= ᐨẏ(paramˌх, m, paramˍ.ʿᵉ, k);
    } 
    if (paramInt > 0) {
      for (k = 0; k < i; k++)
        bool |= ᐨẏ(paramˌх, this.ʿᵉ[k], paramˍ.ʿᵉ, k); 
      if (paramˍ.ʹﮃ == null) {
        paramˍ.ʹﮃ = new int[1];
        bool = true;
      } 
      return bool |= ᐨẏ(paramˌх, paramInt, paramˍ.ʹﮃ, 0);
    } 
    k = this.ʹﮃ.length + this.ᐨẏ;
    if (paramˍ.ʹﮃ == null) {
      paramˍ.ʹﮃ = new int[k + this.ˊ];
      bool = true;
    } 
    byte b;
    for (b = 0; b < k; b++) {
      int m = this.ʹﮃ[b];
      if (this.ʽ != null)
        m = ᐨẏ(paramˌх, m); 
      bool |= ᐨẏ(paramˌх, m, paramˍ.ʹﮃ, b);
    } 
    for (b = 0; b < this.ˊ; b++) {
      int m = this.ˍɫ[b];
      paramInt = ᐨẏ(m, j);
      if (this.ʽ != null)
        paramInt = ᐨẏ(paramˌх, paramInt); 
      bool |= ᐨẏ(paramˌх, paramInt, paramˍ.ʹﮃ, k + b);
    } 
    return bool;
  }
  
  private static boolean ᐨẏ(ˌх paramˌх, int paramInt1, int[] paramArrayOfint, int paramInt2) {
    // Byte code:
    //   0: aload_2
    //   1: iload_3
    //   2: iaload
    //   3: dup
    //   4: istore #4
    //   6: iload_1
    //   7: if_icmpne -> 12
    //   10: iconst_0
    //   11: ireturn
    //   12: iload_1
    //   13: istore #5
    //   15: iload_1
    //   16: ldc_w 67108863
    //   19: iand
    //   20: ldc 4194309
    //   22: if_icmpne -> 38
    //   25: iload #4
    //   27: ldc 4194309
    //   29: if_icmpne -> 34
    //   32: iconst_0
    //   33: ireturn
    //   34: ldc 4194309
    //   36: istore #5
    //   38: iload #4
    //   40: ifne -> 50
    //   43: aload_2
    //   44: iload_3
    //   45: iload #5
    //   47: iastore
    //   48: iconst_1
    //   49: ireturn
    //   50: iload #4
    //   52: ldc -67108864
    //   54: iand
    //   55: ifne -> 68
    //   58: iload #4
    //   60: ldc 62914560
    //   62: iand
    //   63: ldc 8388608
    //   65: if_icmpne -> 296
    //   68: iload #5
    //   70: ldc 4194309
    //   72: if_icmpne -> 77
    //   75: iconst_0
    //   76: ireturn
    //   77: iload #5
    //   79: ldc_w -4194304
    //   82: iand
    //   83: iload #4
    //   85: ldc_w -4194304
    //   88: iand
    //   89: if_icmpne -> 176
    //   92: iload #4
    //   94: ldc 62914560
    //   96: iand
    //   97: ldc 8388608
    //   99: if_icmpne -> 129
    //   102: iload #5
    //   104: ldc -67108864
    //   106: iand
    //   107: ldc 8388608
    //   109: ior
    //   110: aload_0
    //   111: iload #5
    //   113: ldc 1048575
    //   115: iand
    //   116: iload #4
    //   118: ldc 1048575
    //   120: iand
    //   121: invokevirtual ˊ : (II)I
    //   124: ior
    //   125: istore_0
    //   126: goto -> 335
    //   129: ldc -67108864
    //   131: iload #5
    //   133: ldc -67108864
    //   135: iand
    //   136: iadd
    //   137: dup
    //   138: istore_1
    //   139: ldc 8388608
    //   141: ior
    //   142: aload_0
    //   143: ldc_w '囹я鎮孡䋈꺄꣊耆ࠡ譥俞鳋侲ᮧঔℲ'
    //   146: invokevirtual toCharArray : ()[C
    //   149: dup
    //   150: dup
    //   151: iconst_5
    //   152: dup_x1
    //   153: caload
    //   154: sipush #16710
    //   157: ixor
    //   158: i2c
    //   159: castore
    //   160: sipush #31115
    //   163: iconst_1
    //   164: iconst_4
    //   165: invokestatic j : (Ljava/lang/Object;SIS)Ljava/lang/String;
    //   168: invokevirtual ˍɫ : (Ljava/lang/String;)I
    //   171: ior
    //   172: istore_0
    //   173: goto -> 335
    //   176: iload #5
    //   178: ldc -67108864
    //   180: iand
    //   181: ifne -> 194
    //   184: iload #5
    //   186: ldc 62914560
    //   188: iand
    //   189: ldc 8388608
    //   191: if_icmpne -> 290
    //   194: iload #5
    //   196: ldc -67108864
    //   198: iand
    //   199: dup
    //   200: istore_1
    //   201: ifeq -> 219
    //   204: iload #5
    //   206: ldc 62914560
    //   208: iand
    //   209: ldc 8388608
    //   211: if_icmpeq -> 219
    //   214: iload_1
    //   215: ldc -67108864
    //   217: iadd
    //   218: istore_1
    //   219: iload #4
    //   221: ldc -67108864
    //   223: iand
    //   224: dup
    //   225: istore #5
    //   227: ifeq -> 247
    //   230: iload #4
    //   232: ldc 62914560
    //   234: iand
    //   235: ldc 8388608
    //   237: if_icmpeq -> 247
    //   240: iload #5
    //   242: ldc -67108864
    //   244: iadd
    //   245: istore #5
    //   247: iload_1
    //   248: iload #5
    //   250: invokestatic min : (II)I
    //   253: ldc 8388608
    //   255: ior
    //   256: aload_0
    //   257: ldc_w '?苭厛阢?㦈馾磩Ꝩ鲰ਁ睱龪ያ嫤ࡁ'
    //   260: invokevirtual toCharArray : ()[C
    //   263: dup
    //   264: dup
    //   265: iconst_2
    //   266: dup_x1
    //   267: caload
    //   268: sipush #30212
    //   271: ixor
    //   272: i2c
    //   273: castore
    //   274: sipush #1805
    //   277: iconst_4
    //   278: iconst_5
    //   279: invokestatic j : (Ljava/lang/Object;SIS)Ljava/lang/String;
    //   282: invokevirtual ˍɫ : (Ljava/lang/String;)I
    //   285: ior
    //   286: istore_0
    //   287: goto -> 335
    //   290: ldc 4194304
    //   292: istore_0
    //   293: goto -> 335
    //   296: iload #4
    //   298: ldc 4194309
    //   300: if_icmpne -> 332
    //   303: iload #5
    //   305: ldc -67108864
    //   307: iand
    //   308: ifne -> 321
    //   311: iload #5
    //   313: ldc 62914560
    //   315: iand
    //   316: ldc 8388608
    //   318: if_icmpne -> 326
    //   321: iload #5
    //   323: goto -> 328
    //   326: ldc 4194304
    //   328: istore_0
    //   329: goto -> 335
    //   332: ldc 4194304
    //   334: istore_0
    //   335: iload_0
    //   336: iload #4
    //   338: if_icmpeq -> 347
    //   341: aload_2
    //   342: iload_3
    //   343: iload_0
    //   344: iastore
    //   345: iconst_1
    //   346: ireturn
    //   347: iconst_0
    //   348: ireturn
  }
  
  final void ᐨẏ(ʿপ paramʿপ) {
    int[] arrayOfInt1 = this.ʿᵉ;
    int i = 0;
    byte b = 0;
    int j = 0;
    while (j < arrayOfInt1.length) {
      int m = arrayOfInt1[j];
      j += (m == 4194308 || m == 4194307) ? 2 : 1;
      if (m == 4194304) {
        b++;
        continue;
      } 
      i += b + 1;
      b = 0;
    } 
    int[] arrayOfInt2 = this.ʹﮃ;
    b = 0;
    j = 0;
    while (j < arrayOfInt2.length) {
      int m = arrayOfInt2[j];
      j += (m == 4194308 || m == 4194307) ? 2 : 1;
      b++;
    } 
    int k = paramʿপ.ᐨẏ(this.ˊ.ʻบ, i, b);
    j = 0;
    while (i-- > 0) {
      int m = arrayOfInt1[j];
      j += (m == 4194308 || m == 4194307) ? 2 : 1;
      int i1 = m;
      int n = k++;
      ʿপ ʿপ1;
      (ʿপ1 = paramʿপ).ᴵƚ[n] = i1;
    } 
    j = 0;
    while (b-- > 0) {
      int m = arrayOfInt2[j];
      j += (m == 4194308 || m == 4194307) ? 2 : 1;
      int i1 = m;
      int n = k++;
      ʿপ ʿপ1;
      (ʿপ1 = paramʿপ).ᴵƚ[n] = i1;
    } 
    paramʿপ.ՙᗮ();
  }
  
  static void ᐨẏ(ˌх paramˌх, int paramInt, ʿᵉ paramʿᵉ) {
    // Byte code:
    //   0: iload_1
    //   1: ldc -67108864
    //   3: iand
    //   4: bipush #26
    //   6: ishr
    //   7: dup
    //   8: istore_3
    //   9: ifne -> 187
    //   12: iload_1
    //   13: ldc 1048575
    //   15: iand
    //   16: istore #4
    //   18: iload_1
    //   19: ldc 62914560
    //   21: iand
    //   22: lookupswitch default -> 179, 4194304 -> 64, 8388608 -> 74, 12582912 -> 114, 16777216 -> 142
    //   64: aload_2
    //   65: iload #4
    //   67: invokevirtual ᐨẏ : (I)Lyyds/sniarbtej/ʿᵉ;
    //   70: pop
    //   71: goto -> 442
    //   74: aload_2
    //   75: bipush #7
    //   77: invokevirtual ᐨẏ : (I)Lyyds/sniarbtej/ʿᵉ;
    //   80: aload_0
    //   81: dup
    //   82: iload #4
    //   84: istore_3
    //   85: dup
    //   86: astore_1
    //   87: getfield ˊ : [Lyyds/sniarbtej/ιﾌ;
    //   90: iload_3
    //   91: aaload
    //   92: getfield ʹл : Ljava/lang/String;
    //   95: astore_3
    //   96: dup
    //   97: astore_1
    //   98: bipush #7
    //   100: aload_3
    //   101: invokevirtual ᐨẏ : (ILjava/lang/String;)Lyyds/sniarbtej/ˊᵃ;
    //   104: getfield ͺᴲ : I
    //   107: invokevirtual ˊ : (I)Lyyds/sniarbtej/ʿᵉ;
    //   110: pop
    //   111: goto -> 442
    //   114: aload_2
    //   115: bipush #8
    //   117: invokevirtual ᐨẏ : (I)Lyyds/sniarbtej/ʿᵉ;
    //   120: aload_0
    //   121: iload #4
    //   123: istore_3
    //   124: dup
    //   125: astore_1
    //   126: getfield ˊ : [Lyyds/sniarbtej/ιﾌ;
    //   129: iload_3
    //   130: aaload
    //   131: getfield ˊ : J
    //   134: l2i
    //   135: invokevirtual ˊ : (I)Lyyds/sniarbtej/ʿᵉ;
    //   138: pop
    //   139: goto -> 442
    //   142: aload_2
    //   143: bipush #8
    //   145: invokevirtual ᐨẏ : (I)Lyyds/sniarbtej/ʿᵉ;
    //   148: pop
    //   149: aload_0
    //   150: iload #4
    //   152: istore_1
    //   153: dup
    //   154: astore_0
    //   155: getfield ᐨẏ : [Lyyds/sniarbtej/ʻւ;
    //   158: aload_0
    //   159: getfield ˊ : [Lyyds/sniarbtej/ιﾌ;
    //   162: iload_1
    //   163: aaload
    //   164: getfield ˊ : J
    //   167: l2i
    //   168: aaload
    //   169: getfield ʾ : Lyyds/sniarbtej/ᔪ;
    //   172: aload_2
    //   173: invokevirtual ˊ : (Lyyds/sniarbtej/ʿᵉ;)V
    //   176: goto -> 442
    //   179: new java/lang/AssertionError
    //   182: dup
    //   183: invokespecial <init> : ()V
    //   186: athrow
    //   187: new java/lang/StringBuilder
    //   190: dup
    //   191: invokespecial <init> : ()V
    //   194: astore #4
    //   196: iload_3
    //   197: iinc #3, -1
    //   200: ifle -> 214
    //   203: aload #4
    //   205: bipush #91
    //   207: invokevirtual append : (C)Ljava/lang/StringBuilder;
    //   210: pop
    //   211: goto -> 196
    //   214: iload_1
    //   215: ldc 62914560
    //   217: iand
    //   218: ldc 8388608
    //   220: if_icmpne -> 258
    //   223: aload #4
    //   225: bipush #76
    //   227: invokevirtual append : (C)Ljava/lang/StringBuilder;
    //   230: aload_0
    //   231: iload_1
    //   232: ldc 1048575
    //   234: iand
    //   235: istore_3
    //   236: dup
    //   237: astore_1
    //   238: getfield ˊ : [Lyyds/sniarbtej/ιﾌ;
    //   241: iload_3
    //   242: aaload
    //   243: getfield ʹл : Ljava/lang/String;
    //   246: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   249: bipush #59
    //   251: invokevirtual append : (C)Ljava/lang/StringBuilder;
    //   254: pop
    //   255: goto -> 420
    //   258: iload_1
    //   259: ldc 1048575
    //   261: iand
    //   262: tableswitch default -> 412, 1 -> 368, 2 -> 379, 3 -> 401, 4 -> 390, 5 -> 412, 6 -> 412, 7 -> 412, 8 -> 412, 9 -> 324, 10 -> 335, 11 -> 346, 12 -> 357
    //   324: aload #4
    //   326: bipush #90
    //   328: invokevirtual append : (C)Ljava/lang/StringBuilder;
    //   331: pop
    //   332: goto -> 420
    //   335: aload #4
    //   337: bipush #66
    //   339: invokevirtual append : (C)Ljava/lang/StringBuilder;
    //   342: pop
    //   343: goto -> 420
    //   346: aload #4
    //   348: bipush #67
    //   350: invokevirtual append : (C)Ljava/lang/StringBuilder;
    //   353: pop
    //   354: goto -> 420
    //   357: aload #4
    //   359: bipush #83
    //   361: invokevirtual append : (C)Ljava/lang/StringBuilder;
    //   364: pop
    //   365: goto -> 420
    //   368: aload #4
    //   370: bipush #73
    //   372: invokevirtual append : (C)Ljava/lang/StringBuilder;
    //   375: pop
    //   376: goto -> 420
    //   379: aload #4
    //   381: bipush #70
    //   383: invokevirtual append : (C)Ljava/lang/StringBuilder;
    //   386: pop
    //   387: goto -> 420
    //   390: aload #4
    //   392: bipush #74
    //   394: invokevirtual append : (C)Ljava/lang/StringBuilder;
    //   397: pop
    //   398: goto -> 420
    //   401: aload #4
    //   403: bipush #68
    //   405: invokevirtual append : (C)Ljava/lang/StringBuilder;
    //   408: pop
    //   409: goto -> 420
    //   412: new java/lang/AssertionError
    //   415: dup
    //   416: invokespecial <init> : ()V
    //   419: athrow
    //   420: aload_2
    //   421: bipush #7
    //   423: invokevirtual ᐨẏ : (I)Lyyds/sniarbtej/ʿᵉ;
    //   426: aload_0
    //   427: aload #4
    //   429: invokevirtual toString : ()Ljava/lang/String;
    //   432: invokevirtual ᐨẏ : (Ljava/lang/String;)Lyyds/sniarbtej/ˊᵃ;
    //   435: getfield ͺᴲ : I
    //   438: invokevirtual ˊ : (I)Lyyds/sniarbtej/ʿᵉ;
    //   441: pop
    //   442: return
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ˍ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */