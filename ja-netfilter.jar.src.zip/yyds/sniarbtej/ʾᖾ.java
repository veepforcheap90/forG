package yyds.sniarbtej;

import java.util.Comparator;

final class ʾᖾ implements Comparator<Comparable> {
  private static int ᐨẏ(Comparable<Comparable> paramComparable1, Comparable paramComparable2) {
    return paramComparable1.compareTo(paramComparable2);
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ʾᖾ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */