package yyds.sniarbtej;

public final class ﭔ extends ʻล {
  private ᐨᘂ ˊ;
  
  private ﭔ(ᐨᘂ paramᐨᘂ) {
    this(null, paramᐨᘂ);
  }
  
  public ﭔ(ʻล paramʻล, ᐨᘂ paramᐨᘂ) {
    super(589824, paramʻล);
    this.ˊ = paramᐨᘂ;
  }
  
  public final void ʿᵉ(String paramString) {
    this.ˊ.ʿᵉ(paramString);
    super.ʿᵉ(paramString);
  }
  
  public final void ʹﮃ(String paramString) {
    this.ˊ.ʹﮃ(paramString);
    super.ʹﮃ(paramString);
  }
  
  public final void ᐨẏ(String paramString1, int paramInt, String paramString2) {
    this.ˊ.ᐨẏ(paramString1, paramInt, paramString2);
    super.ᐨẏ(paramString1, paramInt, paramString2);
  }
  
  public final void ᐨẏ(String paramString, int paramInt, String... paramVarArgs) {
    this.ˊ.ᐨẏ(paramString, paramInt, paramVarArgs);
    super.ᐨẏ(paramString, paramInt, paramVarArgs);
  }
  
  public final void ˊ(String paramString, int paramInt, String... paramVarArgs) {
    this.ˊ.ˊ(paramString, paramInt, paramVarArgs);
    super.ˊ(paramString, paramInt, paramVarArgs);
  }
  
  public final void ՙᗮ(String paramString) {
    this.ˊ.ՙᗮ(paramString);
    super.ՙᗮ(paramString);
  }
  
  public final void ᐨẏ(String paramString, String... paramVarArgs) {
    this.ˊ.ᐨẏ(paramString, paramVarArgs);
    super.ᐨẏ(paramString, paramVarArgs);
  }
  
  public final void ᐨẏ() {
    this.ˊ.ʼᐡ();
    super.ᐨẏ();
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ﭔ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */