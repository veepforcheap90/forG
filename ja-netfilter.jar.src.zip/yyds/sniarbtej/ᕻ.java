package yyds.sniarbtej;

import java.util.Arrays;

public class ᕻ {
  private static boolean ˌᔹ = true;
  
  public String name;
  
  public String ˎᴗ;
  
  public String ˊﮈ;
  
  public λ ᴵʖ;
  
  public λ ﾞл;
  
  public int ͺᴲ;
  
  public ᕻ() {}
  
  private static void ʻล(String paramString) {
    System.out.println(paramString);
  }
  
  private static void ˊ(String paramString, Object paramObject) {
    ᐨẏ(paramString, paramObject, -1);
  }
  
  private static void ᐨẏ(String paramString, Object paramObject, int paramInt) {
    try {
      if (paramObject != null) {
        String str1 = paramObject.getClass().getName();
        "匎♞".toCharArray()[0] = (char)("匎♞".toCharArray()[0] ^ 0x6091);
        "髍ឺ".toCharArray()[0] = (char)("髍ឺ".toCharArray()[0] ^ 0x4214);
        String str2 = paramString + ˉﻤ$ͺſ.v("匎♞".toCharArray(), (short)29409, 3, (short)1) + paramInt + ˉﻤ$ͺſ.v("髍ឺ".toCharArray(), (short)3518, 4, (short)2);
        if (paramInt == -1)
          str2 = paramString; 
        paramString = paramObject.toString();
        if (paramObject instanceof Object[]) {
          ᐨẏ(str2, (Object[])paramObject);
          return;
        } 
        if (paramObject instanceof char[]) {
          str1 = Arrays.toString((char[])paramObject);
        } else if (paramObject instanceof byte[]) {
          "⛘".toCharArray()[0] = (char)("⛘".toCharArray()[0] ^ 0x6EF6);
          str1 = ˉﻤ$ͺſ.v("⛘".toCharArray(), (short)25531, 1, (short)1) + Arrays.toString((byte[])paramObject);
        } else if (paramObject instanceof int[]) {
          "껜焒".toCharArray()[0] = (char)("껜焒".toCharArray()[0] ^ 0x456F);
          str1 = ˉﻤ$ͺſ.v("껜焒".toCharArray(), (short)4271, 4, (short)4) + Arrays.toString((int[])paramObject);
        } else if (paramObject instanceof long[]) {
          "칵攈".toCharArray()[0] = (char)("칵攈".toCharArray()[0] ^ 0x1A03);
          str1 = ˉﻤ$ͺſ.v("칵攈".toCharArray(), (short)4157, 2, (short)4) + Arrays.toString((long[])paramObject);
        } else if (paramObject instanceof boolean[]) {
          "埐ⳏ".toCharArray()[0] = (char)("埐ⳏ".toCharArray()[0] ^ 0x28D1);
          str1 = ˉﻤ$ͺſ.v("埐ⳏ".toCharArray(), (short)13120, 5, (short)3) + Arrays.toString((boolean[])paramObject);
        } else if (paramObject instanceof double[]) {
          "줱嬁".toCharArray()[0] = (char)("줱嬁".toCharArray()[0] ^ 0x440C);
          str1 = ˉﻤ$ͺſ.v("줱嬁".toCharArray(), (short)17775, 0, (short)3) + Arrays.toString((double[])paramObject);
        } else if (paramObject instanceof float[]) {
          "⒈".toCharArray()[0] = (char)("⒈".toCharArray()[0] ^ 0x77E2);
          str1 = ˉﻤ$ͺſ.v("⒈".toCharArray(), (short)4887, 0, (short)3) + Arrays.toString((float[])paramObject);
        } 
        "ᯋ".toCharArray()[0] = (char)("ᯋ".toCharArray()[0] ^ 0x301D);
        "壆厡".toCharArray()[0] = (char)("壆厡".toCharArray()[0] ^ 0x78F1);
        "퍓偻".toCharArray()[0] = (char)("퍓偻".toCharArray()[0] ^ 0x3A2);
        paramString = str2 + ˉﻤ$ͺſ.v("ᯋ".toCharArray(), (short)13098, 4, (short)0) + paramString + ˉﻤ$ͺſ.v("壆厡".toCharArray(), (short)23284, 3, (short)3) + str1 + ˉﻤ$ͺſ.v("퍓偻".toCharArray(), (short)16418, 2, (short)3);
        System.out.println(paramString);
      } else {
        "촢╟锌㕝᏶⺆㝥∌".toCharArray()[2] = (char)("촢╟锌㕝᏶⺆㝥∌".toCharArray()[2] ^ 0x6CD9);
        paramString = paramString + ˉﻤ$ͺſ.v("촢╟锌㕝᏶⺆㝥∌".toCharArray(), (short)22153, 3, (short)2);
        System.out.println(paramString);
        return;
      } 
    } catch (Throwable throwable2) {
      Throwable throwable1;
      (throwable1 = null).printStackTrace();
    } 
  }
  
  private static void ᐨẏ(String paramString, Object[] paramArrayOfObject) {
    if (paramArrayOfObject == null) {
      "ꩀ⡵奉◦∠䎀䍏욗穯窭鐘틋ℤ磍꤁댃壹嶉".toCharArray()[3] = (char)("ꩀ⡵奉◦∠䎀䍏욗穯窭鐘틋ℤ磍꤁댃壹嶉".toCharArray()[3] ^ 0x515B);
      paramString = paramString + ˉﻤ$ͺſ.v("ꩀ⡵奉◦∠䎀䍏욗穯窭鐘틋ℤ磍꤁댃壹嶉".toCharArray(), (short)5917, 4, (short)0) + paramArrayOfObject;
      System.out.println(paramString);
      return;
    } 
    if (paramArrayOfObject.length == 0) {
      "Ֆ픑∷ꂌ㎼᳃趝樷ꤞ쾅䄲魱➽璍ད䙂姧留ꕪ뵖ΰ".toCharArray()[14] = (char)("Ֆ픑∷ꂌ㎼᳃趝樷ꤞ쾅䄲魱➽璍ད䙂姧留ꕪ뵖ΰ".toCharArray()[14] ^ 0x7B55);
      paramString = paramString + ˉﻤ$ͺſ.v("Ֆ픑∷ꂌ㎼᳃趝樷ꤞ쾅䄲魱➽璍ད䙂姧留ꕪ뵖ΰ".toCharArray(), (short)5189, 1, (short)3) + paramArrayOfObject;
      System.out.println(paramString);
      return;
    } 
    for (byte b = 0; b < paramArrayOfObject.length; b++)
      ᐨẏ(paramString, paramArrayOfObject[b], b); 
  }
  
  private static void ˈے(String paramString) {
    StackTraceElement[] arrayOfStackTraceElement = Thread.currentThread().getStackTrace();
    byte b = 2;
    int i;
    if ((i = arrayOfStackTraceElement.length) > 20)
      i = 20; 
    if (i < 2)
      b = 0; 
    for (b = b; b < i; b++) {
      "浗᳷?䬽ʰ䗁੎㔇鏌୉躕䓨嘄".toCharArray()[10] = (char)("浗᳷?䬽ʰ䗁੎㔇鏌୉躕䓨嘄".toCharArray()[10] ^ 0x5491);
      "ㆧᨒ".toCharArray()[0] = (char)("ㆧᨒ".toCharArray()[0] ^ 0x5CA7);
      String str = paramString + ᐝᵣ$ﾞﾇ.j("浗᳷?䬽ʰ䗁੎㔇鏌୉躕䓨嘄".toCharArray(), (short)23693, 3, (short)3) + b + ᐝᵣ$ﾞﾇ.j("ㆧᨒ".toCharArray(), (short)18889, 4, (short)2) + arrayOfStackTraceElement[b];
      System.out.println(str);
    } 
  }
  
  public ᕻ(String paramString1, String paramString2, String paramString3, λ paramλ1, λ paramλ2, int paramInt) {
    this.name = paramString1;
    this.ˎᴗ = paramString2;
    this.ˊﮈ = paramString3;
    this.ᴵʖ = paramλ1;
    this.ﾞл = paramλ2;
    this.ͺᴲ = paramInt;
  }
  
  public void ᐨẏ(ˉｓ paramˉｓ) {
    paramˉｓ.ᐨẏ(this.name, this.ˎᴗ, this.ˊﮈ, this.ᴵʖ.ﾞл(), this.ﾞл.ﾞл(), this.ͺᴲ);
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ᕻ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */