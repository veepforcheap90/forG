package yyds.sniarbtej;

import java.util.Date;
import ylt.pmn.zubdqvgt;

final class ˈट implements ˌ々 {
  public final <T> ٴۉ<T> ᐨẏ(ˑĴ paramˑĴ, ʸ<T> paramʸ) {
    ʸ<T> ʸ1;
    return zubdqvgt.G((ʸ1 = paramʸ).ᐨم, Date.class) ? new ʹﭴ() : null;
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ˈट.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */