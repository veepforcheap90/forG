package yyds.sniarbtej;

import java.util.HashSet;

final class ᴵᒮ {
  private final String ᐨẏ;
  
  private final HashSet<String> ᐨẏ;
  
  ᴵᒮ(String paramString) {
    this.ᐨẏ = (HashSet<String>)paramString;
    this.ᐨẏ = new HashSet<>();
  }
  
  final void ʹō(String paramString) {
    if (!this.ᐨẏ.add(paramString)) {
      "옋栓硏".toCharArray()[1] = (char)("옋栓硏".toCharArray()[1] ^ 0x6071);
      "뻹랛?尽揸賚栜쪿풩蘏⦠앲［㭙뮦書螸ᮗ⭩".toCharArray()[3] = (char)("뻹랛?尽揸賚栜쪿풩蘏⦠앲［㭙뮦書螸ᮗ⭩".toCharArray()[3] ^ 0x2BE4);
      throw new IllegalArgumentException(this.ᐨẏ + ᐝᵣ$ﾞﾇ.j("옋栓硏".toCharArray(), (short)23229, 4, (short)1) + paramString + ᐝᵣ$ﾞﾇ.j("뻹랛?尽揸賚栜쪿풩蘏⦠앲［㭙뮦書螸ᮗ⭩".toCharArray(), (short)25294, 2, (short)5));
    } 
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ᴵᒮ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */