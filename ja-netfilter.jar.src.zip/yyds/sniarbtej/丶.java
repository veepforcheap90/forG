package yyds.sniarbtej;

public final class 丶 extends ˉｓ {
  private ᐨᘂ ˊ;
  
  public 丶(ᐨᘂ paramᐨᘂ) {
    this(null, paramᐨᘂ);
  }
  
  public 丶(ˉｓ paramˉｓ, ᐨᘂ paramᐨᘂ) {
    super(589824, paramˉｓ);
    this.ˊ = paramᐨᘂ;
  }
  
  public final void ᐨẏ(String paramString, int paramInt) {
    this.ˊ.ᐨẏ(paramString, paramInt);
    super.ᐨẏ(paramString, paramInt);
  }
  
  public final ᐨẏ ᐨẏ(String paramString, boolean paramBoolean) {
    ᐨᘂ ᐨᘂ1 = this.ˊ.ᐨẏ(paramString, paramBoolean);
    return new ιๅ(super.ᐨẏ(paramString, paramBoolean), ᐨᘂ1);
  }
  
  public final ᐨẏ ᐨẏ(int paramInt, ˏɪ paramˏɪ, String paramString, boolean paramBoolean) {
    ᐨᘂ ᐨᘂ1 = this.ˊ.ᴵʖ(paramInt, paramˏɪ, paramString, paramBoolean);
    return new ιๅ(super.ᐨẏ(paramInt, paramˏɪ, paramString, paramBoolean), ᐨᘂ1);
  }
  
  public final void ᴵʖ(ᴵʖ paramᴵʖ) {
    this.ˊ.ՙᗮ(paramᴵʖ);
    super.ᴵʖ(paramᴵʖ);
  }
  
  public final ᐨẏ ˊ() {
    ᐨᘂ ᐨᘂ1 = this.ˊ.ᐨẏ();
    return new ιๅ(super.ˊ(), ᐨᘂ1);
  }
  
  public final void ᐨẏ(int paramInt, boolean paramBoolean) {
    this.ˊ.ᐨẏ(paramInt, paramBoolean);
    super.ᐨẏ(paramInt, paramBoolean);
  }
  
  public final ᐨẏ ᐨẏ(int paramInt, String paramString, boolean paramBoolean) {
    ᐨᘂ ᐨᘂ1 = this.ˊ.ᐨẏ(paramInt, paramString, paramBoolean);
    return new ιๅ(super.ᐨẏ(paramInt, paramString, paramBoolean), ᐨᘂ1);
  }
  
  public final void ᴵʖ() {
    this.ˊ.ᴵʖ();
    super.ᴵʖ();
  }
  
  public final void ᐨẏ(int paramInt1, int paramInt2, Object[] paramArrayOfObject1, int paramInt3, Object[] paramArrayOfObject2) {
    this.ˊ.ᐨẏ(paramInt1, paramInt2, paramArrayOfObject1, paramInt3, paramArrayOfObject2);
    super.ᐨẏ(paramInt1, paramInt2, paramArrayOfObject1, paramInt3, paramArrayOfObject2);
  }
  
  public final void ʹﮃ(int paramInt) {
    this.ˊ.ʹﮃ(paramInt);
    super.ʹﮃ(paramInt);
  }
  
  public final void ˊ(int paramInt1, int paramInt2) {
    this.ˊ.ˊ(paramInt1, paramInt2);
    super.ˊ(paramInt1, paramInt2);
  }
  
  public final void ᴵʖ(int paramInt1, int paramInt2) {
    this.ˊ.ᴵʖ(paramInt1, paramInt2);
    super.ᴵʖ(paramInt1, paramInt2);
  }
  
  public final void ᐨẏ(int paramInt, String paramString) {
    this.ˊ.ᐨẏ(paramInt, paramString);
    super.ᐨẏ(paramInt, paramString);
  }
  
  public final void ᐨẏ(int paramInt, String paramString1, String paramString2, String paramString3) {
    this.ˊ.ᐨẏ(paramInt, paramString1, paramString2, paramString3);
    super.ᐨẏ(paramInt, paramString1, paramString2, paramString3);
  }
  
  public final void ᐨẏ(int paramInt, String paramString1, String paramString2, String paramString3, boolean paramBoolean) {
    if (this.ˊ.ᐨẏ < 327680) {
      if (paramBoolean != ((paramInt == 185))) {
        "Ο郠搵ࡃ毻啰崺ﰭ⦒廨ᡸ䛁ᦁ휆鮕꼭㩉⿜똖嵞挺ꑨ袑죴蔹열懙៑䣒Ỗ궑ꓪ宿獪₌䧶㷎逴Ⅎ鴆⣸".toCharArray()[30] = (char)("Ο郠搵ࡃ毻啰崺ﰭ⦒廨ᡸ䛁ᦁ휆鮕꼭㩉⿜똖嵞挺ꑨ袑죴蔹열懙៑䣒Ỗ궑ꓪ宿獪₌䧶㷎逴Ⅎ鴆⣸".toCharArray()[30] ^ 0x26CF);
        throw new IllegalArgumentException(ˏȓ$ᴵЃ.E("Ο郠搵ࡃ毻啰崺ﰭ⦒廨ᡸ䛁ᦁ휆鮕꼭㩉⿜똖嵞挺ꑨ袑죴蔹열懙៑䣒Ỗ궑ꓪ宿獪₌䧶㷎逴Ⅎ鴆⣸".toCharArray(), (short)7407, (short)1, (short)0));
      } 
      String str3 = paramString3;
      String str2 = paramString2;
      String str1 = paramString1;
      int i = paramInt;
      ᐨᘂ ᐨᘂ1;
      (ᐨᘂ1 = this.ˊ).ᐨẏ(i, str1, str2, str3, (i == 185));
    } else {
      this.ˊ.ᐨẏ(paramInt, paramString1, paramString2, paramString3, paramBoolean);
    } 
    if (this.ᐨẏ != null)
      this.ᐨẏ.ᐨẏ(paramInt, paramString1, paramString2, paramString3, paramBoolean); 
  }
  
  public final void ᐨẏ(String paramString1, String paramString2, ʹō paramʹō, Object... paramVarArgs) {
    this.ˊ.ᐨẏ(paramString1, paramString2, paramʹō, paramVarArgs);
    super.ᐨẏ(paramString1, paramString2, paramʹō, paramVarArgs);
  }
  
  public final void ᐨẏ(int paramInt, ᔪ paramᔪ) {
    this.ˊ.ᐨẏ(paramInt, paramᔪ);
    super.ᐨẏ(paramInt, paramᔪ);
  }
  
  public final void ˊ(ᔪ paramᔪ) {
    this.ˊ.ˊ(paramᔪ);
    super.ˊ(paramᔪ);
  }
  
  public final void ˊ(Object paramObject) {
    this.ˊ.ˊ(paramObject);
    super.ˊ(paramObject);
  }
  
  public final void ﾞл(int paramInt1, int paramInt2) {
    this.ˊ.ﾞл(paramInt1, paramInt2);
    super.ﾞл(paramInt1, paramInt2);
  }
  
  public final void ᐨẏ(int paramInt1, int paramInt2, ᔪ paramᔪ, ᔪ... paramVarArgs) {
    this.ˊ.ᐨẏ(paramInt1, paramInt2, paramᔪ, paramVarArgs);
    super.ᐨẏ(paramInt1, paramInt2, paramᔪ, paramVarArgs);
  }
  
  public final void ᐨẏ(ᔪ paramᔪ, int[] paramArrayOfint, ᔪ[] paramArrayOfᔪ) {
    this.ˊ.ᐨẏ(paramᔪ, paramArrayOfint, paramArrayOfᔪ);
    super.ᐨẏ(paramᔪ, paramArrayOfint, paramArrayOfᔪ);
  }
  
  public final void ˊ(String paramString, int paramInt) {
    this.ˊ.ˊ(paramString, paramInt);
    super.ˊ(paramString, paramInt);
  }
  
  public final ᐨẏ ˊ(int paramInt, ˏɪ paramˏɪ, String paramString, boolean paramBoolean) {
    ᐨᘂ ᐨᘂ1 = this.ˊ.ˊ(paramInt, paramˏɪ, paramString, paramBoolean);
    return new ιๅ(super.ˊ(paramInt, paramˏɪ, paramString, paramBoolean), ᐨᘂ1);
  }
  
  public final void ᐨẏ(ᔪ paramᔪ1, ᔪ paramᔪ2, ᔪ paramᔪ3, String paramString) {
    this.ˊ.ᐨẏ(paramᔪ1, paramᔪ2, paramᔪ3, paramString);
    super.ᐨẏ(paramᔪ1, paramᔪ2, paramᔪ3, paramString);
  }
  
  public final ᐨẏ ᴵʖ(int paramInt, ˏɪ paramˏɪ, String paramString, boolean paramBoolean) {
    ᐨᘂ ᐨᘂ1 = this.ˊ.ᐨẏ(paramInt, paramˏɪ, paramString, paramBoolean);
    return new ιๅ(super.ᴵʖ(paramInt, paramˏɪ, paramString, paramBoolean), ᐨᘂ1);
  }
  
  public final void ᐨẏ(String paramString1, String paramString2, String paramString3, ᔪ paramᔪ1, ᔪ paramᔪ2, int paramInt) {
    this.ˊ.ᐨẏ(paramString1, paramString2, paramString3, paramᔪ1, paramᔪ2, paramInt);
    super.ᐨẏ(paramString1, paramString2, paramString3, paramᔪ1, paramᔪ2, paramInt);
  }
  
  public final ᐨẏ ᐨẏ(int paramInt, ˏɪ paramˏɪ, ᔪ[] paramArrayOfᔪ1, ᔪ[] paramArrayOfᔪ2, int[] paramArrayOfint, String paramString, boolean paramBoolean) {
    ᐨᘂ ᐨᘂ1 = this.ˊ.ᐨẏ(paramInt, paramˏɪ, paramArrayOfᔪ1, paramArrayOfᔪ2, paramArrayOfint, paramString, paramBoolean);
    return new ιๅ(super.ᐨẏ(paramInt, paramˏɪ, paramArrayOfᔪ1, paramArrayOfᔪ2, paramArrayOfint, paramString, paramBoolean), ᐨᘂ1);
  }
  
  public final void ˊ(int paramInt, ᔪ paramᔪ) {
    this.ˊ.ˊ(paramInt, paramᔪ);
    super.ˊ(paramInt, paramᔪ);
  }
  
  public final void ʿᵉ(int paramInt1, int paramInt2) {
    this.ˊ.ʿᵉ(paramInt1, paramInt2);
    super.ʿᵉ(paramInt1, paramInt2);
  }
  
  public final void ᐨẏ() {
    this.ˊ.ͺĹ();
    super.ᐨẏ();
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\丶.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */