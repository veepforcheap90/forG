package yyds.sniarbtej;

import java.util.Map;

final class ﹹ extends ᵁ {
  ﹹ(ʿא paramʿא) {
    super(paramʿא.ˊ, (byte)0);
  }
  
  private Map.Entry<K, V> ᐨẏ() {
    return ᐨẏ();
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ﹹ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */