package yyds.sniarbtej;

import java.util.Map;

public final class ۦ extends Ӏ {
  public int ՙﺙ;
  
  private int ᐝﺌ;
  
  public ۦ(int paramInt1, int paramInt2) {
    super(132);
    this.ՙﺙ = paramInt1;
    this.ᐝﺌ = paramInt2;
  }
  
  public final int ﹳיִ() {
    return 10;
  }
  
  public final void ᐨẏ(ˉｓ paramˉｓ) {
    paramˉｓ.ﾞл(this.ՙﺙ, this.ᐝﺌ);
    ˊ(paramˉｓ);
  }
  
  public final Ӏ ᐨẏ(Map<λ, λ> paramMap) {
    return (new ۦ(this.ՙﺙ, this.ᐝﺌ)).ᐨẏ(this);
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ۦ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */