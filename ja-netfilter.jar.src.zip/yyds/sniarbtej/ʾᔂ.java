package yyds.sniarbtej;

import java.util.Map;

public final class ʾᔂ extends Ӏ {
  public String ˈהּ;
  
  private String name;
  
  public String ˎᴗ;
  
  public boolean ʾ;
  
  private ʾᔂ(int paramInt, String paramString1, String paramString2, String paramString3) {
    this(paramInt, paramString1, paramString2, paramString3, (paramInt == 185));
  }
  
  public ʾᔂ(int paramInt, String paramString1, String paramString2, String paramString3, boolean paramBoolean) {
    super(paramInt);
    this.ˈהּ = paramString1;
    this.name = paramString2;
    this.ˎᴗ = paramString3;
    this.ʾ = paramBoolean;
  }
  
  private void ٴӵ(int paramInt) {
    this.ՙঘ = paramInt;
  }
  
  public final int ﹳיִ() {
    return 5;
  }
  
  public final void ᐨẏ(ˉｓ paramˉｓ) {
    paramˉｓ.ᐨẏ(this.ՙঘ, this.ˈהּ, this.name, this.ˎᴗ, this.ʾ);
    ˊ(paramˉｓ);
  }
  
  public final Ӏ ᐨẏ(Map<λ, λ> paramMap) {
    return (new ʾᔂ(this.ՙঘ, this.ˈהּ, this.name, this.ˎᴗ, this.ʾ)).ᐨẏ(this);
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ʾᔂ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */