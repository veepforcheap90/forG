package yyds.sniarbtej;

public abstract class ˊᵃ {
  private static int יᴩ = 7;
  
  private static int ˏу = 9;
  
  private static int ᐝᙇ = 10;
  
  private static int ᴵỲ = 11;
  
  private static int ՙᔀ = 8;
  
  private static int ᐝĹ = 3;
  
  private static int ᐧঽ = 4;
  
  private static int ᐨฑ = 5;
  
  private static int ᴵﺣ = 6;
  
  private static int ʼс = 12;
  
  private static int ʼʇ = 1;
  
  private static int ﱢ = 15;
  
  private static int ـপ = 16;
  
  private static int ʽĺ = 17;
  
  private static int ﻩ = 18;
  
  private static int ͺƗ = 19;
  
  private static int ՙˊ = 20;
  
  private static int ՙب = 64;
  
  private static int ﹳᕂ = 128;
  
  private static int ﾅ = 129;
  
  private static int ˍˠ = 130;
  
  private static int יฅ = 131;
  
  public final int ͺᴲ;
  
  public final int ᙆ;
  
  final String ˈהּ;
  
  public final String name;
  
  public final String ʹл;
  
  public final long ˊ;
  
  int ᐨḶ;
  
  ˊᵃ(int paramInt1, int paramInt2, String paramString1, String paramString2, String paramString3, long paramLong) {
    this.ͺᴲ = paramInt1;
    this.ᙆ = paramInt2;
    this.ˈהּ = paramString1;
    this.name = paramString2;
    this.ʹл = paramString3;
    this.ˊ = paramLong;
  }
  
  final int ʹō() {
    if (this.ᐨḶ == 0)
      this.ᐨḶ = ˑܘ.ᐨم(this.ʹл); 
    return this.ᐨḶ;
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ˊᵃ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */