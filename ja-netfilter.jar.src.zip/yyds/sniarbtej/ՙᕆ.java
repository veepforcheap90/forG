package yyds.sniarbtej;

import java.io.PrintWriter;
import java.io.StringWriter;

final class ՙᕆ extends ᐧє {
  ՙᕆ(int paramInt1, int paramInt2, String paramString1, String paramString2, String paramString3, String[] paramArrayOfString, ˉｓ paramˉｓ) {
    super(paramInt1, paramInt2, paramString1, paramString2, paramString3, paramArrayOfString);
  }
  
  public final void ᐨẏ() {
    // Byte code:
    //   0: aload_0
    //   1: getfield ˌپ : I
    //   4: istore_1
    //   5: aload_0
    //   6: getfield ˑỲ : I
    //   9: istore_2
    //   10: iconst_0
    //   11: istore_3
    //   12: iconst_0
    //   13: istore #4
    //   15: aload_0
    //   16: getfield ᴵʖ : Lyyds/sniarbtej/ˉｓ;
    //   19: instanceof yyds/sniarbtej/ـﾚ
    //   22: ifeq -> 120
    //   25: aload_0
    //   26: getfield ᴵʖ : Lyyds/sniarbtej/ˉｓ;
    //   29: checkcast yyds/sniarbtej/ـﾚ
    //   32: dup
    //   33: astore #4
    //   35: dup
    //   36: astore #5
    //   38: getfield ˊ : Lyyds/sniarbtej/ʽ;
    //   41: iconst_1
    //   42: invokevirtual ᐨẏ : (I)Z
    //   45: ifne -> 60
    //   48: aload #5
    //   50: getfield ˊ : Lyyds/sniarbtej/ʽ;
    //   53: iconst_2
    //   54: invokevirtual ᐨẏ : (I)Z
    //   57: ifeq -> 64
    //   60: iconst_1
    //   61: goto -> 65
    //   64: iconst_0
    //   65: ifne -> 72
    //   68: iconst_1
    //   69: goto -> 73
    //   72: iconst_0
    //   73: istore_3
    //   74: aload #4
    //   76: dup
    //   77: astore #5
    //   79: getfield ᔪ : I
    //   82: ldc 65535
    //   84: iand
    //   85: bipush #51
    //   87: if_icmplt -> 94
    //   90: iconst_1
    //   91: goto -> 95
    //   94: iconst_0
    //   95: ifeq -> 117
    //   98: aload #4
    //   100: dup
    //   101: astore #5
    //   103: getfield ˊ : Lyyds/sniarbtej/ʽ;
    //   106: iconst_2
    //   107: invokevirtual ᐨẏ : (I)Z
    //   110: ifne -> 117
    //   113: iconst_1
    //   114: goto -> 118
    //   117: iconst_0
    //   118: istore #4
    //   120: iload #4
    //   122: ifeq -> 142
    //   125: new yyds/sniarbtej/ˋن
    //   128: dup
    //   129: new yyds/sniarbtej/ᐧǏ
    //   132: dup
    //   133: invokespecial <init> : ()V
    //   136: invokespecial <init> : (Lyyds/sniarbtej/וּ;)V
    //   139: goto -> 156
    //   142: new yyds/sniarbtej/ιᒶ
    //   145: dup
    //   146: new yyds/sniarbtej/ᐧǏ
    //   149: dup
    //   150: invokespecial <init> : ()V
    //   153: invokespecial <init> : (Lyyds/sniarbtej/וּ;)V
    //   156: astore #4
    //   158: iload_3
    //   159: ifeq -> 196
    //   162: aload #4
    //   164: ldc '议巌돚뮕ࡼ'
    //   166: invokevirtual toCharArray : ()[C
    //   169: dup
    //   170: dup
    //   171: iconst_3
    //   172: dup_x1
    //   173: caload
    //   174: sipush #15434
    //   177: ixor
    //   178: i2c
    //   179: castore
    //   180: sipush #24237
    //   183: iconst_5
    //   184: iconst_0
    //   185: invokestatic E : (Ljava/lang/Object;SSS)Ljava/lang/String;
    //   188: aload_0
    //   189: invokevirtual ᐨẏ : (Ljava/lang/String;Lyyds/sniarbtej/ᐧє;)[Lyyds/sniarbtej/ιՆ;
    //   192: pop
    //   193: goto -> 614
    //   196: aload #4
    //   198: ldc '엊ߓ捷솄㝝ᵪ'
    //   200: invokevirtual toCharArray : ()[C
    //   203: dup
    //   204: dup
    //   205: iconst_1
    //   206: dup_x1
    //   207: caload
    //   208: sipush #2623
    //   211: ixor
    //   212: i2c
    //   213: castore
    //   214: sipush #24864
    //   217: iconst_0
    //   218: iconst_1
    //   219: invokestatic E : (Ljava/lang/Object;SSS)Ljava/lang/String;
    //   222: aload_0
    //   223: astore #6
    //   225: astore_3
    //   226: astore #5
    //   228: aload #6
    //   230: dup
    //   231: dup
    //   232: astore #7
    //   234: getfield ˎᴗ : Ljava/lang/String;
    //   237: invokestatic ᐨم : (Ljava/lang/String;)I
    //   240: iconst_2
    //   241: ishr
    //   242: istore #8
    //   244: aload #7
    //   246: getfield ᒬ : I
    //   249: bipush #8
    //   251: iand
    //   252: ifeq -> 258
    //   255: iinc #8, -1
    //   258: aload #7
    //   260: getfield ˊ : Lyyds/sniarbtej/ـс;
    //   263: invokevirtual ᐨẏ : ()Ljava/util/ListIterator;
    //   266: astore #7
    //   268: aload #7
    //   270: invokeinterface hasNext : ()Z
    //   275: ifeq -> 401
    //   278: aload #7
    //   280: invokeinterface next : ()Ljava/lang/Object;
    //   285: checkcast yyds/sniarbtej/Ӏ
    //   288: dup
    //   289: astore #9
    //   291: instanceof yyds/sniarbtej/ᕁ
    //   294: ifeq -> 369
    //   297: aload #9
    //   299: checkcast yyds/sniarbtej/ᕁ
    //   302: getfield ՙﺙ : I
    //   305: istore #10
    //   307: aload #9
    //   309: invokevirtual ˈהּ : ()I
    //   312: bipush #22
    //   314: if_icmpeq -> 347
    //   317: aload #9
    //   319: invokevirtual ˈהּ : ()I
    //   322: bipush #24
    //   324: if_icmpeq -> 347
    //   327: aload #9
    //   329: invokevirtual ˈהּ : ()I
    //   332: bipush #55
    //   334: if_icmpeq -> 347
    //   337: aload #9
    //   339: invokevirtual ˈהּ : ()I
    //   342: bipush #57
    //   344: if_icmpne -> 351
    //   347: iconst_2
    //   348: goto -> 352
    //   351: iconst_1
    //   352: istore #11
    //   354: iload #8
    //   356: iload #10
    //   358: iload #11
    //   360: iadd
    //   361: invokestatic max : (II)I
    //   364: istore #8
    //   366: goto -> 268
    //   369: aload #9
    //   371: instanceof yyds/sniarbtej/ۦ
    //   374: ifeq -> 398
    //   377: aload #9
    //   379: checkcast yyds/sniarbtej/ۦ
    //   382: getfield ՙﺙ : I
    //   385: istore #10
    //   387: iload #8
    //   389: iload #10
    //   391: iconst_1
    //   392: iadd
    //   393: invokestatic max : (II)I
    //   396: istore #8
    //   398: goto -> 268
    //   401: iload #8
    //   403: putfield ˌپ : I
    //   406: aload #6
    //   408: iconst_m1
    //   409: putfield ˑỲ : I
    //   412: aload #5
    //   414: aload_3
    //   415: aload #6
    //   417: invokevirtual ᐨẏ : (Ljava/lang/String;Lyyds/sniarbtej/ᐧє;)[Lyyds/sniarbtej/ιՆ;
    //   420: pop
    //   421: aload #6
    //   423: aload #5
    //   425: getfield ᐨẏ : [Lyyds/sniarbtej/ιՆ;
    //   428: astore #7
    //   430: iconst_0
    //   431: istore #8
    //   433: aload #7
    //   435: dup
    //   436: astore #7
    //   438: arraylength
    //   439: istore #9
    //   441: iconst_0
    //   442: istore #10
    //   444: iload #10
    //   446: iload #9
    //   448: if_icmpge -> 515
    //   451: aload #7
    //   453: iload #10
    //   455: aaload
    //   456: dup
    //   457: astore #11
    //   459: ifnull -> 509
    //   462: iconst_0
    //   463: istore_3
    //   464: iconst_0
    //   465: istore #6
    //   467: iload #6
    //   469: aload #11
    //   471: dup
    //   472: astore #12
    //   474: getfield ᐝᒰ : I
    //   477: if_icmpge -> 501
    //   480: iload_3
    //   481: aload #11
    //   483: iload #6
    //   485: invokevirtual ˊ : (I)Lyyds/sniarbtej/ן;
    //   488: invokeinterface ˍɫ : ()I
    //   493: iadd
    //   494: istore_3
    //   495: iinc #6, 1
    //   498: goto -> 467
    //   501: iload #8
    //   503: iload_3
    //   504: invokestatic max : (II)I
    //   507: istore #8
    //   509: iinc #10, 1
    //   512: goto -> 444
    //   515: iload #8
    //   517: putfield ˑỲ : I
    //   520: aload #5
    //   522: getfield ᐨẏ : [Lyyds/sniarbtej/ιՆ;
    //   525: pop
    //   526: goto -> 614
    //   529: astore_1
    //   530: aload_0
    //   531: aload #4
    //   533: aload_1
    //   534: astore #6
    //   536: astore_3
    //   537: astore #5
    //   539: new java/io/StringWriter
    //   542: dup
    //   543: invokespecial <init> : ()V
    //   546: astore #7
    //   548: new java/io/PrintWriter
    //   551: dup
    //   552: aload #7
    //   554: iconst_1
    //   555: invokespecial <init> : (Ljava/io/Writer;Z)V
    //   558: astore #8
    //   560: aload #5
    //   562: aload_3
    //   563: aload #8
    //   565: invokestatic ᐨẏ : (Lyyds/sniarbtej/ᐧє;Lyyds/sniarbtej/ιᒶ;Ljava/io/PrintWriter;)V
    //   568: aload #8
    //   570: invokevirtual close : ()V
    //   573: new java/lang/IllegalArgumentException
    //   576: dup
    //   577: new java/lang/StringBuilder
    //   580: dup
    //   581: invokespecial <init> : ()V
    //   584: aload #6
    //   586: invokevirtual getMessage : ()Ljava/lang/String;
    //   589: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   592: bipush #32
    //   594: invokevirtual append : (C)Ljava/lang/StringBuilder;
    //   597: aload #7
    //   599: invokevirtual toString : ()Ljava/lang/String;
    //   602: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   605: invokevirtual toString : ()Ljava/lang/String;
    //   608: aload #6
    //   610: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   613: athrow
    //   614: aload_0
    //   615: getfield ᴵʖ : Lyyds/sniarbtej/ˉｓ;
    //   618: ifnull -> 639
    //   621: aload_0
    //   622: iload_1
    //   623: putfield ˌپ : I
    //   626: aload_0
    //   627: iload_2
    //   628: putfield ˑỲ : I
    //   631: aload_0
    //   632: dup
    //   633: getfield ᴵʖ : Lyyds/sniarbtej/ˉｓ;
    //   636: invokevirtual ᐨẏ : (Lyyds/sniarbtej/ˉｓ;)V
    //   639: return
    // Exception table:
    //   from	to	target	type
    //   158	526	529	java/lang/IndexOutOfBoundsException
    //   158	526	529	yyds/sniarbtej/ιƚ
  }
  
  private void ᐨẏ(ιᒶ<ﹳه> paramιᒶ, Exception paramException) {
    StringWriter stringWriter = new StringWriter();
    PrintWriter printWriter = new PrintWriter(stringWriter, true);
    ˉʭ.ᐨẏ(this, paramιᒶ, printWriter);
    printWriter.close();
    throw new IllegalArgumentException(paramException.getMessage() + ' ' + stringWriter.toString(), paramException);
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ՙᕆ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */