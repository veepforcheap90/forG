package yyds.sniarbtej;

import java.util.Map;

public final class ˏﾚ extends Ӏ {
  public ˏﾚ(int paramInt) {
    super(paramInt);
  }
  
  public final int ﹳיִ() {
    return 0;
  }
  
  public final void ᐨẏ(ˉｓ paramˉｓ) {
    paramˉｓ.ʹﮃ(this.ՙঘ);
    ˊ(paramˉｓ);
  }
  
  public final Ӏ ᐨẏ(Map<λ, λ> paramMap) {
    return (new ˏﾚ(this.ՙঘ)).ᐨẏ(this);
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ˏﾚ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */