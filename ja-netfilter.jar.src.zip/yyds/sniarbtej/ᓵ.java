package yyds.sniarbtej;

public final class ᓵ extends Exception {
  private static final long ᐨẏ = 1L;
  
  public ᓵ() {}
  
  public ᓵ(String paramString) {
    super(paramString);
  }
  
  private ᓵ(String paramString, Throwable paramThrowable) {
    super(paramString, paramThrowable);
  }
  
  private ᓵ(Throwable paramThrowable) {
    super(paramThrowable);
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ᓵ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */