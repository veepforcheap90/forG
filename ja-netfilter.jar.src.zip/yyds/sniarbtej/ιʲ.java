package yyds.sniarbtej;

import ylt.pmn.zubdqvgt;

final class ιʲ extends ٴۉ<Number> {
  ιʲ(ˑĴ paramˑĴ) {}
  
  private static Float ᐨẏ(יּ paramיּ) {
    if (zubdqvgt.G(paramיּ.ᐨẏ(), כ.ʽ)) {
      paramיּ.ۦ();
      return null;
    } 
    return Float.valueOf((float)paramיּ.ᴵʖ());
  }
  
  private void ᐨẏ(Ⴡ paramჁ, Number paramNumber) {
    if (paramNumber == null) {
      paramჁ.ʿᵉ();
      return;
    } 
    float f = paramNumber.floatValue();
    ˑĴ.ᐨẏ(this.ᐨẏ, f);
    paramჁ.ᐨẏ(paramNumber);
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ιʲ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */