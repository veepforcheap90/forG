package yyds.sniarbtej;

enum יﺜ {
  public final ᐧｴ ᐨẏ(Long paramLong) {
    return new ﭘ(paramLong);
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\יﺜ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */