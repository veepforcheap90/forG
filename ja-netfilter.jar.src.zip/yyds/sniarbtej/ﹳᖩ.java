package yyds.sniarbtej;

public final class ﹳᖩ {
  private String name;
  
  private int ᒬ;
  
  public ﹳᖩ(String paramString, int paramInt) {
    this.name = paramString;
    this.ᒬ = paramInt;
  }
  
  public final void ᐨẏ(ˉｓ paramˉｓ) {
    paramˉｓ.ᐨẏ(this.name, this.ᒬ);
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ﹳᖩ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */