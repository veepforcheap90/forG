package yyds.sniarbtej;

import ylt.pmn.zubdqvgt;

final class ﾞﺣ implements ˌ々 {
  ﾞﺣ(Class paramClass, ٴۉ paramٴۉ) {}
  
  public final <T> ٴۉ<T> ᐨẏ(ˑĴ paramˑĴ, ʸ<T> paramʸ) {
    ʸ<T> ʸ1;
    return zubdqvgt.G((ʸ1 = paramʸ).ᐨم, this.ﾞл) ? this.ﹳיִ : null;
  }
  
  public final String toString() {
    "弛揆缟ᒦǃ?ㅙ殫摣ꡫ㎼㙸緄".toCharArray()[4] = (char)("弛揆缟ᒦǃ?ㅙ殫摣ꡫ㎼㙸緄".toCharArray()[4] ^ 0x4820);
    "⛕餖?ᘵ厡詟剺鞬覰ᆄ".toCharArray()[4] = (char)("⛕餖?ᘵ厡詟剺鞬覰ᆄ".toCharArray()[4] ^ 0x870);
    "䅸".toCharArray()[0] = (char)("䅸".toCharArray()[0] ^ 0x41C6);
    return ˉﻤ$ͺſ.v("弛揆缟ᒦǃ?ㅙ殫摣ꡫ㎼㙸緄".toCharArray(), (short)244, 3, (short)4) + this.ﾞл.getName() + ˉﻤ$ͺſ.v("⛕餖?ᘵ厡詟剺鞬覰ᆄ".toCharArray(), (short)2431, 1, (short)4) + this.ﹳיִ + ˉﻤ$ͺſ.v("䅸".toCharArray(), (short)18833, 5, (short)2);
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ﾞﺣ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */