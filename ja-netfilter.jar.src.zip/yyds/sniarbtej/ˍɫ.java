package yyds.sniarbtej;

public abstract class ˍɫ {
  protected final int ᐨẏ;
  
  protected ˍɫ ᐨẏ;
  
  public ˍɫ(int paramInt) {
    this(paramInt, null);
  }
  
  public ˍɫ(int paramInt, ˍɫ paramˍɫ) {
    if (paramInt != 589824 && paramInt != 524288 && paramInt != 458752 && paramInt != 393216 && paramInt != 327680 && paramInt != 262144 && paramInt != 17432576) {
      "⡯䘙ⱻㇵ촬团哢䯟᳌䝔Ṓ䖤붞冦䕄璶".toCharArray()[15] = (char)("⡯䘙ⱻㇵ촬团哢䯟᳌䝔Ṓ䖤붞冦䕄璶".toCharArray()[15] ^ 0x438E);
      throw new IllegalArgumentException(ˏȓ$ᴵЃ.E("⡯䘙ⱻㇵ촬团哢䯟᳌䝔Ṓ䖤붞冦䕄璶".toCharArray(), (short)7459, (short)2, (short)4) + paramInt);
    } 
    if (paramInt == 17432576)
      ᐨم.ᐨẏ(this); 
    this.ᐨẏ = paramInt;
    this.ᐨẏ = paramˍɫ;
  }
  
  private ˍɫ ᐨẏ() {
    return this.ᐨẏ;
  }
  
  public void ᐨẏ(int paramInt1, int paramInt2, String paramString1, String paramString2, String paramString3, String[] paramArrayOfString) {
    if (this.ᐨẏ < 524288 && (paramInt2 & 0x10000) != 0) {
      "릈㒢㽴㮇鏻ꁱꉝ辻䕂窒쎡⼌覻ப瓴薮ﹳ煓嘫煔".toCharArray()[11] = (char)("릈㒢㽴㮇鏻ꁱꉝ辻䕂窒쎡⼌覻ப瓴薮ﹳ煓嘫煔".toCharArray()[11] ^ 0xC8B);
      throw new UnsupportedOperationException(ˉﻤ$ͺſ.v("릈㒢㽴㮇鏻ꁱꉝ辻䕂窒쎡⼌覻ப瓴薮ﹳ煓嘫煔".toCharArray(), (short)16256, 1, (short)3));
    } 
    if (this.ᐨẏ != null)
      this.ᐨẏ.ᐨẏ(paramInt1, paramInt2, paramString1, paramString2, paramString3, paramArrayOfString); 
  }
  
  public void ᐨẏ(String paramString1, String paramString2) {
    if (this.ᐨẏ != null)
      this.ᐨẏ.ᐨẏ(paramString1, paramString2); 
  }
  
  public ʻล ᐨẏ(String paramString1, int paramInt, String paramString2) {
    if (this.ᐨẏ < 393216) {
      "嗒裥扅꟨竝簍쇹즡쯭唰䫤ㆄ䉞뭣?刖".toCharArray()[14] = (char)("嗒裥扅꟨竝簍쇹즡쯭唰䫤ㆄ䉞뭣?刖".toCharArray()[14] ^ 0x6B51);
      throw new UnsupportedOperationException(ˏȓ$ᴵЃ.E("嗒裥扅꟨竝簍쇹즡쯭唰䫤ㆄ䉞뭣?刖".toCharArray(), (short)17134, (short)4, (short)3));
    } 
    return (this.ᐨẏ != null) ? this.ᐨẏ.ᐨẏ(paramString1, paramInt, paramString2) : null;
  }
  
  public void ᐨẏ(String paramString) {
    if (this.ᐨẏ < 458752) {
      "形牄奤쏩肳蕣陗훸嫍瘒뭂妦뵠隸傟ࡘ僎⇷㶮塉".toCharArray()[4] = (char)("形牄奤쏩肳蕣陗훸嫍瘒뭂妦뵠隸傟ࡘ僎⇷㶮塉".toCharArray()[4] ^ 0x6EED);
      throw new UnsupportedOperationException(ˉﻤ$ͺſ.v("形牄奤쏩肳蕣陗훸嫍瘒뭂妦뵠隸傟ࡘ僎⇷㶮塉".toCharArray(), (short)2949, 1, (short)5));
    } 
    if (this.ᐨẏ != null)
      this.ᐨẏ.ᐨẏ(paramString); 
  }
  
  public void ˊ(String paramString1, String paramString2, String paramString3) {
    if (this.ᐨẏ != null)
      this.ᐨẏ.ˊ(paramString1, paramString2, paramString3); 
  }
  
  public ᐨẏ ᐨẏ(String paramString, boolean paramBoolean) {
    return (this.ᐨẏ != null) ? this.ᐨẏ.ᐨẏ(paramString, paramBoolean) : null;
  }
  
  public ᐨẏ ᐨẏ(int paramInt, ˏɪ paramˏɪ, String paramString, boolean paramBoolean) {
    if (this.ᐨẏ < 327680) {
      "ឬ㴫苄偾遠毊迃౻匘ㆎ콤繤煫␴嘠䪄뎆忰齂?ۧ荅ｭ᥸".toCharArray()[16] = (char)("ឬ㴫苄偾遠毊迃౻匘ㆎ콤繤煫␴嘠䪄뎆忰齂?ۧ荅ｭ᥸".toCharArray()[16] ^ 0x73E2);
      throw new UnsupportedOperationException(ᐝᵣ$ﾞﾇ.j("ឬ㴫苄偾遠毊迃౻匘ㆎ콤繤煫␴嘠䪄뎆忰齂?ۧ荅ｭ᥸".toCharArray(), (short)9438, 4, (short)1));
    } 
    return (this.ᐨẏ != null) ? this.ᐨẏ.ᐨẏ(paramInt, paramˏɪ, paramString, paramBoolean) : null;
  }
  
  public void ᴵʖ(ᴵʖ paramᴵʖ) {
    if (this.ᐨẏ != null)
      this.ᐨẏ.ᴵʖ(paramᴵʖ); 
  }
  
  public void ˊ(String paramString) {
    if (this.ᐨẏ < 458752) {
      "ꟲ쵓ﯙˬ৑ड띸雿並뢶薾텦寂籘酩䨞ׂ?㶱쳛é".toCharArray()[18] = (char)("ꟲ쵓ﯙˬ৑ड띸雿並뢶薾텦寂籘酩䨞ׂ?㶱쳛é".toCharArray()[18] ^ 0x4503);
      throw new UnsupportedOperationException(ᐨẏ$ᐝт.W("ꟲ쵓ﯙˬ৑ड띸雿並뢶薾텦寂籘酩䨞ׂ?㶱쳛é".toCharArray(), (short)24778, (byte)5, (short)4));
    } 
    if (this.ᐨẏ != null)
      this.ᐨẏ.ˊ(paramString); 
  }
  
  public void ᴵʖ(String paramString) {
    if (this.ᐨẏ < 589824) {
      "룪氬ᦰ뙬㦮顏⁦㯚⦔뷝퀝ஞ민❰靪?풯ũ叹Ⲛ䙟靏犑漴䡊恵榥?ⵥ쏡ᙧ泗É乶".toCharArray()[8] = (char)("룪氬ᦰ뙬㦮顏⁦㯚⦔뷝퀝ஞ민❰靪?풯ũ叹Ⲛ䙟靏犑漴䡊恵榥?ⵥ쏡ᙧ泗É乶".toCharArray()[8] ^ 0xB48);
      throw new UnsupportedOperationException(ᐨẏ$ᐝт.W("룪氬ᦰ뙬㦮顏⁦㯚⦔뷝퀝ஞ민❰靪?풯ũ叹Ⲛ䙟靏犑漴䡊恵榥?ⵥ쏡ᙧ泗É乶".toCharArray(), (short)10238, (byte)3, (short)5));
    } 
    if (this.ᐨẏ != null)
      this.ᐨẏ.ᴵʖ(paramString); 
  }
  
  public void ᐨẏ(String paramString1, String paramString2, String paramString3, int paramInt) {
    if (this.ᐨẏ != null)
      this.ᐨẏ.ᐨẏ(paramString1, paramString2, paramString3, paramInt); 
  }
  
  public ʼᵖ ᐨẏ(String paramString1, String paramString2, String paramString3) {
    if (this.ᐨẏ < 524288) {
      "Ꮷᢩ赠ᥚⱈ㕙鷿閝与設?扺⛻钎齺᜷咞ђ".toCharArray()[9] = (char)("Ꮷᢩ赠ᥚⱈ㕙鷿閝与設?扺⛻钎齺᜷咞ђ".toCharArray()[9] ^ 0x145);
      throw new UnsupportedOperationException(ˏȓ$ᴵЃ.E("Ꮷᢩ赠ᥚⱈ㕙鷿閝与設?扺⛻钎齺᜷咞ђ".toCharArray(), (short)26313, (short)4, (short)4));
    } 
    return (this.ᐨẏ != null) ? this.ᐨẏ.ᐨẏ(paramString1, paramString2, paramString3) : null;
  }
  
  public ᴵƚ ᐨẏ(int paramInt, String paramString1, String paramString2, String paramString3, Object paramObject) {
    return (this.ᐨẏ != null) ? this.ᐨẏ.ᐨẏ(paramInt, paramString1, paramString2, paramString3, paramObject) : null;
  }
  
  public ˉｓ ᐨẏ(int paramInt, String paramString1, String paramString2, String paramString3, String[] paramArrayOfString) {
    return (this.ᐨẏ != null) ? this.ᐨẏ.ᐨẏ(paramInt, paramString1, paramString2, paramString3, paramArrayOfString) : null;
  }
  
  public void ᐨẏ() {
    if (this.ᐨẏ != null)
      this.ᐨẏ.ᐨẏ(); 
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ˍɫ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */