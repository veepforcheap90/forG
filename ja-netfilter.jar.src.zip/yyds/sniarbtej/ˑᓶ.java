package yyds.sniarbtej;

import java.util.Map;

public final class ˑᓶ extends Ӏ {
  private int ܬ;
  
  private λ ᴵʖ;
  
  public ˑᓶ(int paramInt, λ paramλ) {
    super(-1);
    this.ܬ = paramInt;
    this.ᴵʖ = paramλ;
  }
  
  public final int ﹳיִ() {
    return 15;
  }
  
  public final void ᐨẏ(ˉｓ paramˉｓ) {
    paramˉｓ.ˊ(this.ܬ, this.ᴵʖ.ﾞл());
  }
  
  public final Ӏ ᐨẏ(Map<λ, λ> paramMap) {
    return new ˑᓶ(this.ܬ, ᐨẏ(this.ᴵʖ, paramMap));
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ˑᓶ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */