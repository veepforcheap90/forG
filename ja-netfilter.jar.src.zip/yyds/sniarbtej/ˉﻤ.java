package yyds.sniarbtej;

import ylt.pmn.zubdqvgt;

final class ˉﻤ extends ٴۉ<StringBuilder> {
  private static StringBuilder ᐨẏ(יּ paramיּ) {
    if (zubdqvgt.G(paramיּ.ᐨẏ(), כ.ʽ)) {
      paramיּ.ۦ();
      return null;
    } 
    return new StringBuilder(paramיּ.ٴӵ());
  }
  
  private static void ᐨẏ(Ⴡ paramჁ, StringBuilder paramStringBuilder) {
    paramჁ.ˊ((paramStringBuilder == null) ? null : paramStringBuilder.toString());
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ˉﻤ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */