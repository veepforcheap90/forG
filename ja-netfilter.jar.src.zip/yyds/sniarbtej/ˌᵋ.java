package yyds.sniarbtej;

import java.util.List;

public final class ˌᵋ extends ˍɫ {
  private ᴵઽ ᐨẏ;
  
  private String ˊ;
  
  private ˌᵋ(ˍɫ paramˍɫ, ᴵઽ paramᴵઽ) {
    this(589824, paramˍɫ, paramᴵઽ);
  }
  
  private ˌᵋ(int paramInt, ˍɫ paramˍɫ, ᴵઽ paramᴵઽ) {
    super(589824, paramˍɫ);
    this.ᐨẏ = paramᴵઽ;
  }
  
  public final void ᐨẏ(int paramInt1, int paramInt2, String paramString1, String paramString2, String paramString3, String[] paramArrayOfString) {
    this.ˊ = paramString1;
    super.ᐨẏ(paramInt1, paramInt2, this.ᐨẏ.ᴵʖ(paramString1), this.ᐨẏ.ˊ(paramString2, false), this.ᐨẏ.ᴵʖ(paramString3), (paramArrayOfString == null) ? null : this.ᐨẏ.ᐨẏ(paramArrayOfString));
  }
  
  public final ʻล ᐨẏ(String paramString1, int paramInt, String paramString2) {
    ʻล ʻล1;
    if ((ʻล1 = super.ᐨẏ(paramString1 = paramString1, paramInt, paramString2)) == null)
      return null; 
    ʻล ʻล2 = ʻล1;
    ˌᵋ ˌᵋ1 = this;
    return new ˌᔹ(ˌᵋ1.ᐨẏ, ʻล2, ˌᵋ1.ᐨẏ);
  }
  
  public final ᐨẏ ᐨẏ(String paramString, boolean paramBoolean) {
    ᐨẏ ᐨẏ;
    return ((ᐨẏ = super.ᐨẏ(this.ᐨẏ.ˊ(paramString), paramBoolean)) == null) ? null : ᐨẏ(paramString, ᐨẏ);
  }
  
  public final ᐨẏ ᐨẏ(int paramInt, ˏɪ paramˏɪ, String paramString, boolean paramBoolean) {
    ᐨẏ ᐨẏ;
    return ((ᐨẏ = super.ᐨẏ(paramInt, paramˏɪ, this.ᐨẏ.ˊ(paramString), paramBoolean)) == null) ? null : ᐨẏ(paramString, ᐨẏ);
  }
  
  public final void ᴵʖ(ᴵʖ paramᴵʖ) {
    if (paramᴵʖ instanceof ᵕ) {
      ᵕ ᵕ;
      List<String> list = (ᵕ = (ᵕ)paramᴵʖ).ʹﮃ;
      for (byte b = 0; b < list.size(); b++) {
        String str;
        list.set(b, str = list.get(b));
      } 
    } 
    super.ᴵʖ(paramᴵʖ);
  }
  
  public final ʼᵖ ᐨẏ(String paramString1, String paramString2, String paramString3) {
    ʼᵖ ʼᵖ1;
    if ((ʼᵖ1 = super.ᐨẏ(paramString1 = paramString1, this.ᐨẏ.ˊ(paramString2), this.ᐨẏ.ˊ(paramString3, true))) == null)
      return null; 
    ʼᵖ ʼᵖ2 = ʼᵖ1;
    ˌᵋ ˌᵋ1 = this;
    return new ʼᐡ(ˌᵋ1.ᐨẏ, ʼᵖ2, ˌᵋ1.ᐨẏ);
  }
  
  public final ᴵƚ ᐨẏ(int paramInt, String paramString1, String paramString2, String paramString3, Object paramObject) {
    ᴵƚ ᴵƚ1;
    if ((ᴵƚ1 = super.ᐨẏ(paramInt, this.ᐨẏ.ʿᵉ(this.ˊ, paramString1), this.ᐨẏ.ˊ(paramString2), this.ᐨẏ.ˊ(paramString3, true), (paramObject == null) ? null : this.ᐨẏ.ᐨẏ(paramObject))) == null)
      return null; 
    ᴵƚ ᴵƚ2 = ᴵƚ1;
    ˌᵋ ˌᵋ1 = this;
    return new ٴᖟ(ˌᵋ1.ᐨẏ, ᴵƚ2, ˌᵋ1.ᐨẏ);
  }
  
  public final ˉｓ ᐨẏ(int paramInt, String paramString1, String paramString2, String paramString3, String[] paramArrayOfString) {
    String str = this.ᐨẏ.ﾞл(paramString2);
    ˉｓ ˉｓ1;
    if ((ˉｓ1 = super.ᐨẏ(paramInt, this.ᐨẏ.ᐨẏ(this.ˊ, paramString1, paramString2), str, this.ᐨẏ.ˊ(paramString3, false), (paramArrayOfString == null) ? null : this.ᐨẏ.ᐨẏ(paramArrayOfString))) == null)
      return null; 
    ˉｓ ˉｓ2 = ˉｓ1;
    ˌᵋ ˌᵋ1 = this;
    return new ˎאּ(ˌᵋ1.ᐨẏ, ˉｓ2, ˌᵋ1.ᐨẏ);
  }
  
  public final void ᐨẏ(String paramString1, String paramString2, String paramString3, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: dup
    //   2: getfield ᐨẏ : Lyyds/sniarbtej/ᴵઽ;
    //   5: aload_1
    //   6: invokevirtual ᴵʖ : (Ljava/lang/String;)Ljava/lang/String;
    //   9: aload_2
    //   10: ifnonnull -> 17
    //   13: aconst_null
    //   14: goto -> 25
    //   17: aload_0
    //   18: getfield ᐨẏ : Lyyds/sniarbtej/ᴵઽ;
    //   21: aload_2
    //   22: invokevirtual ᴵʖ : (Ljava/lang/String;)Ljava/lang/String;
    //   25: aload_3
    //   26: ifnonnull -> 33
    //   29: aconst_null
    //   30: goto -> 180
    //   33: aload_0
    //   34: getfield ᐨẏ : Lyyds/sniarbtej/ᴵઽ;
    //   37: aload_1
    //   38: aload_3
    //   39: astore_3
    //   40: astore_2
    //   41: dup
    //   42: astore_1
    //   43: aload_2
    //   44: invokevirtual ᴵʖ : (Ljava/lang/String;)Ljava/lang/String;
    //   47: dup
    //   48: astore_1
    //   49: aload_2
    //   50: invokevirtual equals : (Ljava/lang/Object;)Z
    //   53: ifne -> 179
    //   56: aload_2
    //   57: bipush #47
    //   59: invokevirtual lastIndexOf : (I)I
    //   62: istore #5
    //   64: aload_1
    //   65: bipush #47
    //   67: invokevirtual lastIndexOf : (I)I
    //   70: istore #6
    //   72: iload #5
    //   74: iconst_m1
    //   75: if_icmpeq -> 102
    //   78: iload #6
    //   80: iconst_m1
    //   81: if_icmpeq -> 102
    //   84: aload_2
    //   85: iload #5
    //   87: invokevirtual substring : (I)Ljava/lang/String;
    //   90: aload_1
    //   91: iload #6
    //   93: invokevirtual substring : (I)Ljava/lang/String;
    //   96: invokevirtual equals : (Ljava/lang/Object;)Z
    //   99: ifne -> 179
    //   102: aload_1
    //   103: ldc 'Ѐ沧'
    //   105: invokevirtual toCharArray : ()[C
    //   108: dup
    //   109: dup
    //   110: iconst_0
    //   111: dup_x1
    //   112: caload
    //   113: sipush #20230
    //   116: ixor
    //   117: i2c
    //   118: castore
    //   119: sipush #1519
    //   122: iconst_1
    //   123: iconst_4
    //   124: invokestatic v : (Ljava/lang/Object;SIS)Ljava/lang/String;
    //   127: invokevirtual contains : (Ljava/lang/CharSequence;)Z
    //   130: ifeq -> 179
    //   133: aload_1
    //   134: bipush #36
    //   136: invokevirtual lastIndexOf : (I)I
    //   139: iconst_1
    //   140: iadd
    //   141: istore #5
    //   143: iload #5
    //   145: aload_1
    //   146: invokevirtual length : ()I
    //   149: if_icmpge -> 170
    //   152: aload_1
    //   153: iload #5
    //   155: invokevirtual charAt : (I)C
    //   158: invokestatic isDigit : (C)Z
    //   161: ifeq -> 170
    //   164: iinc #5, 1
    //   167: goto -> 143
    //   170: aload_1
    //   171: iload #5
    //   173: invokevirtual substring : (I)Ljava/lang/String;
    //   176: goto -> 180
    //   179: aload_3
    //   180: iload #4
    //   182: invokespecial ᐨẏ : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)V
    //   185: return
  }
  
  public final void ˊ(String paramString1, String paramString2, String paramString3) {
    super.ˊ(this.ᐨẏ.ᴵʖ(paramString1), (paramString2 == null) ? null : this.ᐨẏ.ᐨẏ(paramString1, paramString2, paramString3), (paramString3 == null) ? null : this.ᐨẏ.ﾞл(paramString3));
  }
  
  public final void ᐨẏ(String paramString) {
    super.ᐨẏ(this.ᐨẏ.ᴵʖ(paramString));
  }
  
  public final void ˊ(String paramString) {
    super.ˊ(this.ᐨẏ.ᴵʖ(paramString));
  }
  
  public final void ᴵʖ(String paramString) {
    super.ᴵʖ(this.ᐨẏ.ᴵʖ(paramString));
  }
  
  private ᴵƚ ᐨẏ(ᴵƚ paramᴵƚ) {
    return new ٴᖟ(this.ᐨẏ, paramᴵƚ, this.ᐨẏ);
  }
  
  private ˉｓ ᐨẏ(ˉｓ paramˉｓ) {
    return new ˎאּ(this.ᐨẏ, paramˉｓ, this.ᐨẏ);
  }
  
  @Deprecated
  private ᐨẏ ᐨẏ(ᐨẏ paramᐨẏ) {
    return new ʴ(this.ᐨẏ, null, paramᐨẏ, this.ᐨẏ);
  }
  
  private ᐨẏ ᐨẏ(String paramString, ᐨẏ paramᐨẏ) {
    return (new ʴ(this.ᐨẏ, paramString, paramᐨẏ, this.ᐨẏ)).ˊ(ᐨẏ(paramᐨẏ));
  }
  
  private ʻล ᐨẏ(ʻล paramʻล) {
    return new ˌᔹ(this.ᐨẏ, paramʻล, this.ᐨẏ);
  }
  
  private ʼᵖ ᐨẏ(ʼᵖ paramʼᵖ) {
    return new ʼᐡ(this.ᐨẏ, paramʼᵖ, this.ᐨẏ);
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ˌᵋ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */