package yyds.sniarbtej;

public final class ˌᔹ extends ʻล {
  private ᴵઽ ᐨẏ;
  
  private ˌᔹ(ʻล paramʻล, ᴵઽ paramᴵઽ) {
    this(589824, paramʻล, paramᴵઽ);
  }
  
  protected ˌᔹ(int paramInt, ʻล paramʻล, ᴵઽ paramᴵઽ) {
    super(paramInt, paramʻล);
    this.ᐨẏ = paramᴵઽ;
  }
  
  public final void ʿᵉ(String paramString) {
    super.ʿᵉ(this.ᐨẏ.ᴵʖ(paramString));
  }
  
  public final void ʹﮃ(String paramString) {
    super.ʹﮃ(paramString = paramString);
  }
  
  public final void ᐨẏ(String paramString1, int paramInt, String paramString2) {
    super.ᐨẏ(paramString1 = paramString1, paramInt, paramString2);
  }
  
  public final void ᐨẏ(String paramString, int paramInt, String... paramVarArgs) {
    String[] arrayOfString = null;
    if (paramVarArgs != null) {
      arrayOfString = new String[paramVarArgs.length];
      for (byte b = 0; b < paramVarArgs.length; b++)
        String str1 = paramVarArgs[b]; 
    } 
    String str;
    super.ᐨẏ(str = paramString, paramInt, arrayOfString);
  }
  
  public final void ˊ(String paramString, int paramInt, String... paramVarArgs) {
    String[] arrayOfString = null;
    if (paramVarArgs != null) {
      arrayOfString = new String[paramVarArgs.length];
      for (byte b = 0; b < paramVarArgs.length; b++)
        String str1 = paramVarArgs[b]; 
    } 
    String str;
    super.ˊ(str = paramString, paramInt, arrayOfString);
  }
  
  public final void ՙᗮ(String paramString) {
    super.ՙᗮ(this.ᐨẏ.ᴵʖ(paramString));
  }
  
  public final void ᐨẏ(String paramString, String... paramVarArgs) {
    String[] arrayOfString = new String[paramVarArgs.length];
    for (byte b = 0; b < paramVarArgs.length; b++)
      arrayOfString[b] = this.ᐨẏ.ᴵʖ(paramVarArgs[b]); 
    super.ᐨẏ(this.ᐨẏ.ᴵʖ(paramString), arrayOfString);
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ˌᔹ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */