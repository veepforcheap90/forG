package yyds.sniarbtej;

import java.util.LinkedHashMap;

final class ˋᴷ implements ʿн<T> {
  ˋᴷ(ˍʶ paramˍʶ) {}
  
  public final T ʿᵉ() {
    return (T)new LinkedHashMap<>();
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ˋᴷ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */