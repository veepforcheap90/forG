package yyds.sniarbtej;

import java.io.File;
import java.lang.instrument.Instrumentation;

public final class ˌᒥ {
  private final String ᐝт;
  
  private final String ˏﬤ;
  
  private final String ɟ;
  
  private final File ᐨẏ;
  
  final File ˊ;
  
  final boolean ˎᴗ;
  
  final Instrumentation ᐨẏ;
  
  private ˌᒥ(Instrumentation paramInstrumentation, File paramFile, boolean paramBoolean) {
    this(paramInstrumentation, paramFile, null, paramBoolean);
  }
  
  public ˌᒥ(Instrumentation paramInstrumentation, File paramFile, String paramString, boolean paramBoolean) {
    this.ᐨẏ = paramInstrumentation;
    this.ˊ = paramFile;
    this.ᐨẏ = (Instrumentation)paramFile.getParentFile();
    String str = paramString;
    if ((str == null || str.isEmpty())) {
      this.ɟ = "";
    } else {
      this.ɟ = paramString.toLowerCase();
    } 
    this.ᐝт = ᐧᎰ.ـﭔ();
    "븯䰊큚移뤴缕⢪".toCharArray()[7] = (char)("븯䰊큚移뤴缕⢪".toCharArray()[7] ^ 0x78B2);
    this.ˏﬤ = ˏȓ$ᴵЃ.E("븯䰊큚移뤴缕⢪".toCharArray(), (short)17819, (short)1, (short)5);
    this.ˎᴗ = paramBoolean;
    ͺבּ.ˊ(this);
  }
  
  private String ˍ() {
    return this.ᐝт;
  }
  
  private String ʹō() {
    return this.ˏﬤ;
  }
  
  private String ᐝᵣ() {
    return this.ɟ;
  }
  
  private File ᐨẏ() {
    return (File)this.ᐨẏ;
  }
  
  public final File ˊ() {
    return this.ˊ;
  }
  
  public final boolean ˌх() {
    return this.ˎᴗ;
  }
  
  private boolean ιﾌ() {
    return !this.ˎᴗ;
  }
  
  public final Instrumentation ᐨẏ() {
    return this.ᐨẏ;
  }
  
  public final String toString() {
    "料奀胈鳨芸ᜄⳖ샨㑎쒆灜ꅰ݈⧺䦚鉃?갓깹厖褐箑⊌".toCharArray()[3] = (char)("料奀胈鳨芸ᜄⳖ샨㑎쒆灜ꅰ݈⧺䦚鉃?갓깹厖褐箑⊌".toCharArray()[3] ^ 0x5BDA);
    "ꋘ힦䐑ܧ鳀瘤숅愻ᎁ꽍樯탲灛翋".toCharArray()[9] = (char)("ꋘ힦䐑ܧ鳀瘤숅愻ᎁ꽍樯탲灛翋".toCharArray()[9] ^ 0x24FF);
    "솹艀ᨤ糦奄і粞䂺⡯ନ".toCharArray()[2] = (char)("솹艀ᨤ糦奄і粞䂺⡯ନ".toCharArray()[2] ^ 0xE6);
    "❇慽桐斋트樍狥‰র冧侞ႀ".toCharArray()[6] = (char)("❇慽桐斋트樍狥‰র冧侞ႀ".toCharArray()[6] ^ 0x1C22);
    "㜂ꔊ镃些鈰┚妗ᔭ襉?䂬甧⶯㙵곭畍".toCharArray()[10] = (char)("㜂ꔊ镃些鈰┚妗ᔭ襉?䂬甧⶯㙵곭畍".toCharArray()[10] ^ 0x4116);
    "⁅웚㏫룊봤꽸Ⰹ玽緍겧渡㲕☲䯉킵媙䄓".toCharArray()[4] = (char)("⁅웚㏫룊봤꽸Ⰹ玽緍겧渡㲕☲䯉킵媙䄓".toCharArray()[4] ^ 0x9C1);
    "梁Ҩ".toCharArray()[1] = (char)("梁Ҩ".toCharArray()[1] ^ 0x4140);
    return ᐝᵣ$ﾞﾇ.j("料奀胈鳨芸ᜄⳖ샨㑎쒆灜ꅰ݈⧺䦚鉃?갓깹厖褐箑⊌".toCharArray(), (short)23380, 0, (short)1) + this.ᐝт + ᐝᵣ$ﾞﾇ.j("ꋘ힦䐑ܧ鳀瘤숅愻ᎁ꽍樯탲灛翋".toCharArray(), (short)12038, 1, (short)4) + this.ˏﬤ + ᐝᵣ$ﾞﾇ.j("솹艀ᨤ糦奄і粞䂺⡯ନ".toCharArray(), (short)6917, 1, (short)2) + this.ɟ + ᐝᵣ$ﾞﾇ.j("❇慽桐斋트樍狥‰র冧侞ႀ".toCharArray(), (short)31571, 0, (short)5) + this.ᐨẏ + ᐝᵣ$ﾞﾇ.j("㜂ꔊ镃些鈰┚妗ᔭ襉?䂬甧⶯㙵곭畍".toCharArray(), (short)2699, 5, (short)5) + this.ˊ + ᐝᵣ$ﾞﾇ.j("⁅웚㏫룊봤꽸Ⰹ玽緍겧渡㲕☲䯉킵媙䄓".toCharArray(), (short)30988, 0, (short)4) + this.ˎᴗ + ᐝᵣ$ﾞﾇ.j("梁Ҩ".toCharArray(), (short)6125, 1, (short)4);
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ˌᒥ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */