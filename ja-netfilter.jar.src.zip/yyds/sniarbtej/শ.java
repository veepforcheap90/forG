package yyds.sniarbtej;

import java.util.TreeMap;

final class শ implements ʿн<T> {
  শ(ˍʶ paramˍʶ) {}
  
  public final T ʿᵉ() {
    return (T)new TreeMap<>();
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\শ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */