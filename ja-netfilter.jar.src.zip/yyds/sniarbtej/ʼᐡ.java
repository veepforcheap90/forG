package yyds.sniarbtej;

public final class ʼᐡ extends ʼᵖ {
  private ᴵઽ ᐨẏ;
  
  private ʼᐡ(ʼᵖ paramʼᵖ, ᴵઽ paramᴵઽ) {
    this(589824, paramʼᵖ, paramᴵઽ);
  }
  
  protected ʼᐡ(int paramInt, ʼᵖ paramʼᵖ, ᴵઽ paramᴵઽ) {
    super(paramInt, paramʼᵖ);
    this.ᐨẏ = paramᴵઽ;
  }
  
  public final ᐨẏ ᐨẏ(String paramString, boolean paramBoolean) {
    ᐨẏ ᐨẏ;
    return ((ᐨẏ = super.ᐨẏ(this.ᐨẏ.ˊ(paramString), paramBoolean)) == null) ? null : ᐨẏ(paramString, ᐨẏ);
  }
  
  public final ᐨẏ ᐨẏ(int paramInt, ˏɪ paramˏɪ, String paramString, boolean paramBoolean) {
    ᐨẏ ᐨẏ;
    return ((ᐨẏ = super.ᐨẏ(paramInt, paramˏɪ, this.ᐨẏ.ˊ(paramString), paramBoolean)) == null) ? null : ᐨẏ(paramString, ᐨẏ);
  }
  
  @Deprecated
  private ᐨẏ ᐨẏ(ᐨẏ paramᐨẏ) {
    return new ʴ(this.ᐨẏ, null, paramᐨẏ, this.ᐨẏ);
  }
  
  private ᐨẏ ᐨẏ(String paramString, ᐨẏ paramᐨẏ) {
    return (new ʴ(this.ᐨẏ, paramString, paramᐨẏ, this.ᐨẏ)).ˊ(ᐨẏ(paramᐨẏ));
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ʼᐡ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */