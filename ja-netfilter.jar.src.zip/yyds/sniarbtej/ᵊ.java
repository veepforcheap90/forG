package yyds.sniarbtej;

import java.util.LinkedList;

final class ᵊ implements ʿн<T> {
  ᵊ(ˍʶ paramˍʶ) {}
  
  public final T ʿᵉ() {
    return (T)new LinkedList();
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ᵊ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */