package yyds.sniarbtej;

import ylt.pmn.zubdqvgt;

public final class ﹳه implements ן {
  public static final ﹳه ᐨẏ = new ﹳه(null);
  
  public static final ﹳه ˊ = new ﹳه(ˑܘ.ʹﮃ);
  
  public static final ﹳه ᴵʖ = new ﹳه(ˑܘ.ՙᗮ);
  
  public static final ﹳه ﾞл = new ﹳه(ˑܘ.ˍɫ);
  
  public static final ﹳه ʿᵉ = new ﹳه(ˑܘ.ʽ);
  
  public static final ﹳه ʹﮃ = new ﹳه(ˑܘ.ˊ(ˏȓ$ᴵЃ.E("긿怣᩺焜뗽ﲀ䋖싅ⶠ፧ꃲ錻獀뢶⥺".toCharArray(), (short)29905, (short)4, (short)3)));
  
  public static final ﹳه ՙᗮ = new ﹳه(ˑܘ.ᐨẏ);
  
  final ˑܘ ˌ;
  
  public ﹳه(ˑܘ paramˑܘ) {
    this.ˌ = paramˑܘ;
  }
  
  public final ˑܘ ᴵʖ() {
    return this.ˌ;
  }
  
  public final int ˍɫ() {
    return (zubdqvgt.G(this.ˌ, ˑܘ.ˍɫ) || zubdqvgt.G(this.ˌ, ˑܘ.ʽ)) ? 2 : 1;
  }
  
  public final boolean ʾܪ() {
    return (this.ˌ != null && (this.ˌ.ˉｓ() == 10 || this.ˌ.ˉｓ() == 9));
  }
  
  public final boolean equals(Object paramObject) {
    return zubdqvgt.G(paramObject, this) ? true : ((paramObject instanceof ﹳه) ? ((this.ˌ == null) ? ((((ﹳه)paramObject).ˌ == null)) : this.ˌ.equals(((ﹳه)paramObject).ˌ)) : false);
  }
  
  public final int hashCode() {
    return (this.ˌ == null) ? 0 : this.ˌ.hashCode();
  }
  
  public final String toString() {
    if (zubdqvgt.G(this, ᐨẏ)) {
      "⺒ၳ".toCharArray()[0] = (char)("⺒ၳ".toCharArray()[0] ^ 0x8D4);
      return ˏȓ$ᴵЃ.E("⺒ၳ".toCharArray(), (short)12266, (short)2, (short)1);
    } 
    if (zubdqvgt.G(this, ՙᗮ)) {
      "濈喗".toCharArray()[0] = (char)("濈喗".toCharArray()[0] ^ 0x7B2C);
      return ˏȓ$ᴵЃ.E("濈喗".toCharArray(), (short)15853, (short)0, (short)1);
    } 
    if (zubdqvgt.G(this, ʹﮃ)) {
      "䍱ሯ".toCharArray()[0] = (char)("䍱ሯ".toCharArray()[0] ^ 0x1C62);
      return ˏȓ$ᴵЃ.E("䍱ሯ".toCharArray(), (short)22902, (short)3, (short)0);
    } 
    return this.ˌ.ᴵʖ();
  }
  
  static {
    "긿怣᩺焜뗽ﲀ䋖싅ⶠ፧ꃲ錻獀뢶⥺".toCharArray()[5] = (char)("긿怣᩺焜뗽ﲀ䋖싅ⶠ፧ꃲ錻獀뢶⥺".toCharArray()[5] ^ 0x4BBF);
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ﹳه.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */