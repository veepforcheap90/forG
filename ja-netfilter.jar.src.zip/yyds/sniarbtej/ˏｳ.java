package yyds.sniarbtej;

import java.util.Comparator;

final class ˏｳ implements Comparator<ˌț> {
  ˏｳ(গ paramগ) {}
  
  private int ᐨẏ(ˌț paramˌț1, ˌț paramˌț2) {
    return ᐨẏ(paramˌț1) - ᐨẏ(paramˌț2);
  }
  
  private int ᐨẏ(ˌț paramˌț) {
    int j = this.ᐨẏ.ˊ.ᐨẏ(paramˌț.ᴵʖ);
    int i;
    return (i = this.ᐨẏ.ˊ.ᐨẏ(paramˌț.ﾞл)) - j;
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ˏｳ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */