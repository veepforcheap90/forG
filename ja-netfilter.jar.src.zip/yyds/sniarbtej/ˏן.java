package yyds.sniarbtej;

import ylt.pmn.zubdqvgt;

final class ˏן extends ٴۉ<StringBuffer> {
  private static StringBuffer ᐨẏ(יּ paramיּ) {
    if (zubdqvgt.G(paramיּ.ᐨẏ(), כ.ʽ)) {
      paramיּ.ۦ();
      return null;
    } 
    return new StringBuffer(paramיּ.ٴӵ());
  }
  
  private static void ᐨẏ(Ⴡ paramჁ, StringBuffer paramStringBuffer) {
    paramჁ.ˊ((paramStringBuffer == null) ? null : paramStringBuffer.toString());
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ˏן.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */