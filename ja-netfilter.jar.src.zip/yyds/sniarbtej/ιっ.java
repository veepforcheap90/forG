package yyds.sniarbtej;

import java.util.Map;

final class ιっ extends ˊᐹ {
  ιっ(ᴵܚ paramᴵܚ) {
    super(paramᴵܚ.ᐨẏ, (byte)0);
  }
  
  private Map.Entry<K, V> ᐨẏ() {
    return ᴵʖ();
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ιっ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */