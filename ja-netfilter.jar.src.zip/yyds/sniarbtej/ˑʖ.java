package yyds.sniarbtej;

public class ˑʖ extends RuntimeException {
  private static long ᐨẏ = -4086729973971783390L;
  
  public ˑʖ(String paramString) {
    super(paramString);
  }
  
  public ˑʖ(String paramString, Throwable paramThrowable) {
    super(paramString, paramThrowable);
  }
  
  public ˑʖ(Throwable paramThrowable) {
    super(paramThrowable);
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ˑʖ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */