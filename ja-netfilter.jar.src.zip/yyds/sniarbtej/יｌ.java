package yyds.sniarbtej;

public final class יｌ extends ͺᔮ {
  public final String ᔪ() {
    "܁᭏ឬꨓ洱⑏㯞㡯쓷栌ᑏ짬鼖佮렪㌩⤔ﾄ僽?䭞큻运䏕".toCharArray()[9] = (char)("܁᭏ឬꨓ洱⑏㯞㡯쓷栌ᑏ짬鼖佮렪㌩⤔ﾄ僽?䭞큻运䏕".toCharArray()[9] ^ 0x3BF6);
    return ˍɫ$יς.J("܁᭏ឬꨓ洱⑏㯞㡯쓷栌ᑏ짬鼖佮렪㌩⤔ﾄ僽?䭞큻运䏕".toCharArray(), (short)8052, (short)2, (byte)4);
  }
  
  public final byte[] ˍɫ(byte[] paramArrayOfbyte) {
    return ᐨẏ(paramArrayOfbyte, paramᐧє -> {
          "뵨?봗㯠ꣿ??ᖛ≃溄⇉爠".toCharArray()[4] = (char)("뵨?봗㯠ꣿ??ᖛ≃溄⇉爠".toCharArray()[4] ^ 0xFB7);
          "腨㡻紿".toCharArray()[2] = (char)("腨㡻紿".toCharArray()[2] ^ 0x4315);
          if (ˍɫ$יς.J("뵨?봗㯠ꣿ??ᖛ≃溄⇉爠".toCharArray(), (short)2646, (short)1, (byte)0).equals(paramᐧє.name) && ˍɫ$יς.J("腨㡻紿".toCharArray(), (short)3429, (short)1, (byte)0).equals(paramᐧє.ˎᴗ)) {
            ـс ـс;
            (ـс = new ـс()).ᐨẏ(new ᕁ(25, 0));
            "㧞蔈᝷".toCharArray()[0] = (char)("㧞蔈᝷".toCharArray()[0] ^ 0x70B5);
            "⏹ᆄ䟠⦶릗꒫媢젬珰㥎䭲훜ঙ㽷ツ偌锣仝Ღ졠࿙".toCharArray()[11] = (char)("⏹ᆄ䟠⦶릗꒫媢젬珰㥎䭲훜ঙ㽷ツ偌锣仝Ღ졠࿙".toCharArray()[11] ^ 0x5CBC);
            ـс.ᐨẏ(new ʾᔂ(184, ן, ˍɫ$יς.J("㧞蔈᝷".toCharArray(), (short)1295, (short)1, (byte)5), ˍɫ$יς.J("⏹ᆄ䟠⦶릗꒫媢젬珰㥎䭲훜ঙ㽷ツ偌锣仝Ღ졠࿙".toCharArray(), (short)4361, (short)4, (byte)4), false));
            paramᐧє.ˊ.ˊ(ـс);
          } 
        });
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\יｌ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */