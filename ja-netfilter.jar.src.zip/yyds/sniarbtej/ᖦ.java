package yyds.sniarbtej;

abstract class ᖦ {
  final String name;
  
  final boolean ʻᒱ;
  
  final boolean ﹳܕ;
  
  protected ᖦ(String paramString, boolean paramBoolean1, boolean paramBoolean2) {
    this.name = paramString;
    this.ʻᒱ = paramBoolean1;
    this.ﹳܕ = paramBoolean2;
  }
  
  abstract boolean ˊ(Object paramObject);
  
  abstract void ᐨẏ(Ⴡ paramჁ, Object paramObject);
  
  abstract void ᐨẏ(יּ paramיּ, Object paramObject);
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ᖦ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */