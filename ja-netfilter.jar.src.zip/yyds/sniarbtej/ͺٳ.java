package yyds.sniarbtej;

public abstract class ͺٳ {
  private static int ՙﮞ = -1;
  
  private static int ˎﮈ = 76;
  
  private static int ʻᴋ = 64;
  
  private static final int ʹᵋ = 2;
  
  private static final int ᐝᔄ = 8192;
  
  private static int ﾞҭ = 255;
  
  private static byte ᐨẏ = 61;
  
  @Deprecated
  private byte ˊ = 61;
  
  protected final byte ᴵʖ;
  
  private final int ˍ々;
  
  private final int ﾞᵤ;
  
  protected final int ͺʢ;
  
  private final int ʽỲ;
  
  protected ͺٳ(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    this(3, 4, paramInt3, paramInt4, (byte)61);
  }
  
  private ͺٳ(int paramInt1, int paramInt2, int paramInt3, int paramInt4, byte paramByte) {
    this.ˍ々 = paramInt1;
    this.ﾞᵤ = paramInt2;
    paramInt1 = (paramInt3 > 0 && paramInt4 > 0) ? 1 : 0;
    this.ͺʢ = (paramInt1 != 0) ? (paramInt3 / paramInt2 * paramInt2) : 0;
    this.ʽỲ = paramInt4;
    this.ᴵʖ = 61;
  }
  
  private static boolean ᐨẏ(ઽ paramઽ) {
    return (paramઽ.ͺо != null);
  }
  
  private static int ᐨẏ(ઽ paramઽ) {
    return (paramઽ.ͺо != null) ? (paramઽ.ˑﮌ - paramઽ.ˏǐ) : 0;
  }
  
  private static int ᵕ() {
    return 8192;
  }
  
  private byte[] ᐨẏ(ઽ paramઽ) {
    if (paramઽ.ͺо == null) {
      paramઽ.ͺо = new byte[8192];
      paramઽ.ˑﮌ = 0;
      paramઽ.ˏǐ = 0;
    } else {
      byte[] arrayOfByte = new byte[paramઽ.ͺо.length << 1];
      System.arraycopy(paramઽ.ͺо, 0, arrayOfByte, 0, paramઽ.ͺо.length);
      paramઽ.ͺо = arrayOfByte;
    } 
    return paramઽ.ͺо;
  }
  
  protected final byte[] ᐨẏ(int paramInt, ઽ paramઽ) {
    if (paramઽ.ͺо == null || paramઽ.ͺо.length < paramઽ.ˑﮌ + paramInt) {
      paramઽ = paramઽ;
      ͺٳ ͺٳ1 = this;
      if (paramઽ.ͺо == null) {
        paramઽ.ͺо = new byte[8192];
        paramઽ.ˑﮌ = 0;
        paramઽ.ˏǐ = 0;
      } else {
        byte[] arrayOfByte = new byte[paramઽ.ͺо.length << 1];
        System.arraycopy(paramઽ.ͺо, 0, arrayOfByte, 0, paramઽ.ͺо.length);
        paramઽ.ͺо = arrayOfByte;
      } 
      return paramઽ.ͺо;
    } 
    return paramઽ.ͺо;
  }
  
  private int ᐨẏ(byte[] paramArrayOfbyte, int paramInt1, int paramInt2, ઽ paramઽ) {
    if (paramઽ.ͺо != null) {
      ઽ ઽ1;
      int i = Math.min(((ઽ1 = paramઽ).ͺо != null) ? (ઽ1.ˑﮌ - ઽ1.ˏǐ) : 0, paramInt2);
      System.arraycopy(paramઽ.ͺо, paramઽ.ˏǐ, paramArrayOfbyte, 0, i);
      paramઽ.ˏǐ += i;
      if (paramઽ.ˏǐ >= paramઽ.ˑﮌ)
        paramઽ.ͺо = null; 
      return i;
    } 
    return paramઽ.ᵕ ? -1 : 0;
  }
  
  protected static boolean ᴵʖ(byte paramByte) {
    switch (paramByte) {
      case 9:
      case 10:
      case 13:
      case 32:
        return true;
    } 
    return false;
  }
  
  private Object ᴵʖ(Object paramObject) {
    if (!(paramObject instanceof byte[])) {
      "䞣奃䙁ꢻ빢扆垧✛졃녞ᵏ㟍꿰Ⳣɕ檇⩕麎쥤峿岷?滳⺲戢后禲㬅燣爵夲㳞㰁壪堎妥嵣ԏ⤠㦹ꀂ쎆欎ᛕ〄뮂ߐؓ⽣".toCharArray()[50] = (char)("䞣奃䙁ꢻ빢扆垧✛졃녞ᵏ㟍꿰Ⳣɕ檇⩕麎쥤峿岷?滳⺲戢后禲㬅燣爵夲㳞㰁壪堎妥嵣ԏ⤠㦹ꀂ쎆欎ᛕ〄뮂ߐؓ⽣".toCharArray()[50] ^ 0x22C9);
      throw new ᐝﻠ(ᐝᵣ$ﾞﾇ.j("䞣奃䙁ꢻ빢扆垧✛졃녞ᵏ㟍꿰Ⳣɕ檇⩕麎쥤峿岷?滳⺲戢后禲㬅燣爵夲㳞㰁壪堎妥嵣ԏ⤠㦹ꀂ쎆欎ᛕ〄뮂ߐؓ⽣".toCharArray(), (short)30017, 1, (short)4));
    } 
    return ՙᗮ((byte[])paramObject);
  }
  
  private String ﾞл(byte[] paramArrayOfbyte) {
    return ˈօ.ᐨẏ(paramArrayOfbyte = ՙᗮ(paramArrayOfbyte), ˑ一.ʹﮃ);
  }
  
  private String ʿᵉ(byte[] paramArrayOfbyte) {
    return ˈօ.ᐨẏ(paramArrayOfbyte = ՙᗮ(paramArrayOfbyte), ˑ一.ʹﮃ);
  }
  
  private Object ﾞл(Object paramObject) {
    if (paramObject instanceof byte[])
      return ʹﮃ((byte[])paramObject); 
    if (paramObject instanceof String)
      return ˊ((String)paramObject); 
    "風鶷᳋伀ᤥ蝍앯꩛쫼더腡퐟ૼࣁ뚅쀀௺蠓켿謰揜虥ꐈ㳡꟰ｷ㛢嗔ᑮ럵૘ꚙ㽍㺗?ﭪ誤慶菂ඞ᪵༟飽圚邯０種采⥐遃㋞邓Է撊ꅤ뮖䌂截".toCharArray()[62] = (char)("風鶷᳋伀ᤥ蝍앯꩛쫼더腡퐟ૼࣁ뚅쀀௺蠓켿謰揜虥ꐈ㳡꟰ｷ㛢嗔ᑮ럵૘ꚙ㽍㺗?ﭪ誤慶菂ඞ᪵༟飽圚邯０種采⥐遃㋞邓Է撊ꅤ뮖䌂截".toCharArray()[62] ^ 0x7A75);
    throw new ᓵ(ᐝᵣ$ﾞﾇ.j("風鶷᳋伀ᤥ蝍앯꩛쫼더腡퐟ૼࣁ뚅쀀௺蠓켿謰揜虥ꐈ㳡꟰ｷ㛢嗔ᑮ럵૘ꚙ㽍㺗?ﭪ誤慶菂ඞ᪵༟飽圚邯０種采⥐遃㋞邓Է撊ꅤ뮖䌂截".toCharArray(), (short)8579, 4, (short)0));
  }
  
  public final byte[] ˊ(String paramString) {
    return ʹﮃ(ˈօ.ᐨẏ(paramString = paramString, ˑ一.ʹﮃ));
  }
  
  public final byte[] ʹﮃ(byte[] paramArrayOfbyte) {
    if (paramArrayOfbyte == null || paramArrayOfbyte.length == 0)
      return paramArrayOfbyte; 
    ઽ ઽ = new ઽ();
    ˊ(paramArrayOfbyte, 0, paramArrayOfbyte.length, ઽ);
    ˊ(paramArrayOfbyte, 0, -1, ઽ);
    paramArrayOfbyte = new byte[ઽ.ˑﮌ];
    ᐨẏ(paramArrayOfbyte, 0, paramArrayOfbyte.length, ઽ);
    return paramArrayOfbyte;
  }
  
  public final byte[] ՙᗮ(byte[] paramArrayOfbyte) {
    return (paramArrayOfbyte == null || paramArrayOfbyte.length == 0) ? paramArrayOfbyte : ᐨẏ(paramArrayOfbyte, 0, paramArrayOfbyte.length);
  }
  
  private byte[] ᐨẏ(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
    if (paramArrayOfbyte == null || paramArrayOfbyte.length == 0)
      return paramArrayOfbyte; 
    ઽ ઽ = new ઽ();
    ᐨẏ(paramArrayOfbyte, 0, paramInt2, ઽ);
    ᐨẏ(paramArrayOfbyte, 0, -1, ઽ);
    paramArrayOfbyte = new byte[ઽ.ˑﮌ - ઽ.ˏǐ];
    ᐨẏ(paramArrayOfbyte, 0, paramArrayOfbyte.length, ઽ);
    return paramArrayOfbyte;
  }
  
  abstract void ᐨẏ(byte[] paramArrayOfbyte, int paramInt1, int paramInt2, ઽ paramઽ);
  
  abstract void ˊ(byte[] paramArrayOfbyte, int paramInt1, int paramInt2, ઽ paramઽ);
  
  protected abstract boolean ˊ(byte paramByte);
  
  private boolean ᐨẏ(byte[] paramArrayOfbyte, boolean paramBoolean) {
    int i = (paramArrayOfbyte = paramArrayOfbyte).length;
    for (byte b = 0; b < i; b++) {
      byte b1 = paramArrayOfbyte[b];
      if (!ˊ(b1) && b1 != this.ᴵʖ && !ᴵʖ(b1))
        return false; 
    } 
    return true;
  }
  
  private boolean ʿᵉ(String paramString) {
    boolean bool = true;
    byte[] arrayOfByte = ˈօ.ᐨẏ(paramString = paramString, ˑ一.ʹﮃ);
    ͺٳ ͺٳ1 = this;
    int i = (arrayOfByte = arrayOfByte).length;
    for (byte b = 0; b < i; b++) {
      byte b1 = arrayOfByte[b];
      if (!ͺٳ1.ˊ(b1) && b1 != ͺٳ1.ᴵʖ && !ᴵʖ(b1))
        return false; 
    } 
    return true;
  }
  
  protected final boolean ᴵʖ(byte[] paramArrayOfbyte) {
    if (paramArrayOfbyte == null)
      return false; 
    int i = (paramArrayOfbyte = paramArrayOfbyte).length;
    for (byte b = 0; b < i; b++) {
      byte b1 = paramArrayOfbyte[b];
      if (this.ᴵʖ == b1 || ˊ(b1))
        return true; 
    } 
    return false;
  }
  
  public final long ᐨẏ(byte[] paramArrayOfbyte) {
    long l = ((paramArrayOfbyte.length + this.ˍ々 - 1) / this.ˍ々) * this.ﾞᵤ;
    if (this.ͺʢ > 0)
      l += (l + this.ͺʢ - 1L) / this.ͺʢ * this.ʽỲ; 
    return l;
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ͺٳ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */