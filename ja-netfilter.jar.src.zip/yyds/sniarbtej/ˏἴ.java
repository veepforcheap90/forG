package yyds.sniarbtej;

import java.util.Map;

public final class ˏἴ extends Ӏ {
  public Object ʿᵉ;
  
  public ˏἴ(Object paramObject) {
    super(18);
    this.ʿᵉ = paramObject;
  }
  
  public final int ﹳיִ() {
    return 9;
  }
  
  public final void ᐨẏ(ˉｓ paramˉｓ) {
    paramˉｓ.ˊ(this.ʿᵉ);
    ˊ(paramˉｓ);
  }
  
  public final Ӏ ᐨẏ(Map<λ, λ> paramMap) {
    return (new ˏἴ(this.ʿᵉ)).ᐨẏ(this);
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ˏἴ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */