package yyds.sniarbtej;

final class ˊں extends ˉʭ {
  ˊں(int paramInt, ˍɫ paramˍɫ, boolean paramBoolean) {
    super(17432576, paramˍɫ, false);
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ˊں.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */