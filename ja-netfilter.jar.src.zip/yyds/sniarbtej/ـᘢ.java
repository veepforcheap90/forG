package yyds.sniarbtej;

public abstract class ـᘢ {
  private static char ᐨẏ = '+';
  
  private static char ˊ = '-';
  
  private static char ᴵʖ = '=';
  
  private int ᐨẏ;
  
  public ـᘢ(int paramInt) {
    if (paramInt != 589824 && paramInt != 524288 && paramInt != 458752 && paramInt != 393216 && paramInt != 327680 && paramInt != 262144 && paramInt != 17432576) {
      "憂鼽뻄秜㿮㐃ᖠﴌ졋Ϛ좞馍ᵾ꾢䎾颽傍".toCharArray()[5] = (char)("憂鼽뻄秜㿮㐃ᖠﴌ졋Ϛ좞馍ᵾ꾢䎾颽傍".toCharArray()[5] ^ 0x43CA);
      throw new IllegalArgumentException(ˍɫ$יς.J("憂鼽뻄秜㿮㐃ᖠﴌ졋Ϛ좞馍ᵾ꾢䎾颽傍".toCharArray(), (short)5842, (short)0, (byte)1) + paramInt);
    } 
  }
  
  public void ʾ(String paramString) {}
  
  public ـᘢ ˊ() {
    return this;
  }
  
  public ـᘢ ʿᵉ() {
    return this;
  }
  
  public ـᘢ ˍɫ() {
    return this;
  }
  
  public ـᘢ ﾞл() {
    return this;
  }
  
  public ـᘢ ʹﮃ() {
    return this;
  }
  
  public ـᘢ ՙᗮ() {
    return this;
  }
  
  public ـᘢ ᴵʖ() {
    return this;
  }
  
  public void ᐨẏ(char paramChar) {}
  
  public void ͺо(String paramString) {}
  
  public ـᘢ ᐨẏ() {
    return this;
  }
  
  public void ʾܪ(String paramString) {}
  
  public void ᐨم(String paramString) {}
  
  public void ʹл() {}
  
  public ـᘢ ᐨẏ(char paramChar) {
    return this;
  }
  
  public void ᐨẏ() {}
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ـᘢ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */