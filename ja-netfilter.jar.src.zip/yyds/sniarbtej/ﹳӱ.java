package yyds.sniarbtej;

public interface ﹳӱ {
  public static final String ן = ˏȓ.class.getName().replace(ᐝᵣ$ﾞﾇ.j("登".toCharArray(), (short)19068, 0, (short)3), ᐝᵣ$ﾞﾇ.j("?䁯".toCharArray(), (short)30099, 4, (short)4));
  
  public static final int ᐧﭴ = 458752;
  
  boolean ʹﮃ(String paramString);
  
  String ᔪ();
  
  byte[] ˍɫ(byte[] paramArrayOfbyte);
  
  static {
    "登".toCharArray()[0] = (char)("登".toCharArray()[0] ^ 0x4C64);
    "?䁯".toCharArray()[0] = (char)("?䁯".toCharArray()[0] ^ 0x1981);
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ﹳӱ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */