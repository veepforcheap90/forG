package yyds.sniarbtej;

import ylt.pmn.zubdqvgt;

final class ǀ implements ˌ々 {
  ǀ(Class paramClass1, Class paramClass2, ٴۉ paramٴۉ) {}
  
  public final <T> ٴۉ<T> ᐨẏ(ˑĴ paramˑĴ, ʸ<T> paramʸ) {
    Class<? super T> clazz;
    ʸ<T> ʸ1;
    return (zubdqvgt.G(clazz = (ʸ1 = paramʸ).ᐨم, this.ʿᵉ) || zubdqvgt.G(clazz, this.ʹﮃ)) ? this.ﹳיִ : null;
  }
  
  public final String toString() {
    "踋䉱俔䞬?셀䯭⯞䍗弻毤".toCharArray()[10] = (char)("踋䉱俔䞬?셀䯭⯞䍗弻毤".toCharArray()[10] ^ 0x4241);
    "ᰇ䊾".toCharArray()[0] = (char)("ᰇ䊾".toCharArray()[0] ^ 0x4A3B);
    "㦼ଁꝐ敞ཿ沞ďƍ혓睴".toCharArray()[4] = (char)("㦼ଁꝐ敞ཿ沞ďƍ혓睴".toCharArray()[4] ^ 0x3D3B);
    "ὠ⅔".toCharArray()[0] = (char)("ὠ⅔".toCharArray()[0] ^ 0x289C);
    return ᐨẏ$ᐝт.W("踋䉱俔䞬?셀䯭⯞䍗弻毤".toCharArray(), (short)19253, (byte)0, (short)1) + this.ʹﮃ.getName() + ᐨẏ$ᐝт.W("ᰇ䊾".toCharArray(), (short)4873, (byte)5, (short)5) + this.ʿᵉ.getName() + ᐨẏ$ᐝт.W("㦼ଁꝐ敞ཿ沞ďƍ혓睴".toCharArray(), (short)20254, (byte)5, (short)4) + this.ﹳיִ + ᐨẏ$ᐝт.W("ὠ⅔".toCharArray(), (short)17558, (byte)5, (short)3);
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ǀ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */