package yyds.sniarbtej;

public abstract class ˉｓ {
  private static final String ˌᵋ = ˍɫ$יς.J("髚喡頋䫩֯楄㌄뱳뵒?룩͍ⶤ깳Ǣ岱彋㫁撸塳寗㕕莈ᛗ".toCharArray(), (short)4427, (short)4, (byte)3).intern();
  
  protected final int ᐨẏ;
  
  protected ˉｓ ᐨẏ;
  
  public ˉｓ(int paramInt) {
    this(paramInt, null);
  }
  
  public ˉｓ(int paramInt, ˉｓ paramˉｓ) {
    if (paramInt != 589824 && paramInt != 524288 && paramInt != 458752 && paramInt != 393216 && paramInt != 327680 && paramInt != 262144 && paramInt != 17432576) {
      "鴈媶謙埦꒳｜?﭂᦭௉͆흝삎틖ܢ".toCharArray()[12] = (char)("鴈媶謙埦꒳｜?﭂᦭௉͆흝삎틖ܢ".toCharArray()[12] ^ 0x790D);
      throw new IllegalArgumentException(ᐝᵣ$ﾞﾇ.j("鴈媶謙埦꒳｜?﭂᦭௉͆흝삎틖ܢ".toCharArray(), (short)14556, 4, (short)0) + paramInt);
    } 
    if (paramInt == 17432576)
      ᐨم.ᐨẏ(this); 
    this.ᐨẏ = paramInt;
    this.ᐨẏ = paramˉｓ;
  }
  
  private ˉｓ ᐨẏ() {
    return this.ᐨẏ;
  }
  
  public void ᐨẏ(String paramString, int paramInt) {
    if (this.ᐨẏ < 327680) {
      "ꅪ繷뱷丩꾋㕻쎽뉝ᚕ楔?䴹璜뷈ꘖ닒뤷粮픰足侀᜕㶿?橙".toCharArray()[0] = (char)("ꅪ繷뱷丩꾋㕻쎽뉝ᚕ楔?䴹璜뷈ꘖ닒뤷粮픰足侀᜕㶿?橙".toCharArray()[0] ^ 0x6248);
      throw new UnsupportedOperationException(ˉﻤ$ͺſ.v("ꅪ繷뱷丩꾋㕻쎽뉝ᚕ楔?䴹璜뷈ꘖ닒뤷粮픰足侀᜕㶿?橙".toCharArray(), (short)25407, 0, (short)3).intern());
    } 
    if (this.ᐨẏ != null)
      this.ᐨẏ.ᐨẏ(paramString, paramInt); 
  }
  
  public ᐨẏ ˊ() {
    return (this.ᐨẏ != null) ? this.ᐨẏ.ˊ() : null;
  }
  
  public ᐨẏ ᐨẏ(String paramString, boolean paramBoolean) {
    return (this.ᐨẏ != null) ? this.ᐨẏ.ᐨẏ(paramString, paramBoolean) : null;
  }
  
  public ᐨẏ ᐨẏ(int paramInt, ˏɪ paramˏɪ, String paramString, boolean paramBoolean) {
    if (this.ᐨẏ < 327680) {
      "ꓧⲦ倷陥긿ᅘ뭇⹖ꔩ䂛㜮⤻ࠦ᮰ߙ燱䨣ቂ쀄뉆ໆᕟ쯁愤議癯".toCharArray()[21] = (char)("ꓧⲦ倷陥긿ᅘ뭇⹖ꔩ䂛㜮⤻ࠦ᮰ߙ燱䨣ቂ쀄뉆ໆᕟ쯁愤議癯".toCharArray()[21] ^ 0x1F0A);
      throw new UnsupportedOperationException(ᐨẏ$ᐝт.W("ꓧⲦ倷陥긿ᅘ뭇⹖ꔩ䂛㜮⤻ࠦ᮰ߙ燱䨣ቂ쀄뉆ໆᕟ쯁愤議癯".toCharArray(), (short)32060, (byte)2, (short)2).intern());
    } 
    return (this.ᐨẏ != null) ? this.ᐨẏ.ᐨẏ(paramInt, paramˏɪ, paramString, paramBoolean) : null;
  }
  
  public void ᐨẏ(int paramInt, boolean paramBoolean) {
    if (this.ᐨẏ != null)
      this.ᐨẏ.ᐨẏ(paramInt, paramBoolean); 
  }
  
  public ᐨẏ ᐨẏ(int paramInt, String paramString, boolean paramBoolean) {
    return (this.ᐨẏ != null) ? this.ᐨẏ.ᐨẏ(paramInt, paramString, paramBoolean) : null;
  }
  
  public void ᴵʖ(ᴵʖ paramᴵʖ) {
    if (this.ᐨẏ != null)
      this.ᐨẏ.ᴵʖ(paramᴵʖ); 
  }
  
  public void ᴵʖ() {
    if (this.ᐨẏ != null)
      this.ᐨẏ.ᴵʖ(); 
  }
  
  public void ᐨẏ(int paramInt1, int paramInt2, Object[] paramArrayOfObject1, int paramInt3, Object[] paramArrayOfObject2) {
    if (this.ᐨẏ != null)
      this.ᐨẏ.ᐨẏ(paramInt1, paramInt2, paramArrayOfObject1, paramInt3, paramArrayOfObject2); 
  }
  
  public void ʹﮃ(int paramInt) {
    if (this.ᐨẏ != null)
      this.ᐨẏ.ʹﮃ(paramInt); 
  }
  
  public void ˊ(int paramInt1, int paramInt2) {
    if (this.ᐨẏ != null)
      this.ᐨẏ.ˊ(paramInt1, paramInt2); 
  }
  
  public void ᴵʖ(int paramInt1, int paramInt2) {
    if (this.ᐨẏ != null)
      this.ᐨẏ.ᴵʖ(paramInt1, paramInt2); 
  }
  
  public void ᐨẏ(int paramInt, String paramString) {
    if (this.ᐨẏ != null)
      this.ᐨẏ.ᐨẏ(paramInt, paramString); 
  }
  
  public void ᐨẏ(int paramInt, String paramString1, String paramString2, String paramString3) {
    if (this.ᐨẏ != null)
      this.ᐨẏ.ᐨẏ(paramInt, paramString1, paramString2, paramString3); 
  }
  
  @Deprecated
  public final void ˊ(int paramInt, String paramString1, String paramString2, String paramString3) {
    int i = paramInt | ((this.ᐨẏ < 327680) ? 256 : 0);
    ᐨẏ(i, paramString1, paramString2, paramString3, (paramInt == 185));
  }
  
  public void ᐨẏ(int paramInt, String paramString1, String paramString2, String paramString3, boolean paramBoolean) {
    if (this.ᐨẏ < 327680 && (paramInt & 0x100) == 0) {
      if (paramBoolean != ((paramInt == 185))) {
        "䯑?䋞Ⱟࠪퟕ夝鎧頽ⷦ淎̠隷ῇዘ鎄ﳱ爅⮣綘孡ꂞ̶඲ᔞꀩᯞⅬ뗶醉쀛쪌Ⰺ돱嫧?बꋪ뇚⊷᜾Ⓦ휶﹗䛆".toCharArray()[22] = (char)("䯑?䋞Ⱟࠪퟕ夝鎧頽ⷦ淎̠隷ῇዘ鎄ﳱ爅⮣綘孡ꂞ̶඲ᔞꀩᯞⅬ뗶醉쀛쪌Ⰺ돱嫧?बꋪ뇚⊷᜾Ⓦ휶﹗䛆".toCharArray()[22] ^ 0x5590);
        throw new UnsupportedOperationException(ˉﻤ$ͺſ.v("䯑?䋞Ⱟࠪퟕ夝鎧頽ⷦ淎̠隷ῇዘ鎄ﳱ爅⮣綘孡ꂞ̶඲ᔞꀩᯞⅬ뗶醉쀛쪌Ⰺ돱嫧?बꋪ뇚⊷᜾Ⓦ휶﹗䛆".toCharArray(), (short)23357, 1, (short)0));
      } 
      ˊ(paramInt, paramString1, paramString2, paramString3);
      return;
    } 
    if (this.ᐨẏ != null)
      this.ᐨẏ.ᐨẏ(paramInt & 0xFFFFFEFF, paramString1, paramString2, paramString3, paramBoolean); 
  }
  
  public void ᐨẏ(String paramString1, String paramString2, ʹō paramʹō, Object... paramVarArgs) {
    if (this.ᐨẏ < 327680) {
      "隂歜圽⪁咎뀈纲땂퀼鯲烅稝ྕ헲艦泹袓択?㷰ꍧ?䟤珉尃ꤙ忆".toCharArray()[3] = (char)("隂歜圽⪁咎뀈纲땂퀼鯲烅稝ྕ헲艦泹袓択?㷰ꍧ?䟤珉尃ꤙ忆".toCharArray()[3] ^ 0x125E);
      throw new UnsupportedOperationException(ᐨẏ$ᐝт.W("隂歜圽⪁咎뀈纲땂퀼鯲烅稝ྕ헲艦泹袓択?㷰ꍧ?䟤珉尃ꤙ忆".toCharArray(), (short)16479, (byte)4, (short)4).intern());
    } 
    if (this.ᐨẏ != null)
      this.ᐨẏ.ᐨẏ(paramString1, paramString2, paramʹō, paramVarArgs); 
  }
  
  public void ᐨẏ(int paramInt, ᔪ paramᔪ) {
    if (this.ᐨẏ != null)
      this.ᐨẏ.ᐨẏ(paramInt, paramᔪ); 
  }
  
  public void ˊ(ᔪ paramᔪ) {
    if (this.ᐨẏ != null)
      this.ᐨẏ.ˊ(paramᔪ); 
  }
  
  public void ˊ(Object paramObject) {
    if (this.ᐨẏ < 327680 && (paramObject instanceof ʹō || (paramObject instanceof ˑܘ && ((ˑܘ)paramObject).ˉｓ() == 11))) {
      "֌퐿ꐋ硽嫔ꑯ뿺㟶㇑碭䯘ࣇ籒ꯊ窢↸嚙随釆喝뭣ꢲ䪉벝긻渥".toCharArray()[4] = (char)("֌퐿ꐋ硽嫔ꑯ뿺㟶㇑碭䯘ࣇ籒ꯊ窢↸嚙随釆喝뭣ꢲ䪉벝긻渥".toCharArray()[4] ^ 0x7F5F);
      throw new UnsupportedOperationException(ᐝᵣ$ﾞﾇ.j("֌퐿ꐋ硽嫔ꑯ뿺㟶㇑碭䯘ࣇ籒ꯊ窢↸嚙随釆喝뭣ꢲ䪉벝긻渥".toCharArray(), (short)29721, 3, (short)5).intern());
    } 
    if (this.ᐨẏ < 458752 && paramObject instanceof ʾܪ) {
      "픦鵬ਏ㻙훯芁붫﬏⫁יִ㳍컒꠩飝ぬ耹⯪辜ЩⰝ⣆췶ﵢ䥃".toCharArray()[12] = (char)("픦鵬ਏ㻙훯芁붫﬏⫁יִ㳍컒꠩飝ぬ耹⯪辜ЩⰝ⣆췶ﵢ䥃".toCharArray()[12] ^ 0x35A2);
      throw new UnsupportedOperationException(ᐝᵣ$ﾞﾇ.j("픦鵬ਏ㻙훯芁붫﬏⫁יִ㳍컒꠩飝ぬ耹⯪辜ЩⰝ⣆췶ﵢ䥃".toCharArray(), (short)21843, 2, (short)3));
    } 
    if (this.ᐨẏ != null)
      this.ᐨẏ.ˊ(paramObject); 
  }
  
  public void ﾞл(int paramInt1, int paramInt2) {
    if (this.ᐨẏ != null)
      this.ᐨẏ.ﾞл(paramInt1, paramInt2); 
  }
  
  public void ᐨẏ(int paramInt1, int paramInt2, ᔪ paramᔪ, ᔪ... paramVarArgs) {
    if (this.ᐨẏ != null)
      this.ᐨẏ.ᐨẏ(paramInt1, paramInt2, paramᔪ, paramVarArgs); 
  }
  
  public void ᐨẏ(ᔪ paramᔪ, int[] paramArrayOfint, ᔪ[] paramArrayOfᔪ) {
    if (this.ᐨẏ != null)
      this.ᐨẏ.ᐨẏ(paramᔪ, paramArrayOfint, paramArrayOfᔪ); 
  }
  
  public void ˊ(String paramString, int paramInt) {
    if (this.ᐨẏ != null)
      this.ᐨẏ.ˊ(paramString, paramInt); 
  }
  
  public ᐨẏ ˊ(int paramInt, ˏɪ paramˏɪ, String paramString, boolean paramBoolean) {
    if (this.ᐨẏ < 327680) {
      "?㲕ﴹ飨ᘱ쵐吜畁⿸鮁⎓䈨毳턩牊?振ࠠ稌䑠彳ኔ嵯".toCharArray()[12] = (char)("?㲕ﴹ飨ᘱ쵐吜畁⿸鮁⎓䈨毳턩牊?振ࠠ稌䑠彳ኔ嵯".toCharArray()[12] ^ 0x70E3);
      throw new UnsupportedOperationException(ᐝᵣ$ﾞﾇ.j("?㲕ﴹ飨ᘱ쵐吜畁⿸鮁⎓䈨毳턩牊?振ࠠ稌䑠彳ኔ嵯".toCharArray(), (short)1302, 3, (short)0).intern());
    } 
    return (this.ᐨẏ != null) ? this.ᐨẏ.ˊ(paramInt, paramˏɪ, paramString, paramBoolean) : null;
  }
  
  public void ᐨẏ(ᔪ paramᔪ1, ᔪ paramᔪ2, ᔪ paramᔪ3, String paramString) {
    if (this.ᐨẏ != null)
      this.ᐨẏ.ᐨẏ(paramᔪ1, paramᔪ2, paramᔪ3, paramString); 
  }
  
  public ᐨẏ ᴵʖ(int paramInt, ˏɪ paramˏɪ, String paramString, boolean paramBoolean) {
    if (this.ᐨẏ < 327680) {
      "审뷩缈㠭螛ꎢᔟꘕĵ菟곈ଳ泗韸Ꟁ䉐㹚佐?䏎抲蓣뙶㫼⠇ᇄ".toCharArray()[17] = (char)("审뷩缈㠭螛ꎢᔟꘕĵ菟곈ଳ泗韸Ꟁ䉐㹚佐?䏎抲蓣뙶㫼⠇ᇄ".toCharArray()[17] ^ 0x43C8);
      throw new UnsupportedOperationException(ᐨẏ$ᐝт.W("审뷩缈㠭螛ꎢᔟꘕĵ菟곈ଳ泗韸Ꟁ䉐㹚佐?䏎抲蓣뙶㫼⠇ᇄ".toCharArray(), (short)12990, (byte)4, (short)4).intern());
    } 
    return (this.ᐨẏ != null) ? this.ᐨẏ.ᴵʖ(paramInt, paramˏɪ, paramString, paramBoolean) : null;
  }
  
  public void ᐨẏ(String paramString1, String paramString2, String paramString3, ᔪ paramᔪ1, ᔪ paramᔪ2, int paramInt) {
    if (this.ᐨẏ != null)
      this.ᐨẏ.ᐨẏ(paramString1, paramString2, paramString3, paramᔪ1, paramᔪ2, paramInt); 
  }
  
  public ᐨẏ ᐨẏ(int paramInt, ˏɪ paramˏɪ, ᔪ[] paramArrayOfᔪ1, ᔪ[] paramArrayOfᔪ2, int[] paramArrayOfint, String paramString, boolean paramBoolean) {
    if (this.ᐨẏ < 327680) {
      "듋ㅴ쮼⏋언驾坟㨞쨲ᴧ軜㻃?磱嶵輪晴魯F옰ꈞᦐ슙㙃ӎ秃".toCharArray()[20] = (char)("듋ㅴ쮼⏋언驾坟㨞쨲ᴧ軜㻃?磱嶵輪晴魯F옰ꈞᦐ슙㙃ӎ秃".toCharArray()[20] ^ 0x27ED);
      throw new UnsupportedOperationException(ˉﻤ$ͺſ.v("듋ㅴ쮼⏋언驾坟㨞쨲ᴧ軜㻃?磱嶵輪晴魯F옰ꈞᦐ슙㙃ӎ秃".toCharArray(), (short)2052, 1, (short)3).intern());
    } 
    return (this.ᐨẏ != null) ? this.ᐨẏ.ᐨẏ(paramInt, paramˏɪ, paramArrayOfᔪ1, paramArrayOfᔪ2, paramArrayOfint, paramString, paramBoolean) : null;
  }
  
  public void ˊ(int paramInt, ᔪ paramᔪ) {
    if (this.ᐨẏ != null)
      this.ᐨẏ.ˊ(paramInt, paramᔪ); 
  }
  
  public void ʿᵉ(int paramInt1, int paramInt2) {
    if (this.ᐨẏ != null)
      this.ᐨẏ.ʿᵉ(paramInt1, paramInt2); 
  }
  
  public void ᐨẏ() {
    if (this.ᐨẏ != null)
      this.ᐨẏ.ᐨẏ(); 
  }
  
  static {
    "髚喡頋䫩֯楄㌄뱳뵒?룩͍ⶤ깳Ǣ岱彋㫁撸塳寗㕕莈ᛗ".toCharArray()[6] = (char)("髚喡頋䫩֯楄㌄뱳뵒?룩͍ⶤ깳Ǣ岱彋㫁撸塳寗㕕莈ᛗ".toCharArray()[6] ^ 0x5309);
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ˉｓ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */