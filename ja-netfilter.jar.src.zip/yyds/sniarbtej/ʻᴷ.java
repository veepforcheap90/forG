package yyds.sniarbtej;

import java.util.Map;

public final class ʻᴷ extends Ӏ {
  private String name;
  
  public String ˎᴗ;
  
  private ʹō ˊ;
  
  private Object[] ʿᵉ;
  
  public ʻᴷ(String paramString1, String paramString2, ʹō paramʹō, Object... paramVarArgs) {
    super(186);
    this.name = paramString1;
    this.ˎᴗ = paramString2;
    this.ˊ = paramʹō;
    this.ʿᵉ = paramVarArgs;
  }
  
  public final int ﹳיִ() {
    return 6;
  }
  
  public final void ᐨẏ(ˉｓ paramˉｓ) {
    paramˉｓ.ᐨẏ(this.name, this.ˎᴗ, this.ˊ, this.ʿᵉ);
    ˊ(paramˉｓ);
  }
  
  public final Ӏ ᐨẏ(Map<λ, λ> paramMap) {
    return (new ʻᴷ(this.name, this.ˎᴗ, this.ˊ, this.ʿᵉ)).ᐨẏ(this);
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ʻᴷ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */