package yyds.sniarbtej;

import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.lang.reflect.Type;
import java.util.Arrays;
import java.util.Collection;

public final class ˊо {
  private final Field ᐨẏ;
  
  public ˊо(Field paramField) {
    ˌᑦ.ˊ(paramField);
    this.ᐨẏ = paramField;
  }
  
  public final Class<?> ᐨẏ() {
    return this.ᐨẏ.getDeclaringClass();
  }
  
  public final String getName() {
    return this.ᐨẏ.getName();
  }
  
  public final Type ᐨẏ() {
    return this.ᐨẏ.getGenericType();
  }
  
  public final Class<?> ˊ() {
    return this.ᐨẏ.getType();
  }
  
  public final <T extends Annotation> T ᐨẏ(Class<T> paramClass) {
    return this.ᐨẏ.getAnnotation(paramClass);
  }
  
  public final Collection<Annotation> ᐨẏ() {
    return Arrays.asList(this.ᐨẏ.getAnnotations());
  }
  
  public final boolean ᴵʖ(int paramInt) {
    return ((this.ᐨẏ.getModifiers() & paramInt) != 0);
  }
  
  final Object get(Object paramObject) {
    return this.ᐨẏ.get(paramObject);
  }
  
  final boolean ٴӵ() {
    return this.ᐨẏ.isSynthetic();
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ˊо.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */