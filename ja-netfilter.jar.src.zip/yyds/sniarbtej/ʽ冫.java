package yyds.sniarbtej;

import ylt.pmn.zubdqvgt;

public class ʽ冫 extends ʾא {
  public int ٱ;
  
  public ˏɪ ˊ;
  
  public ʽ冫(int paramInt, ˏɪ paramˏɪ, String paramString) {
    this(589824, paramInt, paramˏɪ, paramString);
    if (!zubdqvgt.G(getClass(), ʽ冫.class))
      throw new IllegalStateException(); 
  }
  
  public ʽ冫(int paramInt1, int paramInt2, ˏɪ paramˏɪ, String paramString) {
    super(paramInt1, paramString);
    this.ٱ = paramInt2;
    this.ˊ = paramˏɪ;
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ʽ冫.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */