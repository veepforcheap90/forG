package yyds.sniarbtej;

import java.math.BigInteger;
import java.net.InetAddress;
import java.net.URL;
import java.util.Date;
import java.util.List;

public class ˏȓ {
  public static BigInteger C1(BigInteger paramBigInteger1, BigInteger paramBigInteger2, BigInteger paramBigInteger3) {
    return ͺבּ.ᐨẏ(paramBigInteger1, paramBigInteger2, paramBigInteger3);
  }
  
  public static String C1(String paramString) {
    return ͺבּ.ᴵƚ(paramString);
  }
  
  public static Object C1(InetAddress paramInetAddress) {
    return ͺבּ.ᐨẏ(paramInetAddress);
  }
  
  public static URL C1(URL paramURL) {
    return ͺבּ.ᐨẏ(paramURL);
  }
  
  public static List<String> C1(List<String> paramList) {
    return ͺבּ.ᐨẏ(paramList);
  }
  
  public static boolean C1(CharSequence paramCharSequence1, CharSequence paramCharSequence2) {
    return ͺבּ.ᐨẏ(paramCharSequence2);
  }
  
  public static void C2(String paramString) {
    ͺבּ.ﾞǰ(paramString);
  }
  
  public static void C2(Object paramObject) {
    ͺבּ.ͺо(paramObject);
  }
  
  public static Date C3(Object paramObject) {
    return ͺבּ.ᐨẏ(paramObject);
  }
  
  public static ClassLoader C2(ClassLoader paramClassLoader) {
    return ͺבּ.ᐨẏ(paramClassLoader);
  }
  
  public static void C4(Object paramObject) {
    ͺבּ.ʾ(paramObject);
  }
  
  public static void C5(Object paramObject) {}
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ˏȓ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */