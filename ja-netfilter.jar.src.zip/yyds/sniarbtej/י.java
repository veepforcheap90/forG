package yyds.sniarbtej;

import java.util.ListIterator;

public final class י extends ͺᔮ {
  public final String ᔪ() {
    "椀Ⳡᴤ缛謞ಉ㼧研??饸輷⒐ဂᒴ釸ዯ慲?Ƞ襾醰퐐需졁門ﾹ㟯穚".toCharArray()[29] = (char)("椀Ⳡᴤ缛謞ಉ㼧研??饸輷⒐ဂᒴ釸ዯ慲?Ƞ襾醰퐐需졁門ﾹ㟯穚".toCharArray()[29] ^ 0x760A);
    return ˍɫ$יς.J("椀Ⳡᴤ缛謞ಉ㼧研??饸輷⒐ဂᒴ釸ዯ慲?Ƞ襾醰퐐需졁門ﾹ㟯穚".toCharArray(), (short)6309, (short)4, (byte)5);
  }
  
  public final byte[] ˍɫ(byte[] paramArrayOfbyte) {
    return ᐨẏ(paramArrayOfbyte, paramᐧє -> {
          "㝵ꊨꓲ昉魌寬䮠ⴽ嶗褭䕴鏩?䐩㪧".toCharArray()[2] = (char)("㝵ꊨꓲ昉魌寬䮠ⴽ嶗褭䕴鏩?䐩㪧".toCharArray()[2] ^ 0x68D3);
          "끐襘蓃숪?ߝ줼᧥調狒衯闒Þ佊嫌田弿땡⿓".toCharArray()[3] = (char)("끐襘蓃숪?ߝ줼᧥調狒衯闒Þ佊嫌田弿땡⿓".toCharArray()[3] ^ 0x24C4);
          if (ˍɫ$יς.J("㝵ꊨꓲ昉魌寬䮠ⴽ嶗褭䕴鏩?䐩㪧".toCharArray(), (short)10893, (short)3, (byte)3).equals(paramᐧє.name) && ˍɫ$יς.J("끐襘蓃숪?ߝ줼᧥調狒衯闒Þ佊嫌田弿땡⿓".toCharArray(), (short)31819, (short)5, (byte)1).equals(paramᐧє.ˎᴗ)) {
            ـс ـс;
            (ـс = new ـс()).ᐨẏ(new ᕁ(25, 0));
            ـс.ᐨẏ(new ᕁ(25, 0));
            "下꫐ꋩ☜샳氓ꮸˍ?⾁ꘁ鞿⠶囜⌛ಳⱑꩪ⭏ꊽ盈嵽;ꑦ쒈篢㳛".toCharArray()[16] = (char)("下꫐ꋩ☜샳氓ꮸˍ?⾁ꘁ鞿⠶囜⌛ಳⱑꩪ⭏ꊽ盈嵽;ꑦ쒈篢㳛".toCharArray()[16] ^ 0x3665);
            "?歸춁ݗ㻞樇".toCharArray()[0] = (char)("?歸춁ݗ㻞樇".toCharArray()[0] ^ 0x601C);
            "䝫圤೏ꈸꋾ㦦⼖셋홼暅耝懈?뾰㊷".toCharArray()[15] = (char)("䝫圤೏ꈸꋾ㦦⼖셋홼暅耝懈?뾰㊷".toCharArray()[15] ^ 0x5E4C);
            ـс.ᐨẏ(new ˑܥ(180, ˍɫ$יς.J("下꫐ꋩ☜샳氓ꮸˍ?⾁ꘁ鞿⠶囜⌛ಳⱑꩪ⭏ꊽ盈嵽;ꑦ쒈篢㳛".toCharArray(), (short)15188, (short)4, (byte)4), ˍɫ$יς.J("?歸춁ݗ㻞樇".toCharArray(), (short)24718, (short)3, (byte)5), ˍɫ$יς.J("䝫圤೏ꈸꋾ㦦⼖셋홼暅耝懈?뾰㊷".toCharArray(), (short)5525, (short)4, (byte)3)));
            "㷛⓳拞".toCharArray()[1] = (char)("㷛⓳拞".toCharArray()[1] ^ 0x2FA2);
            "昿ᵆ椰ᶂ뢁ᒃợ㒠㟖ꍣ᩹밢罜昢똞຤櫓客폧㤐?Q㫫罁밇㊊蝕㝁맭ᗷ".toCharArray()[23] = (char)("昿ᵆ椰ᶂ뢁ᒃợ㒠㟖ꍣ᩹밢罜昢똞຤櫓客폧㤐?Q㫫罁밇㊊蝕㝁맭ᗷ".toCharArray()[23] ^ 0x6330);
            ـс.ᐨẏ(new ʾᔂ(184, ן, ˍɫ$יς.J("㷛⓳拞".toCharArray(), (short)20784, (short)3, (byte)2), ˍɫ$יς.J("昿ᵆ椰ᶂ뢁ᒃợ㒠㟖ꍣ᩹밢罜昢똞຤櫓客폧㤐?Q㫫罁밇㊊蝕㝁맭ᗷ".toCharArray(), (short)28325, (short)2, (byte)2), false));
            "퍍鷬號哼憁쭦鴱귁䴲㔼奺ᅶत坍?አ㬊쟒쩧慓ᯧ蓜䓺⧂୧ᒩ헯녲恰".toCharArray()[14] = (char)("퍍鷬號哼憁쭦鴱귁䴲㔼奺ᅶत坍?አ㬊쟒쩧慓ᯧ蓜䓺⧂୧ᒩ헯녲恰".toCharArray()[14] ^ 0x77A);
            "ꈇ㆝耮ࡵ횞햑ᄨ".toCharArray()[0] = (char)("ꈇ㆝耮ࡵ횞햑ᄨ".toCharArray()[0] ^ 0x2D83);
            "嶡젨㻑䀹ꋾ☠㔗郇ﶇꟓ䨓₎砵秴開ࢀߚ".toCharArray()[3] = (char)("嶡젨㻑䀹ꋾ☠㔗郇ﶇꟓ䨓₎砵秴開ࢀߚ".toCharArray()[3] ^ 0x152A);
            ـс.ᐨẏ(new ˑܥ(181, ˍɫ$יς.J("퍍鷬號哼憁쭦鴱귁䴲㔼奺ᅶत坍?አ㬊쟒쩧慓ᯧ蓜䓺⧂୧ᒩ헯녲恰".toCharArray(), (short)22682, (short)2, (byte)4), ˍɫ$יς.J("ꈇ㆝耮ࡵ횞햑ᄨ".toCharArray(), (short)16940, (short)2, (byte)2), ˍɫ$יς.J("嶡젨㻑䀹ꋾ☠㔗郇ﶇꟓ䨓₎砵秴開ࢀߚ".toCharArray(), (short)1211, (short)4, (byte)3)));
            ListIterator<Ӏ> listIterator = paramᐧє.ˊ.ᐨẏ();
            while (listIterator.hasNext()) {
              Ӏ ӏ = listIterator.next();
              if (0 == ӏ.ﹳיִ() && 176 == ӏ.ˈהּ()) {
                ـс ـс2 = ـс;
                Ӏ ӏ1;
                Ӏ ӏ2 = (ӏ1 = (ӏ1 = ӏ).ᐨẏ).ᐨẏ;
                ـс ـс1 = paramᐧє.ˊ;
                if (ـс2.ʿᵉ != 0) {
                  ـс1.ʿᵉ += ـс2.ʿᵉ;
                  ӏ = ـс2.ᴵʖ;
                  Ӏ ӏ3 = ـс2.ﾞл;
                  Ӏ ӏ4;
                  if ((ӏ4 = ӏ2.ˊ) == null) {
                    ـс1.ﾞл = ӏ3;
                  } else {
                    ӏ4.ᐨẏ = ӏ3;
                  } 
                  ӏ2.ˊ = ӏ;
                  ӏ3.ˊ = ӏ4;
                  ӏ.ᐨẏ = ӏ2;
                  ـс1.ᐨẏ = null;
                  ـс2.ˊ(false);
                } 
                return;
              } 
            } 
          } 
        });
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\י.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */