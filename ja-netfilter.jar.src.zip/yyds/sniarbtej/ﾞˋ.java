package yyds.sniarbtej;

import java.util.Currency;

final class ﾞˋ extends ٴۉ<Currency> {
  private static Currency ᐨẏ(יּ paramיּ) {
    return Currency.getInstance(paramיּ.ٴӵ());
  }
  
  private static void ᐨẏ(Ⴡ paramჁ, Currency paramCurrency) {
    paramჁ.ˊ(paramCurrency.getCurrencyCode());
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ﾞˋ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */