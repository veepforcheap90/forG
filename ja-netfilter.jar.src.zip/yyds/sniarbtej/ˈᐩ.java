package yyds.sniarbtej;

import java.util.concurrent.atomic.AtomicBoolean;

final class ˈᐩ extends ٴۉ<AtomicBoolean> {
  private static AtomicBoolean ᐨẏ(יּ paramיּ) {
    return new AtomicBoolean(paramיּ.ˈے());
  }
  
  private static void ᐨẏ(Ⴡ paramჁ, AtomicBoolean paramAtomicBoolean) {
    paramჁ.ᐨẏ(paramAtomicBoolean.get());
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ˈᐩ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */