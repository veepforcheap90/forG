package yyds.sniarbtej;

final class ﾉ implements ˌ々 {
  ﾉ(ʸ paramʸ, ٴۉ paramٴۉ) {}
  
  public final <T> ٴۉ<T> ᐨẏ(ˑĴ paramˑĴ, ʸ<T> paramʸ) {
    return paramʸ.equals(this.ᴵʖ) ? this.ﹳיִ : null;
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ﾉ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */