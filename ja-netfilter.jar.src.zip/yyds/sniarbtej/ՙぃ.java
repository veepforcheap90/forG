package yyds.sniarbtej;

import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.EnumSet;

final class ՙぃ implements ʿн<T> {
  ՙぃ(ˍʶ paramˍʶ, Type paramType) {}
  
  public final T ʿᵉ() {
    if (this.ʹﮃ instanceof ParameterizedType) {
      Type type;
      if (type = ((ParameterizedType)this.ʹﮃ).getActualTypeArguments()[0] instanceof Class)
        return (T)EnumSet.noneOf((Class<Enum>)type); 
      "쭪?慤줐瑉㫛⥦藚Ῡ๞ⅺ䇊꒚?ᖋ놵愄잹慷".toCharArray()[10] = (char)("쭪?慤줐瑉㫛⥦藚Ῡ๞ⅺ䇊꒚?ᖋ놵愄잹慷".toCharArray()[10] ^ 0xEF5);
      throw new ᙆ(ˏȓ$ᴵЃ.E("쭪?慤줐瑉㫛⥦藚Ῡ๞ⅺ䇊꒚?ᖋ놵愄잹慷".toCharArray(), (short)5159, (short)5, (short)0) + this.ʹﮃ.toString());
    } 
    "겶ʢ坖⋣♝鮜ꑜᬛ㫻덉躕霞⼋㰩脥ສ?ᮜㅖ".toCharArray()[4] = (char)("겶ʢ坖⋣♝鮜ꑜᬛ㫻덉躕霞⼋㰩脥ສ?ᮜㅖ".toCharArray()[4] ^ 0x3461);
    throw new ᙆ(ˏȓ$ᴵЃ.E("겶ʢ坖⋣♝鮜ꑜᬛ㫻덉躕霞⼋㰩脥ສ?ᮜㅖ".toCharArray(), (short)29103, (short)2, (short)1) + this.ʹﮃ.toString());
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ՙぃ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */