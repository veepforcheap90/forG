package yyds.sniarbtej;

import ylt.pmn.zubdqvgt;

final class ʱ extends ٴۉ<Boolean> {
  private static Boolean ᐨẏ(יּ paramיּ) {
    if (zubdqvgt.G(paramיּ.ᐨẏ(), כ.ʽ)) {
      paramיּ.ۦ();
      return null;
    } 
    return Boolean.valueOf(paramיּ.ٴӵ());
  }
  
  private static void ᐨẏ(Ⴡ paramჁ, Boolean paramBoolean) {
    "腢줕챪ᮿ⨨".toCharArray()[3] = (char)("腢줕챪ᮿ⨨".toCharArray()[3] ^ 0x6F7C);
    paramჁ.ˊ((paramBoolean == null) ? ˏȓ$ᴵЃ.E("腢줕챪ᮿ⨨".toCharArray(), (short)27733, (short)5, (short)4) : paramBoolean.toString());
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ʱ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */