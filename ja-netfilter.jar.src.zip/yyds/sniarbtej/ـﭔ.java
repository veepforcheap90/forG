package yyds.sniarbtej;

public interface ـﭔ {
  public static final int ᴵܚ = 262144;
  
  public static final int ιっ = 327680;
  
  public static final int ιะ = 393216;
  
  public static final int ﭕ = 458752;
  
  public static final int ˊᐹ = 524288;
  
  public static final int ـᔭ = 589824;
  
  @Deprecated
  public static final int ᐝʶ = 17432576;
  
  public static final int ʾᖾ = 256;
  
  public static final int ʿא = 256;
  
  public static final int ﹹ = 196653;
  
  public static final int 冫 = 46;
  
  public static final int ˌᖬ = 47;
  
  public static final int ᵁ = 48;
  
  public static final int ˎǰ = 49;
  
  public static final int ʿн = 50;
  
  public static final int ˏﮞ = 51;
  
  public static final int ˏɪ = 52;
  
  public static final int ﾞﭠ = 53;
  
  public static final int ŀ = 54;
  
  public static final int ˋﯿ = 55;
  
  public static final int ˋץ = 56;
  
  public static final int ſ = 57;
  
  public static final int ʹĿ = 58;
  
  public static final int ᐝİ = 59;
  
  public static final int ιТ = 60;
  
  public static final int ǐ = 61;
  
  public static final int ٴゞ = 62;
  
  public static final int ˑє = 63;
  
  public static final int ͺſ = 64;
  
  public static final int ʹﭴ = 65;
  
  public static final int ˈट = 66;
  
  public static final int ʼᔦ = 67;
  
  public static final int ڍ = -65536;
  
  public static final int ͺใ = 1;
  
  public static final int ʻḽ = 2;
  
  public static final int ฯ = 4;
  
  public static final int ˏﾁ = 8;
  
  public static final int ˏﮐ = 16;
  
  public static final int ˈﺬ = 32;
  
  public static final int ˉϜ = 32;
  
  public static final int ιԴ = 32;
  
  public static final int ᐧᖿ = 32;
  
  public static final int ˏᵃ = 64;
  
  public static final int ـᓶ = 64;
  
  public static final int ᖦ = 64;
  
  public static final int ˊᒾ = 128;
  
  public static final int ͺẎ = 128;
  
  public static final int ᴿ = 256;
  
  public static final int ᵇ = 512;
  
  public static final int ᐨⅬ = 1024;
  
  public static final int ﾞｽ = 2048;
  
  public static final int ˊɻ = 4096;
  
  public static final int ˊť = 8192;
  
  public static final int ٴᒶ = 16384;
  
  public static final int ˈর = 32768;
  
  public static final int יڈ = 32768;
  
  public static final int ˉʴ = 65536;
  
  public static final int ʿῙ = 131072;
  
  public static final int ί = 4;
  
  public static final int ῐ = 5;
  
  public static final int ـﮐ = 6;
  
  public static final int ˉﻤ = 7;
  
  public static final int ᐨه = 8;
  
  public static final int ˏן = 9;
  
  public static final int 丨 = 10;
  
  public static final int ʹר = 11;
  
  public static final int ᐝṝ = 1;
  
  public static final int ᐨυ = 2;
  
  public static final int ﾞˋ = 3;
  
  public static final int ʻᘥ = 4;
  
  public static final int ـІ = 5;
  
  public static final int ˏｔ = 6;
  
  public static final int ˋᔫ = 7;
  
  public static final int ﹳս = 8;
  
  public static final int ﾉ = 9;
  
  public static final int ﾞﺣ = -1;
  
  public static final int ǀ = 0;
  
  public static final int יﾉ = 1;
  
  public static final int ιᓛ = 2;
  
  public static final int ɺ = 3;
  
  public static final int ᴵᔿ = 4;
  
  public static final Integer ᐨẏ = Integer.valueOf(0);
  
  public static final Integer ˊ = Integer.valueOf(1);
  
  public static final Integer ᴵʖ = Integer.valueOf(2);
  
  public static final Integer ﾞл = Integer.valueOf(3);
  
  public static final Integer ʿᵉ = Integer.valueOf(4);
  
  public static final Integer ʹﮃ = Integer.valueOf(5);
  
  public static final Integer ՙᗮ = Integer.valueOf(6);
  
  public static final int ʱ = 0;
  
  public static final int ˎᔽ = 1;
  
  public static final int ᐨᘧ = 2;
  
  public static final int ᴵﾜ = 3;
  
  public static final int ـﾌ = 4;
  
  public static final int ˈᐩ = 5;
  
  public static final int ՙʜ = 6;
  
  public static final int ʹᔭ = 7;
  
  public static final int ʸ = 8;
  
  public static final int יּ = 9;
  
  public static final int ٴᵇ = 10;
  
  public static final int ʾเ = 11;
  
  public static final int כ = 12;
  
  public static final int Ⴡ = 13;
  
  public static final int ˑɺ = 14;
  
  public static final int ڎ = 15;
  
  public static final int ͺٳ = 16;
  
  public static final int ઽ = 17;
  
  public static final int ˉῚ = 18;
  
  public static final int ﹱ = 21;
  
  public static final int ˑ一 = 22;
  
  public static final int ᓵ = 23;
  
  public static final int ᐝﻠ = 24;
  
  public static final int ᕻ = 25;
  
  public static final int ـיּ = 46;
  
  public static final int ᐴ = 47;
  
  public static final int ˈօ = 48;
  
  public static final int ﾞᔺ = 49;
  
  public static final int ˌᒥ = 50;
  
  public static final int ˋﺯ = 51;
  
  public static final int ᵨ = 52;
  
  public static final int ͺẏ = 53;
  
  public static final int ͺﮈ = 54;
  
  public static final int ͺבּ = 55;
  
  public static final int ˈᕻ = 56;
  
  public static final int ˏȓ = 57;
  
  public static final int יᴄ = 58;
  
  public static final int ﾞʲ = 79;
  
  public static final int ʿᒧ = 80;
  
  public static final int ͺᔮ = 81;
  
  public static final int ʹﬧ = 82;
  
  public static final int ˌḮ = 83;
  
  public static final int ᴵয = 84;
  
  public static final int ᴵϛ = 85;
  
  public static final int יｌ = 86;
  
  public static final int ﹳӱ = 87;
  
  public static final int ᐨל = 88;
  
  public static final int ʾٵ = 89;
  
  public static final int ᵟ = 90;
  
  public static final int ʻڏ = 91;
  
  public static final int ٴƨ = 92;
  
  public static final int י = 93;
  
  public static final int ᐨп = 94;
  
  public static final int ﹳﹲ = 95;
  
  public static final int ˌț = 96;
  
  public static final int ᐧᎰ = 97;
  
  public static final int ﹳ宀 = 98;
  
  public static final int ʻɬ = 99;
  
  public static final int ȉ = 100;
  
  public static final int ʿﾝ = 101;
  
  public static final int ՙｷ = 102;
  
  public static final int ՙﺰ = 103;
  
  public static final int І = 104;
  
  public static final int יﯩ = 105;
  
  public static final int ᑊ = 106;
  
  public static final int ˑᖬ = 107;
  
  public static final int ʷ = 108;
  
  public static final int ͺᴠ = 109;
  
  public static final int ᐨ亠 = 110;
  
  public static final int ʼᒺ = 111;
  
  public static final int ˊᔪ = 112;
  
  public static final int ˋڌ = 113;
  
  public static final int ᐨᑈ = 114;
  
  public static final int ˌง = 115;
  
  public static final int ˋἽ = 116;
  
  public static final int ʽｴ = 117;
  
  public static final int ٴᒉ = 118;
  
  public static final int ʻϟ = 119;
  
  public static final int ιｿ = 120;
  
  public static final int ـᒦ = 121;
  
  public static final int ᒦ = 122;
  
  public static final int ˋᓯ = 123;
  
  public static final int ᴵᕝ = 124;
  
  public static final int ʼऽ = 125;
  
  public static final int Ꮮ = 126;
  
  public static final int ᒪ = 127;
  
  public static final int ˍṝ = 128;
  
  public static final int ʽﻧ = 129;
  
  public static final int ﾞᴝ = 130;
  
  public static final int ـᔩ = 131;
  
  public static final int ˍƆ = 132;
  
  public static final int ﹳٮ = 133;
  
  public static final int ᐨᖦ = 134;
  
  public static final int ﹳᔈ = 135;
  
  public static final int ˍⅴ = 136;
  
  public static final int ιגּ = 137;
  
  public static final int ـܥ = 138;
  
  public static final int צ = 139;
  
  public static final int ΐ = 140;
  
  public static final int ː = 141;
  
  public static final int ٴﾐ = 142;
  
  public static final int ͺ亅 = 143;
  
  public static final int ˉแ = 144;
  
  public static final int ᐧᴛ = 145;
  
  public static final int יｷ = 146;
  
  public static final int ˋᴏ = 147;
  
  public static final int ՙϛ = 148;
  
  public static final int ˈﭡ = 149;
  
  public static final int ﺯ = 150;
  
  public static final int ͺﭤ = 151;
  
  public static final int ˈᔭ = 152;
  
  public static final int ᴵপ = 153;
  
  public static final int ᐨڎ = 154;
  
  public static final int ˉᖟ = 155;
  
  public static final int ˉס = 156;
  
  public static final int ᴵډ = 157;
  
  public static final int ċ = 158;
  
  public static final int ʻऱ = 159;
  
  public static final int ˌর = 160;
  
  public static final int ʿᒼ = 161;
  
  public static final int ʌ = 162;
  
  public static final int ʹᵠ = 163;
  
  public static final int ͺᔩ = 164;
  
  public static final int ᐨⅈ = 165;
  
  public static final int ʾʹ = 166;
  
  public static final int ʼἶ = 167;
  
  public static final int ܪ = 168;
  
  public static final int ﾞｼ = 169;
  
  public static final int ه = 170;
  
  public static final int ĭ = 171;
  
  public static final int ږ = 172;
  
  public static final int ˍদ = 173;
  
  public static final int ʿ丫 = 174;
  
  public static final int ܕ = 175;
  
  public static final int ণ = 176;
  
  public static final int ʹˆ = 177;
  
  public static final int ˌᘇ = 178;
  
  public static final int ʽষ = 179;
  
  public static final int ﹳｬ = 180;
  
  public static final int Ꮁ = 181;
  
  public static final int ﹳঢ = 182;
  
  public static final int ﾞﮣ = 183;
  
  public static final int ᒨ = 184;
  
  public static final int ʿΞ = 185;
  
  public static final int ـঌ = 186;
  
  public static final int ˌﭔ = 187;
  
  public static final int ᙇ = 188;
  
  public static final int ʼｽ = 189;
  
  public static final int ʽᔺ = 190;
  
  public static final int ˑᴰ = 191;
  
  public static final int ᴼ = 192;
  
  public static final int ۊ = 193;
  
  public static final int ͺᒭ = 194;
  
  public static final int ᐨɾ = 195;
  
  public static final int ˏᵪ = 197;
  
  public static final int ˌﺰ = 198;
  
  public static final int ˊণ = 199;
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ـﭔ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */