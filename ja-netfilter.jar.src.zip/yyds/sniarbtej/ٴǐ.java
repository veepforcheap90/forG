package yyds.sniarbtej;

import ylt.pmn.zubdqvgt;

public class ٴǐ extends ᴵƚ {
  private boolean ᴵƚ;
  
  private ٴǐ(ᴵƚ paramᴵƚ) {
    this(589824, paramᴵƚ);
    if (!zubdqvgt.G(getClass(), ٴǐ.class))
      throw new IllegalStateException(); 
  }
  
  protected ٴǐ(int paramInt, ᴵƚ paramᴵƚ) {
    super(paramInt, paramᴵƚ);
  }
  
  public final ᐨẏ ᐨẏ(String paramString, boolean paramBoolean) {
    ᴶ();
    ـｊ.ᐨẏ(49, paramString, false);
    return new ͺᖽ(super.ᐨẏ(paramString, paramBoolean));
  }
  
  public final ᐨẏ ᐨẏ(int paramInt, ˏɪ paramˏɪ, String paramString, boolean paramBoolean) {
    ᴶ();
    int i;
    if ((i = (new ʾเ(paramInt)).ˉｓ()) != 19) {
      "≩攲퐩ᬸꥅ䀀餙綞갽꒯渁磰洷鿷逅䨲邦ᄧ⊍픕촅呩醘ﻡ⩯ꯐᐸ뀩䣱".toCharArray()[11] = (char)("≩攲퐩ᬸꥅ䀀餙綞갽꒯渁磰洷鿷逅䨲邦ᄧ⊍픕촅呩醘ﻡ⩯ꯐᐸ뀩䣱".toCharArray()[11] ^ 0x1BC);
      throw new IllegalArgumentException(ˉﻤ$ͺſ.v("≩攲퐩ᬸꥅ䀀餙綞갽꒯渁磰洷鿷逅䨲邦ᄧ⊍픕촅呩醘ﻡ⩯ꯐᐸ뀩䣱".toCharArray(), (short)12224, 4, (short)4) + Integer.toHexString(i));
    } 
    ˉʭ.ʹō(paramInt);
    ـｊ.ᐨẏ(49, paramString, false);
    return new ͺᖽ(super.ᐨẏ(paramInt, paramˏɪ, paramString, paramBoolean));
  }
  
  public final void ᴵʖ(ᴵʖ paramᴵʖ) {
    ᴶ();
    if (paramᴵʖ == null) {
      "輾沓퍏호䝎癍蠾ꉀ㳅₢乶径뇄匐麉훥⪮겜䢇勨❅ﰨ疐䙓菦稵追卦蹧⽑헹䡤ﵱ౔".toCharArray()[4] = (char)("輾沓퍏호䝎癍蠾ꉀ㳅₢乶径뇄匐麉훥⪮겜䢇勨❅ﰨ疐䙓菦稵追卦蹧⽑헹䡤ﵱ౔".toCharArray()[4] ^ 0x39F0);
      throw new IllegalArgumentException(ˏȓ$ᴵЃ.E("輾沓퍏호䝎癍蠾ꉀ㳅₢乶径뇄匐麉훥⪮겜䢇勨❅ﰨ疐䙓菦稵追卦蹧⽑헹䡤ﵱ౔".toCharArray(), (short)30551, (short)5, (short)0));
    } 
    super.ᴵʖ(paramᴵʖ);
  }
  
  public final void ᐨẏ() {
    ᴶ();
    this.ᴵƚ = true;
    super.ᐨẏ();
  }
  
  private void ᴶ() {
    if (this.ᴵƚ) {
      "?뎴骠ꜰ嶂䠴泰蒩ꋜ曷翖潁ꌇᵻӻ꩸ุṰ숏編腆粇豇듰氯┳諻薭皏玼ᅺ鍻ପ颃㈼㨪죵䀜㙮ඈ쒝懙혽춒㵍?潁ᐄ塰छ".toCharArray()[6] = (char)("?뎴骠ꜰ嶂䠴泰蒩ꋜ曷翖潁ꌇᵻӻ꩸ุṰ숏編腆粇豇듰氯┳諻薭皏玼ᅺ鍻ପ颃㈼㨪죵䀜㙮ඈ쒝懙혽춒㵍?潁ᐄ塰छ".toCharArray()[6] ^ 0x7CEE);
      throw new IllegalStateException(ᐨẏ$ᐝт.W("?뎴骠ꜰ嶂䠴泰蒩ꋜ曷翖潁ꌇᵻӻ꩸ุṰ숏編腆粇豇듰氯┳諻薭皏玼ᅺ鍻ପ颃㈼㨪죵䀜㙮ඈ쒝懙혽춒㵍?潁ᐄ塰छ".toCharArray(), (short)601, (byte)0, (short)2));
    } 
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ٴǐ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */