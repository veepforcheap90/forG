package yyds.sniarbtej;

final class ιᓛ implements ˌ々 {
  ιᓛ(Class paramClass, ٴۉ paramٴۉ) {}
  
  public final <T2> ٴۉ<T2> ᐨẏ(ˑĴ paramˑĴ, ʸ<T2> paramʸ) {
    ʸ<T2> ʸ1;
    Class<? super T2> clazz = (ʸ1 = paramʸ).ᐨم;
    return !this.ʽ.isAssignableFrom(clazz) ? null : new ɺ(this, clazz);
  }
  
  public final String toString() {
    "ꯣꮧ帕㩜閭懲즻௬㨱﫿솄\005䩵ಀꔦ䦩ꋔᒶ㱼駈泌㭸".toCharArray()[7] = (char)("ꯣꮧ帕㩜閭懲즻௬㨱﫿솄\005䩵ಀꔦ䦩ꋔᒶ㱼駈泌㭸".toCharArray()[7] ^ 0x57F0);
    "秷༫䄱ꐩ糃警ᢹ⣈顽搣".toCharArray()[4] = (char)("秷༫䄱ꐩ糃警ᢹ⣈顽搣".toCharArray()[4] ^ 0x4C05);
    "൯㙊".toCharArray()[0] = (char)("൯㙊".toCharArray()[0] ^ 0x3A97);
    return ˍɫ$יς.J("ꯣꮧ帕㩜閭懲즻௬㨱﫿솄\005䩵ಀꔦ䦩ꋔᒶ㱼駈泌㭸".toCharArray(), (short)8897, (short)1, (byte)2) + this.ʽ.getName() + ˍɫ$יς.J("秷༫䄱ꐩ糃警ᢹ⣈顽搣".toCharArray(), (short)17955, (short)4, (byte)3) + this.ﹳיִ + ˍɫ$יς.J("൯㙊".toCharArray(), (short)15513, (short)1, (byte)2);
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ιᓛ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */