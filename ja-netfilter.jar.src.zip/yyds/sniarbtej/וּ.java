package yyds.sniarbtej;

import java.util.List;

public abstract class וּ<V extends ן> {
  private int ᐨẏ;
  
  protected וּ(int paramInt) {}
  
  public abstract V ᐨẏ(ˑܘ paramˑܘ);
  
  public final V ˊ(ˑܘ paramˑܘ) {
    return ᐨẏ(paramˑܘ);
  }
  
  public final V ᴵʖ(ˑܘ paramˑܘ) {
    return ᐨẏ(paramˑܘ);
  }
  
  public final V ˊ() {
    return ᐨẏ((ˑܘ)null);
  }
  
  public final V ﾞл(ˑܘ paramˑܘ) {
    return ᐨẏ(paramˑܘ);
  }
  
  public abstract V ᐨẏ(Ӏ paramӀ);
  
  public abstract V ˊ(Ӏ paramӀ, V paramV);
  
  public abstract V ᐨẏ(Ӏ paramӀ, V paramV);
  
  public abstract V ᐨẏ(Ӏ paramӀ, V paramV1, V paramV2);
  
  public abstract V ᐨẏ(Ӏ paramӀ, V paramV1, V paramV2, V paramV3);
  
  public abstract V ᐨẏ(Ӏ paramӀ, List<? extends V> paramList);
  
  public abstract void ᐨẏ(Ӏ paramӀ, V paramV1, V paramV2);
  
  public abstract V ᐨẏ(V paramV1, V paramV2);
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\וּ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */