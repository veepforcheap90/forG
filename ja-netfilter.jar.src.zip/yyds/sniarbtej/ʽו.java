package yyds.sniarbtej;

import java.util.List;
import ylt.pmn.zubdqvgt;

public class ʽו extends וּ<ﹳه> implements ـﭔ {
  public static final ˑܘ ᴵƚ = ˑܘ.ˊ(ᐝᵣ$ﾞﾇ.j("氭鋌쯫탹䭜".toCharArray(), (short)27839, 2, (short)3));
  
  public ʽו() {
    super(589824);
    if (!zubdqvgt.G(getClass(), ʽו.class))
      throw new IllegalStateException(); 
  }
  
  protected ʽו(int paramInt) {
    super(paramInt);
  }
  
  public ﹳه ᐨẏ(ˑܘ paramˑܘ) {
    if (paramˑܘ == null)
      return ﹳه.ᐨẏ; 
    switch (paramˑܘ.ˉｓ()) {
      case 0:
        return null;
      case 1:
      case 2:
      case 3:
      case 4:
      case 5:
        return ﹳه.ˊ;
      case 6:
        return ﹳه.ᴵʖ;
      case 7:
        return ﹳه.ﾞл;
      case 8:
        return ﹳه.ʿᵉ;
      case 9:
      case 10:
        return ﹳه.ʹﮃ;
    } 
    throw new AssertionError();
  }
  
  private ﹳه ᐨẏ(Ӏ paramӀ) {
    ʾܪ ʾܪ;
    Object object;
    switch (paramӀ.ˈהּ()) {
      case 1:
        return ᐨẏ(ᴵƚ);
      case 2:
      case 3:
      case 4:
      case 5:
      case 6:
      case 7:
      case 8:
        return ﹳه.ˊ;
      case 9:
      case 10:
        return ﹳه.ﾞл;
      case 11:
      case 12:
      case 13:
        return ﹳه.ᴵʖ;
      case 14:
      case 15:
        return ﹳه.ʿᵉ;
      case 16:
      case 17:
        return ﹳه.ˊ;
      case 18:
        if (object = ((ˏἴ)paramӀ).ʿᵉ instanceof Integer)
          return ﹳه.ˊ; 
        if (object instanceof Float)
          return ﹳه.ᴵʖ; 
        if (object instanceof Long)
          return ﹳه.ﾞл; 
        if (object instanceof Double)
          return ﹳه.ʿᵉ; 
        if (object instanceof String) {
          "ᛴ鼸ହ찠遯㼘訳Ꙗ姇╛䏐㠌".toCharArray()[4] = (char)("ᛴ鼸ହ찠遯㼘訳Ꙗ姇╛䏐㠌".toCharArray()[4] ^ 0xF0F);
          return ᐨẏ(ˑܘ.ˊ(ˍɫ$יς.J("ᛴ鼸ହ찠遯㼘訳Ꙗ姇╛䏐㠌".toCharArray(), (short)12326, (short)5, (byte)3)));
        } 
        if (object instanceof ˑܘ) {
          int i;
          if ((i = ((ˑܘ)object).ˉｓ()) == 10 || i == 9) {
            "췂✽謪?쥡጑醡ᕧ᫠ᴳ哸ᄋ䭇䔻".toCharArray()[7] = (char)("췂✽謪?쥡጑醡ᕧ᫠ᴳ哸ᄋ䭇䔻".toCharArray()[7] ^ 0x6660);
            return ᐨẏ(ˑܘ.ˊ(ˍɫ$יς.J("췂✽謪?쥡጑醡ᕧ᫠ᴳ哸ᄋ䭇䔻".toCharArray(), (short)23303, (short)4, (byte)1)));
          } 
          if (i == 11) {
            "Ẑ劫朅鬟ꨆᆇ퍧Ꮛꀇ浦㽍Ẵ낍䴱Њ⏉㧸녆䕱낡鼅୮".toCharArray()[10] = (char)("Ẑ劫朅鬟ꨆᆇ퍧Ꮛꀇ浦㽍Ẵ낍䴱Њ⏉㧸녆䕱낡鼅୮".toCharArray()[10] ^ 0x1165);
            return ᐨẏ(ˑܘ.ˊ(ˍɫ$יς.J("Ẑ劫朅鬟ꨆᆇ퍧Ꮛꀇ浦㽍Ẵ낍䴱Њ⏉㧸녆䕱낡鼅୮".toCharArray(), (short)4173, (short)4, (byte)1)));
          } 
          "駑噭ʫꭱ푖鋪趄抇瘕ޔ稶䊘糡謿羅뺫ᙦ豩纰".toCharArray()[11] = (char)("駑噭ʫꭱ푖鋪趄抇瘕ޔ稶䊘糡謿羅뺫ᙦ豩纰".toCharArray()[11] ^ 0x3C0D);
          throw new ιƚ(paramӀ, ˍɫ$יς.J("駑噭ʫꭱ푖鋪趄抇瘕ޔ稶䊘糡謿羅뺫ᙦ豩纰".toCharArray(), (short)9935, (short)3, (byte)5) + object);
        } 
        if (object instanceof ʹō) {
          "阫駑熈겑苅ƥ䳪巎ਬ鈴晴ꨁꯀꊌ琉當垠괊䆂맠珞䏆縖联껇犺ㅁ".toCharArray()[5] = (char)("阫駑熈겑苅ƥ䳪巎ਬ鈴晴ꨁꯀꊌ琉當垠괊䆂맠珞䏆縖联껇犺ㅁ".toCharArray()[5] ^ 0x6E5D);
          return ᐨẏ(ˑܘ.ˊ(ˍɫ$יς.J("阫駑熈겑苅ƥ䳪巎ਬ鈴晴ꨁꯀꊌ琉當垠괊䆂맠珞䏆縖联껇犺ㅁ".toCharArray(), (short)20731, (short)5, (byte)2)));
        } 
        if (object instanceof ʾܪ)
          return ᐨẏ(ˑܘ.ᐨẏ((ʾܪ = (ʾܪ)object).ᴵʖ)); 
        "㮐ퟥꙬ盰륬㻈낕ᩄ?땬㰯ꖙ橖⺾峪岀".toCharArray()[16] = (char)("㮐ퟥꙬ盰륬㻈낕ᩄ?땬㰯ꖙ橖⺾峪岀".toCharArray()[16] ^ 0x6BEC);
        throw new ιƚ(ʾܪ, ˍɫ$יς.J("㮐ퟥꙬ盰륬㻈낕ᩄ?땬㰯ꖙ橖⺾峪岀".toCharArray(), (short)5223, (short)0, (byte)0) + object);
      case 168:
        return ﹳه.ՙᗮ;
      case 178:
        return ᐨẏ(ˑܘ.ᐨẏ(((ˑܥ)ʾܪ).ˎᴗ));
      case 187:
        return ᐨẏ(ˑܘ.ˊ(((ᔉ)ʾܪ).ˎᴗ));
    } 
    throw new AssertionError();
  }
  
  public ﹳه ᐨẏ(Ӏ paramӀ, ﹳه paramﹳه) {
    return paramﹳه;
  }
  
  public ﹳه ˊ(Ӏ paramӀ, ﹳه paramﹳه) {
    switch (paramӀ.ˈהּ()) {
      case 116:
      case 132:
      case 136:
      case 139:
      case 142:
      case 145:
      case 146:
      case 147:
        return ﹳه.ˊ;
      case 118:
      case 134:
      case 137:
      case 144:
        return ﹳه.ᴵʖ;
      case 117:
      case 133:
      case 140:
      case 143:
        return ﹳه.ﾞл;
      case 119:
      case 135:
      case 138:
      case 141:
        return ﹳه.ʿᵉ;
      case 153:
      case 154:
      case 155:
      case 156:
      case 157:
      case 158:
      case 170:
      case 171:
      case 172:
      case 173:
      case 174:
      case 175:
      case 176:
      case 179:
        return null;
      case 180:
        return ᐨẏ(ˑܘ.ᐨẏ(((ˑܥ)paramӀ).ˎᴗ));
      case 188:
        switch (((ʿḶ)paramӀ).ᐨป) {
          case 4:
            "郺䈣⥱".toCharArray()[0] = (char)("郺䈣⥱".toCharArray()[0] ^ 0x2E88);
            return ᐨẏ(ˑܘ.ᐨẏ(ˍɫ$יς.J("郺䈣⥱".toCharArray(), (short)10581, (short)5, (byte)4)));
          case 5:
            "㿓臯㋈".toCharArray()[1] = (char)("㿓臯㋈".toCharArray()[1] ^ 0x2870);
            return ᐨẏ(ˑܘ.ᐨẏ(ˍɫ$יς.J("㿓臯㋈".toCharArray(), (short)5484, (short)3, (byte)1)));
          case 8:
            "퍁䏣ᚆ".toCharArray()[0] = (char)("퍁䏣ᚆ".toCharArray()[0] ^ 0x7F);
            return ᐨẏ(ˑܘ.ᐨẏ(ˍɫ$יς.J("퍁䏣ᚆ".toCharArray(), (short)19235, (short)4, (byte)1)));
          case 9:
            "䛥瀅Ḽ".toCharArray()[0] = (char)("䛥瀅Ḽ".toCharArray()[0] ^ 0x611);
            return ᐨẏ(ˑܘ.ᐨẏ(ˍɫ$יς.J("䛥瀅Ḽ".toCharArray(), (short)17732, (short)4, (byte)2)));
          case 10:
            "췧畬᭱".toCharArray()[0] = (char)("췧畬᭱".toCharArray()[0] ^ 0x5379);
            return ᐨẏ(ˑܘ.ᐨẏ(ˍɫ$יς.J("췧畬᭱".toCharArray(), (short)26871, (short)2, (byte)5)));
          case 6:
            "鶆쥌㴍".toCharArray()[0] = (char)("鶆쥌㴍".toCharArray()[0] ^ 0x2105);
            return ᐨẏ(ˑܘ.ᐨẏ(ˍɫ$יς.J("鶆쥌㴍".toCharArray(), (short)5903, (short)1, (byte)1)));
          case 7:
            "瀴貰ᴳ".toCharArray()[1] = (char)("瀴貰ᴳ".toCharArray()[1] ^ 0x4CC9);
            return ᐨẏ(ˑܘ.ᐨẏ(ˍɫ$יς.J("瀴貰ᴳ".toCharArray(), (short)8659, (short)0, (byte)5)));
          case 11:
            "䱀ᇞ".toCharArray()[0] = (char)("䱀ᇞ".toCharArray()[0] ^ 0x10B2);
            return ᐨẏ(ˑܘ.ᐨẏ(ˍɫ$יς.J("䱀ᇞ".toCharArray(), (short)4025, (short)5, (byte)3)));
        } 
        "⹵㠶뵝蘄浐ᮊᲚ脣嚊㜤ﴀ᷅᜷?깠묵ۑ呺".toCharArray()[13] = (char)("⹵㠶뵝蘄浐ᮊᲚ脣嚊㜤ﴀ᷅᜷?깠묵ۑ呺".toCharArray()[13] ^ 0x50C0);
        throw new ιƚ(paramӀ, ˍɫ$יς.J("⹵㠶뵝蘄浐ᮊᲚ脣嚊㜤ﴀ᷅᜷?깠묵ۑ呺".toCharArray(), (short)12474, (short)1, (byte)4));
      case 189:
        "䜭┒".toCharArray()[0] = (char)("䜭┒".toCharArray()[0] ^ 0x1D93);
        return ᐨẏ(ˑܘ.ᐨẏ(ˍɫ$יς.J("䜭┒".toCharArray(), (short)20335, (short)4, (byte)3) + ˑܘ.ˊ(((ᔉ)paramӀ).ˎᴗ)));
      case 190:
        return ﹳه.ˊ;
      case 191:
        return null;
      case 192:
        return ᐨẏ(ˑܘ.ˊ(((ᔉ)paramӀ).ˎᴗ));
      case 193:
        return ﹳه.ˊ;
      case 194:
      case 195:
      case 198:
      case 199:
        return null;
    } 
    throw new AssertionError();
  }
  
  public ﹳه ᐨẏ(Ӏ paramӀ, ﹳه paramﹳه1, ﹳه paramﹳه2) {
    switch (paramӀ.ˈהּ()) {
      case 46:
      case 51:
      case 52:
      case 53:
      case 96:
      case 100:
      case 104:
      case 108:
      case 112:
      case 120:
      case 122:
      case 124:
      case 126:
      case 128:
      case 130:
        return ﹳه.ˊ;
      case 48:
      case 98:
      case 102:
      case 106:
      case 110:
      case 114:
        return ﹳه.ᴵʖ;
      case 47:
      case 97:
      case 101:
      case 105:
      case 109:
      case 113:
      case 121:
      case 123:
      case 125:
      case 127:
      case 129:
      case 131:
        return ﹳه.ﾞл;
      case 49:
      case 99:
      case 103:
      case 107:
      case 111:
      case 115:
        return ﹳه.ʿᵉ;
      case 50:
        return ﹳه.ʹﮃ;
      case 148:
      case 149:
      case 150:
      case 151:
      case 152:
        return ﹳه.ˊ;
      case 159:
      case 160:
      case 161:
      case 162:
      case 163:
      case 164:
      case 165:
      case 166:
      case 181:
        return null;
    } 
    throw new AssertionError();
  }
  
  public ﹳه ᐨẏ(Ӏ paramӀ, ﹳه paramﹳه1, ﹳه paramﹳه2, ﹳه paramﹳه3) {
    return null;
  }
  
  public ﹳه ᐨẏ(Ӏ paramӀ, List<? extends ﹳه> paramList) {
    int i;
    return ((i = paramӀ.ˈהּ()) == 197) ? ᐨẏ(ˑܘ.ᐨẏ(((ˍᒄ)paramӀ).ˎᴗ)) : ((i == 186) ? ᐨẏ(ˑܘ.ﾞл(((ʻᴷ)paramӀ).ˎᴗ)) : ᐨẏ(ˑܘ.ﾞл(((ʾᔂ)paramӀ).ˎᴗ)));
  }
  
  public void ᐨẏ(Ӏ paramӀ, ﹳه paramﹳه1, ﹳه paramﹳه2) {}
  
  public ﹳه ᐨẏ(ﹳه paramﹳه1, ﹳه paramﹳه2) {
    return !paramﹳه1.equals(paramﹳه2) ? ﹳه.ᐨẏ : paramﹳه1;
  }
  
  static {
    "氭鋌쯫탹䭜".toCharArray()[3] = (char)("氭鋌쯫탹䭜".toCharArray()[3] ^ 0x5A15);
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ʽו.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */