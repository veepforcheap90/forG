package yyds.sniarbtej;

enum ﾞᐦ {
  ˊ, ᴵʖ, ﾞл, ʿᵉ, ʹﮃ, ՙᗮ, ˍɫ, ʽ, ʾܪ;
  
  static {
    "鞝젤ᬌ쎺薞穃".toCharArray()[4] = (char)("鞝젤ᬌ쎺薞穃".toCharArray()[4] ^ 0x2B11);
  }
  
  static {
    "ৎⲈ끤ꇠ露Ե".toCharArray()[2] = (char)("ৎⲈ끤ꇠ露Ե".toCharArray()[2] ^ 0x1A22);
  }
  
  static {
    "캆艞᧧".toCharArray()[4] = (char)("캆艞᧧".toCharArray()[4] ^ 0x4710);
  }
  
  static {
    "籄铲㐎絨騕ῇ".toCharArray()[1] = (char)("籄铲㐎絨騕ῇ".toCharArray()[1] ^ 0x23);
  }
  
  static {
    "띄픸➳ఏ穗".toCharArray()[3] = (char)("띄픸➳ఏ穗".toCharArray()[3] ^ 0x73BC);
  }
  
  static {
    "疼퓘ඖ浕飏㴹⛖".toCharArray()[2] = (char)("疼퓘ඖ浕飏㴹⛖".toCharArray()[2] ^ 0x5774);
  }
  
  static {
    "榋ᑲ鲕\000ꦈ셑蔐᫔ਯ쬂准".toCharArray()[6] = (char)("榋ᑲ鲕\000ꦈ셑蔐᫔ਯ쬂准".toCharArray()[6] ^ 0x7053);
  }
  
  static {
    "뵿䞾ෆ泮븷蘲跓坍곓䩾".toCharArray()[0] = (char)("뵿䞾ෆ泮븷蘲跓坍곓䩾".toCharArray()[0] ^ 0x7FAB);
  }
  
  static {
    "䀓䆴팴൸".toCharArray()[0] = (char)("䀓䆴팴൸".toCharArray()[0] ^ 0x5348);
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ﾞᐦ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */