package yyds.sniarbtej;

public interface ˌ々 {
  <T> ٴۉ<T> ᐨẏ(ˑĴ paramˑĴ, ʸ<T> paramʸ);
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ˌ々.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */