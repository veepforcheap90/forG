package yyds.sniarbtej;

import java.lang.reflect.Field;
import ylt.pmn.zubdqvgt;

final class ˏᵃ extends ᖦ {
  private ٴۉ<?> ˍɫ = ᐧᖿ.ᐨẏ(this.ᐨẏ, (ˑĴ)this.ﾞл, this.ˊ, this.ﾞл);
  
  ˏᵃ(ᐧᖿ paramᐧᖿ, String paramString, boolean paramBoolean1, boolean paramBoolean2, ˑĴ paramˑĴ, Field paramField, ʸ paramʸ, boolean paramBoolean3) {
    super(paramString, paramBoolean1, paramBoolean2);
  }
  
  final void ᐨẏ(Ⴡ paramჁ, Object paramObject) {
    paramObject = this.ˊ.get(paramObject);
    ᐨⅬ<Object> ᐨⅬ;
    ʸ ʸ1;
    (ᐨⅬ = new ᐨⅬ((ˑĴ)this.ﾞл, this.ˍɫ, (ʸ1 = this.ﾞл).ՙᗮ)).ᐨẏ(paramჁ, paramObject);
  }
  
  final void ᐨẏ(יּ paramיּ, Object paramObject) {
    if ((paramיּ = (יּ)this.ˍɫ.ᐨẏ(paramיּ)) != null || !this.ˊᴬ)
      this.ˊ.set(paramObject, paramיּ); 
  }
  
  public final boolean ˊ(Object paramObject) {
    Object object;
    return !this.ʻᒱ ? false : (!zubdqvgt.G(object = this.ˊ.get(paramObject), paramObject));
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ˏᵃ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */