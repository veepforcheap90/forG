package yyds.sniarbtej;

import java.lang.reflect.Field;
import java.util.Locale;

enum ٴᒻ {
  public final String ᐨẏ(Field paramField) {
    "ͦỬ".toCharArray()[0] = (char)("ͦỬ".toCharArray()[0] ^ 0x243F);
    return ﾞɫ.ՙᗮ(paramField.getName(), ᐨẏ$ᐝт.W("ͦỬ".toCharArray(), (short)18034, (byte)0, (short)5)).toLowerCase(Locale.ENGLISH);
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ٴᒻ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */