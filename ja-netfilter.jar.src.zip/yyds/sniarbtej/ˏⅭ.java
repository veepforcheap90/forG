package yyds.sniarbtej;

public final class ˏⅭ {
  private String name;
  
  private String ᴶ;
  
  private String গ;
  
  private int ᒬ;
  
  public ˏⅭ(String paramString1, String paramString2, String paramString3, int paramInt) {
    this.name = paramString1;
    this.ᴶ = paramString2;
    this.গ = paramString3;
    this.ᒬ = paramInt;
  }
  
  public final void ᐨẏ(ˍɫ paramˍɫ) {
    paramˍɫ.ᐨẏ(this.name, this.ᴶ, this.গ, this.ᒬ);
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ˏⅭ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */