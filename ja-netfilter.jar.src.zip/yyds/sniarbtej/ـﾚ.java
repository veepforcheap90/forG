package yyds.sniarbtej;

final class ـﾚ extends ˉｓ {
  final int ᔪ;
  
  final ʽ ˊ;
  
  ـﾚ(int paramInt1, int paramInt2, ʽ paramʽ, ˉｓ paramˉｓ) {
    super(paramInt1, paramˉｓ);
    this.ᔪ = paramInt2;
    this.ˊ = paramʽ;
  }
  
  final boolean ᐨم() {
    return (this.ˊ.ᐨẏ(1) || this.ˊ.ᐨẏ(2));
  }
  
  final boolean ʾ() {
    return this.ˊ.ᐨẏ(2);
  }
  
  final boolean ͺо() {
    return ((this.ᔪ & 0xFFFF) >= 51);
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ـﾚ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */