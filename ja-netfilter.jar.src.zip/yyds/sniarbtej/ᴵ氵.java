package yyds.sniarbtej;

import java.util.LinkedHashSet;

final class ᴵ氵 implements ʿн<T> {
  ᴵ氵(ˍʶ paramˍʶ) {}
  
  public final T ʿᵉ() {
    return (T)new LinkedHashSet();
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ᴵ氵.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */