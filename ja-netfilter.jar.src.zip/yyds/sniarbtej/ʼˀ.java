package yyds.sniarbtej;

public final class ʼˀ {
  private String Ӏ;
  
  private int ᒬ;
  
  private String ˏﬤ;
  
  public ʼˀ(String paramString1, int paramInt, String paramString2) {
    this.Ӏ = paramString1;
    this.ᒬ = paramInt;
    this.ˏﬤ = paramString2;
  }
  
  public final void ᐨẏ(ʻล paramʻล) {
    paramʻล.ᐨẏ(this.Ӏ, this.ᒬ, this.ˏﬤ);
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ʼˀ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */