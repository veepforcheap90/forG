package yyds.sniarbtej;

import ylt.pmn.zubdqvgt;

final class ʼᔮ extends ٴۉ<Number> {
  ʼᔮ(ˑĴ paramˑĴ) {}
  
  private static Double ᐨẏ(יּ paramיּ) {
    if (zubdqvgt.G(paramיּ.ᐨẏ(), כ.ʽ)) {
      paramיּ.ۦ();
      return null;
    } 
    return Double.valueOf(paramיּ.ᴵʖ());
  }
  
  private void ᐨẏ(Ⴡ paramჁ, Number paramNumber) {
    if (paramNumber == null) {
      paramჁ.ʿᵉ();
      return;
    } 
    double d = paramNumber.doubleValue();
    ˑĴ.ᐨẏ(this.ᐨẏ, d);
    paramჁ.ᐨẏ(paramNumber);
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ʼᔮ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */