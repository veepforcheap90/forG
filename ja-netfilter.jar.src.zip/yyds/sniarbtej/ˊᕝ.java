package yyds.sniarbtej;

import java.util.AbstractSet;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import ylt.pmn.zubdqvgt;

final class ˊᕝ<T> extends AbstractSet<T> {
  final T ՙᗮ = null;
  
  final T ˍɫ = null;
  
  ˊᕝ() {}
  
  ˊᕝ(T paramT) {}
  
  ˊᕝ(T paramT1, T paramT2) {}
  
  public final Iterator<T> iterator() {
    return new ᐨḶ<>(this.ՙᗮ, this.ˍɫ);
  }
  
  public final int size() {
    return (this.ՙᗮ == null) ? 0 : ((this.ˍɫ == null) ? 1 : 2);
  }
  
  final Set<T> ᐨẏ(ˊᕝ<T> paramˊᕝ) {
    if ((zubdqvgt.G(paramˊᕝ.ՙᗮ, this.ՙᗮ) && zubdqvgt.G(paramˊᕝ.ˍɫ, this.ˍɫ)) || (zubdqvgt.G(paramˊᕝ.ՙᗮ, this.ˍɫ) && zubdqvgt.G(paramˊᕝ.ˍɫ, this.ՙᗮ)))
      return this; 
    if (paramˊᕝ.ՙᗮ == null)
      return this; 
    if (this.ՙᗮ == null)
      return paramˊᕝ; 
    if (paramˊᕝ.ˍɫ == null) {
      if (this.ˍɫ == null)
        return new ˊᕝ(this.ՙᗮ, paramˊᕝ.ՙᗮ); 
      if (zubdqvgt.G(paramˊᕝ.ՙᗮ, this.ՙᗮ) || zubdqvgt.G(paramˊᕝ.ՙᗮ, this.ˍɫ))
        return this; 
    } 
    if (this.ˍɫ == null && (zubdqvgt.G(this.ՙᗮ, paramˊᕝ.ՙᗮ) || zubdqvgt.G(this.ՙᗮ, paramˊᕝ.ˍɫ)))
      return paramˊᕝ; 
    HashSet<T> hashSet;
    (hashSet = new HashSet<>(4)).add(this.ՙᗮ);
    if (this.ˍɫ != null)
      hashSet.add(this.ˍɫ); 
    hashSet.add(paramˊᕝ.ՙᗮ);
    if (paramˊᕝ.ˍɫ != null)
      hashSet.add(paramˊᕝ.ˍɫ); 
    return hashSet;
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ˊᕝ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */