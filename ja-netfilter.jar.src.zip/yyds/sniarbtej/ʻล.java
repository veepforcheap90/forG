package yyds.sniarbtej;

public abstract class ʻล {
  private int ᐨẏ;
  
  private ʻล ᐨẏ;
  
  public ʻล(int paramInt) {
    this(paramInt, null);
  }
  
  public ʻล(int paramInt, ʻล paramʻล) {
    if (paramInt != 589824 && paramInt != 524288 && paramInt != 458752 && paramInt != 393216 && paramInt != 327680 && paramInt != 262144 && paramInt != 17432576) {
      "ᗻု큣⼐推埂＾눃勯㋧䚿筐釨痖ᴍ".toCharArray()[8] = (char)("ᗻု큣⼐推埂＾눃勯㋧䚿筐釨痖ᴍ".toCharArray()[8] ^ 0xE21);
      throw new IllegalArgumentException(ˏȓ$ᴵЃ.E("ᗻု큣⼐推埂＾눃勯㋧䚿筐釨痖ᴍ".toCharArray(), (short)5164, (short)2, (short)3) + paramInt);
    } 
    if (paramInt == 17432576)
      ᐨم.ᐨẏ(this); 
    this.ᐨẏ = paramʻล;
  }
  
  private ʻล ᐨẏ() {
    return this.ᐨẏ;
  }
  
  public void ʿᵉ(String paramString) {
    if (this.ᐨẏ != null)
      this.ᐨẏ.ʿᵉ(paramString); 
  }
  
  public void ʹﮃ(String paramString) {
    if (this.ᐨẏ != null)
      this.ᐨẏ.ʹﮃ(paramString); 
  }
  
  public void ᐨẏ(String paramString1, int paramInt, String paramString2) {
    if (this.ᐨẏ != null)
      this.ᐨẏ.ᐨẏ(paramString1, paramInt, paramString2); 
  }
  
  public void ᐨẏ(String paramString, int paramInt, String... paramVarArgs) {
    if (this.ᐨẏ != null)
      this.ᐨẏ.ᐨẏ(paramString, paramInt, paramVarArgs); 
  }
  
  public void ˊ(String paramString, int paramInt, String... paramVarArgs) {
    if (this.ᐨẏ != null)
      this.ᐨẏ.ˊ(paramString, paramInt, paramVarArgs); 
  }
  
  public void ՙᗮ(String paramString) {
    if (this.ᐨẏ != null)
      this.ᐨẏ.ՙᗮ(paramString); 
  }
  
  public void ᐨẏ(String paramString, String... paramVarArgs) {
    if (this.ᐨẏ != null)
      this.ᐨẏ.ᐨẏ(paramString, paramVarArgs); 
  }
  
  public void ᐨẏ() {
    if (this.ᐨẏ != null)
      this.ᐨẏ.ᐨẏ(); 
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ʻล.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */