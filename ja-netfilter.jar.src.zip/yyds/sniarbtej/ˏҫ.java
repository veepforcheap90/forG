package yyds.sniarbtej;

import ylt.pmn.zubdqvgt;

final class ˏҫ implements ˌ々 {
  private final ʸ<?> ˊ;
  
  private final boolean ˌᵋ;
  
  private final Class<?> ᐨẏ;
  
  private final יỉ<?> ᐨẏ;
  
  private final ˊᴄ<?> ᐨẏ;
  
  private ˏҫ(Object paramObject, ʸ<?> paramʸ, boolean paramBoolean, Class<?> paramClass) {
    this.ᐨẏ = (paramObject instanceof יỉ) ? (ˊᴄ<?>)paramObject : null;
    this.ᐨẏ = (paramObject instanceof ˊᴄ) ? (ˊᴄ)paramObject : null;
    ˌᑦ.ﾞл((this.ᐨẏ != null || this.ᐨẏ != null));
    this.ˊ = paramʸ;
    this.ˌᵋ = paramBoolean;
    this.ᐨẏ = (ˊᴄ<?>)paramClass;
  }
  
  public final <T> ٴۉ<T> ᐨẏ(ˑĴ paramˑĴ, ʸ<T> paramʸ) {
    ʸ<?> ʸ1;
    boolean bool;
    return (bool = (this.ˊ != null) ? ((this.ˊ.equals(paramʸ) || (this.ˌᵋ && zubdqvgt.G((ʸ1 = this.ˊ).ՙᗮ, (ʸ1 = paramʸ).ᐨم))) ? true : false) : this.ᐨẏ.isAssignableFrom((ʸ1 = paramʸ).ᐨم)) ? new ιﹽ<>((יỉ)this.ᐨẏ, this.ᐨẏ, paramˑĴ, paramʸ, this, (byte)0) : null;
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ˏҫ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */