package yyds.sniarbtej;

import java.io.EOFException;
import java.io.IOException;
import java.io.Writer;

public class ˏɪ {
  private static int ͺῘ = 0;
  
  private static int ﹳϯ = 1;
  
  private static int ˌᴿ = 2;
  
  private static int ˌᐣ = 3;
  
  private final byte[] ʿᵉ;
  
  private final int ـｔ;
  
  private ˏɪ() {
    throw new UnsupportedOperationException();
  }
  
  public static ᐧｴ ᐨẏ(יּ paramיּ) {
    boolean bool = true;
    try {
      paramיּ.ᐨẏ();
      bool = false;
      return ﾞｽ.ˈהּ.ᐨẏ(paramיּ);
    } catch (EOFException eOFException) {
      if (bool)
        return ڊ.ᐨẏ; 
      throw new ՙĩ(eOFException);
    } catch (ˑɺ ˑɺ) {
      throw new ՙĩ(ˑɺ);
    } catch (IOException iOException) {
      throw new ᙆ(iOException);
    } catch (NumberFormatException numberFormatException) {
      throw new ՙĩ(numberFormatException);
    } 
  }
  
  public static void ˊ(ᐧｴ paramᐧｴ, Ⴡ paramჁ) {
    ﾞｽ.ˈהּ.ᐨẏ(paramჁ, paramᐧｴ);
  }
  
  public static Writer ᐨẏ(Appendable paramAppendable) {
    return (paramAppendable instanceof Writer) ? (Writer)paramAppendable : new ŀ(paramAppendable, (byte)0);
  }
  
  public ˏɪ(byte[] paramArrayOfbyte, int paramInt) {
    this.ʿᵉ = paramArrayOfbyte;
    this.ـｔ = paramInt;
  }
  
  public int ˈے() {
    return this.ʿᵉ[this.ـｔ];
  }
  
  public int ՙᗮ(int paramInt) {
    return this.ʿᵉ[this.ـｔ + 2 * paramInt + 1];
  }
  
  public int ˍɫ(int paramInt) {
    return this.ʿᵉ[this.ـｔ + 2 * paramInt + 2];
  }
  
  private static ˏɪ ᐨẏ(String paramString) {
    if (paramString == null || paramString.length() == 0)
      return null; 
    int i = paramString.length();
    ʿᵉ ʿᵉ;
    (ʿᵉ = new ʿᵉ(i)).ᐨẏ(0);
    byte b = 0;
    while (b < i) {
      char c;
      if ((c = paramString.charAt(b++)) == '[') {
        ʿᵉ.ᐨẏ(0, 0);
        continue;
      } 
      if (c == '.') {
        ʿᵉ.ᐨẏ(1, 0);
        continue;
      } 
      if (c == '*') {
        ʿᵉ.ᐨẏ(2, 0);
        continue;
      } 
      if (c >= '0' && c <= '9') {
        int j = c - 48;
        while (b < i) {
          if ((c = paramString.charAt(b++)) >= '0' && c <= '9') {
            j = j * 10 + c - 48;
            continue;
          } 
          if (c != ';')
            throw new IllegalArgumentException(); 
        } 
        ʿᵉ.ᐨẏ(3, j);
        continue;
      } 
      throw new IllegalArgumentException();
    } 
    ʿᵉ.ˊ[0] = (byte)(ʿᵉ.ʹﮃ / 2);
    return new ˏɪ(ʿᵉ.ˊ, 0);
  }
  
  public String toString() {
    int i = ˈے();
    StringBuilder stringBuilder = new StringBuilder(i << 1);
    for (byte b = 0; b < i; b++) {
      switch (ՙᗮ(b)) {
        case 0:
          stringBuilder.append('[');
          break;
        case 1:
          stringBuilder.append('.');
          break;
        case 2:
          stringBuilder.append('*');
          break;
        case 3:
          stringBuilder.append(ˍɫ(b)).append(';');
          break;
        default:
          throw new AssertionError();
      } 
    } 
    return stringBuilder.toString();
  }
  
  public static void ᐨẏ(ˏɪ paramˏɪ, ʿᵉ paramʿᵉ) {
    if (paramˏɪ == null) {
      paramʿᵉ.ᐨẏ(0);
      return;
    } 
    int i = (paramˏɪ.ʿᵉ[paramˏɪ.ـｔ] << 1) + 1;
    paramʿᵉ.ᐨẏ(paramˏɪ.ʿᵉ, paramˏɪ.ـｔ, i);
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ˏɪ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */