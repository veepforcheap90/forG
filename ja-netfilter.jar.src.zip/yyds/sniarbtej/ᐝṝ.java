package yyds.sniarbtej;

import java.net.InetAddress;
import ylt.pmn.zubdqvgt;

final class ᐝṝ extends ٴۉ<InetAddress> {
  private static InetAddress ᐨẏ(יּ paramיּ) {
    if (zubdqvgt.G(paramיּ.ᐨẏ(), כ.ʽ)) {
      paramיּ.ۦ();
      return null;
    } 
    return InetAddress.getByName(paramיּ.ٴӵ());
  }
  
  private static void ᐨẏ(Ⴡ paramჁ, InetAddress paramInetAddress) {
    paramჁ.ˊ((paramInetAddress == null) ? null : paramInetAddress.getHostAddress());
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ᐝṝ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */