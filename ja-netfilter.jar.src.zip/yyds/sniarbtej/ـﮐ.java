package yyds.sniarbtej;

import java.math.BigInteger;
import ylt.pmn.zubdqvgt;

final class ـﮐ extends ٴۉ<BigInteger> {
  private static BigInteger ᐨẏ(יּ paramיּ) {
    if (zubdqvgt.G(paramיּ.ᐨẏ(), כ.ʽ)) {
      paramיּ.ۦ();
      return null;
    } 
    try {
      return new BigInteger(paramיּ.ٴӵ());
    } catch (NumberFormatException numberFormatException) {
      throw new ՙĩ(numberFormatException);
    } 
  }
  
  private static void ᐨẏ(Ⴡ paramჁ, BigInteger paramBigInteger) {
    paramჁ.ᐨẏ(paramBigInteger);
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ـﮐ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */