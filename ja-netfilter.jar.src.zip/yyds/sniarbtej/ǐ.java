package yyds.sniarbtej;

import java.lang.reflect.Array;
import java.util.ArrayList;
import ylt.pmn.zubdqvgt;

public final class ǐ<E> extends ٴۉ<Object> {
  public static final ˌ々 ˊ = new ٴゞ();
  
  private final Class<E> ᴵʖ;
  
  private final ٴۉ<E> ﾞл;
  
  public ǐ(ˑĴ paramˑĴ, ٴۉ<E> paramٴۉ, Class<E> paramClass) {
    this.ﾞл = new ᐨⅬ<>(paramˑĴ, paramٴۉ, paramClass);
    this.ᴵʖ = paramClass;
  }
  
  public final Object ᐨẏ(יּ paramיּ) {
    if (zubdqvgt.G(paramיּ.ᐨẏ(), כ.ʽ)) {
      paramיּ.ۦ();
      return null;
    } 
    ArrayList<E> arrayList = new ArrayList();
    paramיּ.ᵘ();
    while (paramיּ.hasNext()) {
      E e = this.ﾞл.ᐨẏ(paramיּ);
      arrayList.add(e);
    } 
    paramיּ.ˑܥ();
    Object object = Array.newInstance(this.ᴵʖ, arrayList.size());
    for (byte b = 0; b < arrayList.size(); b++)
      Array.set(object, b, arrayList.get(b)); 
    return object;
  }
  
  public final void ᐨẏ(Ⴡ paramჁ, Object paramObject) {
    if (paramObject == null) {
      paramჁ.ʿᵉ();
      return;
    } 
    paramჁ.ᐨẏ();
    byte b = 0;
    int i = Array.getLength(paramObject);
    while (b < i) {
      Object object = Array.get(paramObject, b);
      this.ﾞл.ᐨẏ(paramჁ, (E)object);
      b++;
    } 
    paramჁ.ˊ();
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ǐ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */