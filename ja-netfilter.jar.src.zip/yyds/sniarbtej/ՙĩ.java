package yyds.sniarbtej;

public final class ՙĩ extends ˑʖ {
  private static final long ᐨẏ = 1L;
  
  public ՙĩ(String paramString) {
    super(paramString);
  }
  
  public ՙĩ(String paramString, Throwable paramThrowable) {
    super(paramString, paramThrowable);
  }
  
  public ՙĩ(Throwable paramThrowable) {
    super(paramThrowable);
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ՙĩ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */