package yyds.sniarbtej;

import java.lang.reflect.Type;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ܝ {
  private ˎე ᐨẏ;
  
  private ｨ ᐨẏ;
  
  private ˌэ ᐨẏ;
  
  private final Map<Type, ᐝэ<?>> ʾ;
  
  private final List<ˌ々> ـไ;
  
  private final List<ˌ々> ˊᴬ;
  
  private boolean ιﾌ;
  
  private String ˑゞ;
  
  private int ʽί;
  
  private int ˋﾇ;
  
  private boolean ιˠ;
  
  private boolean ˈהּ;
  
  private boolean ﹳיִ;
  
  private boolean ᐧפ;
  
  private boolean ˑܘ;
  
  private final BigInteger ᐨẏ;
  
  private final BigInteger ˊ;
  
  private final int ʻˎ;
  
  private final int ʼｆ;
  
  private int ˈږ;
  
  private final BigInteger ᴵʖ;
  
  private final boolean ʴ;
  
  public ܝ() {
    this.ᐨẏ = ˎე.ˊ;
    this.ᐨẏ = (BigInteger)ｨ.ˊ;
    this.ᐨẏ = (BigInteger)ﾞɫ.ᐨẏ;
    this.ʾ = new HashMap<>();
    this.ـไ = new ArrayList<>();
    this.ˊᴬ = new ArrayList<>();
    this.ʽί = 2;
    this.ˋﾇ = 2;
    this.ﹳיִ = true;
  }
  
  private ܝ ᐨẏ(double paramDouble) {
    this.ᐨẏ = (BigInteger)this.ᐨẏ.ᐨẏ(paramDouble);
    return this;
  }
  
  private ܝ ᐨẏ(int... paramVarArgs) {
    this.ᐨẏ = (BigInteger)this.ᐨẏ.ᐨẏ(paramVarArgs);
    return this;
  }
  
  private ܝ ᐨẏ() {
    this.ˑܘ = true;
    return this;
  }
  
  private ܝ ˊ() {
    this.ᐨẏ = (BigInteger)this.ᐨẏ.ᴵʖ();
    return this;
  }
  
  private ܝ ᴵʖ() {
    this.ιﾌ = true;
    return this;
  }
  
  private ܝ ﾞл() {
    this.ιˠ = true;
    return this;
  }
  
  private ܝ ʿᵉ() {
    this.ᐨẏ = (BigInteger)this.ᐨẏ.ˊ();
    return this;
  }
  
  private ܝ ᐨẏ(ｨ paramｨ) {
    this.ᐨẏ = (BigInteger)paramｨ;
    return this;
  }
  
  private ܝ ᐨẏ(ﾞɫ paramﾞɫ) {
    this.ᐨẏ = (BigInteger)paramﾞɫ;
    return this;
  }
  
  private ܝ ᐨẏ(ˌэ paramˌэ) {
    this.ᐨẏ = (BigInteger)paramˌэ;
    return this;
  }
  
  private ܝ ᐨẏ(ᴶ... paramVarArgs) {
    int i = (paramVarArgs = paramVarArgs).length;
    for (byte b = 0; b < i; b++) {
      ᴶ ᴶ1 = paramVarArgs[b];
      this.ᐨẏ = (BigInteger)this.ᐨẏ.ᐨẏ(ᴶ1, true, true);
    } 
    return this;
  }
  
  private ܝ ᐨẏ(ᴶ paramᴶ) {
    this.ᐨẏ = (BigInteger)this.ᐨẏ.ᐨẏ(paramᴶ, true, false);
    return this;
  }
  
  private ܝ ˊ(ᴶ paramᴶ) {
    this.ᐨẏ = (BigInteger)this.ᐨẏ.ᐨẏ(paramᴶ, false, true);
    return this;
  }
  
  private ܝ ʹﮃ() {
    this.ᐧפ = true;
    return this;
  }
  
  private ܝ ՙᗮ() {
    this.ﹳיִ = false;
    return this;
  }
  
  private ܝ ᐨẏ(String paramString) {
    this.ˑゞ = paramString;
    return this;
  }
  
  private ܝ ᐨẏ(int paramInt) {
    this.ʽί = paramInt;
    this.ˑゞ = null;
    return this;
  }
  
  private ܝ ᐨẏ(int paramInt1, int paramInt2) {
    this.ʽί = paramInt1;
    this.ˋﾇ = paramInt2;
    this.ˑゞ = null;
    return this;
  }
  
  private ܝ ᐨẏ(Type paramType, Object paramObject) {
    ˌᑦ.ﾞл((paramObject instanceof יỉ || paramObject instanceof ˊᴄ || paramObject instanceof ᐝэ || paramObject instanceof ٴۉ));
    if (paramObject instanceof ᐝэ)
      this.ʾ.put(paramType, (ᐝэ)paramObject); 
    if (paramObject instanceof יỉ || paramObject instanceof ˊᴄ) {
      ʸ<?> ʸ = ʸ.ᐨẏ(paramType);
      this.ـไ.add(ιﹽ.ˊ(ʸ, paramObject));
    } 
    if (paramObject instanceof ٴۉ)
      this.ـไ.add(ﾞｽ.ᐨẏ(ʸ.ᐨẏ(paramType), (ٴۉ)paramObject)); 
    return this;
  }
  
  private ܝ ᐨẏ(ˌ々 paramˌ々) {
    this.ـไ.add(paramˌ々);
    return this;
  }
  
  private ܝ ᐨẏ(Class<?> paramClass, Object paramObject) {
    ˌᑦ.ﾞл((paramObject instanceof יỉ || paramObject instanceof ˊᴄ || paramObject instanceof ٴۉ));
    if (paramObject instanceof ˊᴄ || paramObject instanceof יỉ)
      this.ˊᴬ.add(0, ιﹽ.ᐨẏ(paramClass, paramObject)); 
    if (paramObject instanceof ٴۉ)
      this.ـไ.add(ﾞｽ.ˊ(paramClass, (ٴۉ)paramObject)); 
    return this;
  }
  
  private ܝ ˍɫ() {
    this.ˈהּ = true;
    return this;
  }
  
  private ˑĴ ᐨẏ() {
    ˌᴉ ˌᴉ;
    ArrayList<ˌ々> arrayList1;
    (arrayList1 = new ArrayList<>()).addAll(this.ـไ);
    Collections.reverse(arrayList1);
    arrayList1.addAll(this.ˊᴬ);
    ArrayList<ˌ々> arrayList2 = arrayList1;
    int j = this.ˋﾇ;
    int i = this.ʽί;
    String str;
    if ((str = this.ˑゞ) != null && !"".equals(str.trim())) {
      ˌᴉ = new ˌᴉ(str);
    } else if (i != 2 && j != 2) {
      ˌᴉ = new ˌᴉ(i, j);
    } else {
      return new ˑĴ((ˎე)this.ᐨẏ, (ˌэ)this.ᐨẏ, this.ʾ, this.ιﾌ, this.ιˠ, this.ˑܘ, this.ﹳיִ, this.ᐧפ, this.ˈהּ, (ｨ)this.ᐨẏ, arrayList1);
    } 
    arrayList2.add(ιﹽ.ᐨẏ(ʸ.ᐨẏ(Date.class), ˌᴉ));
    return new ˑĴ((ˎე)this.ᐨẏ, (ˌэ)this.ᐨẏ, this.ʾ, this.ιﾌ, this.ιˠ, this.ˑܘ, this.ﹳיִ, this.ᐧפ, this.ˈהּ, (ｨ)this.ᐨẏ, arrayList1);
  }
  
  private static void ᐨẏ(String paramString, int paramInt1, int paramInt2, List<ˌ々> paramList) {
    ˌᴉ ˌᴉ;
    if (paramString != null && !"".equals(paramString.trim())) {
      ˌᴉ = new ˌᴉ(paramString);
    } else if (paramInt1 != 2 && paramInt2 != 2) {
      ˌᴉ = new ˌᴉ(paramInt1, paramInt2);
    } else {
      return;
    } 
    paramList.add(ιﹽ.ᐨẏ(ʸ.ᐨẏ(Date.class), ˌᴉ));
  }
  
  private ܝ(BigInteger paramBigInteger1, BigInteger paramBigInteger2, int paramInt, boolean paramBoolean) {
    this.ˈږ = 0;
    this.ᐨẏ = paramBigInteger1;
    this.ˊ = paramBigInteger2;
    this.ʴ = paramBoolean;
    int i = paramBigInteger1.bitLength();
    this.ᴵʖ = new BigInteger(String.valueOf(paramInt));
    int j;
    if ((j = (int)Math.ceil(i / Math.log(paramInt) * Math.log(2.0D))) % 5 != 0)
      j = (j / 5 + 1) * 5; 
    this.ʼｆ = j;
    this.ʻˎ = i / 8 - 1;
  }
  
  public String ᐨẏ(byte[] paramArrayOfbyte) {
    int i;
    byte[] arrayOfByte = new byte[((i = paramArrayOfbyte.length % this.ʻˎ) == 0) ? paramArrayOfbyte.length : (paramArrayOfbyte.length + this.ʻˎ - i)];
    System.arraycopy(paramArrayOfbyte, 0, arrayOfByte, this.ʻˎ - i, paramArrayOfbyte.length);
    StringBuffer stringBuffer = new StringBuffer();
    for (i = 0; i < arrayOfByte.length; i += this.ʻˎ) {
      int k = this.ʻˎ;
      int j = i;
      StringBuffer stringBuffer1 = stringBuffer;
      byte[] arrayOfByte1 = arrayOfByte;
      ܝ ܝ1 = this;
      if (k != 0) {
        byte[] arrayOfByte2 = new byte[ܝ1.ʻˎ];
        System.arraycopy(arrayOfByte1, j, arrayOfByte2, 0, k);
        BigInteger bigInteger;
        if ((bigInteger = new BigInteger(1, arrayOfByte2)).compareTo(ܝ1.ˊ) >= 0) {
          "頻쯒椷ᾦ﫞費뚋蜍ᥐﭥ藉쉰꺝﷏鞟⣻齻樧".toCharArray()[6] = (char)("頻쯒椷ᾦ﫞費뚋蜍ᥐﭥ藉쉰꺝﷏鞟⣻齻樧".toCharArray()[6] ^ 0x6DA1);
          throw new IllegalArgumentException(ˍɫ$יς.J("頻쯒椷ᾦ﫞費뚋蜍ᥐﭥ藉쉰꺝﷏鞟⣻齻樧".toCharArray(), (short)6335, (short)5, (byte)0));
        } 
        bigInteger = bigInteger.modPow(ܝ1.ᐨẏ, ܝ1.ˊ);
        stringBuffer1.append(ܝ1.ͺо(ܝ1.ᐨẏ(bigInteger)));
      } 
    } 
    return stringBuffer.toString();
  }
  
  private void ᐨẏ(byte[] paramArrayOfbyte, StringBuffer paramStringBuffer, int paramInt1, int paramInt2) {
    if (paramInt2 == 0)
      return; 
    byte[] arrayOfByte = new byte[this.ʻˎ];
    System.arraycopy(paramArrayOfbyte, paramInt1, arrayOfByte, 0, paramInt2);
    BigInteger bigInteger;
    if ((bigInteger = new BigInteger(1, arrayOfByte)).compareTo(this.ˊ) >= 0) {
      "筲ꪭꈷ쏦ᬈ豇鹀„垶礦崐⫵ᦐ砞풀㧼컳껆䏔".toCharArray()[7] = (char)("筲ꪭꈷ쏦ᬈ豇鹀„垶礦崐⫵ᦐ砞풀㧼컳껆䏔".toCharArray()[7] ^ 0x5AB1);
      throw new IllegalArgumentException(ᐝᵣ$ﾞﾇ.j("筲ꪭꈷ쏦ᬈ豇鹀„垶礦崐⫵ᦐ砞풀㧼컳껆䏔".toCharArray(), (short)25692, 3, (short)0));
    } 
    bigInteger = bigInteger.modPow(this.ᐨẏ, this.ˊ);
    paramStringBuffer.append(ͺо(ᐨẏ(bigInteger)));
  }
  
  private String ͺо(String paramString) {
    StringBuffer stringBuffer = new StringBuffer();
    for (byte b = 0; b < paramString.length(); b++) {
      StringBuffer stringBuffer1 = stringBuffer;
      ܝ ܝ1;
      if ((ܝ1 = this).ˈږ > 0 && ܝ1.ˈږ % 5 == 0)
        if (ܝ1.ˈږ % 30 == 0) {
          stringBuffer1.append('\n');
        } else if (ܝ1.ʴ) {
          stringBuffer1.append('-');
        }  
      ܝ1.ˈږ++;
      stringBuffer.append(paramString.charAt(b));
    } 
    return stringBuffer.toString();
  }
  
  private String ᐨẏ(BigInteger paramBigInteger) {
    StringBuffer stringBuffer = new StringBuffer();
    for (byte b = 0; b < this.ʼｆ; b++) {
      BigInteger bigInteger;
      int i;
      if ((i = (bigInteger = paramBigInteger.mod(this.ᴵʖ)).intValue()) < 10) {
        i = (char)(i + 48);
      } else if (i < 36) {
        i = (char)(i + 65 - 10);
      } else if (i < 62) {
        i = (char)(i + 97 - 36);
      } else {
        i = (char)(i + 33 - 62);
      } 
      stringBuffer.insert(0, i);
      paramBigInteger = paramBigInteger.divide(this.ᴵʖ);
    } 
    return stringBuffer.toString();
  }
  
  private void ᐨẏ(StringBuffer paramStringBuffer) {
    if (this.ˈږ > 0 && this.ˈږ % 5 == 0)
      if (this.ˈږ % 30 == 0) {
        paramStringBuffer.append('\n');
      } else if (this.ʴ) {
        paramStringBuffer.append('-');
      }  
    this.ˈږ++;
  }
  
  private static char ᐨẏ(BigInteger paramBigInteger) {
    int i;
    if ((i = paramBigInteger.intValue()) < 10) {
      i = (char)(i + 48);
    } else if (i < 36) {
      i = (char)(i + 65 - 10);
    } else if (i < 62) {
      i = (char)(i + 97 - 36);
    } else {
      i = (char)(i + 33 - 62);
    } 
    return i;
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ܝ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */