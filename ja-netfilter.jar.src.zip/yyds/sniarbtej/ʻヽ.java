package yyds.sniarbtej;

import java.util.List;

public final class ʻヽ {
  private String ﾟ;
  
  private List<String> ʴ;
  
  public ʻヽ(String paramString, List<String> paramList) {
    this.ﾟ = paramString;
    this.ʴ = paramList;
  }
  
  public final void ᐨẏ(ʻล paramʻล) {
    paramʻล.ᐨẏ(this.ﾟ, this.ʴ.<String>toArray(new String[0]));
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ʻヽ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */