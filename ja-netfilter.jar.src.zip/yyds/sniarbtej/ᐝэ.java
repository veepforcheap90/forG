package yyds.sniarbtej;

public interface ᐝэ<T> {
  T ﾞл();
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ᐝэ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */