package yyds.sniarbtej;

import java.util.ArrayList;

public final class ͺĹ extends ـᘢ {
  private final ـᘢ ᐨẏ;
  
  private final ᴵઽ ᐨẏ;
  
  private ArrayList<String> ᐨẏ = new ArrayList<>();
  
  public ͺĹ(ـᘢ paramـᘢ, ᴵઽ paramᴵઽ) {
    this(589824, paramـᘢ, paramᴵઽ);
  }
  
  private ͺĹ(int paramInt, ـᘢ paramـᘢ, ᴵઽ paramᴵઽ) {
    super(589824);
    this.ᐨẏ = (ArrayList<String>)paramـᘢ;
    this.ᐨẏ = (ArrayList<String>)paramᴵઽ;
  }
  
  public final void ʾܪ(String paramString) {
    this.ᐨẏ.add(paramString);
    this.ᐨẏ.ʾܪ(this.ᐨẏ.ᴵʖ(paramString));
  }
  
  public final void ᐨم(String paramString) {
    String str = this.ᐨẏ.remove(this.ᐨẏ.size() - 1);
    paramString = str + '$' + paramString;
    this.ᐨẏ.add(paramString);
    str = this.ᐨẏ.ᴵʖ(str) + '$';
    int i = (paramString = this.ᐨẏ.ᴵʖ(paramString)).startsWith(str) ? str.length() : (paramString.lastIndexOf('$') + 1);
    this.ᐨẏ.ᐨم(paramString.substring(i));
  }
  
  public final void ʾ(String paramString) {
    this.ᐨẏ.ʾ(paramString);
  }
  
  public final void ͺо(String paramString) {
    this.ᐨẏ.ͺо(paramString);
  }
  
  public final ـᘢ ᐨẏ() {
    this.ᐨẏ.ᐨẏ();
    return this;
  }
  
  public final void ᐨẏ(char paramChar) {
    this.ᐨẏ.ᐨẏ(paramChar);
  }
  
  public final ـᘢ ˊ() {
    this.ᐨẏ.ˊ();
    return this;
  }
  
  public final ـᘢ ᴵʖ() {
    this.ᐨẏ.ᴵʖ();
    return this;
  }
  
  public final ـᘢ ﾞл() {
    this.ᐨẏ.ﾞл();
    return this;
  }
  
  public final ـᘢ ʿᵉ() {
    this.ᐨẏ.ʿᵉ();
    return this;
  }
  
  public final ـᘢ ʹﮃ() {
    this.ᐨẏ.ʹﮃ();
    return this;
  }
  
  public final ـᘢ ՙᗮ() {
    this.ᐨẏ.ՙᗮ();
    return this;
  }
  
  public final ـᘢ ˍɫ() {
    this.ᐨẏ.ˍɫ();
    return this;
  }
  
  public final void ʹл() {
    this.ᐨẏ.ʹл();
  }
  
  public final ـᘢ ᐨẏ(char paramChar) {
    this.ᐨẏ.ᐨẏ(paramChar);
    return this;
  }
  
  public final void ᐨẏ() {
    this.ᐨẏ.ᐨẏ();
    this.ᐨẏ.remove(this.ᐨẏ.size() - 1);
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ͺĹ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */