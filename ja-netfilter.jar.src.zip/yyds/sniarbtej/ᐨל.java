package yyds.sniarbtej;

import java.util.ListIterator;

public final class ᐨל extends ͺᔮ {
  public final String ᔪ() {
    "驕᲍ꊸ㶙㚸㄃䪻ギꝬ〖犱療湴樆혧ಉ᾿谕㨾Ø꣦ﴘ菐䱄稢壅哧ᒘꎧ⚙뤜ё꙳䱡ଁⒼ霗涁画⵼谁﯉씚ﷷ䶍휈ﳣ朑".toCharArray()[25] = (char)("驕᲍ꊸ㶙㚸㄃䪻ギꝬ〖犱療湴樆혧ಉ᾿谕㨾Ø꣦ﴘ菐䱄稢壅哧ᒘꎧ⚙뤜ё꙳䱡ଁⒼ霗涁画⵼谁﯉씚ﷷ䶍휈ﳣ朑".toCharArray()[25] ^ 0x19D);
    return ᐝᵣ$ﾞﾇ.j("驕᲍ꊸ㶙㚸㄃䪻ギꝬ〖犱療湴樆혧ಉ᾿谕㨾Ø꣦ﴘ菐䱄稢壅哧ᒘꎧ⚙뤜ё꙳䱡ଁⒼ霗涁画⵼谁﯉씚ﷷ䶍휈ﳣ朑".toCharArray(), (short)20334, 4, (short)5);
  }
  
  public final byte[] ˍɫ(byte[] paramArrayOfbyte) {
    return ᐨẏ(paramArrayOfbyte, paramᐧє -> {
          "싻䪭ᙇฑダ驝䢺?㉙º㛺ᕈ旸아ᘼ왻耍ፇ杻⪵".toCharArray()[6] = (char)("싻䪭ᙇฑダ驝䢺?㉙º㛺ᕈ旸아ᘼ왻耍ፇ杻⪵".toCharArray()[6] ^ 0x1EC4);
          "燅ᆁ垐譃蒍쭾佲嬯焋ꩩ뗸鳄ᨊ捴?銺앝舗躂亂⧨".toCharArray()[1] = (char)("燅ᆁ垐譃蒍쭾佲嬯焋ꩩ뗸鳄ᨊ捴?銺앝舗躂亂⧨".toCharArray()[1] ^ 0x6563);
          if (ˉﻤ$ͺſ.v("싻䪭ᙇฑダ驝䢺?㉙º㛺ᕈ旸아ᘼ왻耍ፇ杻⪵".toCharArray(), (short)9820, 1, (short)0).equals(paramᐧє.name) && paramᐧє.ˎᴗ.equals(ˉﻤ$ͺſ.v("燅ᆁ垐譃蒍쭾佲嬯焋ꩩ뗸鳄ᨊ捴?銺앝舗躂亂⧨".toCharArray(), (short)31709, 1, (short)3))) {
            ـс ـс = paramᐧє.ˊ;
            Ӏ ӏ = null;
            ListIterator<Ӏ> listIterator = ـс.ᐨẏ();
            while (listIterator.hasNext()) {
              Ӏ ӏ1;
              if ((ӏ1 = listIterator.next()).ˈהּ() == 176)
                ӏ = ӏ1; 
            } 
            if (ӏ != null) {
              ـс.ᴵʖ(ӏ, new ᕁ(58, 0));
              ـс.ᴵʖ(ӏ, new ᕁ(25, 0));
              "⭺".toCharArray()[1] = (char)("⭺".toCharArray()[1] ^ 0x5081);
              "떜쇒牢瀿븁?鸯ꋁњﲔ㧇鏼繎솯ႜᮠ鍷컌俞軑?戥䬢쾰㘞횣᳻큩〢篤쎬㉌ᮗ㢾船ꀨ规搵门敨ㅦ곀拐燎".toCharArray()[47] = (char)("떜쇒牢瀿븁?鸯ꋁњﲔ㧇鏼繎솯ႜᮠ鍷컌俞軑?戥䬢쾰㘞횣᳻큩〢篤쎬㉌ᮗ㢾船ꀨ规搵门敨ㅦ곀拐燎".toCharArray()[47] ^ 0x139C);
              ـс.ᴵʖ(ӏ, new ʾᔂ(184, ן, ˉﻤ$ͺſ.v("⭺".toCharArray(), (short)9542, 0, (short)2), ˉﻤ$ͺſ.v("떜쇒牢瀿븁?鸯ꋁњﲔ㧇鏼繎솯ႜᮠ鍷컌俞軑?戥䬢쾰㘞횣᳻큩〢篤쎬㉌ᮗ㢾船ꀨ规搵门敨ㅦ곀拐燎".toCharArray(), (short)8921, 4, (short)5), false));
            } 
          } 
        });
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ᐨל.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */