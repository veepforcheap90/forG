package yyds.sniarbtej;

import java.lang.reflect.Type;

public interface ˊᴄ<T> {
  T ᐨẏ(ᐧｴ paramᐧｴ, Type paramType, ـﾗ paramـﾗ);
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ˊᴄ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */