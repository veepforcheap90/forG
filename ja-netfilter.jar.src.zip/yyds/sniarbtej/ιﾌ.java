package yyds.sniarbtej;

public final class ιﾌ extends ˊᵃ {
  public final int ʹｨ;
  
  public ιﾌ ᐨẏ;
  
  ιﾌ(int paramInt1, int paramInt2, String paramString1, String paramString2, String paramString3, long paramLong, int paramInt3) {
    super(paramInt1, paramInt2, paramString1, paramString2, paramString3, paramLong);
    this.ʹｨ = paramInt3;
  }
  
  ιﾌ(int paramInt1, int paramInt2, String paramString, int paramInt3) {
    super(paramInt1, paramInt2, null, null, paramString, 0L);
    this.ʹｨ = paramInt3;
  }
  
  public ιﾌ(int paramInt1, int paramInt2, String paramString, long paramLong, int paramInt3) {
    super(paramInt1, paramInt2, null, null, paramString, paramLong);
    this.ʹｨ = paramInt3;
  }
  
  ιﾌ(int paramInt1, int paramInt2, String paramString1, String paramString2, int paramInt3) {
    super(paramInt1, 12, null, paramString1, paramString2, 0L);
    this.ʹｨ = paramInt3;
  }
  
  ιﾌ(int paramInt1, int paramInt2, long paramLong, int paramInt3) {
    super(paramInt1, paramInt2, null, null, null, paramLong);
    this.ʹｨ = paramInt3;
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ιﾌ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */