package yyds.sniarbtej;

import java.lang.reflect.Type;

final class ˑײַ implements ʿн<T> {
  private final ˋץ ᐨẏ = ˋץ.ᐨẏ();
  
  ˑײַ(ˍʶ paramˍʶ, Class paramClass, Type paramType) {}
  
  public final T ʿᵉ() {
    try {
      T t;
      return (T)(t = this.ᐨẏ.ᐨẏ((Class<Object>)this.ˊ));
    } catch (Exception exception) {
      "婡䟎椐嵌䯻ᓐ᨜瀫᫋혒欧┃턫핵嶰踗䎃ˡ쳆᝽똷血첦텨ষ粎⨔纞쭩ꅉꊒᬻ㖋铚席袬埀䍾ꨜ᷌".toCharArray()[17] = (char)("婡䟎椐嵌䯻ᓐ᨜瀫᫋혒欧┃턫핵嶰踗䎃ˡ쳆᝽똷血첦텨ষ粎⨔纞쭩ꅉꊒᬻ㖋铚席袬埀䍾ꨜ᷌".toCharArray()[17] ^ 0x3EB7);
      "纡Ռ녻༮אּ裏紴㹜⪨悘쾃᜾唻脋ሮ連㲦䲸౉⤄욊漉蚥袼䖺䳔鼢↰細ᗬⵏ뽊尨夆鲖벊緖ⵥ湿滉歞鄨鶻⦦潯玜緱⬃۷ﴄ䓆䔝䎥壙끢瘄钍⊤ㄚ⸘㩲䇫ထ缗ﮏ瞑⹪巕巸⇓".toCharArray()[28] = (char)("纡Ռ녻༮אּ裏紴㹜⪨悘쾃᜾唻脋ሮ連㲦䲸౉⤄욊漉蚥袼䖺䳔鼢↰細ᗬⵏ뽊尨夆鲖벊緖ⵥ湿滉歞鄨鶻⦦潯玜緱⬃۷ﴄ䓆䔝䎥壙끢瘄钍⊤ㄚ⸘㩲䇫ထ缗ﮏ瞑⹪巕巸⇓".toCharArray()[28] ^ 0x50E1);
      throw new RuntimeException(ˏȓ$ᴵЃ.E("婡䟎椐嵌䯻ᓐ᨜瀫᫋혒欧┃턫핵嶰踗䎃ˡ쳆᝽똷血첦텨ষ粎⨔纞쭩ꅉꊒᬻ㖋铚席袬埀䍾ꨜ᷌".toCharArray(), (short)6123, (short)3, (short)3) + this.ʹﮃ + ˏȓ$ᴵЃ.E("纡Ռ녻༮אּ裏紴㹜⪨悘쾃᜾唻脋ሮ連㲦䲸౉⤄욊漉蚥袼䖺䳔鼢↰細ᗬⵏ뽊尨夆鲖벊緖ⵥ湿滉歞鄨鶻⦦潯玜緱⬃۷ﴄ䓆䔝䎥壙끢瘄钍⊤ㄚ⸘㩲䇫ထ缗ﮏ瞑⹪巕巸⇓".toCharArray(), (short)30123, (short)4, (short)4), exception);
    } 
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ˑײַ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */