package yyds.sniarbtej;

public final class ʻւ {
  public final int ͺᴲ;
  
  final ᔪ ʾ;
  
  ʻւ ᐨẏ;
  
  ʻւ(int paramInt, ᔪ paramᔪ) {
    this.ͺᴲ = paramInt;
    this.ʾ = paramᔪ;
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ʻւ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */