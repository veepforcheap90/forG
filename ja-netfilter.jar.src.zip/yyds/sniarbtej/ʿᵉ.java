package yyds.sniarbtej;

public final class ʿᵉ {
  public byte[] ˊ = new byte[64];
  
  public int ʹﮃ;
  
  public ʿᵉ() {}
  
  public ʿᵉ(int paramInt) {}
  
  ʿᵉ(byte[] paramArrayOfbyte) {
    this.ʹﮃ = paramArrayOfbyte.length;
  }
  
  private int size() {
    return this.ʹﮃ;
  }
  
  public final ʿᵉ ᐨẏ(int paramInt) {
    int i;
    if ((i = this.ʹﮃ) + 1 > this.ˊ.length)
      ᐨẏ(1); 
    this.ˊ[i++] = (byte)paramInt;
    this.ʹﮃ = i;
    return this;
  }
  
  public final ʿᵉ ᐨẏ(int paramInt1, int paramInt2) {
    int i;
    if ((i = this.ʹﮃ) + 2 > this.ˊ.length)
      ᐨẏ(2); 
    byte[] arrayOfByte;
    (arrayOfByte = this.ˊ)[i++] = (byte)paramInt1;
    arrayOfByte[i++] = (byte)paramInt2;
    this.ʹﮃ = i;
    return this;
  }
  
  public final ʿᵉ ˊ(int paramInt) {
    int i;
    if ((i = this.ʹﮃ) + 2 > this.ˊ.length)
      ᐨẏ(2); 
    byte[] arrayOfByte;
    (arrayOfByte = this.ˊ)[i++] = (byte)(paramInt >>> 8);
    arrayOfByte[i++] = (byte)paramInt;
    this.ʹﮃ = i;
    return this;
  }
  
  public final ʿᵉ ˊ(int paramInt1, int paramInt2) {
    int i;
    if ((i = this.ʹﮃ) + 3 > this.ˊ.length)
      ᐨẏ(3); 
    byte[] arrayOfByte;
    (arrayOfByte = this.ˊ)[i++] = (byte)paramInt1;
    arrayOfByte[i++] = (byte)(paramInt2 >>> 8);
    arrayOfByte[i++] = (byte)paramInt2;
    this.ʹﮃ = i;
    return this;
  }
  
  final ʿᵉ ᐨẏ(int paramInt1, int paramInt2, int paramInt3) {
    if ((paramInt1 = this.ʹﮃ) + 4 > this.ˊ.length)
      ᐨẏ(4); 
    byte[] arrayOfByte;
    (arrayOfByte = this.ˊ)[paramInt1++] = 15;
    arrayOfByte[paramInt1++] = (byte)paramInt2;
    arrayOfByte[paramInt1++] = (byte)(paramInt3 >>> 8);
    arrayOfByte[paramInt1++] = (byte)paramInt3;
    this.ʹﮃ = paramInt1;
    return this;
  }
  
  public final ʿᵉ ᴵʖ(int paramInt) {
    int i;
    if ((i = this.ʹﮃ) + 4 > this.ˊ.length)
      ᐨẏ(4); 
    byte[] arrayOfByte;
    (arrayOfByte = this.ˊ)[i++] = (byte)(paramInt >>> 24);
    arrayOfByte[i++] = (byte)(paramInt >>> 16);
    arrayOfByte[i++] = (byte)(paramInt >>> 8);
    arrayOfByte[i++] = (byte)paramInt;
    this.ʹﮃ = i;
    return this;
  }
  
  final ʿᵉ ˊ(int paramInt1, int paramInt2, int paramInt3) {
    int i;
    if ((i = this.ʹﮃ) + 5 > this.ˊ.length)
      ᐨẏ(5); 
    byte[] arrayOfByte;
    (arrayOfByte = this.ˊ)[i++] = (byte)paramInt1;
    arrayOfByte[i++] = (byte)(paramInt2 >>> 8);
    arrayOfByte[i++] = (byte)paramInt2;
    arrayOfByte[i++] = (byte)(paramInt3 >>> 8);
    arrayOfByte[i++] = (byte)paramInt3;
    this.ʹﮃ = i;
    return this;
  }
  
  public final ʿᵉ ᐨẏ(long paramLong) {
    int i;
    if ((i = this.ʹﮃ) + 8 > this.ˊ.length)
      ᐨẏ(8); 
    byte[] arrayOfByte = this.ˊ;
    int j = (int)(paramLong >>> 32L);
    arrayOfByte[i++] = (byte)(j >>> 24);
    arrayOfByte[i++] = (byte)(j >>> 16);
    arrayOfByte[i++] = (byte)(j >>> 8);
    arrayOfByte[i++] = (byte)j;
    j = (int)paramLong;
    arrayOfByte[i++] = (byte)(j >>> 24);
    arrayOfByte[i++] = (byte)(j >>> 16);
    arrayOfByte[i++] = (byte)(j >>> 8);
    arrayOfByte[i++] = (byte)j;
    this.ʹﮃ = i;
    return this;
  }
  
  public final ʿᵉ ᐨẏ(String paramString) {
    int i;
    if ((i = paramString.length()) > 65535) {
      "⑆?讑?྘䒡鷾嘚肁ڊ춈孤㒍༺읠ᒴ밒熀".toCharArray()[4] = (char)("⑆?讑?྘䒡鷾嘚肁ڊ춈孤㒍༺읠ᒴ밒熀".toCharArray()[4] ^ 0x3097);
      throw new IllegalArgumentException(ˏȓ$ᴵЃ.E("⑆?讑?྘䒡鷾嘚肁ڊ춈孤㒍༺읠ᒴ밒熀".toCharArray(), (short)4398, (short)0, (short)0));
    } 
    int j;
    if ((j = this.ʹﮃ) + 2 + i > this.ˊ.length)
      ᐨẏ(i + 2); 
    byte[] arrayOfByte;
    (arrayOfByte = this.ˊ)[j++] = (byte)(i >>> 8);
    arrayOfByte[j++] = (byte)i;
    for (byte b = 0; b < i; b++) {
      char c;
      if ((c = paramString.charAt(b)) > '\000' && c <= '') {
        arrayOfByte[j++] = (byte)c;
      } else {
        this.ʹﮃ = j;
        return ᐨẏ(paramString, b, 65535);
      } 
    } 
    this.ʹﮃ = j;
    return this;
  }
  
  final ʿᵉ ᐨẏ(String paramString, int paramInt1, int paramInt2) {
    int i = paramString.length();
    int j = paramInt1;
    int k;
    for (k = paramInt1; k < i; k++) {
      char c;
      if ((c = paramString.charAt(k)) > '\000' && c <= '') {
        j++;
      } else if (c <= '߿') {
        j += 2;
      } else {
        j += 3;
      } 
    } 
    if (j > paramInt2) {
      "룫쎩顅凭쓽袕吴멁ᬈꙵᗘ聩턉羏悡ᛯ㙊赔价乚".toCharArray()[11] = (char)("룫쎩顅凭쓽袕吴멁ᬈꙵᗘ聩턉羏悡ᛯ㙊赔价乚".toCharArray()[11] ^ 0x46ED);
      throw new IllegalArgumentException(ˏȓ$ᴵЃ.E("룫쎩顅凭쓽袕吴멁ᬈꙵᗘ聩턉羏悡ᛯ㙊赔价乚".toCharArray(), (short)5424, (short)1, (short)0));
    } 
    if ((k = this.ʹﮃ - paramInt1 - 2) >= 0) {
      this.ˊ[k] = (byte)(j >>> 8);
      this.ˊ[k + 1] = (byte)j;
    } 
    if (this.ʹﮃ + j - paramInt1 > this.ˊ.length)
      ᐨẏ(j - paramInt1); 
    int m = this.ʹﮃ;
    for (paramInt1 = paramInt1; paramInt1 < i; paramInt1++) {
      if ((paramInt2 = paramString.charAt(paramInt1)) > 0 && paramInt2 <= 127) {
        this.ˊ[m++] = (byte)paramInt2;
      } else if (paramInt2 <= 2047) {
        this.ˊ[m++] = (byte)(0xC0 | paramInt2 >> 6 & 0x1F);
        this.ˊ[m++] = (byte)(0x80 | paramInt2 & 0x3F);
      } else {
        this.ˊ[m++] = (byte)(0xE0 | paramInt2 >> 12 & 0xF);
        this.ˊ[m++] = (byte)(0x80 | paramInt2 >> 6 & 0x3F);
        this.ˊ[m++] = (byte)(0x80 | paramInt2 & 0x3F);
      } 
    } 
    this.ʹﮃ = m;
    return this;
  }
  
  public final ʿᵉ ᐨẏ(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
    if (this.ʹﮃ + paramInt2 > this.ˊ.length)
      ᐨẏ(paramInt2); 
    if (paramArrayOfbyte != null)
      System.arraycopy(paramArrayOfbyte, paramInt1, this.ˊ, this.ʹﮃ, paramInt2); 
    this.ʹﮃ += paramInt2;
    return this;
  }
  
  private void ᐨẏ(int paramInt) {
    if (this.ʹﮃ > this.ˊ.length) {
      "嬪눚䜢袁ﴍᔅ궞ި韊?᩼궦ꉫ攝".toCharArray()[6] = (char)("嬪눚䜢袁ﴍᔅ궞ި韊?᩼궦ꉫ攝".toCharArray()[6] ^ 0x5757);
      throw new AssertionError(ˉﻤ$ͺſ.v("嬪눚䜢袁ﴍᔅ궞ި韊?᩼궦ꉫ攝".toCharArray(), (short)28038, 5, (short)3));
    } 
    int i = 2 * this.ˊ.length;
    paramInt = this.ʹﮃ + paramInt;
    byte[] arrayOfByte = new byte[(i > paramInt) ? i : paramInt];
    System.arraycopy(this.ˊ, 0, arrayOfByte, 0, this.ʹﮃ);
    this.ˊ = arrayOfByte;
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ʿᵉ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */