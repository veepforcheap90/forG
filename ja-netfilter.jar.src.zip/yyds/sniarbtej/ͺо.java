package yyds.sniarbtej;

final class ͺо extends ՙ⁔ {
  ͺо(ᔪ paramᔪ) {
    super(paramᔪ);
  }
  
  public final void ᐨẏ(int paramInt1, int paramInt2, ˊᵃ paramˊᵃ, ˌх paramˌх) {
    super.ᐨẏ(paramInt1, paramInt2, paramˊᵃ, paramˌх);
    ՙ⁔ ՙ⁔1 = new ՙ⁔(null);
    ᐨẏ(paramˌх, ՙ⁔1, 0);
    ᐨẏ(ՙ⁔1);
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ͺо.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */