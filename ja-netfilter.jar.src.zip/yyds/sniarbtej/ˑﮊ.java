package yyds.sniarbtej;

import java.lang.reflect.Type;

public interface ˑﮊ {
  ᐧｴ ˊ(Object paramObject);
  
  ᐧｴ ˊ(Object paramObject, Type paramType);
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ˑﮊ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */