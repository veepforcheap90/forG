package yyds.sniarbtej;

import java.lang.reflect.Type;

final class ٴゞ implements ˌ々 {
  public final <T> ٴۉ<T> ᐨẏ(ˑĴ paramˑĴ, ʸ<T> paramʸ) {
    Type type;
    if (!(type = (paramʸ = paramʸ).ՙᗮ instanceof java.lang.reflect.GenericArrayType) && (!(type instanceof Class) || !((Class)type).isArray()))
      return null; 
    type = ˑỲ.ˊ(type);
    ٴۉ<?> ٴۉ = paramˑĴ.ᐨẏ(ʸ.ᐨẏ(type));
    return new ǐ(paramˑĴ, ٴۉ, ˑỲ.ᐨẏ(type));
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ٴゞ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */