package yyds.sniarbtej;

import ylt.pmn.zubdqvgt;

final class ʻบ extends ٴۉ<T> {
  ʻบ(ٴۉ paramٴۉ) {}
  
  public final void ᐨẏ(Ⴡ paramჁ, T paramT) {
    if (paramT == null) {
      paramჁ.ʿᵉ();
      return;
    } 
    this.ᴵʖ.ᐨẏ(paramჁ, paramT);
  }
  
  public final T ᐨẏ(יּ paramיּ) {
    if (zubdqvgt.G(paramיּ.ᐨẏ(), כ.ʽ)) {
      paramיּ.ۦ();
      return null;
    } 
    return this.ᴵʖ.ᐨẏ(paramיּ);
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ʻบ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */