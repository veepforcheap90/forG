package yyds.sniarbtej;

public final class ʿᒧ {
  private String code;
  
  private String fallbackDate;
  
  private String paidUpTo;
  
  private boolean extend;
  
  public ʿᒧ() {
    "陣뒯҇丨焺㑈揞﻽໧柤".toCharArray()[2] = (char)("陣뒯҇丨焺㑈揞﻽໧柤".toCharArray()[2] ^ 0x22D0);
    this.fallbackDate = ˍɫ$יς.J("陣뒯҇丨焺㑈揞﻽໧柤".toCharArray(), (short)2581, (short)4, (byte)2);
    "蛂Ωꪝ拇᫜ꢩ遤⪟꺕穭".toCharArray()[5] = (char)("蛂Ωꪝ拇᫜ꢩ遤⪟꺕穭".toCharArray()[5] ^ 0x3FC6);
    this.paidUpTo = ˍɫ$יς.J("蛂Ωꪝ拇᫜ꢩ遤⪟꺕穭".toCharArray(), (short)18002, (short)0, (byte)5);
    this.extend = false;
  }
  
  public final String getCode() {
    return this.code;
  }
  
  public final void setCode(String paramString) {
    this.code = paramString;
  }
  
  public final String getFallbackDate() {
    return this.fallbackDate;
  }
  
  public final void setFallbackDate(String paramString) {
    this.fallbackDate = paramString;
  }
  
  public final String getPaidUpTo() {
    return this.paidUpTo;
  }
  
  public final void setPaidUpTo(String paramString) {
    this.paidUpTo = paramString;
  }
  
  public final boolean isExtend() {
    return this.extend;
  }
  
  public final void setExtend(boolean paramBoolean) {
    this.extend = paramBoolean;
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ʿᒧ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */