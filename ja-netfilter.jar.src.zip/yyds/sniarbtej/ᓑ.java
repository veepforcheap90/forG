package yyds.sniarbtej;

import java.lang.reflect.Type;

final class ᓑ implements ʿн<T> {
  ᓑ(ˍʶ paramˍʶ, ᐝэ paramᐝэ, Type paramType) {}
  
  public final T ʿᵉ() {
    return this.ᐨẏ.ﾞл();
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ᓑ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */