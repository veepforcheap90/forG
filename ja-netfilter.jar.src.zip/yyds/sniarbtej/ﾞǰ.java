package yyds.sniarbtej;

final class ﾞǰ extends ʼᵖ {
  final ˌх ᐨẏ;
  
  final int ᐝт;
  
  final int ɟ;
  
  int ﾞǰ;
  
  ˊ ᴵʖ;
  
  ˊ ﾞл;
  
  ˊ ʿᵉ;
  
  ˊ ʹﮃ;
  
  ᴵʖ ˊ;
  
  ﾞǰ(ˌх paramˌх, String paramString1, String paramString2, String paramString3) {
    super(589824);
    this.ᐨẏ = paramˌх;
    this.ᐝт = paramˌх.ՙᗮ(paramString1);
    this.ɟ = paramˌх.ՙᗮ(paramString2);
    if (paramString3 != null)
      this.ﾞǰ = paramˌх.ՙᗮ(paramString3); 
  }
  
  public final ᐨẏ ᐨẏ(String paramString, boolean paramBoolean) {
    return paramBoolean ? (this.ᴵʖ = ˊ.ᐨẏ(this.ᐨẏ, paramString, this.ᴵʖ)) : (this.ﾞл = ˊ.ᐨẏ(this.ᐨẏ, paramString, this.ﾞл));
  }
  
  public final ᐨẏ ᐨẏ(int paramInt, ˏɪ paramˏɪ, String paramString, boolean paramBoolean) {
    return paramBoolean ? (this.ʿᵉ = ˊ.ᐨẏ(this.ᐨẏ, paramInt, paramˏɪ, paramString, this.ʿᵉ)) : (this.ʹﮃ = ˊ.ᐨẏ(this.ᐨẏ, paramInt, paramˏɪ, paramString, this.ʹﮃ));
  }
  
  public final void ᴵʖ(ᴵʖ paramᴵʖ) {
    paramᴵʖ.ᐨẏ = this.ˊ;
    this.ˊ = paramᴵʖ;
  }
  
  public final void ᐨẏ() {}
  
  final int ˍ() {
    int i = (i = 6 + ᴵʖ.ᐨẏ(this.ᐨẏ, 0, this.ﾞǰ)) + ˊ.ᐨẏ(this.ᴵʖ, this.ﾞл, this.ʿᵉ, this.ʹﮃ);
    if (this.ˊ != null)
      i += this.ˊ.ᐨẏ(this.ᐨẏ); 
    return i;
  }
  
  final void ʿᵉ(ʿᵉ paramʿᵉ) {
    paramʿᵉ.ˊ(this.ᐝт).ˊ(this.ɟ);
    int i = 0;
    if (this.ﾞǰ != 0)
      i++; 
    if (this.ᴵʖ != null)
      i++; 
    if (this.ﾞл != null)
      i++; 
    if (this.ʿᵉ != null)
      i++; 
    if (this.ʹﮃ != null)
      i++; 
    if (this.ˊ != null)
      i += this.ˊ.ᐨẏ(); 
    paramʿᵉ.ˊ(i);
    ᴵʖ.ᐨẏ(this.ᐨẏ, 0, this.ﾞǰ, paramʿᵉ);
    ˊ.ᐨẏ(this.ᐨẏ, this.ᴵʖ, this.ﾞл, this.ʿᵉ, this.ʹﮃ, paramʿᵉ);
    if (this.ˊ != null)
      this.ˊ.ᐨẏ(this.ᐨẏ, paramʿᵉ); 
  }
  
  final void ᐨẏ(ﾞл paramﾞл) {
    paramﾞл.ᐨẏ(this.ˊ);
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ﾞǰ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */