package yyds.sniarbtej;

import java.util.Iterator;
import java.util.Map;

final class ٴᵇ extends ˋᕁ {
  public final void ᐨẏ(יּ paramיּ) {
    if (paramיּ instanceof ڍ) {
      (paramיּ = paramיּ).ᐨẏ(כ.ʿᵉ);
      Iterator<Map.Entry> iterator;
      Map.Entry entry = (iterator = (Iterator<Map.Entry>)paramיּ.ՙᗮ()).next();
      ((ڍ)paramיּ).ᴵʖ.add(entry.getValue());
      ((ڍ)paramיּ).ᴵʖ.add(new ﭘ((String)entry.getKey()));
      return;
    } 
    int i;
    if ((i = יּ.ᐨẏ(paramיּ)) == 0)
      i = יּ.ˊ(paramיּ); 
    if (i == 13) {
      יּ.ᐨẏ(paramיּ, 9);
      return;
    } 
    if (i == 12) {
      יּ.ᐨẏ(paramיּ, 8);
      return;
    } 
    if (i == 14) {
      יּ.ᐨẏ(paramיּ, 10);
      return;
    } 
    "0弐퐑즶朗憽墘ゅ⽌࣋ꪵ{㕍錨⾂쨎㘌洀昺晔㥨夛孮".toCharArray()[3] = (char)("0弐퐑즶朗憽墘ゅ⽌࣋ꪵ{㕍錨⾂쨎㘌洀昺晔㥨夛孮".toCharArray()[3] ^ 0x1E44);
    "焥웻ľ뽋햒졃똿䥔吷珳".toCharArray()[7] = (char)("焥웻ľ뽋햒졃똿䥔吷珳".toCharArray()[7] ^ 0x1E6);
    "晫茸㦢㾱㫥⪮".toCharArray()[7] = (char)("晫茸㦢㾱㫥⪮".toCharArray()[7] ^ 0x47A);
    "좷ﲏ狢硩⦨".toCharArray()[1] = (char)("좷ﲏ狢硩⦨".toCharArray()[1] ^ 0x6C2E);
    throw new IllegalStateException(ᐝᵣ$ﾞﾇ.j("0弐퐑즶朗憽墘ゅ⽌࣋ꪵ{㕍錨⾂쨎㘌洀昺晔㥨夛孮".toCharArray(), (short)5441, 1, (short)4) + paramיּ.ᐨẏ() + ᐝᵣ$ﾞﾇ.j("焥웻ľ뽋햒졃똿䥔吷珳".toCharArray(), (short)16256, 5, (short)3) + יּ.ᴵʖ(paramיּ) + ᐝᵣ$ﾞﾇ.j("晫茸㦢㾱㫥⪮".toCharArray(), (short)9258, 3, (short)0) + יּ.ﾞл(paramיּ) + ᐝᵣ$ﾞﾇ.j("좷ﲏ狢硩⦨".toCharArray(), (short)17889, 0, (short)2) + paramיּ.ˌ());
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ٴᵇ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */