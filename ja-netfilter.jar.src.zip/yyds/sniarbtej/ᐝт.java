package yyds.sniarbtej;

import java.util.List;
import java.util.Set;
import ylt.pmn.zubdqvgt;

public class ᐝт extends וּ<ɟ> implements ـﭔ {
  public ᐝт() {
    super(589824);
    if (!zubdqvgt.G(getClass(), ᐝт.class))
      throw new IllegalStateException(); 
  }
  
  private ᐝт(int paramInt) {
    super(paramInt);
  }
  
  private static ɟ ᐨẏ(ˑܘ paramˑܘ) {
    return zubdqvgt.G(paramˑܘ, ˑܘ.ᐨẏ) ? null : new ɟ((paramˑܘ == null) ? 1 : paramˑܘ.ˍɫ());
  }
  
  private static ɟ ᐨẏ(Ӏ paramӀ) {
    byte b;
    Object object;
    switch (paramӀ.ˈהּ()) {
      case 9:
      case 10:
      case 14:
      case 15:
        b = 2;
        return new ɟ(b, paramӀ);
      case 18:
        i = (object = ((ˏἴ)paramӀ).ʿᵉ instanceof Long || object instanceof Double) ? 2 : 1;
        return new ɟ(i, paramӀ);
      case 178:
        i = ˑܘ.ᐨẏ(((ˑܥ)paramӀ).ˎᴗ).ˍɫ();
        return new ɟ(i, paramӀ);
    } 
    int i = 1;
    return new ɟ(i, paramӀ);
  }
  
  private static ɟ ᐨẏ(Ӏ paramӀ, ɟ paramɟ) {
    return new ɟ((paramɟ = paramɟ).ʿᵉ, paramӀ);
  }
  
  private static ɟ ˊ(Ӏ paramӀ) {
    switch (paramӀ.ˈהּ()) {
      case 117:
      case 119:
      case 133:
      case 135:
      case 138:
      case 140:
      case 141:
      case 143:
        i = 2;
        return new ɟ(i, paramӀ);
      case 180:
        i = ˑܘ.ᐨẏ(((ˑܥ)paramӀ).ˎᴗ).ˍɫ();
        return new ɟ(i, paramӀ);
    } 
    int i = 1;
    return new ɟ(i, paramӀ);
  }
  
  private static ɟ ᴵʖ(Ӏ paramӀ) {
    switch (paramӀ.ˈהּ()) {
      case 47:
      case 49:
      case 97:
      case 99:
      case 101:
      case 103:
      case 105:
      case 107:
      case 109:
      case 111:
      case 113:
      case 115:
      case 121:
      case 123:
      case 125:
      case 127:
      case 129:
      case 131:
        b = 2;
        return new ɟ(b, paramӀ);
    } 
    byte b = 1;
    return new ɟ(b, paramӀ);
  }
  
  private static ɟ ﾞл(Ӏ paramӀ) {
    return new ɟ(1, paramӀ);
  }
  
  private static ɟ ʿᵉ(Ӏ paramӀ) {
    int i;
    if ((i = paramӀ.ˈהּ()) == 197) {
      i = 1;
    } else if (i == 186) {
      i = ˑܘ.ﾞл(((ʻᴷ)paramӀ).ˎᴗ).ˍɫ();
    } else {
      i = ˑܘ.ﾞл(((ʾᔂ)paramӀ).ˎᴗ).ˍɫ();
    } 
    return new ɟ(i, paramӀ);
  }
  
  private static void ˎᴗ() {}
  
  private static ɟ ᐨẏ(ɟ paramɟ1, ɟ paramɟ2) {
    // Byte code:
    //   0: aload_0
    //   1: getfield ᐨẏ : Ljava/util/Set;
    //   4: instanceof yyds/sniarbtej/ˊᕝ
    //   7: ifeq -> 331
    //   10: aload_1
    //   11: getfield ᐨẏ : Ljava/util/Set;
    //   14: instanceof yyds/sniarbtej/ˊᕝ
    //   17: ifeq -> 331
    //   20: aload_0
    //   21: getfield ᐨẏ : Ljava/util/Set;
    //   24: checkcast yyds/sniarbtej/ˊᕝ
    //   27: aload_1
    //   28: getfield ᐨẏ : Ljava/util/Set;
    //   31: checkcast yyds/sniarbtej/ˊᕝ
    //   34: astore_3
    //   35: astore_2
    //   36: aload_3
    //   37: getfield ՙᗮ : Ljava/lang/Object;
    //   40: aload_2
    //   41: getfield ՙᗮ : Ljava/lang/Object;
    //   44: invokestatic G : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   47: ifeq -> 64
    //   50: aload_3
    //   51: getfield ˍɫ : Ljava/lang/Object;
    //   54: aload_2
    //   55: getfield ˍɫ : Ljava/lang/Object;
    //   58: invokestatic G : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   61: ifne -> 92
    //   64: aload_3
    //   65: getfield ՙᗮ : Ljava/lang/Object;
    //   68: aload_2
    //   69: getfield ˍɫ : Ljava/lang/Object;
    //   72: invokestatic G : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   75: ifeq -> 96
    //   78: aload_3
    //   79: getfield ˍɫ : Ljava/lang/Object;
    //   82: aload_2
    //   83: getfield ՙᗮ : Ljava/lang/Object;
    //   86: invokestatic G : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   89: ifeq -> 96
    //   92: aload_2
    //   93: goto -> 286
    //   96: aload_3
    //   97: getfield ՙᗮ : Ljava/lang/Object;
    //   100: ifnonnull -> 107
    //   103: aload_2
    //   104: goto -> 286
    //   107: aload_2
    //   108: getfield ՙᗮ : Ljava/lang/Object;
    //   111: ifnonnull -> 118
    //   114: aload_3
    //   115: goto -> 286
    //   118: aload_3
    //   119: getfield ˍɫ : Ljava/lang/Object;
    //   122: ifnonnull -> 182
    //   125: aload_2
    //   126: getfield ˍɫ : Ljava/lang/Object;
    //   129: ifnonnull -> 150
    //   132: new yyds/sniarbtej/ˊᕝ
    //   135: dup
    //   136: aload_2
    //   137: getfield ՙᗮ : Ljava/lang/Object;
    //   140: aload_3
    //   141: getfield ՙᗮ : Ljava/lang/Object;
    //   144: invokespecial <init> : (Ljava/lang/Object;Ljava/lang/Object;)V
    //   147: goto -> 286
    //   150: aload_3
    //   151: getfield ՙᗮ : Ljava/lang/Object;
    //   154: aload_2
    //   155: getfield ՙᗮ : Ljava/lang/Object;
    //   158: invokestatic G : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   161: ifne -> 178
    //   164: aload_3
    //   165: getfield ՙᗮ : Ljava/lang/Object;
    //   168: aload_2
    //   169: getfield ˍɫ : Ljava/lang/Object;
    //   172: invokestatic G : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   175: ifeq -> 182
    //   178: aload_2
    //   179: goto -> 286
    //   182: aload_2
    //   183: getfield ˍɫ : Ljava/lang/Object;
    //   186: ifnonnull -> 221
    //   189: aload_2
    //   190: getfield ՙᗮ : Ljava/lang/Object;
    //   193: aload_3
    //   194: getfield ՙᗮ : Ljava/lang/Object;
    //   197: invokestatic G : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   200: ifne -> 217
    //   203: aload_2
    //   204: getfield ՙᗮ : Ljava/lang/Object;
    //   207: aload_3
    //   208: getfield ˍɫ : Ljava/lang/Object;
    //   211: invokestatic G : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   214: ifeq -> 221
    //   217: aload_3
    //   218: goto -> 286
    //   221: new java/util/HashSet
    //   224: dup
    //   225: iconst_4
    //   226: invokespecial <init> : (I)V
    //   229: dup
    //   230: astore #4
    //   232: aload_2
    //   233: getfield ՙᗮ : Ljava/lang/Object;
    //   236: invokevirtual add : (Ljava/lang/Object;)Z
    //   239: pop
    //   240: aload_2
    //   241: getfield ˍɫ : Ljava/lang/Object;
    //   244: ifnull -> 257
    //   247: aload #4
    //   249: aload_2
    //   250: getfield ˍɫ : Ljava/lang/Object;
    //   253: invokevirtual add : (Ljava/lang/Object;)Z
    //   256: pop
    //   257: aload #4
    //   259: aload_3
    //   260: getfield ՙᗮ : Ljava/lang/Object;
    //   263: invokevirtual add : (Ljava/lang/Object;)Z
    //   266: pop
    //   267: aload_3
    //   268: getfield ˍɫ : Ljava/lang/Object;
    //   271: ifnull -> 284
    //   274: aload #4
    //   276: aload_3
    //   277: getfield ˍɫ : Ljava/lang/Object;
    //   280: invokevirtual add : (Ljava/lang/Object;)Z
    //   283: pop
    //   284: aload #4
    //   286: dup
    //   287: astore_2
    //   288: aload_0
    //   289: getfield ᐨẏ : Ljava/util/Set;
    //   292: invokestatic G : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   295: ifeq -> 311
    //   298: aload_0
    //   299: getfield ʿᵉ : I
    //   302: aload_1
    //   303: getfield ʿᵉ : I
    //   306: if_icmpne -> 311
    //   309: aload_0
    //   310: areturn
    //   311: new yyds/sniarbtej/ɟ
    //   314: dup
    //   315: aload_0
    //   316: getfield ʿᵉ : I
    //   319: aload_1
    //   320: getfield ʿᵉ : I
    //   323: invokestatic min : (II)I
    //   326: aload_2
    //   327: invokespecial <init> : (ILjava/util/Set;)V
    //   330: areturn
    //   331: aload_0
    //   332: getfield ʿᵉ : I
    //   335: aload_1
    //   336: getfield ʿᵉ : I
    //   339: if_icmpne -> 381
    //   342: aload_0
    //   343: getfield ᐨẏ : Ljava/util/Set;
    //   346: aload_1
    //   347: getfield ᐨẏ : Ljava/util/Set;
    //   350: astore_3
    //   351: dup
    //   352: astore_2
    //   353: invokeinterface size : ()I
    //   358: aload_3
    //   359: invokeinterface size : ()I
    //   364: if_icmpge -> 371
    //   367: iconst_0
    //   368: goto -> 378
    //   371: aload_2
    //   372: aload_3
    //   373: invokeinterface containsAll : (Ljava/util/Collection;)Z
    //   378: ifne -> 427
    //   381: new java/util/HashSet
    //   384: dup
    //   385: invokespecial <init> : ()V
    //   388: dup
    //   389: astore_2
    //   390: aload_0
    //   391: getfield ᐨẏ : Ljava/util/Set;
    //   394: invokevirtual addAll : (Ljava/util/Collection;)Z
    //   397: pop
    //   398: aload_2
    //   399: aload_1
    //   400: getfield ᐨẏ : Ljava/util/Set;
    //   403: invokevirtual addAll : (Ljava/util/Collection;)Z
    //   406: pop
    //   407: new yyds/sniarbtej/ɟ
    //   410: dup
    //   411: aload_0
    //   412: getfield ʿᵉ : I
    //   415: aload_1
    //   416: getfield ʿᵉ : I
    //   419: invokestatic min : (II)I
    //   422: aload_2
    //   423: invokespecial <init> : (ILjava/util/Set;)V
    //   426: areturn
    //   427: aload_0
    //   428: areturn
  }
  
  private static <E> boolean ᐨẏ(Set<E> paramSet1, Set<E> paramSet2) {
    return (paramSet1.size() < paramSet2.size()) ? false : paramSet1.containsAll(paramSet2);
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ᐝт.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */