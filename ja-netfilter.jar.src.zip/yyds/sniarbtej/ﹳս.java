package yyds.sniarbtej;

import ylt.pmn.zubdqvgt;

final class ﹳս extends ٴۉ<Boolean> {
  private static Boolean ᐨẏ(יּ paramיּ) {
    if (zubdqvgt.G(paramיּ.ᐨẏ(), כ.ʽ)) {
      paramיּ.ۦ();
      return null;
    } 
    return zubdqvgt.G(paramיּ.ᐨẏ(), כ.ʹﮃ) ? Boolean.valueOf(Boolean.parseBoolean(paramיּ.ٴӵ())) : Boolean.valueOf(paramיּ.ˈے());
  }
  
  private static void ᐨẏ(Ⴡ paramჁ, Boolean paramBoolean) {
    if (paramBoolean == null) {
      paramჁ.ʿᵉ();
      return;
    } 
    paramჁ.ᐨẏ(paramBoolean.booleanValue());
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ﹳս.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */