package yyds.sniarbtej;

public abstract class ᴵƚ {
  protected final int ᐨẏ;
  
  protected ᴵƚ ᐨẏ;
  
  public ᴵƚ(int paramInt) {
    this(paramInt, null);
  }
  
  public ᴵƚ(int paramInt, ᴵƚ paramᴵƚ) {
    if (paramInt != 589824 && paramInt != 524288 && paramInt != 458752 && paramInt != 393216 && paramInt != 327680 && paramInt != 262144 && paramInt != 17432576) {
      "鍋긛甑쐋䓍衱䍛盨뻐죧몟嫽웗խ육䍼".toCharArray()[9] = (char)("鍋긛甑쐋䓍衱䍛盨뻐죧몟嫽웗խ육䍼".toCharArray()[9] ^ 0x7BA4);
      throw new IllegalArgumentException(ˉﻤ$ͺſ.v("鍋긛甑쐋䓍衱䍛盨뻐죧몟嫽웗խ육䍼".toCharArray(), (short)10024, 2, (short)4) + paramInt);
    } 
    if (paramInt == 17432576)
      ᐨم.ᐨẏ(this); 
    this.ᐨẏ = paramInt;
    this.ᐨẏ = paramᴵƚ;
  }
  
  private ᴵƚ ᐨẏ() {
    return this.ᐨẏ;
  }
  
  public ᐨẏ ᐨẏ(String paramString, boolean paramBoolean) {
    return (this.ᐨẏ != null) ? this.ᐨẏ.ᐨẏ(paramString, paramBoolean) : null;
  }
  
  public ᐨẏ ᐨẏ(int paramInt, ˏɪ paramˏɪ, String paramString, boolean paramBoolean) {
    if (this.ᐨẏ < 327680) {
      "椌ἷ᫡娍ꩭ᤾퇧캈뽧降꺉ꮤষ꽣눊⠗䘫㉟瀒⋪꺰᷺寛鱀溃鸽ㅡ".toCharArray()[21] = (char)("椌ἷ᫡娍ꩭ᤾퇧캈뽧降꺉ꮤষ꽣눊⠗䘫㉟瀒⋪꺰᷺寛鱀溃鸽ㅡ".toCharArray()[21] ^ 0x5DE9);
      throw new UnsupportedOperationException(ᐨẏ$ᐝт.W("椌ἷ᫡娍ꩭ᤾퇧캈뽧降꺉ꮤষ꽣눊⠗䘫㉟瀒⋪꺰᷺寛鱀溃鸽ㅡ".toCharArray(), (short)4825, (byte)1, (short)3));
    } 
    return (this.ᐨẏ != null) ? this.ᐨẏ.ᐨẏ(paramInt, paramˏɪ, paramString, paramBoolean) : null;
  }
  
  public void ᴵʖ(ᴵʖ paramᴵʖ) {
    if (this.ᐨẏ != null)
      this.ᐨẏ.ᴵʖ(paramᴵʖ); 
  }
  
  public void ᐨẏ() {
    if (this.ᐨẏ != null)
      this.ᐨẏ.ᐨẏ(); 
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ᴵƚ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */