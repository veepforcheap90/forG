package yyds.sniarbtej;

import java.lang.reflect.Type;
import java.util.Collection;
import ylt.pmn.zubdqvgt;

final class ͺſ<E> extends ٴۉ<Collection<E>> {
  private final ٴۉ<E> ʿᵉ;
  
  private final ʿн<? extends Collection<E>> ᐨẏ;
  
  public ͺſ(ˑĴ paramˑĴ, Type paramType, ٴۉ<E> paramٴۉ, ʿн<? extends Collection<E>> paramʿн) {
    this.ʿᵉ = new ᐨⅬ<>(paramˑĴ, paramٴۉ, paramType);
    this.ᐨẏ = paramʿн;
  }
  
  private Collection<E> ᐨẏ(יּ paramיּ) {
    if (zubdqvgt.G(paramיּ.ᐨẏ(), כ.ʽ)) {
      paramיּ.ۦ();
      return null;
    } 
    Collection<E> collection = this.ᐨẏ.ʿᵉ();
    paramיּ.ᵘ();
    while (paramיּ.hasNext()) {
      E e = this.ʿᵉ.ᐨẏ(paramיּ);
      collection.add(e);
    } 
    paramיּ.ˑܥ();
    return collection;
  }
  
  private void ᐨẏ(Ⴡ paramჁ, Collection<E> paramCollection) {
    // Byte code:
    //   0: aload_2
    //   1: ifnonnull -> 10
    //   4: aload_1
    //   5: invokevirtual ʿᵉ : ()Lyyds/sniarbtej/Ⴡ;
    //   8: pop
    //   9: return
    //   10: aload_1
    //   11: invokevirtual ᐨẏ : ()Lyyds/sniarbtej/Ⴡ;
    //   14: pop
    //   15: aload_2
    //   16: invokeinterface iterator : ()Ljava/util/Iterator;
    //   21: astore_2
    //   22: aload_2
    //   23: invokeinterface hasNext : ()Z
    //   28: ifeq -> 50
    //   31: aload_2
    //   32: invokeinterface next : ()Ljava/lang/Object;
    //   37: astore_3
    //   38: aload_0
    //   39: getfield ʿᵉ : Lyyds/sniarbtej/ٴۉ;
    //   42: aload_1
    //   43: aload_3
    //   44: invokevirtual ᐨẏ : (Lyyds/sniarbtej/Ⴡ;Ljava/lang/Object;)V
    //   47: goto -> 22
    //   50: aload_1
    //   51: invokevirtual ˊ : ()Lyyds/sniarbtej/Ⴡ;
    //   54: pop
    //   55: return
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ͺſ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */