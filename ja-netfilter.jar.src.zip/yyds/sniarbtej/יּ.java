package yyds.sniarbtej;

import java.io.Closeable;
import java.io.EOFException;
import java.io.IOException;
import java.io.Reader;

public class יּ implements Closeable {
  private static final char[] ᴵʖ = ᐝᵣ$ﾞﾇ.j("ꓖӯ铭?⮷".toCharArray(), (short)28111, 0, (short)1).toCharArray();
  
  private static final long ᴵʖ = -922337203685477580L;
  
  private static final int ẗ = 0;
  
  private static final int ˏҐ = 1;
  
  private static final int ˉٴ = 2;
  
  private static final int ٴᖨ = 3;
  
  private static final int ʹ = 4;
  
  private static final int ᴵͺ = 5;
  
  private static final int 冖 = 6;
  
  private static final int ـΓ = 7;
  
  private static final int ʾу = 8;
  
  private static final int ʾﺀ = 9;
  
  private static final int ʿᴳ = 10;
  
  private static final int ʹסּ = 11;
  
  private static final int ʹﻋ = 12;
  
  private static final int ـב = 13;
  
  private static final int ͺˍ = 14;
  
  private static final int ˍī = 15;
  
  private static final int ˌӭ = 16;
  
  private static final int יﯦ = 17;
  
  private static final int Ị = 0;
  
  private static final int ˊȯ = 1;
  
  private static final int ᐨﭕ = 2;
  
  private static final int ʻᎥ = 3;
  
  private static final int ᐝﺙ = 4;
  
  private static final int ᴵｫ = 5;
  
  private static final int ˉԴ = 6;
  
  private static final int ٴᓸ = 7;
  
  private final Reader ˊ;
  
  public boolean ˎאּ = false;
  
  private final char[] ﾞл;
  
  private int ˑﮌ = 0;
  
  private int ƭ = 0;
  
  private int ˑᐟ = 0;
  
  private int ʾẎ = 0;
  
  private int ʿﭝ = 0;
  
  private long ﾞл = new char[1024];
  
  private int ⅼ;
  
  private String ιƚ;
  
  private int[] ᐝᵣ = new int[32];
  
  private int יċ = 0;
  
  private String[] ʹﮃ;
  
  private int[] ᔪ;
  
  public יּ(Reader paramReader) {
    this.ᐝᵣ[this.יċ++] = 6;
    this.ʹﮃ = new String[32];
    this.ᔪ = new int[32];
    if (paramReader == null) {
      "ﾸ?ᴟѾⵟᔲ찶➢ꏾ䂷".toCharArray()[7] = (char)("ﾸ?ᴟѾⵟᔲ찶➢ꏾ䂷".toCharArray()[7] ^ 0x6326);
      throw new NullPointerException(ˉﻤ$ͺſ.v("ﾸ?ᴟѾⵟᔲ찶➢ꏾ䂷".toCharArray(), (short)16952, 3, (short)5));
    } 
    this.ˊ = paramReader;
  }
  
  public final void ʿᵉ(boolean paramBoolean) {
    this.ˎאּ = paramBoolean;
  }
  
  public final boolean ـﭔ() {
    return this.ˎאּ;
  }
  
  public void ᵘ() {
    int i;
    if ((i = this.ʿﭝ) == 0)
      i = ۥ(); 
    if (i == 3) {
      ˊ(1);
      this.ᔪ[this.יċ - 1] = 0;
      this.ʿﭝ = 0;
      return;
    } 
    "孭袞⚥㖱⹧嵌儅܂빬妢ㅷ姫歯틳㡋†嶔쿮槏⶗瘤쒎饚ꈵ䉽ᜁᓓ".toCharArray()[6] = (char)("孭袞⚥㖱⹧嵌儅܂빬妢ㅷ姫歯틳㡋†嶔쿮槏⶗瘤쒎饚ꈵ䉽ᜁᓓ".toCharArray()[6] ^ 0x25BE);
    "矉⹄Ꝥ蓩?굴ࠂ꜏Ⱋ".toCharArray()[8] = (char)("矉⹄Ꝥ蓩?굴ࠂ꜏Ⱋ".toCharArray()[8] ^ 0x36A1);
    "逶᰿␪唢ǃ֠곙橷棉".toCharArray()[3] = (char)("逶᰿␪唢ǃ֠곙橷棉".toCharArray()[3] ^ 0x301C);
    "º助諃瀊앰ఖ".toCharArray()[5] = (char)("º助諃瀊앰ఖ".toCharArray()[5] ^ 0x512A);
    יּ יּ1;
    throw new IllegalStateException(ˏȓ$ᴵЃ.E("孭袞⚥㖱⹧嵌儅܂빬妢ㅷ姫歯틳㡋†嶔쿮槏⶗瘤쒎饚ꈵ䉽ᜁᓓ".toCharArray(), (short)285, (short)4, (short)5) + ᐨẏ() + ˏȓ$ᴵЃ.E("矉⹄Ꝥ蓩?굴ࠂ꜏Ⱋ".toCharArray(), (short)14606, (short)3, (short)3) + ((יּ1 = this).ˑᐟ + 1) + ˏȓ$ᴵЃ.E("逶᰿␪唢ǃ֠곙橷棉".toCharArray(), (short)25930, (short)1, (short)0) + ﹳܕ() + ˏȓ$ᴵЃ.E("º助諃瀊앰ఖ".toCharArray(), (short)14822, (short)0, (short)1) + ˌ());
  }
  
  public void ˑܥ() {
    int i;
    if ((i = this.ʿﭝ) == 0)
      i = ۥ(); 
    if (i == 4) {
      this.יċ--;
      this.ᔪ[this.יċ - 1] = this.ᔪ[this.יċ - 1] + 1;
      this.ʿﭝ = 0;
      return;
    } 
    "☆暮蠅⚴鋑⣑姿ხѐꯆ蜭둁禼侨듨⊼௲ ῿焈蹶빯쭦᮪♫緤".toCharArray()[10] = (char)("☆暮蠅⚴鋑⣑姿ხѐꯆ蜭둁禼侨듨⊼௲ ῿焈蹶빯쭦᮪♫緤".toCharArray()[10] ^ 0x5C96);
    "ᤙ肮쌐룮翛礮ᕏ돒欳".toCharArray()[6] = (char)("ᤙ肮쌐룮翛礮ᕏ돒欳".toCharArray()[6] ^ 0x7C9A);
    "४镯ퟄ芼ಓ㳈㟲溳".toCharArray()[3] = (char)("४镯ퟄ芼ಓ㳈㟲溳".toCharArray()[3] ^ 0xA);
    "嚑滝➚ࣆ?䧿㲷".toCharArray()[0] = (char)("嚑滝➚ࣆ?䧿㲷".toCharArray()[0] ^ 0x24F8);
    יּ יּ1;
    throw new IllegalStateException(ᐨẏ$ᐝт.W("☆暮蠅⚴鋑⣑姿ხѐꯆ蜭둁禼侨듨⊼௲ ῿焈蹶빯쭦᮪♫緤".toCharArray(), (short)20271, (byte)2, (short)4) + ᐨẏ() + ᐨẏ$ᐝт.W("ᤙ肮쌐룮翛礮ᕏ돒欳".toCharArray(), (short)4121, (byte)1, (short)4) + ((יּ1 = this).ˑᐟ + 1) + ᐨẏ$ᐝт.W("४镯ퟄ芼ಓ㳈㟲溳".toCharArray(), (short)10078, (byte)2, (short)5) + ﹳܕ() + ᐨẏ$ᐝт.W("嚑滝➚ࣆ?䧿㲷".toCharArray(), (short)31463, (byte)3, (short)3) + ˌ());
  }
  
  public void ᐨ() {
    int i;
    if ((i = this.ʿﭝ) == 0)
      i = ۥ(); 
    if (i == 1) {
      ˊ(3);
      this.ʿﭝ = 0;
      return;
    } 
    "堌慐Ⱔ딡挌胾礅攸わ蠨柮둑孔쮳⓻便锶隠빤筐湉럞鮲洉?墛ﱅ폴‗".toCharArray()[19] = (char)("堌慐Ⱔ딡挌胾礅攸わ蠨柮둑孔쮳⓻便锶隠빤筐湉럞鮲洉?墛ﱅ폴‗".toCharArray()[19] ^ 0x355A);
    "䂩쩉ຑ褄ȭ隲崙ダ".toCharArray()[2] = (char)("䂩쩉ຑ褄ȭ隲崙ダ".toCharArray()[2] ^ 0x6D66);
    "鮙둄▹갊諥㊃Ѷ".toCharArray()[3] = (char)("鮙둄▹갊諥㊃Ѷ".toCharArray()[3] ^ 0x34E8);
    "꜊礗唾䟟ലñ⯃".toCharArray()[3] = (char)("꜊礗唾䟟ലñ⯃".toCharArray()[3] ^ 0x5A35);
    יּ יּ1;
    throw new IllegalStateException(ᐝᵣ$ﾞﾇ.j("堌慐Ⱔ딡挌胾礅攸わ蠨柮둑孔쮳⓻便锶隠빤筐湉럞鮲洉?墛ﱅ폴‗".toCharArray(), (short)6495, 1, (short)1) + ᐨẏ() + ᐝᵣ$ﾞﾇ.j("䂩쩉ຑ褄ȭ隲崙ダ".toCharArray(), (short)3861, 1, (short)2) + ((יּ1 = this).ˑᐟ + 1) + ᐝᵣ$ﾞﾇ.j("鮙둄▹갊諥㊃Ѷ".toCharArray(), (short)23254, 0, (short)1) + ﹳܕ() + ᐝᵣ$ﾞﾇ.j("꜊礗唾䟟ലñ⯃".toCharArray(), (short)29528, 4, (short)4) + ˌ());
  }
  
  public void ﾞঽ() {
    int i;
    if ((i = this.ʿﭝ) == 0)
      i = ۥ(); 
    if (i == 2) {
      this.יċ--;
      this.ʹﮃ[this.יċ] = null;
      this.ᔪ[this.יċ - 1] = this.ᔪ[this.יċ - 1] + 1;
      this.ʿﭝ = 0;
      return;
    } 
    "尔搤丸䰡Թ౨⩈촕??㡻ἲ魉⿕夑ꮃ攮ƨ宇쪤輈艸ఇ醏䕰".toCharArray()[26] = (char)("尔搤丸䰡Թ౨⩈촕??㡻ἲ魉⿕夑ꮃ攮ƨ宇쪤輈艸ఇ醏䕰".toCharArray()[26] ^ 0x6903);
    "軬몿ꂝ뻫|鷜ݞ⛸".toCharArray()[8] = (char)("軬몿ꂝ뻫|鷜ݞ⛸".toCharArray()[8] ^ 0x494);
    "ﳴ씖완㉢秒ྣ䇆".toCharArray()[3] = (char)("ﳴ씖완㉢秒ྣ䇆".toCharArray()[3] ^ 0x65A2);
    "뜠깈贲鵄ᾐ".toCharArray()[4] = (char)("뜠깈贲鵄ᾐ".toCharArray()[4] ^ 0x5C52);
    יּ יּ1;
    throw new IllegalStateException(ᐝᵣ$ﾞﾇ.j("尔搤丸䰡Թ౨⩈촕??㡻ἲ魉⿕夑ꮃ攮ƨ宇쪤輈艸ఇ醏䕰".toCharArray(), (short)25370, 3, (short)4) + ᐨẏ() + ᐝᵣ$ﾞﾇ.j("軬몿ꂝ뻫|鷜ݞ⛸".toCharArray(), (short)10412, 3, (short)2) + ((יּ1 = this).ˑᐟ + 1) + ᐝᵣ$ﾞﾇ.j("ﳴ씖완㉢秒ྣ䇆".toCharArray(), (short)10225, 4, (short)4) + ﹳܕ() + ᐝᵣ$ﾞﾇ.j("뜠깈贲鵄ᾐ".toCharArray(), (short)8234, 2, (short)1) + ˌ());
  }
  
  public boolean hasNext() {
    int i;
    if ((i = this.ʿﭝ) == 0)
      i = ۥ(); 
    return (i != 2 && i != 4);
  }
  
  public כ ᐨẏ() {
    int i;
    if ((i = this.ʿﭝ) == 0)
      i = ۥ(); 
    switch (i) {
      case 1:
        return כ.ᴵʖ;
      case 2:
        return כ.ﾞл;
      case 3:
        return (כ)כ.ᐨẏ;
      case 4:
        return כ.ˊ;
      case 12:
      case 13:
      case 14:
        return כ.ʿᵉ;
      case 5:
      case 6:
        return כ.ˍɫ;
      case 7:
        return כ.ʽ;
      case 8:
      case 9:
      case 10:
      case 11:
        return כ.ʹﮃ;
      case 15:
      case 16:
        return כ.ՙᗮ;
      case 17:
        return כ.ʾܪ;
    } 
    throw new AssertionError();
  }
  
  private int ۥ() {
    int i;
    if ((i = this.ᐝᵣ[this.יċ - 1]) == 1) {
      this.ᐝᵣ[this.יċ - 1] = 2;
    } else if (i == 2) {
      int k;
      switch (k = ᐨẏ(true)) {
        case 93:
          return this.ʿﭝ = 4;
        case 59:
          ˏﾚ();
          break;
        case 44:
          break;
        default:
          "䘮踰㤭᫣෥뇅쮦䵮㮡흜렲쉭꣐?谨襞饺導".toCharArray()[13] = (char)("䘮踰㤭᫣෥뇅쮦䵮㮡흜렲쉭꣐?谨襞饺導".toCharArray()[13] ^ 0x7BA1);
          throw ᐨẏ(ᐨẏ$ᐝт.W("䘮踰㤭᫣෥뇅쮦䵮㮡흜렲쉭꣐?谨襞饺導".toCharArray(), (short)7215, (byte)1, (short)4));
      } 
    } else {
      if (i == 3 || i == 5) {
        this.ᐝᵣ[this.יċ - 1] = 4;
        if (i == 5) {
          int m;
          switch (m = ᐨẏ(true)) {
            case 125:
              return this.ʿﭝ = 2;
            case 59:
              ˏﾚ();
              break;
            case 44:
              break;
            default:
              "⚋쿃闰ꀗ຀똁凂ధ꿛眘㧅９魲伙冤乶뉪ᎇ".toCharArray()[2] = (char)("⚋쿃闰ꀗ຀똁凂ధ꿛眘㧅９魲伙冤乶뉪ᎇ".toCharArray()[2] ^ 0x5BC0);
              throw ᐨẏ(ᐨẏ$ᐝт.W("⚋쿃闰ꀗ຀똁凂ధ꿛眘㧅９魲伙冤乶뉪ᎇ".toCharArray(), (short)15570, (byte)4, (short)5));
          } 
        } 
        int k;
        switch (k = ᐨẏ(true)) {
          case 34:
            return this.ʿﭝ = 13;
          case 39:
            ˏﾚ();
            return this.ʿﭝ = 12;
          case 125:
            if (i != 5)
              return this.ʿﭝ = 2; 
            "좃₃㾒쿪耿苰ನ?횰炛幰﹀㣐".toCharArray()[0] = (char)("좃₃㾒쿪耿苰ನ?횰炛幰﹀㣐".toCharArray()[0] ^ 0x3FFA);
            throw ᐨẏ(ᐨẏ$ᐝт.W("좃₃㾒쿪耿苰ನ?횰炛幰﹀㣐".toCharArray(), (short)22497, (byte)1, (short)0));
        } 
        ˏﾚ();
        this.ˑﮌ--;
        if (ᐨẏ((char)k))
          return this.ʿﭝ = 14; 
        "ᣭ쿬ᬏ넄ꃺ賖ꕉ吥悢횀쌹嶦嫇".toCharArray()[4] = (char)("ᣭ쿬ᬏ넄ꃺ賖ꕉ吥悢횀쌹嶦嫇".toCharArray()[4] ^ 0xB8A);
        throw ᐨẏ(ᐨẏ$ᐝт.W("ᣭ쿬ᬏ넄ꃺ賖ꕉ吥悢횀쌹嶦嫇".toCharArray(), (short)32, (byte)3, (short)1));
      } 
      if (i == 4) {
        this.ᐝᵣ[this.יċ - 1] = 5;
        int k;
        switch (k = ᐨẏ(true)) {
          case 58:
            break;
          case 61:
            ˏﾚ();
            if ((this.ˑﮌ < this.ƭ || ﾞл(1)) && this.ﾞл[this.ˑﮌ] == 62)
              this.ˑﮌ++; 
            break;
          default:
            "檋僈猘ೠ嵺녀ꮿ壘震歙볂焮ㇺ".toCharArray()[6] = (char)("檋僈猘ೠ嵺녀ꮿ壘震歙볂焮ㇺ".toCharArray()[6] ^ 0x6243);
            throw ᐨẏ(ᐨẏ$ᐝт.W("檋僈猘ೠ嵺녀ꮿ壘震歙볂焮ㇺ".toCharArray(), (short)5546, (byte)2, (short)4));
        } 
      } else if (i == 6) {
        if (this.ˎאּ)
          ʻᴷ(); 
        this.ᐝᵣ[this.יċ - 1] = 7;
      } else if (i == 7) {
        int k;
        if ((k = ᐨẏ(false)) == -1)
          return this.ʿﭝ = 17; 
        ˏﾚ();
        this.ˑﮌ--;
      } else if (i == 8) {
        "掶?䩨鍥黦봌暜ଢ଼㉦뵵汎䠢ﳐ饙芵䀿옷렐ሪ㬩".toCharArray()[11] = (char)("掶?䩨鍥黦봌暜ଢ଼㉦뵵汎䠢ﳐ饙芵䀿옷렐ሪ㬩".toCharArray()[11] ^ 0x4A54);
        throw new IllegalStateException(ᐨẏ$ᐝт.W("掶?䩨鍥黦봌暜ଢ଼㉦뵵汎䠢ﳐ饙芵䀿옷렐ሪ㬩".toCharArray(), (short)6794, (byte)0, (short)1));
      } 
    } 
    int j;
    switch (j = ᐨẏ(true)) {
      case 93:
        if (i == 1)
          return this.ʿﭝ = 4; 
      case 44:
      case 59:
        if (i == 1 || i == 2) {
          ˏﾚ();
          this.ˑﮌ--;
          return this.ʿﭝ = 7;
        } 
        "䔋蹊⯈惐㋠幬⽅髟?亨알覛퇬烺 푻巽".toCharArray()[0] = (char)("䔋蹊⯈惐㋠幬⽅髟?亨알覛퇬烺 푻巽".toCharArray()[0] ^ 0x32DE);
        throw ᐨẏ(ᐨẏ$ᐝт.W("䔋蹊⯈惐㋠幬⽅髟?亨알覛퇬烺 푻巽".toCharArray(), (short)13710, (byte)4, (short)5));
      case 39:
        ˏﾚ();
        return this.ʿﭝ = 8;
      case 34:
        if (this.יċ == 1)
          ˏﾚ(); 
        return this.ʿﭝ = 9;
      case 91:
        return this.ʿﭝ = 3;
      case 123:
        return this.ʿﭝ = 1;
    } 
    this.ˑﮌ--;
    if (this.יċ == 1)
      ˏﾚ(); 
    if ((i = ـไ()) != 0)
      return i; 
    if ((i = ˊᴬ()) != 0)
      return i; 
    if (!ᐨẏ(this.ﾞл[this.ˑﮌ])) {
      "ᙤ蟲셻ﭔ諕땉贬봺⼜㉆㰂".toCharArray()[9] = (char)("ᙤ蟲셻ﭔ諕땉贬봺⼜㉆㰂".toCharArray()[9] ^ 0x3B54);
      throw ᐨẏ(ᐨẏ$ᐝт.W("ᙤ蟲셻ﭔ諕땉贬봺⼜㉆㰂".toCharArray(), (short)10462, (byte)1, (short)4));
    } 
    ˏﾚ();
    return this.ʿﭝ = 10;
  }
  
  private int ـไ() {
    String str1;
    String str2;
    byte b1;
    long l;
    if ((l = this.ﾞл[this.ˑﮌ]) == 116 || l == 84) {
      "ㅧ敒Ẕ愃Ձ".toCharArray()[0] = (char)("ㅧ敒Ẕ愃Ձ".toCharArray()[0] ^ 0x22F8);
      str1 = ˏȓ$ᴵЃ.E("ㅧ敒Ẕ愃Ձ".toCharArray(), (short)5922, (short)4, (short)1);
      "幻ჵ?﷡畇".toCharArray()[0] = (char)("幻ჵ?﷡畇".toCharArray()[0] ^ 0x916);
      str2 = ˏȓ$ᴵЃ.E("幻ჵ?﷡畇".toCharArray(), (short)28768, (short)4, (short)2);
      b1 = 5;
    } else if (l == 102 || l == 70) {
      "ृ쬺팈௴ᙼĮ".toCharArray()[0] = (char)("ृ쬺팈௴ᙼĮ".toCharArray()[0] ^ 0x51F5);
      str1 = ˏȓ$ᴵЃ.E("ृ쬺팈௴ᙼĮ".toCharArray(), (short)4622, (short)5, (short)2);
      "敇孒垄ъ郙恳".toCharArray()[0] = (char)("敇孒垄ъ郙恳".toCharArray()[0] ^ 0x611F);
      str2 = ˏȓ$ᴵЃ.E("敇孒垄ъ郙恳".toCharArray(), (short)24010, (short)2, (short)4);
      b1 = 6;
    } else if (l == 110 || l == 78) {
      "؞䁓ⰹ㭊".toCharArray()[2] = (char)("؞䁓ⰹ㭊".toCharArray()[2] ^ 0x60A7);
      str1 = ˏȓ$ᴵЃ.E("؞䁓ⰹ㭊".toCharArray(), (short)3147, (short)4, (short)0);
      "跳럘觘ᅇ".toCharArray()[1] = (char)("跳럘觘ᅇ".toCharArray()[1] ^ 0x6810);
      str2 = ˏȓ$ᴵЃ.E("跳럘觘ᅇ".toCharArray(), (short)710, (short)4, (short)3);
      b1 = 7;
    } else {
      return 0;
    } 
    int i = str1.length();
    for (byte b2 = 1; b2 < i; b2++) {
      if (this.ˑﮌ + b2 >= this.ƭ && !ﾞл(b2 + 1))
        return 0; 
      if ((l = this.ﾞл[this.ˑﮌ + b2]) != str1.charAt(b2) && l != str2.charAt(b2))
        return 0; 
    } 
    if ((this.ˑﮌ + i < this.ƭ || ﾞл(i + 1)) && ᐨẏ(this.ﾞл[this.ˑﮌ + i]))
      return 0; 
    this.ˑﮌ += i;
    return this.ʿﭝ = b1;
  }
  
  private int ˊᴬ() {
    long l1 = this.ﾞл;
    int i = this.ˑﮌ;
    int j = this.ƭ;
    long l2 = 0L;
    boolean bool = false;
    int k = 1;
    byte b1 = 0;
    byte b2;
    for (b2 = 0;; b2++) {
      if (i + b2 == j) {
        if (b2 == l1.length)
          return 0; 
        if (ﾞл(b2 + 1)) {
          i = this.ˑﮌ;
          j = this.ƭ;
        } else {
          break;
        } 
      } 
      long l;
      switch (l = l1[i + b2]) {
        case 45:
          if (!b1) {
            bool = true;
            b1 = 1;
            break;
          } 
          if (b1 == 5) {
            b1 = 6;
            break;
          } 
          return 0;
        case 43:
          if (b1 == 5) {
            b1 = 6;
            break;
          } 
          return 0;
        case 69:
        case 101:
          if (b1 == 2 || b1 == 4) {
            b1 = 5;
            break;
          } 
          return 0;
        case 46:
          if (b1 == 2) {
            b1 = 3;
            break;
          } 
          return 0;
        default:
          if (l < 48 || l > 57) {
            if (ᐨẏ(l))
              return 0; 
            break;
          } 
          if (b1 == 1 || b1 == 0) {
            l2 = -(l - 48);
            b1 = 2;
            break;
          } 
          if (b1 == 2) {
            if (l2 == 0L)
              return 0; 
            long l3 = l2 * 10L - (l - 48);
            k &= (l2 > -922337203685477580L || (l2 == -922337203685477580L && l3 < l2)) ? 1 : 0;
            l2 = l3;
            break;
          } 
          if (b1 == 3) {
            b1 = 4;
            break;
          } 
          if (b1 == 5 || b1 == 6)
            b1 = 7; 
          break;
      } 
    } 
    if (b1 == 2 && k != 0 && (l2 != Long.MIN_VALUE || bool)) {
      this.ﾞл = bool ? l2 : -l2;
      this.ˑﮌ += b2;
      return this.ʿﭝ = 15;
    } 
    if (b1 == 2 || b1 == 4 || b1 == 7) {
      this.ⅼ = b2;
      return this.ʿﭝ = 16;
    } 
    return 0;
  }
  
  private boolean ᐨẏ(char paramChar) {
    switch (paramChar) {
      case '#':
      case '/':
      case ';':
      case '=':
      case '\\':
        ˏﾚ();
      case '\t':
      case '\n':
      case '\f':
      case '\r':
      case ' ':
      case ',':
      case ':':
      case '[':
      case ']':
      case '{':
      case '}':
        return false;
    } 
    return true;
  }
  
  public String ͺо() {
    String str;
    יּ יּ1;
    int i;
    if ((i = this.ʿﭝ) == 0)
      i = ۥ(); 
    if (i == 14) {
      str = ᴵƚ();
    } else if (str == '\f') {
      str = ᐨẏ('\'');
    } else if (str == '\r') {
      str = ᐨẏ('"');
    } else {
      "靰䯅ᓃ쬄翱룚ꟾ쉽챊㒧ť慙ꐽ쑧灗ࡋꉍ䈼䮦逗褼⾌⹎".toCharArray()[9] = (char)("靰䯅ᓃ쬄翱룚ꟾ쉽챊㒧ť慙ꐽ쑧灗ࡋꉍ䈼䮦逗褼⾌⹎".toCharArray()[9] ^ 0x677D);
      "튦⸨瀮襆齊┗콷鏷⣁䪦".toCharArray()[1] = (char)("튦⸨瀮襆齊┗콷鏷⣁䪦".toCharArray()[1] ^ 0x2435);
      "褻땯丑쟦謤⥔ຌ䉡".toCharArray()[1] = (char)("褻땯丑쟦謤⥔ຌ䉡".toCharArray()[1] ^ 0x33EA);
      "܇꽺?稨ݰי疣".toCharArray()[1] = (char)("܇꽺?稨ݰי疣".toCharArray()[1] ^ 0x7E0);
      throw new IllegalStateException(ˍɫ$יς.J("靰䯅ᓃ쬄翱룚ꟾ쉽챊㒧ť慙ꐽ쑧灗ࡋꉍ䈼䮦逗褼⾌⹎".toCharArray(), (short)10194, (short)0, (byte)4) + ᐨẏ() + ˍɫ$יς.J("튦⸨瀮襆齊┗콷鏷⣁䪦".toCharArray(), (short)14724, (short)3, (byte)4) + ((יּ1 = this).ˑᐟ + 1) + ˍɫ$יς.J("褻땯丑쟦謤⥔ຌ䉡".toCharArray(), (short)31700, (short)0, (byte)0) + ﹳܕ() + ˍɫ$יς.J("܇꽺?稨ݰי疣".toCharArray(), (short)25592, (short)1, (byte)5) + ˌ());
    } 
    this.ʿﭝ = 0;
    this.ʹﮃ[this.יċ - 1] = (String)יּ1;
    return (String)יּ1;
  }
  
  public String ٴӵ() {
    String str;
    יּ יּ1;
    int i;
    if ((i = this.ʿﭝ) == 0)
      i = ۥ(); 
    if (i == 10) {
      str = ᴵƚ();
    } else if (str == '\b') {
      str = ᐨẏ('\'');
    } else if (str == '\t') {
      str = ᐨẏ('"');
    } else if (str == '\013') {
      str = this.ιƚ;
      this.ιƚ = null;
    } else if (str == '\017') {
      str = Long.toString(this.ﾞл);
    } else if (str == '\020') {
      str = new String(this.ﾞл, this.ˑﮌ, this.ⅼ);
      this.ˑﮌ += this.ⅼ;
    } else {
      "?苊祀ꕇ绗毡鑘梩歲᪗䄗沋鞘㍯롮ʮ鹣駤﮺생׬捃꿽盷ᴟ".toCharArray()[25] = (char)("?苊祀ꕇ绗毡鑘梩歲᪗䄗沋鞘㍯롮ʮ鹣駤﮺생׬捃꿽盷ᴟ".toCharArray()[25] ^ 0x7C44);
      "鳍뒄쎟驛ꛃ횐謵糠".toCharArray()[7] = (char)("鳍뒄쎟驛ꛃ횐謵糠".toCharArray()[7] ^ 0x480B);
      "닼ჯ늻⥔뺦鶛嚄ꔛ徣".toCharArray()[1] = (char)("닼ჯ늻⥔뺦鶛嚄ꔛ徣".toCharArray()[1] ^ 0x3172);
      "㧷೯㹽荂슞?݋".toCharArray()[2] = (char)("㧷೯㹽荂슞?݋".toCharArray()[2] ^ 0x5300);
      throw new IllegalStateException(ˍɫ$יς.J("?苊祀ꕇ绗毡鑘梩歲᪗䄗沋鞘㍯롮ʮ鹣駤﮺생׬捃꿽盷ᴟ".toCharArray(), (short)32513, (short)5, (byte)5) + ᐨẏ() + ˍɫ$יς.J("鳍뒄쎟驛ꛃ횐謵糠".toCharArray(), (short)2462, (short)1, (byte)2) + ((יּ1 = this).ˑᐟ + 1) + ˍɫ$יς.J("닼ჯ늻⥔뺦鶛嚄ꔛ徣".toCharArray(), (short)1760, (short)1, (byte)2) + ﹳܕ() + ˍɫ$יς.J("㧷೯㹽荂슞?݋".toCharArray(), (short)30380, (short)5, (byte)5) + ˌ());
    } 
    this.ʿﭝ = 0;
    this.ᔪ[this.יċ - 1] = this.ᔪ[this.יċ - 1] + 1;
    return (String)יּ1;
  }
  
  public boolean ˈے() {
    int i;
    if ((i = this.ʿﭝ) == 0)
      i = ۥ(); 
    if (i == 5) {
      this.ʿﭝ = 0;
      this.ᔪ[this.יċ - 1] = this.ᔪ[this.יċ - 1] + 1;
      return true;
    } 
    if (i == 6) {
      this.ʿﭝ = 0;
      this.ᔪ[this.יċ - 1] = this.ᔪ[this.יċ - 1] + 1;
      return false;
    } 
    "륻龍〶伓䕾〔娆繄䎉늉튲募㪋囇尨瀳塳㳱沐띯暅窹뗥㝕ᎈ".toCharArray()[0] = (char)("륻龍〶伓䕾〔娆繄䎉늉튲募㪋囇尨瀳塳㳱沐띯暅窹뗥㝕ᎈ".toCharArray()[0] ^ 0x6D43);
    "┸‫ﭹ䖊㪅⦡ᡸこ焠".toCharArray()[1] = (char)("┸‫ﭹ䖊㪅⦡ᡸこ焠".toCharArray()[1] ^ 0x7E09);
    "剂䲯ℵ早愘訙贰⸶˨".toCharArray()[5] = (char)("剂䲯ℵ早愘訙贰⸶˨".toCharArray()[5] ^ 0x48A4);
    "坢귃䊭빉莭萷䔇".toCharArray()[0] = (char)("坢귃䊭빉莭萷䔇".toCharArray()[0] ^ 0x244A);
    יּ יּ1;
    throw new IllegalStateException(ˏȓ$ᴵЃ.E("륻龍〶伓䕾〔娆繄䎉늉튲募㪋囇尨瀳塳㳱沐띯暅窹뗥㝕ᎈ".toCharArray(), (short)5908, (short)4, (short)5) + ᐨẏ() + ˏȓ$ᴵЃ.E("┸‫ﭹ䖊㪅⦡ᡸこ焠".toCharArray(), (short)6078, (short)4, (short)0) + ((יּ1 = this).ˑᐟ + 1) + ˏȓ$ᴵЃ.E("剂䲯ℵ早愘訙贰⸶˨".toCharArray(), (short)15561, (short)1, (short)2) + ﹳܕ() + ˏȓ$ᴵЃ.E("坢귃䊭빉莭萷䔇".toCharArray(), (short)20136, (short)3, (short)4) + ˌ());
  }
  
  public void ۦ() {
    int i;
    if ((i = this.ʿﭝ) == 0)
      i = ۥ(); 
    if (i == 7) {
      this.ʿﭝ = 0;
      this.ᔪ[this.יċ - 1] = this.ᔪ[this.יċ - 1] + 1;
      return;
    } 
    "鵍⦂︧恦뤬兩䚡淉뙉켣艊煮꺄铫괭蟞㚥婜쯼ㅏ".toCharArray()[3] = (char)("鵍⦂︧恦뤬兩䚡淉뙉켣艊煮꺄铫괭蟞㚥婜쯼ㅏ".toCharArray()[3] ^ 0x6713);
    "晹᠇蚸ຏᣔ斖㔼핰䋷".toCharArray()[4] = (char)("晹᠇蚸ຏᣔ斖㔼핰䋷".toCharArray()[4] ^ 0x5364);
    "㸠兰挣\026揊슎긩ꯇՑ".toCharArray()[6] = (char)("㸠兰挣\026揊슎긩ꯇՑ".toCharArray()[6] ^ 0x40F3);
    "菳滚硅饚燘".toCharArray()[5] = (char)("菳滚硅饚燘".toCharArray()[5] ^ 0x157A);
    יּ יּ1;
    throw new IllegalStateException(ᐨẏ$ᐝт.W("鵍⦂︧恦뤬兩䚡淉뙉켣艊煮꺄铫괭蟞㚥婜쯼ㅏ".toCharArray(), (short)31559, (byte)3, (short)2) + ᐨẏ() + ᐨẏ$ᐝт.W("晹᠇蚸ຏᣔ斖㔼핰䋷".toCharArray(), (short)8027, (byte)0, (short)5) + ((יּ1 = this).ˑᐟ + 1) + ᐨẏ$ᐝт.W("㸠兰挣\026揊슎긩ꯇՑ".toCharArray(), (short)31494, (byte)3, (short)4) + ﹳܕ() + ᐨẏ$ᐝт.W("菳滚硅饚燘".toCharArray(), (short)563, (byte)0, (short)1) + ˌ());
  }
  
  public double ᴵʖ() {
    int i;
    if ((i = this.ʿﭝ) == 0)
      i = ۥ(); 
    if (i == 15) {
      this.ʿﭝ = 0;
      this.ᔪ[this.יċ - 1] = this.ᔪ[this.יċ - 1] + 1;
      return this.ﾞл;
    } 
    if (i == 16) {
      this.ιƚ = new String(this.ﾞл, this.ˑﮌ, this.ⅼ);
      this.ˑﮌ += this.ⅼ;
    } else if (i == 8 || i == 9) {
      this.ιƚ = ᐨẏ((i == 8) ? 39 : 34);
    } else if (i == 10) {
      this.ιƚ = ᴵƚ();
    } else if (i != 11) {
      "鿙ĵꈫ⍭枤슚뻾႙ꐰ崄?吗ᦑλ痼墟逓鳧ᦔ㦞泷".toCharArray()[10] = (char)("鿙ĵꈫ⍭枤슚뻾႙ꐰ崄?吗ᦑλ痼墟逓鳧ᦔ㦞泷".toCharArray()[10] ^ 0x700A);
      "ꆄ㌋ד왍ꩈ뵞亂镥䶴".toCharArray()[4] = (char)("ꆄ㌋ד왍ꩈ뵞亂镥䶴".toCharArray()[4] ^ 0x75ED);
      "遙䁾歛ڞ∞峺".toCharArray()[4] = (char)("遙䁾歛ڞ∞峺".toCharArray()[4] ^ 0x5204);
      "롻✄爘鏋ỵ䎆".toCharArray()[2] = (char)("롻✄爘鏋ỵ䎆".toCharArray()[2] ^ 0x6F79);
      יּ יּ1;
      throw new IllegalStateException(ᐨẏ$ᐝт.W("鿙ĵꈫ⍭枤슚뻾႙ꐰ崄?吗ᦑλ痼墟逓鳧ᦔ㦞泷".toCharArray(), (short)25542, (byte)4, (short)1) + ᐨẏ() + ᐨẏ$ᐝт.W("ꆄ㌋ד왍ꩈ뵞亂镥䶴".toCharArray(), (short)5073, (byte)1, (short)4) + ((יּ1 = this).ˑᐟ + 1) + ᐨẏ$ᐝт.W("遙䁾歛ڞ∞峺".toCharArray(), (short)21608, (byte)0, (short)1) + ﹳܕ() + ᐨẏ$ᐝт.W("롻✄爘鏋ỵ䎆".toCharArray(), (short)26133, (byte)5, (short)3) + ˌ());
    } 
    this.ʿﭝ = 11;
    double d = Double.parseDouble(this.ιƚ);
    if (!this.ˎאּ && (Double.isNaN(d) || Double.isInfinite(d))) {
      "豊揈៣㲔肭㈭⭿뷌渪撪婄嫶᧓律锣?䐓▘尖䞉씽馅ﷲ훙랈钏ꂮ跼뉿饿峟".toCharArray()[31] = (char)("豊揈៣㲔肭㈭⭿뷌渪撪婄嫶᧓律锣?䐓▘尖䞉씽馅ﷲ훙랈钏ꂮ跼뉿饿峟".toCharArray()[31] ^ 0x38CE);
      "퀏꒔띴闺쾢郲ꄸ췚ፂ".toCharArray()[5] = (char)("퀏꒔띴闺쾢郲ꄸ췚ፂ".toCharArray()[5] ^ 0x6805);
      "蚿䔸浿㖐쭾藾谨侾嬁".toCharArray()[4] = (char)("蚿䔸浿㖐쭾藾谨侾嬁".toCharArray()[4] ^ 0x6119);
      "࿂朒凒릯鵚㬨".toCharArray()[3] = (char)("࿂朒凒릯鵚㬨".toCharArray()[3] ^ 0x4AA2);
      יּ יּ1;
      throw new ˑɺ(ᐨẏ$ᐝт.W("豊揈៣㲔肭㈭⭿뷌渪撪婄嫶᧓律锣?䐓▘尖䞉씽馅ﷲ훙랈钏ꂮ跼뉿饿峟".toCharArray(), (short)21167, (byte)5, (short)5) + d + ᐨẏ$ᐝт.W("퀏꒔띴闺쾢郲ꄸ췚ፂ".toCharArray(), (short)19928, (byte)3, (short)3) + ((יּ1 = this).ˑᐟ + 1) + ᐨẏ$ᐝт.W("蚿䔸浿㖐쭾藾谨侾嬁".toCharArray(), (short)6641, (byte)5, (short)5) + ﹳܕ() + ᐨẏ$ᐝт.W("࿂朒凒릯鵚㬨".toCharArray(), (short)2769, (byte)3, (short)1) + ˌ());
    } 
    this.ιƚ = null;
    this.ʿﭝ = 0;
    this.ᔪ[this.יċ - 1] = this.ᔪ[this.יċ - 1] + 1;
    return d;
  }
  
  public long ᴵʖ() {
    int i;
    if ((i = this.ʿﭝ) == 0)
      i = ۥ(); 
    if (i == 15) {
      this.ʿﭝ = 0;
      this.ᔪ[this.יċ - 1] = this.ᔪ[this.יċ - 1] + 1;
      return this.ﾞл;
    } 
    if (i == 16) {
      this.ιƚ = new String(this.ﾞл, this.ˑﮌ, this.ⅼ);
      this.ˑﮌ += this.ⅼ;
    } else if (i == 8 || i == 9) {
      this.ιƚ = ᐨẏ((i == 8) ? 39 : 34);
      try {
        long l1 = Long.parseLong(this.ιƚ);
        this.ʿﭝ = 0;
        this.ᔪ[this.יċ - 1] = this.ᔪ[this.יċ - 1] + 1;
        return l1;
      } catch (NumberFormatException numberFormatException) {}
    } else {
      "⾏⠟⦙乡浌䧉锢鸁硪䊜긁쮟䀰侄롖?㢞핖卜忚캐꟨拙ᄘ䖤".toCharArray()[20] = (char)("⾏⠟⦙乡浌䧉锢鸁硪䊜긁쮟䀰侄롖?㢞핖卜忚캐꟨拙ᄘ䖤".toCharArray()[20] ^ 0x143E);
      "淓ꃾ⭖柶嶅崡무晠猄".toCharArray()[5] = (char)("淓ꃾ⭖柶嶅崡무晠猄".toCharArray()[5] ^ 0x1D47);
      "㵋킗봤ͺ履瀽暉".toCharArray()[7] = (char)("㵋킗봤ͺ履瀽暉".toCharArray()[7] ^ 0x49B0);
      "픽쟦촺袩⡁엫㼯".toCharArray()[1] = (char)("픽쟦촺袩⡁엫㼯".toCharArray()[1] ^ 0x2DCE);
      יּ יּ1;
      throw new IllegalStateException(ˍɫ$יς.J("⾏⠟⦙乡浌䧉锢鸁硪䊜긁쮟䀰侄롖?㢞핖卜忚캐꟨拙ᄘ䖤".toCharArray(), (short)16756, (short)5, (byte)2) + ᐨẏ() + ˍɫ$יς.J("淓ꃾ⭖柶嶅崡무晠猄".toCharArray(), (short)3501, (short)1, (byte)4) + ((יּ1 = this).ˑᐟ + 1) + ˍɫ$יς.J("㵋킗봤ͺ履瀽暉".toCharArray(), (short)12314, (short)0, (byte)5) + ﹳܕ() + ˍɫ$יς.J("픽쟦촺袩⡁엫㼯".toCharArray(), (short)7494, (short)2, (byte)2) + ˌ());
    } 
    this.ʿﭝ = 11;
    double d;
    long l;
    if ((l = (long)(d = Double.parseDouble(this.ιƚ))) != d) {
      "衆ᠤ鸣Ḓཛྷ퐛糢윥蕽얎দ?칗莏⑮?ၺ㴟㔬昩䑥噞".toCharArray()[20] = (char)("衆ᠤ鸣Ḓཛྷ퐛糢윥蕽얎দ?칗莏⑮?ၺ㴟㔬昩䑥噞".toCharArray()[20] ^ 0x6E);
      "므㠎酼桐휺鉹௳ⰴ涇".toCharArray()[3] = (char)("므㠎酼桐휺鉹௳ⰴ涇".toCharArray()[3] ^ 0x6C9A);
      "᭑흉貗⠽贤ၕ㠙".toCharArray()[0] = (char)("᭑흉貗⠽贤ၕ㠙".toCharArray()[0] ^ 0x284B);
      "鿌줋凩ⵚ蔗㤼".toCharArray()[4] = (char)("鿌줋凩ⵚ蔗㤼".toCharArray()[4] ^ 0x6E9C);
      יּ יּ1;
      throw new NumberFormatException(ˍɫ$יς.J("衆ᠤ鸣Ḓཛྷ퐛糢윥蕽얎দ?칗莏⑮?ၺ㴟㔬昩䑥噞".toCharArray(), (short)15415, (short)1, (byte)4) + this.ιƚ + ˍɫ$יς.J("므㠎酼桐휺鉹௳ⰴ涇".toCharArray(), (short)4143, (short)4, (byte)5) + ((יּ1 = this).ˑᐟ + 1) + ˍɫ$יς.J("᭑흉貗⠽贤ၕ㠙".toCharArray(), (short)3126, (short)1, (byte)4) + ﹳܕ() + ˍɫ$יς.J("鿌줋凩ⵚ蔗㤼".toCharArray(), (short)10286, (short)2, (byte)1) + ˌ());
    } 
    this.ιƚ = null;
    this.ʿﭝ = 0;
    this.ᔪ[this.יċ - 1] = this.ᔪ[this.יċ - 1] + 1;
    return l;
  }
  
  private String ᐨẏ(char paramChar) {
    long l = this.ﾞл;
    StringBuilder stringBuilder = new StringBuilder();
    while (true) {
      int i = this.ˑﮌ;
      int j = this.ƭ;
      int k = i;
      while (i < j) {
        long l1;
        if ((l1 = l[i++]) == paramChar) {
          this.ˑﮌ = i;
          stringBuilder.append(l, k, i - k - 1);
          return stringBuilder.toString();
        } 
        if (l1 == 92) {
          this.ˑﮌ = i;
          stringBuilder.append(l, k, i - k - 1);
          stringBuilder.append(ˊ());
          i = this.ˑﮌ;
          j = this.ƭ;
          k = i;
          continue;
        } 
        if (l1 == 10) {
          this.ˑᐟ++;
          this.ʾẎ = i;
        } 
      } 
      stringBuilder.append(l, k, i - k);
      this.ˑﮌ = i;
      if (!ﾞл(1)) {
        "煼᰸磊鿬Փ塀꟦왋⌥㕷淜垒聍刬绩컎庍Ἑ".toCharArray()[5] = (char)("煼᰸磊鿬Փ塀꟦왋⌥㕷淜垒聍刬绩컎庍Ἑ".toCharArray()[5] ^ 0x6FDB);
        throw ᐨẏ(ˍɫ$יς.J("煼᰸磊鿬Փ塀꟦왋⌥㕷淜垒聍刬绩컎庍Ἑ".toCharArray(), (short)21227, (short)1, (byte)4));
      } 
    } 
  }
  
  private String ᴵƚ() {
    String str;
    StringBuilder stringBuilder = null;
    byte b = 0;
    label33: while (true) {
      while (this.ˑﮌ + b < this.ƭ) {
        switch (this.ﾞл[this.ˑﮌ + b]) {
          case 35:
          case 47:
          case 59:
          case 61:
          case 92:
            ˏﾚ();
            break label33;
          case 9:
            break label33;
          case 10:
            break label33;
          case 12:
            break label33;
          case 13:
            break label33;
          case 32:
            break label33;
          case 44:
            break label33;
          case 58:
            break label33;
          case 91:
            break label33;
          case 93:
            break label33;
          case 123:
            break label33;
          case 125:
            break label33;
        } 
        b++;
      } 
      if (b < this.ﾞл.length) {
        if (ﾞл(b + 1))
          continue; 
        break;
      } 
      if (stringBuilder == null)
        stringBuilder = new StringBuilder(); 
      stringBuilder.append(this.ﾞл, this.ˑﮌ, b);
      this.ˑﮌ += b;
      b = 0;
      if (!ﾞл(1))
        break; 
    } 
    if (stringBuilder == null) {
      str = new String(this.ﾞл, this.ˑﮌ, b);
    } else {
      str.append(this.ﾞл, this.ˑﮌ, b);
      str = str.toString();
    } 
    this.ˑﮌ += b;
    return str;
  }
  
  private void ᴵʖ(char paramChar) {
    long l = this.ﾞл;
    while (true) {
      int i = this.ˑﮌ;
      int j = this.ƭ;
      while (i < j) {
        long l1;
        if ((l1 = l[i++]) == paramChar) {
          this.ˑﮌ = i;
          return;
        } 
        if (l1 == 92) {
          this.ˑﮌ = i;
          ˊ();
          i = this.ˑﮌ;
          j = this.ƭ;
          continue;
        } 
        if (l1 == 10) {
          this.ˑᐟ++;
          this.ʾẎ = i;
        } 
      } 
      this.ˑﮌ = i;
      if (!ﾞл(1)) {
        "踚癁彵䛔紧䩟鐒ﵰ䗅嶫쉀㵞蛰Ò駥眵홴።".toCharArray()[6] = (char)("踚癁彵䛔紧䩟鐒ﵰ䗅嶫쉀㵞蛰Ò駥眵홴።".toCharArray()[6] ^ 0x2809);
        throw ᐨẏ(ˏȓ$ᴵЃ.E("踚癁彵䛔紧䩟鐒ﵰ䗅嶫쉀㵞蛰Ò駥眵홴።".toCharArray(), (short)27609, (short)0, (short)2));
      } 
    } 
  }
  
  private void יς() {
    do {
      byte b;
      for (b = 0; this.ˑﮌ + b < this.ƭ; b++) {
        switch (this.ﾞл[this.ˑﮌ + b]) {
          case 35:
          case 47:
          case 59:
          case 61:
          case 92:
            ˏﾚ();
          case 9:
          case 10:
          case 12:
          case 13:
          case 32:
          case 44:
          case 58:
          case 91:
          case 93:
          case 123:
          case 125:
            this.ˑﮌ += b;
            return;
        } 
      } 
      this.ˑﮌ += b;
    } while (ﾞл(1));
  }
  
  public int ˊɼ() {
    יּ יּ2;
    יּ יּ1;
    int j;
    if ((j = this.ʿﭝ) == 0)
      j = ۥ(); 
    if (j == 15) {
      j = (int)this.ﾞл;
      if (this.ﾞл != j) {
        "﬊겸ݰ캲ฬボ쐤手澔伢꫙慽գ퓘酘⸤壭瘒⒜鷖⌷㔷譯灧".toCharArray()[20] = (char)("﬊겸ݰ캲ฬボ쐤手澔伢꫙慽գ퓘酘⸤壭瘒⒜鷖⌷㔷譯灧".toCharArray()[20] ^ 0x50FF);
        "樾藵䃜論穙儰㮗".toCharArray()[7] = (char)("樾藵䃜論穙儰㮗".toCharArray()[7] ^ 0x6DD5);
        "ᆊｦ扁ڻ놥懆₂쏳ਢ".toCharArray()[2] = (char)("ᆊｦ扁ڻ놥懆₂쏳ਢ".toCharArray()[2] ^ 0xCC7);
        "?⃪ᒤ敮齫틊Ԍ".toCharArray()[2] = (char)("?⃪ᒤ敮齫틊Ԍ".toCharArray()[2] ^ 0x24F5);
        throw new NumberFormatException(ˉﻤ$ͺſ.v("﬊겸ݰ캲ฬボ쐤手澔伢꫙慽գ퓘酘⸤壭瘒⒜鷖⌷㔷譯灧".toCharArray(), (short)24262, 2, (short)2) + this.ﾞл + ˉﻤ$ͺſ.v("樾藵䃜論穙儰㮗".toCharArray(), (short)16495, 5, (short)4) + ((יּ2 = this).ˑᐟ + 1) + ˉﻤ$ͺſ.v("ᆊｦ扁ڻ놥懆₂쏳ਢ".toCharArray(), (short)24144, 5, (short)0) + ﹳܕ() + ˉﻤ$ͺſ.v("?⃪ᒤ敮齫틊Ԍ".toCharArray(), (short)10921, 3, (short)4) + ˌ());
      } 
      this.ʿﭝ = 0;
      this.ᔪ[this.יċ - 1] = this.ᔪ[this.יċ - 1] + 1;
      return יּ2;
    } 
    if (יּ2 == 16) {
      this.ιƚ = new String(this.ﾞл, this.ˑﮌ, this.ⅼ);
      this.ˑﮌ += this.ⅼ;
    } else if (יּ2 == 8 || יּ2 == 9) {
      this.ιƚ = ᐨẏ((יּ2 == 8) ? 39 : 34);
      try {
        int k = Integer.parseInt(this.ιƚ);
        this.ʿﭝ = 0;
        this.ᔪ[this.יċ - 1] = this.ᔪ[this.יċ - 1] + 1;
        return k;
      } catch (NumberFormatException numberFormatException) {}
    } else {
      "深କ腇퀂娎⤖?晍긅泙ﵦ讼㐛茧掬檪燺莠?题詒璘".toCharArray()[3] = (char)("深କ腇퀂娎⤖?晍긅泙ﵦ讼㐛茧掬檪燺莠?题詒璘".toCharArray()[3] ^ 0x6719);
      "璑꜐暑꽛뷉놂ꢤ᫠".toCharArray()[2] = (char)("璑꜐暑꽛뷉놂ꢤ᫠".toCharArray()[2] ^ 0x3D07);
      "♾㧷巸ꡑ燺뱦챭墀䯔".toCharArray()[1] = (char)("♾㧷巸ꡑ燺뱦챭墀䯔".toCharArray()[1] ^ 0x7C71);
      "ゆ淰땈ᝏ녡ॷ甦".toCharArray()[4] = (char)("ゆ淰땈ᝏ녡ॷ甦".toCharArray()[4] ^ 0x48DB);
      throw new IllegalStateException(ˉﻤ$ͺſ.v("深କ腇퀂娎⤖?晍긅泙ﵦ讼㐛茧掬檪燺莠?题詒璘".toCharArray(), (short)6114, 2, (short)4) + ᐨẏ() + ˉﻤ$ͺſ.v("璑꜐暑꽛뷉놂ꢤ᫠".toCharArray(), (short)9769, 4, (short)1) + ((יּ2 = this).ˑᐟ + 1) + ˉﻤ$ͺſ.v("♾㧷巸ꡑ燺뱦챭墀䯔".toCharArray(), (short)9083, 4, (short)2) + ﹳܕ() + ˉﻤ$ͺſ.v("ゆ淰땈ᝏ녡ॷ甦".toCharArray(), (short)16479, 4, (short)2) + ˌ());
    } 
    this.ʿﭝ = 11;
    int i;
    double d;
    if ((i = (int)(d = Double.parseDouble(this.ιƚ))) != d) {
      "ꆁ?ﭛ歺ⷋ즕㎍슑놯ﾏ졜戥冼鸢멩通쌒箊㳘丌".toCharArray()[8] = (char)("ꆁ?ﭛ歺ⷋ즕㎍슑놯ﾏ졜戥冼鸢멩通쌒箊㳘丌".toCharArray()[8] ^ 0xE00);
      "㽛㜸齸缥権挾D鑲ㆂ".toCharArray()[2] = (char)("㽛㜸齸缥権挾D鑲ㆂ".toCharArray()[2] ^ 0x7301);
      "髭ᢹ꛴䪍?횤䢓질乹".toCharArray()[4] = (char)("髭ᢹ꛴䪍?횤䢓질乹".toCharArray()[4] ^ 0x5EB9);
      "㒦鶯Ɨ㼊⅙⨕".toCharArray()[1] = (char)("㒦鶯Ɨ㼊⅙⨕".toCharArray()[1] ^ 0x692C);
      throw new NumberFormatException(ˉﻤ$ͺſ.v("ꆁ?ﭛ歺ⷋ즕㎍슑놯ﾏ졜戥冼鸢멩通쌒箊㳘丌".toCharArray(), (short)15722, 2, (short)4) + this.ιƚ + ˉﻤ$ͺſ.v("㽛㜸齸缥権挾D鑲ㆂ".toCharArray(), (short)14157, 4, (short)0) + ((יּ1 = this).ˑᐟ + 1) + ˉﻤ$ͺſ.v("髭ᢹ꛴䪍?횤䢓질乹".toCharArray(), (short)28275, 0, (short)1) + ﹳܕ() + ˉﻤ$ͺſ.v("㒦鶯Ɨ㼊⅙⨕".toCharArray(), (short)30736, 3, (short)5) + ˌ());
    } 
    this.ιƚ = null;
    this.ʿﭝ = 0;
    this.ᔪ[this.יċ - 1] = this.ᔪ[this.יċ - 1] + 1;
    return יּ1;
  }
  
  public void close() {
    this.ʿﭝ = 0;
    this.ᐝᵣ[0] = 8;
    this.יċ = 1;
    this.ˊ.close();
  }
  
  public void ˏⅭ() {
    byte b = 0;
    label48: while (true) {
      int i;
      if ((i = this.ʿﭝ) == 0)
        i = ۥ(); 
      if (i == 3) {
        ˊ(1);
        b++;
      } else if (i == 1) {
        ˊ(3);
        b++;
      } else if (i == 4) {
        this.יċ--;
        b--;
      } else if (i == 2) {
        this.יċ--;
        b--;
      } else {
        יּ יּ1;
        if (i == 14 || i == 10) {
          יּ1 = this;
          do {
            byte b1;
            for (b1 = 0; יּ1.ˑﮌ + b1 < יּ1.ƭ; b1++) {
              switch (יּ1.ﾞл[יּ1.ˑﮌ + b1]) {
                case 35:
                case 47:
                case 59:
                case 61:
                case 92:
                  יּ1.ˏﾚ();
                case 9:
                case 10:
                case 12:
                case 13:
                case 32:
                case 44:
                case 58:
                case 91:
                case 93:
                case 123:
                case 125:
                  יּ1.ˑﮌ += b1;
                  continue label48;
              } 
            } 
            יּ1.ˑﮌ += b1;
          } while (יּ1.ﾞл(1));
        } else if (יּ1 == 8 || יּ1 == 12) {
          ᴵʖ('\'');
        } else if (יּ1 == 9 || יּ1 == 13) {
          ᴵʖ('"');
        } else if (יּ1 == 16) {
          this.ˑﮌ += this.ⅼ;
        } 
      } 
      this.ʿﭝ = 0;
      if (b == 0) {
        this.ᔪ[this.יċ - 1] = this.ᔪ[this.יċ - 1] + 1;
        "귤ꗑ矹￰冥".toCharArray()[3] = (char)("귤ꗑ矹￰冥".toCharArray()[3] ^ 0x48A9);
        this.ʹﮃ[this.יċ - 1] = ˉﻤ$ͺſ.v("귤ꗑ矹￰冥".toCharArray(), (short)14924, 3, (short)4);
        return;
      } 
    } 
  }
  
  private void ˊ(int paramInt) {
    if (this.יċ == this.ᐝᵣ.length) {
      int[] arrayOfInt1 = new int[this.יċ << 1];
      int[] arrayOfInt2 = new int[this.יċ << 1];
      String[] arrayOfString = new String[this.יċ << 1];
      System.arraycopy(this.ᐝᵣ, 0, arrayOfInt1, 0, this.יċ);
      System.arraycopy(this.ᔪ, 0, arrayOfInt2, 0, this.יċ);
      System.arraycopy(this.ʹﮃ, 0, arrayOfString, 0, this.יċ);
      this.ᐝᵣ = arrayOfInt1;
      this.ᔪ = arrayOfInt2;
      this.ʹﮃ = arrayOfString;
    } 
    this.ᐝᵣ[this.יċ++] = paramInt;
  }
  
  private boolean ﾞл(int paramInt) {
    long l = this.ﾞл;
    this.ʾẎ -= this.ˑﮌ;
    if (this.ƭ != this.ˑﮌ) {
      this.ƭ -= this.ˑﮌ;
      System.arraycopy(l, this.ˑﮌ, l, 0, this.ƭ);
    } else {
      this.ƭ = 0;
    } 
    this.ˑﮌ = 0;
    int i;
    while ((i = this.ˊ.read(l, this.ƭ, l.length - this.ƭ)) != -1) {
      this.ƭ += i;
      if (this.ˑᐟ == 0 && this.ʾẎ == 0 && this.ƭ > 0 && l[0] == 65279) {
        this.ˑﮌ++;
        this.ʾẎ++;
        paramInt++;
      } 
      if (this.ƭ >= paramInt)
        return true; 
    } 
    return false;
  }
  
  private int ʻᒱ() {
    return this.ˑᐟ + 1;
  }
  
  private int ﹳܕ() {
    return this.ˑﮌ - this.ʾẎ + 1;
  }
  
  private int ᐨẏ(boolean paramBoolean) {
    long l = this.ﾞл;
    int i = this.ˑﮌ;
    int j = this.ƭ;
    while (true) {
      if (i == j) {
        this.ˑﮌ = i;
        if (ﾞл(1)) {
          i = this.ˑﮌ;
          j = this.ƭ;
        } else {
          if (paramBoolean) {
            "湛콨(悦쿒늽㨊ꌠ䥮裧풻后틯祩읬謧ﭺ㔕".toCharArray()[9] = (char)("湛콨(悦쿒늽㨊ꌠ䥮裧풻后틯祩읬謧ﭺ㔕".toCharArray()[9] ^ 0x209F);
            "열⑎꒾ػ鏘ᦝ体徶".toCharArray()[7] = (char)("열⑎꒾ػ鏘ᦝ体徶".toCharArray()[7] ^ 0x1423);
            יּ יּ1;
            throw new EOFException(ᐨẏ$ᐝт.W("湛콨(悦쿒늽㨊ꌠ䥮裧풻后틯祩읬謧ﭺ㔕".toCharArray(), (short)10926, (byte)4, (short)3) + ((יּ1 = this).ˑᐟ + 1) + ᐨẏ$ᐝт.W("열⑎꒾ػ鏘ᦝ体徶".toCharArray(), (short)31583, (byte)2, (short)5) + ﹳܕ());
          } 
          return -1;
        } 
      } 
      long l1;
      if ((l1 = l[i++]) == 10) {
        this.ˑᐟ++;
        this.ʾẎ = i;
        continue;
      } 
      if (l1 != 32 && l1 != 13 && l1 != 9) {
        int k;
        if (l1 == 47) {
          this.ˑﮌ = i;
          if (i == j) {
            this.ˑﮌ--;
            boolean bool = ﾞл(2);
            this.ˑﮌ++;
            if (!bool)
              return l1; 
          } 
          ˏﾚ();
          long l2;
          switch (l2 = l[this.ˑﮌ]) {
            case 42:
              this.ˑﮌ++;
              "膻䂴".toCharArray()[0] = (char)("膻䂴".toCharArray()[0] ^ 0x54F8);
              if (!ᴵʖ(ᐨẏ$ᐝт.W("膻䂴".toCharArray(), (short)20429, (byte)4, (short)5))) {
                "줂?鏳㡲⍖듋挝⒩絍疡늇懔⟫伦臤蟭컆忺".toCharArray()[9] = (char)("줂?鏳㡲⍖듋挝⒩絍疡늇懔⟫伦臤蟭컆忺".toCharArray()[9] ^ 0x7848);
                throw ᐨẏ(ᐨẏ$ᐝт.W("줂?鏳㡲⍖듋挝⒩絍疡늇懔⟫伦臤蟭컆忺".toCharArray(), (short)30893, (byte)3, (short)3));
              } 
              k = this.ˑﮌ + 2;
              j = this.ƭ;
              continue;
            case 47:
              this.ˑﮌ++;
              ʿḶ();
              k = this.ˑﮌ;
              j = this.ƭ;
              continue;
          } 
          return l1;
        } 
        if (l1 == 35) {
          this.ˑﮌ = k;
          ˏﾚ();
          ʿḶ();
          k = this.ˑﮌ;
          j = this.ƭ;
          continue;
        } 
        this.ˑﮌ = k;
        return l1;
      } 
    } 
  }
  
  private void ˏﾚ() {
    if (!this.ˎאּ) {
      "?鬜䟮틧ꑠꇶ嵔탯铑☵ፉ蔰螝谗윅⫆먿擝㰊篇➍槪舼忻帞漩檩쇌⸆蝸ۏऽ␼횤犫遻✕㧳麂⼌廾࿢꜐匐夊൅극ꗽ㞠碆Ǆ鉝㗷".toCharArray()[37] = (char)("?鬜䟮틧ꑠꇶ嵔탯铑☵ፉ蔰螝谗윅⫆먿擝㰊篇➍槪舼忻帞漩檩쇌⸆蝸ۏऽ␼횤犫遻✕㧳麂⼌廾࿢꜐匐夊൅극ꗽ㞠碆Ǆ鉝㗷".toCharArray()[37] ^ 0x7C49);
      throw ᐨẏ(ˏȓ$ᴵЃ.E("?鬜䟮틧ꑠꇶ嵔탯铑☵ፉ蔰螝谗윅⫆먿擝㰊篇➍槪舼忻帞漩檩쇌⸆蝸ۏऽ␼횤犫遻✕㧳麂⼌廾࿢꜐匐夊൅극ꗽ㞠碆Ǆ鉝㗷".toCharArray(), (short)5415, (short)5, (short)0));
    } 
  }
  
  private void ʿḶ() {
    while (this.ˑﮌ < this.ƭ || ﾞл(1)) {
      long l;
      if ((l = this.ﾞл[this.ˑﮌ++]) == 10) {
        this.ˑᐟ++;
        this.ʾẎ = this.ˑﮌ;
        return;
      } 
      if (l != 13);
    } 
  }
  
  private boolean ᴵʖ(String paramString) {
    while (true) {
      if (this.ˑﮌ + paramString.length() <= this.ƭ || ﾞл(paramString.length())) {
        if (this.ﾞл[this.ˑﮌ] == 10) {
          this.ˑᐟ++;
          this.ʾẎ = this.ˑﮌ + 1;
        } else {
          byte b = 0;
          while (true) {
            if (b < paramString.length()) {
              if (this.ﾞл[this.ˑﮌ + b] == paramString.charAt(b)) {
                b++;
                continue;
              } 
              break;
            } 
            return true;
          } 
        } 
        this.ˑﮌ++;
        continue;
      } 
      return false;
    } 
  }
  
  public String toString() {
    "퉆낭ᛌ캄ﴁ䦱ᇯ碓曦爴".toCharArray()[6] = (char)("퉆낭ᛌ캄ﴁ䦱ᇯ碓曦爴".toCharArray()[6] ^ 0x7019);
    "猇ꡁ梘뭭♬痘㩂ἶ".toCharArray()[0] = (char)("猇ꡁ梘뭭♬痘㩂ἶ".toCharArray()[0] ^ 0x497F);
    יּ יּ1;
    return getClass().getSimpleName() + ˉﻤ$ͺſ.v("퉆낭ᛌ캄ﴁ䦱ᇯ碓曦爴".toCharArray(), (short)24532, 0, (short)5) + ((יּ1 = this).ˑᐟ + 1) + ˉﻤ$ͺſ.v("猇ꡁ梘뭭♬痘㩂ἶ".toCharArray(), (short)23683, 2, (short)1) + ﹳܕ();
  }
  
  public final String ˌ() {
    "爵攛".toCharArray()[0] = (char)("爵攛".toCharArray()[0] ^ 0x642E);
    StringBuilder stringBuilder = new StringBuilder(ᐨẏ$ᐝт.W("爵攛".toCharArray(), (short)29610, (byte)0, (short)4));
    byte b = 0;
    int i = this.יċ;
    while (b < i) {
      switch (this.ᐝᵣ[b]) {
        case 1:
        case 2:
          stringBuilder.append('[').append(this.ᔪ[b]).append(']');
          break;
        case 3:
        case 4:
        case 5:
          stringBuilder.append('.');
          if (this.ʹﮃ[b] != null)
            stringBuilder.append(this.ʹﮃ[b]); 
          break;
      } 
      b++;
    } 
    return stringBuilder.toString();
  }
  
  private char ˊ() {
    char c;
    int i;
    int j;
    if (this.ˑﮌ == this.ƭ && !ﾞл(1)) {
      "斨浖빔놌?痈꣱솿쇆츠ޙ蘛뺍凜㧮ᛲ뗰➳䬶炁".toCharArray()[13] = (char)("斨浖빔놌?痈꣱솿쇆츠ޙ蘛뺍凜㧮ᛲ뗰➳䬶炁".toCharArray()[13] ^ 0x6960);
      throw ᐨẏ(ˍɫ$יς.J("斨浖빔놌?痈꣱솿쇆츠ޙ蘛뺍凜㧮ᛲ뗰➳䬶炁".toCharArray(), (short)22719, (short)4, (byte)0));
    } 
    long l;
    switch (l = this.ﾞл[this.ˑﮌ++]) {
      case 117:
        if (this.ˑﮌ + 4 > this.ƭ && !ﾞл(4)) {
          "ࢬ袔鮈辛꭫䁁ഊ穙ꦅ石ਮ杫ヮ萟嬏柮쪵皕㣽?䲘衏匮百ᐼ祙ۑ湤".toCharArray()[18] = (char)("ࢬ袔鮈辛꭫䁁ഊ穙ꦅ石ਮ杫ヮ萟嬏柮쪵皕㣽?䲘衏匮百ᐼ祙ۑ湤".toCharArray()[18] ^ 0x622);
          throw ᐨẏ(ˍɫ$יς.J("ࢬ袔鮈辛꭫䁁ഊ穙ꦅ石ਮ杫ヮ萟嬏柮쪵皕㣽?䲘衏匮百ᐼ祙ۑ湤".toCharArray(), (short)29160, (short)0, (byte)4));
        } 
        c = Character.MIN_VALUE;
        j = (i = this.ˑﮌ) + 4;
        while (i < j) {
          long l1 = this.ﾞл[i];
          c = (char)(c << 4);
          if (l1 >= 48 && l1 <= 57) {
            c = (char)(c + l1 - 48);
          } else if (l1 >= 97 && l1 <= 102) {
            c = (char)(c + l1 - 97 + 10);
          } else if (l1 >= 65 && l1 <= 70) {
            c = (char)(c + l1 - 65 + 10);
          } else {
            "謿꿼狙".toCharArray()[1] = (char)("謿꿼狙".toCharArray()[1] ^ 0x6363);
            throw new NumberFormatException(ˍɫ$יς.J("謿꿼狙".toCharArray(), (short)17781, (short)1, (byte)5) + new String(this.ﾞл, this.ˑﮌ, 4));
          } 
          i++;
        } 
        this.ˑﮌ += 4;
        return c;
      case 116:
        return '\t';
      case 98:
        return '\b';
      case 110:
        return '\n';
      case 114:
        return '\r';
      case 102:
        return '\f';
      case 10:
        this.ˑᐟ++;
        this.ʾẎ = this.ˑﮌ;
        break;
    } 
    return c;
  }
  
  private IOException ᐨẏ(String paramString) {
    "퍼銷穏⢏屡煀⠥".toCharArray()[7] = (char)("퍼銷穏⢏屡煀⠥".toCharArray()[7] ^ 0x6CA7);
    "ﰿ?⵺廌島懓遨硫".toCharArray()[2] = (char)("ﰿ?⵺廌島懓遨硫".toCharArray()[2] ^ 0x36E7);
    "꺿鹺א䙦캥ሿ".toCharArray()[5] = (char)("꺿鹺א䙦캥ሿ".toCharArray()[5] ^ 0x4435);
    יּ יּ1;
    throw new ˑɺ(paramString + ˉﻤ$ͺſ.v("퍼銷穏⢏屡煀⠥".toCharArray(), (short)1898, 3, (short)4) + ((יּ1 = this).ˑᐟ + 1) + ˉﻤ$ͺſ.v("ﰿ?⵺廌島懓遨硫".toCharArray(), (short)13784, 0, (short)0) + ﹳܕ() + ˉﻤ$ͺſ.v("꺿鹺א䙦캥ሿ".toCharArray(), (short)14301, 2, (short)3) + ˌ());
  }
  
  private void ʻᴷ() {
    ᐨẏ(true);
    this.ˑﮌ--;
    if (this.ˑﮌ + ᴵʖ.length > this.ƭ && !ﾞл(ᴵʖ.length))
      return; 
    for (byte b = 0; b < ᴵʖ.length; b++) {
      if (this.ﾞл[this.ˑﮌ + b] != ᴵʖ[b])
        return; 
    } 
    this.ˑﮌ += ᴵʖ.length;
  }
  
  static {
    ˋᕁ.ᐨẏ = new ٴᵇ();
  }
  
  static {
    "ꓖӯ铭?⮷".toCharArray()[1] = (char)("ꓖӯ铭?⮷".toCharArray()[1] ^ 0x756);
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\יּ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */