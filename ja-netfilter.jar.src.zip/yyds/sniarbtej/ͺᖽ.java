package yyds.sniarbtej;

public final class ͺᖽ extends ᐨẏ {
  private final boolean ٴӵ;
  
  private boolean ᴵƚ;
  
  public ͺᖽ(ᐨẏ paramᐨẏ) {
    this(paramᐨẏ, true);
  }
  
  ͺᖽ(ᐨẏ paramᐨẏ, boolean paramBoolean) {
    super(589824, paramᐨẏ);
    this.ٴӵ = paramBoolean;
  }
  
  public final void ᐨẏ(String paramString, Object paramObject) {
    ᴶ();
    ٴӵ(paramString);
    if (!(paramObject instanceof Byte) && !(paramObject instanceof Boolean) && !(paramObject instanceof Character) && !(paramObject instanceof Short) && !(paramObject instanceof Integer) && !(paramObject instanceof Long) && !(paramObject instanceof Float) && !(paramObject instanceof Double) && !(paramObject instanceof String) && !(paramObject instanceof ˑܘ) && !(paramObject instanceof byte[]) && !(paramObject instanceof boolean[]) && !(paramObject instanceof char[]) && !(paramObject instanceof short[]) && !(paramObject instanceof int[]) && !(paramObject instanceof long[]) && !(paramObject instanceof float[]) && !(paramObject instanceof double[])) {
      "ퟒ囵䴆뼂໼౉젝讯陸ࠥ탽ềꅫⷭ設遆࿴撙᣷㜲촘욆戽⏗".toCharArray()[21] = (char)("ퟒ囵䴆뼂໼౉젝讯陸ࠥ탽ềꅫⷭ設遆࿴撙᣷㜲촘욆戽⏗".toCharArray()[21] ^ 0x3CA6);
      throw new IllegalArgumentException(ᐨẏ$ᐝт.W("ퟒ囵䴆뼂໼౉젝讯陸ࠥ탽ềꅫⷭ設遆࿴撙᣷㜲촘욆戽⏗".toCharArray(), (short)29796, (byte)3, (short)4));
    } 
    if (paramObject instanceof ˑܘ && ((ˑܘ)paramObject).ˉｓ() == 11) {
      "計訡炮ꬨ郎몤¹?ᩐ螒'銱돤ًꓲ譶弐ᤔ暮譹ᦡ".toCharArray()[2] = (char)("計訡炮ꬨ郎몤¹?ᩐ螒'銱돤ًꓲ譶弐ᤔ暮譹ᦡ".toCharArray()[2] ^ 0x4FF3);
      throw new IllegalArgumentException(ᐨẏ$ᐝт.W("計訡炮ꬨ郎몤¹?ᩐ螒'銱돤ًꓲ譶弐ᤔ暮譹ᦡ".toCharArray(), (short)31434, (byte)1, (short)5));
    } 
    super.ᐨẏ(paramString, paramObject);
  }
  
  public final void ᐨẏ(String paramString1, String paramString2, String paramString3) {
    ᴶ();
    ٴӵ(paramString1);
    ـｊ.ᐨẏ(49, paramString2, false);
    if (paramString3 == null) {
      "⢓躣瓅圤㋋乾ጒ꧋ⷎ謴娝ﷀ풑验빗⪩".toCharArray()[3] = (char)("⢓躣瓅圤㋋乾ጒ꧋ⷎ謴娝ﷀ풑验빗⪩".toCharArray()[3] ^ 0x1300);
      throw new IllegalArgumentException(ˍɫ$יς.J("⢓躣瓅圤㋋乾ጒ꧋ⷎ謴娝ﷀ풑验빗⪩".toCharArray(), (short)11952, (short)3, (byte)0));
    } 
    super.ᐨẏ(paramString1, paramString2, paramString3);
  }
  
  public final ᐨẏ ᐨẏ(String paramString1, String paramString2) {
    ᴶ();
    ٴӵ(paramString1);
    ـｊ.ᐨẏ(49, paramString2, false);
    return new ͺᖽ(super.ᐨẏ(paramString1, paramString2));
  }
  
  public final ᐨẏ ᐨẏ(String paramString) {
    ᴶ();
    ٴӵ(paramString);
    return new ͺᖽ(super.ᐨẏ(paramString), false);
  }
  
  public final void ᐨẏ() {
    ᴶ();
    this.ᴵƚ = true;
    super.ᐨẏ();
  }
  
  private void ٴӵ(String paramString) {
    if (this.ٴӵ && paramString == null) {
      "蔺냺ᶅꆠ힄紐㙔㸥䕷傊崶쐍열㽚⠵씵ந䔢쥲颲폦ᛐﹲ?蝷雗ꋔ羫迕㮠쪰?븋㣿".toCharArray()[9] = (char)("蔺냺ᶅꆠ힄紐㙔㸥䕷傊崶쐍열㽚⠵씵ந䔢쥲颲폦ᛐﹲ?蝷雗ꋔ羫迕㮠쪰?븋㣿".toCharArray()[9] ^ 0x1A6F);
      throw new IllegalArgumentException(ᐝᵣ$ﾞﾇ.j("蔺냺ᶅꆠ힄紐㙔㸥䕷傊崶쐍열㽚⠵씵ந䔢쥲颲폦ᛐﹲ?蝷雗ꋔ羫迕㮠쪰?븋㣿".toCharArray(), (short)24544, 3, (short)0));
    } 
  }
  
  private void ᴶ() {
    if (this.ᴵƚ) {
      "Ṣ蠷揿五䬓鯍ꩋᠵୌ㽰?䋫윐ﶸ鳦絬쭷♶㉧绳?쐸낗驄咛訝ꐒ嵲㍂㑀ឪ쪹幛帳︣噐靊乙柣䇫쒂ힷԣ紃?푩쏏櫱獏郥㌿".toCharArray()[54] = (char)("Ṣ蠷揿五䬓鯍ꩋᠵୌ㽰?䋫윐ﶸ鳦絬쭷♶㉧绳?쐸낗驄咛訝ꐒ嵲㍂㑀ឪ쪹幛帳︣噐靊乙柣䇫쒂ힷԣ紃?푩쏏櫱獏郥㌿".toCharArray()[54] ^ 0x56E3);
      throw new IllegalStateException(ˉﻤ$ͺſ.v("Ṣ蠷揿五䬓鯍ꩋᠵୌ㽰?䋫윐ﶸ鳦絬쭷♶㉧绳?쐸낗驄咛訝ꐒ嵲㍂㑀ឪ쪹幛帳︣噐靊乙柣䇫쒂ힷԣ紃?푩쏏櫱獏郥㌿".toCharArray(), (short)8298, 1, (short)4));
    } 
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ͺᖽ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */