package yyds.sniarbtej;

import java.io.IOException;

public final class ˑɺ extends IOException {
  private static final long ᐨẏ = 1L;
  
  public ˑɺ(String paramString) {
    super(paramString);
  }
  
  private ˑɺ(String paramString, Throwable paramThrowable) {
    super(paramString);
    initCause(paramThrowable);
  }
  
  private ˑɺ(Throwable paramThrowable) {
    initCause(paramThrowable);
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ˑɺ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */