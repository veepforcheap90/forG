package yyds.sniarbtej;

final class ᐝᴾ extends ٴۉ<T> {
  private ٴۉ<T> ˊ;
  
  ᐝᴾ(ˎე paramˎე, boolean paramBoolean1, boolean paramBoolean2, ˑĴ paramˑĴ, ʸ paramʸ) {}
  
  public final T ᐨẏ(יּ paramיּ) {
    if (this.ˊɼ) {
      paramיּ.ˏⅭ();
      return null;
    } 
    return ᐨẏ().ᐨẏ(paramיּ);
  }
  
  public final void ᐨẏ(Ⴡ paramჁ, T paramT) {
    if (this.ۥ) {
      paramჁ.ʿᵉ();
      return;
    } 
    ᐨẏ().ᐨẏ(paramჁ, paramT);
  }
  
  private ٴۉ<T> ᐨẏ() {
    ٴۉ<T> ٴۉ1;
    return ((ٴۉ1 = this.ˊ) != null) ? ٴۉ1 : (this.ˊ = this.ᴵʖ.<T>ᐨẏ(this.ᴵʖ, (ʸ<T>)this.ᴵʖ));
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ᐝᴾ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */