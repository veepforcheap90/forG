package yyds.sniarbtej;

import java.lang.annotation.Annotation;
import java.util.HashMap;
import java.util.Map;
import ylt.pmn.zubdqvgt;

final class ՙʜ<T extends Enum<T>> extends ٴۉ<T> {
  private final Map<String, T> ˌ = new HashMap<>();
  
  private final Map<T, String> ˍ = new HashMap<>();
  
  public ՙʜ(Class<T> paramClass) {
    try {
      Enum[] arrayOfEnum;
      int i = (arrayOfEnum = (Enum[])paramClass.getEnumConstants()).length;
      for (byte b = 0; b < i; b++) {
        Enum<Enum> enum_;
        String str = (enum_ = arrayOfEnum[b]).name();
        ˍᔨ ˍᔨ;
        if ((ˍᔨ = paramClass.getField(str).<Annotation>getAnnotation(ˍᔨ.class)) != null) {
          str = ˍᔨ.ʾ();
          String[] arrayOfString;
          int j = (arrayOfString = ˍᔨ.ˊ()).length;
          for (byte b1 = 0; b1 < j; b1++) {
            String str1 = arrayOfString[b1];
            this.ˌ.put(str1, (T)enum_);
          } 
        } 
        this.ˌ.put(str, (T)enum_);
        this.ˍ.put((T)enum_, str);
      } 
      return;
    } catch (NoSuchFieldException noSuchFieldException) {
      "諱胸⋠嬚♙粟⠼䓊㮢雯擶恓Ἕ푶㠿坬㮄".toCharArray()[6] = (char)("諱胸⋠嬚♙粟⠼䓊㮢雯擶恓Ἕ푶㠿坬㮄".toCharArray()[6] ^ 0x1620);
      throw new AssertionError(ˉﻤ$ͺſ.v("諱胸⋠嬚♙粟⠼䓊㮢雯擶恓Ἕ푶㠿坬㮄".toCharArray(), (short)5428, 1, (short)0) + paramClass.getName(), noSuchFieldException);
    } 
  }
  
  private T ᐨẏ(יּ paramיּ) {
    if (zubdqvgt.G(paramיּ.ᐨẏ(), כ.ʽ)) {
      paramיּ.ۦ();
      return null;
    } 
    return this.ˌ.get(paramיּ.ٴӵ());
  }
  
  private void ᐨẏ(Ⴡ paramჁ, T paramT) {
    paramჁ.ˊ((paramT == null) ? null : this.ˍ.get(paramT));
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ՙʜ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */