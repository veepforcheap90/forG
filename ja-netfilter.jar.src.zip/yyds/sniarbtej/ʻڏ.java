package yyds.sniarbtej;

import java.util.ListIterator;

public final class ʻڏ extends ͺᔮ {
  public final String ᔪ() {
    "嶇餢轥쨲멖ꛮ齿ꟻ㟉䭀狧㭪鹯鬋갩䢙嫈䑄ඥว鸞㷡꜃娆蚧?氵쒤?巶麙଑㣁叜洀砧??쏘숗쩫簞".toCharArray()[9] = (char)("嶇餢轥쨲멖ꛮ齿ꟻ㟉䭀狧㭪鹯鬋갩䢙嫈䑄ඥว鸞㷡꜃娆蚧?氵쒤?巶麙଑㣁叜洀砧??쏘숗쩫簞".toCharArray()[9] ^ 0x5100);
    return ˏȓ$ᴵЃ.E("嶇餢轥쨲멖ꛮ齿ꟻ㟉䭀狧㭪鹯鬋갩䢙嫈䑄ඥว鸞㷡꜃娆蚧?氵쒤?巶麙଑㣁叜洀砧??쏘숗쩫簞".toCharArray(), (short)26831, (short)5, (short)0);
  }
  
  public final byte[] ˍɫ(byte[] paramArrayOfbyte) {
    return ᐨẏ(paramArrayOfbyte, paramᐧє -> {
          "訧ꙋꡯ魨킝锤龁ंጣ蒟뭿삷瑁".toCharArray()[1] = (char)("訧ꙋꡯ魨킝锤龁ंጣ蒟뭿삷瑁".toCharArray()[1] ^ 0x265B);
          "法菂䎃,諒퓻퉭ଦ㊮䣊臭￱挟叓퓭≤䍌搎᳕ғ".toCharArray()[13] = (char)("法菂䎃,諒퓻퉭ଦ㊮䣊臭￱挟叓퓭≤䍌搎᳕ғ".toCharArray()[13] ^ 0x426D);
          if (ᐝᵣ$ﾞﾇ.j("訧ꙋꡯ魨킝锤龁ंጣ蒟뭿삷瑁".toCharArray(), (short)7878, 0, (short)1).equals(paramᐧє.name) && ᐝᵣ$ﾞﾇ.j("法菂䎃,諒퓻퉭ଦ㊮䣊臭￱挟叓퓭≤䍌搎᳕ғ".toCharArray(), (short)6875, 0, (short)3).equals(paramᐧє.ˎᴗ)) {
            ـс ـс = paramᐧє.ˊ;
            Ӏ ӏ = null;
            ListIterator<Ӏ> listIterator = ـс.ᐨẏ();
            while (listIterator.hasNext()) {
              Ӏ ӏ1;
              if ((ӏ1 = listIterator.next()).ˈהּ() == 176)
                ӏ = ӏ1; 
            } 
            if (ӏ != null) {
              ـс.ᴵʖ(ӏ, new ᕁ(58, 0));
              ـс.ᴵʖ(ӏ, new ᕁ(25, 0));
              "獿҆㪙".toCharArray()[0] = (char)("獿҆㪙".toCharArray()[0] ^ 0x7A91);
              "Ï峗ㄬ轙狑쯛Ζ῍Η蛝󌒄嬣ㄎꎠ?⚶昔瀎鵬瑰".toCharArray()[10] = (char)("Ï峗ㄬ轙狑쯛Ζ῍Η蛝󌒄嬣ㄎꎠ?⚶昔瀎鵬瑰".toCharArray()[10] ^ 0x7D5C);
              ـс.ᴵʖ(ӏ, new ʾᔂ(184, ן, ᐝᵣ$ﾞﾇ.j("獿҆㪙".toCharArray(), (short)4133, 0, (short)3), ᐝᵣ$ﾞﾇ.j("Ï峗ㄬ轙狑쯛Ζ῍Η蛝󌒄嬣ㄎꎠ?⚶昔瀎鵬瑰".toCharArray(), (short)6929, 5, (short)0), false));
              ـс.ᴵʖ(ӏ, new ᕁ(25, 0));
            } 
          } 
        });
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ʻڏ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */