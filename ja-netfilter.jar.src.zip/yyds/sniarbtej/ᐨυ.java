package yyds.sniarbtej;

import java.util.UUID;
import ylt.pmn.zubdqvgt;

final class ᐨυ extends ٴۉ<UUID> {
  private static UUID ᐨẏ(יּ paramיּ) {
    if (zubdqvgt.G(paramיּ.ᐨẏ(), כ.ʽ)) {
      paramיּ.ۦ();
      return null;
    } 
    return UUID.fromString(paramיּ.ٴӵ());
  }
  
  private static void ᐨẏ(Ⴡ paramჁ, UUID paramUUID) {
    paramჁ.ˊ((paramUUID == null) ? null : paramUUID.toString());
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ᐨυ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */