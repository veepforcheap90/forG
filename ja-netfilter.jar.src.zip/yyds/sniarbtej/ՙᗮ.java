package yyds.sniarbtej;

public final class ՙᗮ extends IndexOutOfBoundsException {
  private static final long ᐨẏ = 160715609518896765L;
  
  private final String ˊ;
  
  private final int ˌ;
  
  public ՙᗮ(String paramString, int paramInt) {
    super(ˏȓ$ᴵЃ.E("筈ᝮ꫁릃껑⹖처巣奝Ɨ苕⛔顐䮾঺".toCharArray(), (short)30679, (short)4, (short)3) + paramString);
    this.ˊ = paramString;
    this.ˌ = paramInt;
  }
  
  private String ᐨẏ() {
    return this.ˊ;
  }
  
  private int ʹﮃ() {
    return this.ˌ;
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ՙᗮ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */