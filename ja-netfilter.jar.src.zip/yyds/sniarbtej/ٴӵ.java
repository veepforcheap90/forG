package yyds.sniarbtej;

final class ٴӵ {
  private static int ﻥ = 0;
  
  private static int ˊᕝ = 2147483647;
  
  private int ᐨḶ;
  
  private ᔪ ᐨẏ;
  
  private ٴӵ ᐨẏ;
  
  ٴӵ(int paramInt, ᔪ paramᔪ, ٴӵ paramٴӵ) {
    this.ᐨḶ = paramInt;
    this.ᐨẏ = (ٴӵ)paramᔪ;
    this.ᐨẏ = paramٴӵ;
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ٴӵ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */