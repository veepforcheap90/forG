package yyds.sniarbtej;

import ylt.pmn.zubdqvgt;

final class ᐨᘧ extends ٴۉ<Number> {
  private static Number ᐨẏ(יּ paramיּ) {
    if (zubdqvgt.G(paramיּ.ᐨẏ(), כ.ʽ)) {
      paramיּ.ۦ();
      return null;
    } 
    try {
      return Short.valueOf((short)paramיּ.ˊɼ());
    } catch (NumberFormatException numberFormatException) {
      throw new ՙĩ(numberFormatException);
    } 
  }
  
  private static void ᐨẏ(Ⴡ paramჁ, Number paramNumber) {
    paramჁ.ᐨẏ(paramNumber);
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ᐨᘧ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */