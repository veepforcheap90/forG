package yyds.sniarbtej;

final class ﭕ extends ˊᐹ {
  ﭕ(ιะ paramιะ) {
    super(paramιะ.ᐨẏ, (byte)0);
  }
  
  public final K next() {
    return (ᴵʖ()).ʾ;
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ﭕ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */