package yyds.sniarbtej;

final class ﹼ implements ʿн<T> {
  ﹼ(ˍʶ paramˍʶ) {}
  
  public final T ʿᵉ() {
    return (T)new ᐝʶ<>();
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ﹼ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */