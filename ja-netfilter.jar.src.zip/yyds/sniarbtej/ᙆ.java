package yyds.sniarbtej;

public final class ᙆ extends ˑʖ {
  private static final long ᐨẏ = 1L;
  
  public ᙆ(String paramString) {
    super(paramString);
  }
  
  private ᙆ(String paramString, Throwable paramThrowable) {
    super(paramString, paramThrowable);
  }
  
  public ᙆ(Throwable paramThrowable) {
    super(paramThrowable);
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ᙆ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */