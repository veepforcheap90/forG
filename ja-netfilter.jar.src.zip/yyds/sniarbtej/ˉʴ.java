package yyds.sniarbtej;

final class ˉʴ extends ٴۉ<Number> {
  private static Number ᐨẏ(יּ paramיּ) {
    כ כ = paramיּ.ᐨẏ();
    switch (ᴵᔿ.ʹō[כ.ordinal()]) {
      case 4:
        paramיּ.ۦ();
        return null;
      case 1:
        return new ˌﺙ(paramיּ.ٴӵ());
    } 
    "㰥쌓䟜ꖅ₅瘵㋕ᚵ斥싆⽁唏媑熥倡鑨慯恍閛?䆂퀉䌵".toCharArray()[19] = (char)("㰥쌓䟜ꖅ₅瘵㋕ᚵ斥싆⽁唏媑熥倡鑨慯恍閛?䆂퀉䌵".toCharArray()[19] ^ 0x3A2F);
    throw new ՙĩ(ˉﻤ$ͺſ.v("㰥쌓䟜ꖅ₅瘵㋕ᚵ斥싆⽁唏媑熥倡鑨慯恍閛?䆂퀉䌵".toCharArray(), (short)13484, 5, (short)5) + כ);
  }
  
  private static void ᐨẏ(Ⴡ paramჁ, Number paramNumber) {
    paramჁ.ᐨẏ(paramNumber);
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ˉʴ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */