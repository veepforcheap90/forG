package yyds.sniarbtej;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.file.FileVisitResult;
import java.nio.file.Path;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.List;
import java.util.jar.JarFile;
import java.util.zip.ZipEntry;

final class ᵨ extends SimpleFileVisitor<Path> {
  ᵨ(List paramList, Path paramPath) {}
  
  private FileVisitResult ᐨẏ(Path paramPath) {
    "᧋赣⇤묓㵞".toCharArray()[2] = (char)("᧋赣⇤묓㵞".toCharArray()[2] ^ 0x23C1);
    String str;
    if (!(str = paramPath.getFileName().toString()).endsWith(ˉﻤ$ͺſ.v("᧋赣⇤묓㵞".toCharArray(), (short)14272, 5, (short)1)))
      return FileVisitResult.CONTINUE; 
    JarFile jarFile = new JarFile(paramPath.toFile());
    try {
      "狻軲웂ﻙ䡭耛輇␇張?蒑뮔ቺꌾ䇛?㔶֙㺬".toCharArray()[4] = (char)("狻軲웂ﻙ䡭耛輇␇張?蒑뮔ቺꌾ䇛?㔶֙㺬".toCharArray()[4] ^ 0x3D13);
      ZipEntry zipEntry;
      if ((zipEntry = jarFile.getEntry(ˉﻤ$ͺſ.v("狻軲웂ﻙ䡭耛輇␇張?蒑뮔ቺꌾ䇛?㔶֙㺬".toCharArray(), (short)7760, 3, (short)3))) == null) {
        FileVisitResult fileVisitResult = FileVisitResult.CONTINUE;
        jarFile.close();
        return fileVisitResult;
      } 
      try {
        InputStream inputStream = jarFile.getInputStream(zipEntry);
        try {
          InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
          try {
            BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
            try {
              String str1 = "";
              String str2 = "";
              String str3 = "";
              try {
                String str4;
                while ((str4 = bufferedReader.readLine()) != null) {
                  "㪂踜㱔㏘ᢰ牴颢ﳏ槺럡ඵ딣윹똌㤅➏".toCharArray()[10] = (char)("㪂踜㱔㏘ᢰ牴颢ﳏ槺럡ඵ딣윹똌㤅➏".toCharArray()[10] ^ 0x6A3A);
                  if (str4.contains(ˉﻤ$ͺſ.v("㪂踜㱔㏘ᢰ牴颢ﳏ槺럡ඵ딣윹똌㤅➏".toCharArray(), (short)26026, 2, (short)5))) {
                    "Α鹍ẍͷﰠ폅㳠".toCharArray()[2] = (char)("Α鹍ẍͷﰠ폅㳠".toCharArray()[2] ^ 0x1EF1);
                    "臱牰".toCharArray()[0] = (char)("臱牰".toCharArray()[0] ^ 0x3F9B);
                    str1 = str4.split(ˉﻤ$ͺſ.v("Α鹍ẍͷﰠ폅㳠".toCharArray(), (short)9471, 0, (short)5))[1].split(ˉﻤ$ͺſ.v("臱牰".toCharArray(), (short)4192, 4, (short)5))[0].trim();
                  } else {
                    "倗）羮辇㹄ᬘ珂笠쨄丅".toCharArray()[0] = (char)("倗）羮辇㹄ᬘ珂笠쨄丅".toCharArray()[0] ^ 0x64B2);
                    if (str4.contains(ˉﻤ$ͺſ.v("倗）羮辇㹄ᬘ珂笠쨄丅".toCharArray(), (short)14161, 2, (short)4))) {
                      "뚦䬗꒤?魺ꈝ磇䄊⤃".toCharArray()[5] = (char)("뚦䬗꒤?魺ꈝ磇䄊⤃".toCharArray()[5] ^ 0x63D6);
                      "芻䖽鮧湼퍾⻇⨀讌洕嚅淞".toCharArray()[2] = (char)("芻䖽鮧湼퍾⻇⨀讌洕嚅淞".toCharArray()[2] ^ 0x10D4);
                      str2 = str4.split(ˉﻤ$ͺſ.v("뚦䬗꒤?魺ꈝ磇䄊⤃".toCharArray(), (short)22201, 3, (short)3))[1].split(ˉﻤ$ͺſ.v("芻䖽鮧湼퍾⻇⨀讌洕嚅淞".toCharArray(), (short)28395, 3, (short)1))[0].trim();
                    } else {
                      "?Ꮴ笜妕Ϟ췌᮵".toCharArray()[2] = (char)("?Ꮴ笜妕Ϟ췌᮵".toCharArray()[2] ^ 0x1DD4);
                      if (str4.contains(ˉﻤ$ͺſ.v("?Ꮴ笜妕Ϟ췌᮵".toCharArray(), (short)22461, 2, (short)2))) {
                        "⌋鲆岼᱊?⭑ෘ".toCharArray()[4] = (char)("⌋鲆岼᱊?⭑ෘ".toCharArray()[4] ^ 0x25D);
                        "꺼뜺頬尦䳌薊ҧ".toCharArray()[1] = (char)("꺼뜺頬尦䳌薊ҧ".toCharArray()[1] ^ 0x3EC);
                        str3 = str4.split(ˉﻤ$ͺſ.v("⌋鲆岼᱊?⭑ෘ".toCharArray(), (short)31724, 4, (short)4))[1].split(ˉﻤ$ͺſ.v("꺼뜺頬尦䳌薊ҧ".toCharArray(), (short)24103, 0, (short)4))[0].trim();
                      } 
                    } 
                  } 
                  if (!str1.isEmpty() && !str2.isEmpty() && !str3.isEmpty())
                    break; 
                } 
                if (!str1.isEmpty()) {
                  "᭷釐릡䬄膧曰姗喴뿑➓ސ귚?㫂䐷".toCharArray()[6] = (char)("᭷釐릡䬄膧曰姗喴뿑➓ސ귚?㫂䐷".toCharArray()[6] ^ 0x6998);
                  "涅陻⭯憷".toCharArray()[0] = (char)("涅陻⭯憷".toCharArray()[0] ^ 0x34C6);
                  "෉⼪".toCharArray()[0] = (char)("෉⼪".toCharArray()[0] ^ 0x39A8);
                  System.out.println(ˉﻤ$ͺſ.v("᭷釐릡䬄膧曰姗喴뿑➓ސ귚?㫂䐷".toCharArray(), (short)5689, 0, (short)5) + str1 + ˉﻤ$ͺſ.v("涅陻⭯憷".toCharArray(), (short)25245, 2, (short)2) + str3 + ˉﻤ$ͺſ.v("෉⼪".toCharArray(), (short)21627, 0, (short)5) + str2);
                  "忲?ᑆᄕ◯碉ᗃګ".toCharArray()[0] = (char)("忲?ᑆᄕ◯碉ᗃګ".toCharArray()[0] ^ 0xEA6);
                  "⮿팡錂⠧䣵哑엊ꯜឍ".toCharArray()[3] = (char)("⮿팡錂⠧䣵哑엊ꯜឍ".toCharArray()[3] ^ 0x1F61);
                  str2 = ˉﻤ$ͺſ.v("忲?ᑆᄕ◯碉ᗃګ".toCharArray(), (short)25050, 3, (short)3) + str1 + ˉﻤ$ͺſ.v("⮿팡錂⠧䣵哑엊ꯜឍ".toCharArray(), (short)20673, 3, (short)2);
                  if (this.ˌᔹ.contains(str1)) {
                    ᐨп.ᐨẏ(this.ᐨẏ.resolve(str2).toFile());
                  } else {
                    str1 = ﹳﹲ.ʹō(str1);
                    ᐨп.ˊ(this.ᐨẏ.resolve(str2).toFile(), str1);
                  } 
                } 
              } catch (Throwable throwable2) {
                Throwable throwable1;
                (throwable1 = null).printStackTrace();
              } 
              bufferedReader.close();
            } catch (Throwable throwable) {
              try {
                bufferedReader.close();
              } catch (Throwable throwable1) {
                throwable.addSuppressed(throwable1);
              } 
              throw throwable;
            } 
            inputStreamReader.close();
          } catch (Throwable throwable) {
            try {
              inputStreamReader.close();
            } catch (Throwable throwable1) {
              throwable.addSuppressed(throwable1);
            } 
            throw throwable;
          } 
          if (inputStream != null)
            inputStream.close(); 
        } catch (Throwable throwable) {
          if (inputStream != null)
            try {
              inputStream.close();
            } catch (Throwable throwable1) {
              throwable.addSuppressed(throwable1);
            }  
          throw throwable;
        } 
      } catch (Exception exception2) {
        Exception exception1;
        (exception1 = null).printStackTrace();
      } 
      jarFile.close();
    } catch (Throwable throwable) {
      try {
        jarFile.close();
      } catch (Throwable throwable1) {
        throwable.addSuppressed(throwable1);
      } 
      throw throwable;
    } 
    return FileVisitResult.CONTINUE;
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ᵨ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */