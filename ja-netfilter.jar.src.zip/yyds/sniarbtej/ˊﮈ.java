package yyds.sniarbtej;

public final class ˊﮈ extends ᴵʖ {
  private String ﹳܕ;
  
  private ˊﮈ(String paramString) {
    super(ˍɫ$יς.J("ᇍ왫嬐皒揨츲Ꙥ旑욽矬搽㏟㊟".toCharArray(), (short)18668, (short)2, (byte)1));
    this.ﹳܕ = paramString;
  }
  
  public ˊﮈ() {
    this(null);
  }
  
  public final ᴵʖ ᐨẏ(ᐨم paramᐨم, int paramInt1, int paramInt2, char[] paramArrayOfchar) {
    return new ˊﮈ(paramᐨم.ᐨẏ(paramInt1, paramArrayOfchar));
  }
  
  public final ʿᵉ ᐨẏ(ʽ paramʽ) {
    ʿᵉ ʿᵉ;
    (ʿᵉ = new ʿᵉ()).ˊ((this.ﹳܕ == null) ? 0 : paramʽ.ˊ(this.ﹳܕ));
    return ʿᵉ;
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ˊﮈ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */