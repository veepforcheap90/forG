package yyds.sniarbtej;

import java.util.ArrayList;
import java.util.concurrent.atomic.AtomicIntegerArray;

final class ˊť extends ٴۉ<AtomicIntegerArray> {
  private static AtomicIntegerArray ᐨẏ(יּ paramיּ) {
    ArrayList<Integer> arrayList = new ArrayList();
    paramיּ.ᵘ();
    while (paramיּ.hasNext()) {
      try {
        int j = paramיּ.ˊɼ();
        arrayList.add(Integer.valueOf(j));
      } catch (NumberFormatException numberFormatException) {
        throw new ՙĩ(numberFormatException);
      } 
    } 
    paramיּ.ˑܥ();
    int i = arrayList.size();
    AtomicIntegerArray atomicIntegerArray = new AtomicIntegerArray(i);
    for (byte b = 0; b < i; b++)
      atomicIntegerArray.set(b, ((Integer)arrayList.get(b)).intValue()); 
    return atomicIntegerArray;
  }
  
  private static void ᐨẏ(Ⴡ paramჁ, AtomicIntegerArray paramAtomicIntegerArray) {
    paramჁ.ᐨẏ();
    byte b = 0;
    int i = paramAtomicIntegerArray.length();
    while (b < i) {
      paramჁ.ᐨẏ(paramAtomicIntegerArray.get(b));
      b++;
    } 
    paramჁ.ˊ();
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ˊť.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */