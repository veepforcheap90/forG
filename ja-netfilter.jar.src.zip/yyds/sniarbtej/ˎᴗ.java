package yyds.sniarbtej;

public final class ˎᴗ extends ᴵʖ {
  private static int ᐧᴼ = 1;
  
  private static int ʿ丿 = 2;
  
  private static int ﾞܢ = 4;
  
  private static int ιī = 8;
  
  private int ˎไ;
  
  private ˎᴗ(int paramInt) {
    super(ˏȓ$ᴵЃ.E("ꊁᜋ韁쓳?Ⓩᇌ駾臗굶ͦ섫⧲ٺ淁௹".toCharArray(), (short)15993, (short)2, (short)4));
    this.ˎไ = paramInt;
  }
  
  public ˎᴗ() {
    this(0);
  }
  
  public final ᴵʖ ᐨẏ(ᐨم paramᐨم, int paramInt1, int paramInt2, char[] paramArrayOfchar) {
    return new ˎᴗ(paramᐨم.ᴵʖ(paramInt1));
  }
  
  public final ʿᵉ ᐨẏ(ʽ paramʽ) {
    ʿᵉ ʿᵉ;
    (ʿᵉ = new ʿᵉ()).ˊ(this.ˎไ);
    return ʿᵉ;
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ˎᴗ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */