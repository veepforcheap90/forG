package yyds.sniarbtej;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.FIELD})
public @interface ʻṿ {
  boolean ʿপ() default true;
  
  boolean ʻล() default true;
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ʻṿ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */