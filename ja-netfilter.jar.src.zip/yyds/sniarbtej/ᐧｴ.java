package yyds.sniarbtej;

import java.io.IOException;
import java.io.StringWriter;
import java.math.BigDecimal;
import java.math.BigInteger;

public abstract class ᐧｴ {
  abstract ᐧｴ ᐨẏ();
  
  public final boolean ˌ() {
    return this instanceof ˋℷ;
  }
  
  public final boolean ˍ() {
    return this instanceof ʻṪ;
  }
  
  public final boolean ʹō() {
    return this instanceof ﭘ;
  }
  
  public final boolean ᐝᵣ() {
    return this instanceof ڊ;
  }
  
  public final ʻṪ ᐨẏ() {
    ᐧｴ ᐧｴ1;
    if (ᐧｴ1 = this instanceof ʻṪ)
      return (ʻṪ)this; 
    "뮨ﾏ퐀馬銲ꖧ컘汳譞凛揨噩雸쟌炪ꏊ汿쨈寐㈊".toCharArray()[1] = (char)("뮨ﾏ퐀馬銲ꖧ컘汳譞凛揨噩雸쟌炪ꏊ汿쨈寐㈊".toCharArray()[1] ^ 0x5434);
    throw new IllegalStateException(ˍɫ$יς.J("뮨ﾏ퐀馬銲ꖧ컘汳譞凛揨噩雸쟌炪ꏊ汿쨈寐㈊".toCharArray(), (short)28841, (short)3, (byte)3) + this);
  }
  
  public final ˋℷ ˊ() {
    ᐧｴ ᐧｴ1;
    if (ᐧｴ1 = this instanceof ˋℷ)
      return (ˋℷ)this; 
    "쵧雃ꕸ씓⎳瑹裩࿨᠇ꭉ潃ꔙ驚＠꿻距튬ڏ誏㫒".toCharArray()[11] = (char)("쵧雃ꕸ씓⎳瑹裩࿨᠇ꭉ潃ꔙ驚＠꿻距튬ڏ誏㫒".toCharArray()[11] ^ 0x6E96);
    throw new IllegalStateException(ˍɫ$יς.J("쵧雃ꕸ씓⎳瑹裩࿨᠇ꭉ潃ꔙ驚＠꿻距튬ڏ誏㫒".toCharArray(), (short)32330, (short)2, (byte)1));
  }
  
  public final ﭘ ᐨẏ() {
    ᐧｴ ᐧｴ1;
    if (ᐧｴ1 = this instanceof ﭘ)
      return (ﭘ)this; 
    "ጊ紅飼ꂈ缣፭垷?瞳◠?ᱩ紲疡┃?ꃳ㲅讵鍄蝄?﫿ᗁ썓欝".toCharArray()[11] = (char)("ጊ紅飼ꂈ缣፭垷?瞳◠?ᱩ紲疡┃?ꃳ㲅讵鍄蝄?﫿ᗁ썓欝".toCharArray()[11] ^ 0x7ECE);
    throw new IllegalStateException(ᐝᵣ$ﾞﾇ.j("ጊ紅飼ꂈ缣፭垷?瞳◠?ᱩ紲疡┃?ꃳ㲅讵鍄蝄?﫿ᗁ썓欝".toCharArray(), (short)16945, 4, (short)4));
  }
  
  private ڊ ᐨẏ() {
    ᐧｴ ᐧｴ1;
    if (ᐧｴ1 = this instanceof ڊ)
      return (ڊ)this; 
    "о㌅᪟덶۵ᆠ׼㧩?渡穀岕붌䗀퇕䆤첢莈橶齃䢯誠ۊ".toCharArray()[9] = (char)("о㌅᪟덶۵ᆠ׼㧩?渡穀岕붌䗀퇕䆤첢莈橶齃䢯誠ۊ".toCharArray()[9] ^ 0x2888);
    throw new IllegalStateException(ᐝᵣ$ﾞﾇ.j("о㌅᪟덶۵ᆠ׼㧩?渡穀岕붌䗀퇕䆤첢莈橶齃䢯誠ۊ".toCharArray(), (short)24347, 0, (short)4));
  }
  
  public boolean ᴵƚ() {
    throw new UnsupportedOperationException(getClass().getSimpleName());
  }
  
  Boolean ᐨẏ() {
    throw new UnsupportedOperationException(getClass().getSimpleName());
  }
  
  public Number ᐨẏ() {
    throw new UnsupportedOperationException(getClass().getSimpleName());
  }
  
  public String ᐨم() {
    throw new UnsupportedOperationException(getClass().getSimpleName());
  }
  
  public double ᐨẏ() {
    throw new UnsupportedOperationException(getClass().getSimpleName());
  }
  
  public float ᐨẏ() {
    throw new UnsupportedOperationException(getClass().getSimpleName());
  }
  
  public long ˊ() {
    throw new UnsupportedOperationException(getClass().getSimpleName());
  }
  
  public int ٴᖟ() {
    throw new UnsupportedOperationException(getClass().getSimpleName());
  }
  
  public byte ᐨẏ() {
    throw new UnsupportedOperationException(getClass().getSimpleName());
  }
  
  public char ᐨẏ() {
    throw new UnsupportedOperationException(getClass().getSimpleName());
  }
  
  public BigDecimal ᐨẏ() {
    throw new UnsupportedOperationException(getClass().getSimpleName());
  }
  
  public BigInteger ᐨẏ() {
    throw new UnsupportedOperationException(getClass().getSimpleName());
  }
  
  public short ᐨẏ() {
    throw new UnsupportedOperationException(getClass().getSimpleName());
  }
  
  public String toString() {
    try {
      StringWriter stringWriter = new StringWriter();
      boolean bool = true;
      Ⴡ ⴡ1;
      Ⴡ ⴡ2;
      (ⴡ2 = ⴡ1 = new Ⴡ(stringWriter)).ˎאּ = bool;
      ˏɪ.ˊ(this, ⴡ1);
      return stringWriter.toString();
    } catch (IOException iOException) {
      throw new AssertionError(iOException);
    } 
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ᐧｴ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */