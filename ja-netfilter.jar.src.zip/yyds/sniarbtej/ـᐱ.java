package yyds.sniarbtej;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public final class ـᐱ extends ـᘢ {
  private static final String ـɻ;
  
  private static final String ʻヽ = ˏȓ$ᴵЃ.E("ᇵ浆ƾ폿初㉈蹱伱ᔬ".toCharArray(), (short)30113, (short)3, (short)1).intern();
  
  private static final String ʼˀ = ˏȓ$ᴵЃ.E("붏ᐷ폘ꋖ拓?㯵⽍쨒؝毘⢝".toCharArray(), (short)24060, (short)0, (short)3).intern();
  
  private static final Map<Character, String> ʾܪ;
  
  private final boolean ˊ;
  
  final StringBuilder ˊ;
  
  private StringBuilder ᴵʖ;
  
  private StringBuilder ﾞл;
  
  private boolean ـﭔ;
  
  private boolean ʼᵖ;
  
  private boolean ﾞǰ;
  
  private boolean ˊᵃ;
  
  private int ˉม;
  
  private int ˏﭠ;
  
  private String ˍᒄ = "";
  
  public ـᐱ(int paramInt) {
    super(589824);
    this.ˊ = ((paramInt & 0x200) != 0) ? 1 : 0;
    this.ˊ = new StringBuilder();
  }
  
  private ـᐱ(StringBuilder paramStringBuilder) {
    super(589824);
    this.ˊ = false;
    this.ˊ = paramStringBuilder;
  }
  
  public final void ʾ(String paramString) {
    "⶜֮䘛".toCharArray()[0] = (char)("⶜֮䘛".toCharArray()[0] ^ 0x1D4C);
    "叚".toCharArray()[0] = (char)("叚".toCharArray()[0] ^ 0x2439);
    this.ˊ.append(this.ـﭔ ? ˍɫ$יς.J("⶜֮䘛".toCharArray(), (short)15007, (short)2, (byte)4).intern() : ˍɫ$יς.J("叚".toCharArray(), (short)17259, (short)2, (byte)5)).append(paramString);
    this.ـﭔ = true;
    this.ʼᵖ = false;
  }
  
  public final ـᘢ ˊ() {
    "哪?⒀觷풳ㆌ䱍态㬏".toCharArray()[1] = (char)("哪?⒀觷풳ㆌ䱍态㬏".toCharArray()[1] ^ 0x422F);
    this.ˍᒄ = ᐝᵣ$ﾞﾇ.j("哪?⒀觷풳ㆌ䱍态㬏".toCharArray(), (short)23870, 5, (short)3).intern();
    ﾟ();
    return this;
  }
  
  public final ـᘢ ʿᵉ() {
    "寭䘃".toCharArray()[0] = (char)("寭䘃".toCharArray()[0] ^ 0x6E6E);
    "寊ሣ襵䃡옫飘㷂蚖靯浏".toCharArray()[3] = (char)("寊ሣ襵䃡옫飘㷂蚖靯浏".toCharArray()[3] ^ 0x71F2);
    this.ˍᒄ = this.ʼᵖ ? ˍɫ$יς.J("寭䘃".toCharArray(), (short)22966, (short)0, (byte)0).intern() : ˍɫ$יς.J("寊ሣ襵䃡옫飘㷂蚖靯浏".toCharArray(), (short)15222, (short)2, (byte)3).intern();
    this.ʼᵖ = true;
    ﾟ();
    return this;
  }
  
  public final ـᘢ ˍɫ() {
    ۥ();
    "唲ﱃ庵냎?懩ᣠར".toCharArray()[2] = (char)("唲ﱃ庵냎?懩ᣠར".toCharArray()[2] ^ 0x7313);
    this.ˍᒄ = ᐨẏ$ᐝт.W("唲ﱃ庵냎?懩ᣠར".toCharArray(), (short)5913, (byte)3, (short)5).intern();
    ﾟ();
    return this;
  }
  
  public final ـᘢ ﾞл() {
    if (this.ˊᵃ) {
      "픿࿻".toCharArray()[1] = (char)("픿࿻".toCharArray()[1] ^ 0x3004);
      this.ˍᒄ = ˏȓ$ᴵЃ.E("픿࿻".toCharArray(), (short)11766, (short)3, (short)3).intern();
    } else {
      "辧౥刯Ḑ嚯៑倦".toCharArray()[8] = (char)("辧౥刯Ḑ嚯៑倦".toCharArray()[8] ^ 0x44BF);
      "￭ࡈ?谗ꜜ蘞졯ｳ㱁堢뒾甗俱".toCharArray()[5] = (char)("￭ࡈ?谗ꜜ蘞졯ｳ㱁堢뒾甗俱".toCharArray()[5] ^ 0x60A2);
      this.ˍᒄ = (this.ˊ != null) ? ˏȓ$ᴵЃ.E("辧౥刯Ḑ嚯៑倦".toCharArray(), (short)32079, (short)0, (short)0).intern() : ˏȓ$ᴵЃ.E("￭ࡈ?谗ꜜ蘞졯ｳ㱁堢뒾甗俱".toCharArray(), (short)15699, (short)5, (short)0).intern();
      this.ˊᵃ = true;
    } 
    ﾟ();
    return this;
  }
  
  public final ـᘢ ʹﮃ() {
    ۥ();
    if (this.ﾞǰ) {
      "簃锉匆".toCharArray()[0] = (char)("簃锉匆".toCharArray()[0] ^ 0x4525);
      this.ˊ.append(ᐝᵣ$ﾞﾇ.j("簃锉匆".toCharArray(), (short)21818, 0, (short)2).intern());
    } else {
      this.ˊ.append('(');
      this.ﾞǰ = true;
    } 
    ﾟ();
    return this;
  }
  
  public final ـᘢ ՙᗮ() {
    ۥ();
    if (this.ﾞǰ) {
      this.ﾞǰ = false;
    } else {
      this.ˊ.append('(');
    } 
    this.ˊ.append(')');
    this.ᴵʖ = new StringBuilder();
    return new ـᐱ(this.ᴵʖ);
  }
  
  public final ـᘢ ᴵʖ() {
    if (this.ﾞл == null) {
      this.ﾞл = new StringBuilder();
    } else {
      "᜞膮揦".toCharArray()[0] = (char)("᜞膮揦".toCharArray()[0] ^ 0x187C);
      this.ﾞл.append(ˉﻤ$ͺſ.v("᜞膮揦".toCharArray(), (short)7252, 5, (short)2).intern());
    } 
    return new ـᐱ(this.ﾞл);
  }
  
  public final void ᐨẏ(char paramChar) {
    String str;
    if ((str = ʾܪ.get(Character.valueOf(paramChar))) == null)
      throw new IllegalArgumentException(); 
    this.ˊ.append(str);
    Ӏ();
  }
  
  public final void ͺо(String paramString) {
    this.ˊ.append(this.ˍᒄ).append(paramString);
    this.ˍᒄ = "";
    Ӏ();
  }
  
  public final ـᘢ ᐨẏ() {
    ﾟ();
    this.ˏﭠ |= 0x1;
    return this;
  }
  
  public final void ʾܪ(String paramString) {
    "ꘀ⒝畢誏駪䀀猖고喯㈝ᕓ紿进筑炥".toCharArray()[6] = (char)("ꘀ⒝畢誏駪䀀猖고喯㈝ᕓ紿进筑炥".toCharArray()[6] ^ 0x23C8);
    if (ˍɫ$יς.J("ꘀ⒝畢誏駪䀀猖고喯㈝ᕓ紿进筑炥".toCharArray(), (short)22557, (short)0, (byte)3).equals(paramString)) {
      boolean bool;
      if (bool = (this.ˉม % 2 != 0 || this.ﾞǰ) ? true : false)
        this.ˊ.append(this.ˍᒄ).append(paramString.replace('/', '.')); 
    } else {
      this.ˊ.append(this.ˍᒄ).append(paramString.replace('/', '.'));
    } 
    this.ˍᒄ = "";
    this.ˉม <<= 1;
  }
  
  public final void ᐨم(String paramString) {
    if (this.ˉม % 2 != 0)
      this.ˊ.append('>'); 
    this.ˉม /= 2;
    this.ˊ.append('.');
    this.ˊ.append(this.ˍᒄ).append(paramString.replace('/', '.'));
    this.ˍᒄ = "";
    this.ˉม <<= 1;
  }
  
  public final void ʹл() {
    if (this.ˉม % 2 == 0) {
      this.ˉม++;
      this.ˊ.append('<');
    } else {
      "皌鐠䗣".toCharArray()[0] = (char)("皌鐠䗣".toCharArray()[0] ^ 0x17BF);
      this.ˊ.append(ᐝᵣ$ﾞﾇ.j("皌鐠䗣".toCharArray(), (short)2044, 4, (short)5).intern());
    } 
    this.ˊ.append('?');
  }
  
  public final ـᘢ ᐨẏ(char paramChar) {
    if (this.ˉม % 2 == 0) {
      this.ˉม++;
      this.ˊ.append('<');
    } else {
      "젠엋㊐".toCharArray()[0] = (char)("젠엋㊐".toCharArray()[0] ^ 0x36A8);
      this.ˊ.append(ᐝᵣ$ﾞﾇ.j("젠엋㊐".toCharArray(), (short)870, 4, (short)0).intern());
    } 
    if (paramChar == '+') {
      "厵糝릮謴?瘺ི榇秝腅エ".toCharArray()[3] = (char)("厵糝릮謴?瘺ི榇秝腅エ".toCharArray()[3] ^ 0x5FD);
      this.ˊ.append(ᐝᵣ$ﾞﾇ.j("厵糝릮謴?瘺ི榇秝腅エ".toCharArray(), (short)981, 2, (short)4));
    } else if (paramChar == '-') {
      "๮?剕ꙝ䛃䏽儝ຣ".toCharArray()[1] = (char)("๮?剕ꙝ䛃䏽儝ຣ".toCharArray()[1] ^ 0x518F);
      this.ˊ.append(ᐝᵣ$ﾞﾇ.j("๮?剕ꙝ䛃䏽儝ຣ".toCharArray(), (short)14431, 5, (short)2));
    } 
    ﾟ();
    return this;
  }
  
  public final void ᐨẏ() {
    if (this.ˉม % 2 != 0)
      this.ˊ.append('>'); 
    this.ˉม /= 2;
    Ӏ();
  }
  
  public final String ˍɫ() {
    return this.ˊ.toString();
  }
  
  public final String ʽ() {
    return (this.ᴵʖ == null) ? null : this.ᴵʖ.toString();
  }
  
  public final String ʾܪ() {
    return (this.ﾞл == null) ? null : this.ﾞл.toString();
  }
  
  private void ۥ() {
    if (this.ـﭔ) {
      this.ˊ.append('>');
      this.ـﭔ = false;
    } 
  }
  
  private void ﾟ() {
    this.ˏﭠ <<= 1;
  }
  
  private void Ӏ() {
    if (this.ˏﭠ % 2 == 0) {
      this.ˏﭠ /= 2;
      return;
    } 
    while (this.ˏﭠ % 2 != 0) {
      this.ˏﭠ /= 2;
      "寁씌䩲".toCharArray()[0] = (char)("寁씌䩲".toCharArray()[0] ^ 0x6647);
      this.ˊ.append(ˉﻤ$ͺſ.v("寁씌䩲".toCharArray(), (short)26627, 4, (short)3));
    } 
  }
  
  static {
    "떚⥨䟖".toCharArray()[0] = (char)("떚⥨䟖".toCharArray()[0] ^ 0x7996);
    ـɻ = ˏȓ$ᴵЃ.E("떚⥨䟖".toCharArray(), (short)18713, (short)0, (short)4).intern();
    "溓焤懐뎹黚㸑".toCharArray()[3] = (char)("溓焤懐뎹黚㸑".toCharArray()[3] ^ 0x5744);
    HashMap<Object, Object> hashMap;
    (hashMap = new HashMap<>()).put(Character.valueOf('Z'), ˏȓ$ᴵЃ.E("溓焤懐뎹黚㸑".toCharArray(), (short)9622, (short)4, (short)1));
    "抶ᱤ밼䋚".toCharArray()[0] = (char)("抶ᱤ밼䋚".toCharArray()[0] ^ 0x1631);
    hashMap.put(Character.valueOf('B'), ˏȓ$ᴵЃ.E("抶ᱤ밼䋚".toCharArray(), (short)24879, (short)0, (short)3));
    "蜒뇻鼓?作".toCharArray()[0] = (char)("蜒뇻鼓?作".toCharArray()[0] ^ 0x4E18);
    hashMap.put(Character.valueOf('C'), ˏȓ$ᴵЃ.E("蜒뇻鼓?作".toCharArray(), (short)22667, (short)5, (short)4));
    "㽼鐄搞ຼꁳ⍳".toCharArray()[0] = (char)("㽼鐄搞ຼꁳ⍳".toCharArray()[0] ^ 0x3C21);
    hashMap.put(Character.valueOf('S'), ˏȓ$ᴵЃ.E("㽼鐄搞ຼꁳ⍳".toCharArray(), (short)1363, (short)3, (short)1));
    "晏?뺡䱦".toCharArray()[0] = (char)("晏?뺡䱦".toCharArray()[0] ^ 0x2BE5);
    hashMap.put(Character.valueOf('I'), ˏȓ$ᴵЃ.E("晏?뺡䱦".toCharArray(), (short)32523, (short)2, (short)2));
    "軘풦䌷簦橘".toCharArray()[1] = (char)("軘풦䌷簦橘".toCharArray()[1] ^ 0x303D);
    hashMap.put(Character.valueOf('J'), ˏȓ$ᴵЃ.E("軘풦䌷簦橘".toCharArray(), (short)10288, (short)1, (short)3));
    "ᢙ䐄飴馺귥ⳝ".toCharArray()[1] = (char)("ᢙ䐄飴馺귥ⳝ".toCharArray()[1] ^ 0x6F72);
    hashMap.put(Character.valueOf('F'), ˏȓ$ᴵЃ.E("ᢙ䐄飴馺귥ⳝ".toCharArray(), (short)29895, (short)3, (short)1));
    "蛹샰堔䔵぀垦".toCharArray()[0] = (char)("蛹샰堔䔵぀垦".toCharArray()[0] ^ 0x601E);
    hashMap.put(Character.valueOf('D'), ˏȓ$ᴵЃ.E("蛹샰堔䔵぀垦".toCharArray(), (short)21171, (short)5, (short)0));
    "ⷷ㹾瑙䍦".toCharArray()[3] = (char)("ⷷ㹾瑙䍦".toCharArray()[3] ^ 0x739A);
    hashMap.put(Character.valueOf('V'), ˏȓ$ᴵЃ.E("ⷷ㹾瑙䍦".toCharArray(), (short)16089, (short)3, (short)1));
    ʾܪ = Collections.unmodifiableMap(hashMap);
  }
  
  static {
    "ᇵ浆ƾ폿初㉈蹱伱ᔬ".toCharArray()[8] = (char)("ᇵ浆ƾ폿初㉈蹱伱ᔬ".toCharArray()[8] ^ 0x4C50);
  }
  
  static {
    "붏ᐷ폘ꋖ拓?㯵⽍쨒؝毘⢝".toCharArray()[2] = (char)("붏ᐷ폘ꋖ拓?㯵⽍쨒؝毘⢝".toCharArray()[2] ^ 0xBA0);
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ـᐱ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */