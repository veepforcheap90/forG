package yyds.sniarbtej;

final class ιТ extends ˋץ {
  public final <T> T ᐨẏ(Class<T> paramClass) {
    "硁竚㤯湻ߪ鳭뉔㥽券ﲍ蛌캗櫊्ໜ͋Љ".toCharArray()[0] = (char)("硁竚㤯湻ߪ鳭뉔㥽券ﲍ蛌캗櫊्ໜ͋Љ".toCharArray()[0] ^ 0x7A40);
    throw new UnsupportedOperationException(ˏȓ$ᴵЃ.E("硁竚㤯湻ߪ鳭뉔㥽券ﲍ蛌캗櫊्ໜ͋Љ".toCharArray(), (short)27567, (short)2, (short)5) + paramClass);
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ιТ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */