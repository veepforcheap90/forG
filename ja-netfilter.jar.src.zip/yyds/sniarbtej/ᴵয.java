package yyds.sniarbtej;

public final class ᴵয extends ͺᔮ {
  public final String ᔪ() {
    "㊬ỏӹ䱕?ԝ튽郼憛瞷슱?雋ᙍ伭牼".toCharArray()[13] = (char)("㊬ỏӹ䱕?ԝ튽郼憛瞷슱?雋ᙍ伭牼".toCharArray()[13] ^ 0x1E4C);
    return ᐝᵣ$ﾞﾇ.j("㊬ỏӹ䱕?ԝ튽郼憛瞷슱?雋ᙍ伭牼".toCharArray(), (short)527, 4, (short)0);
  }
  
  public final byte[] ˍɫ(byte[] paramArrayOfbyte) {
    return ᐨẏ(paramArrayOfbyte, paramᐧє -> {
          "㦝ჿ⹯箳鷟뻣䪻9".toCharArray()[4] = (char)("㦝ჿ⹯箳鷟뻣䪻9".toCharArray()[4] ^ 0x48CF);
          "豜୪?茶蟍ϸ韌잀켎᤼㿌үɭ鐄붓波뉋裖Ꭰ".toCharArray()[1] = (char)("豜୪?茶蟍ϸ韌잀켎᤼㿌үɭ鐄붓波뉋裖Ꭰ".toCharArray()[1] ^ 0x24CE);
          if (ᐝᵣ$ﾞﾇ.j("㦝ჿ⹯箳鷟뻣䪻9".toCharArray(), (short)25437, 1, (short)0).equals(paramᐧє.name) && paramᐧє.ˎᴗ.startsWith(ᐝᵣ$ﾞﾇ.j("豜୪?茶蟍ϸ韌잀켎᤼㿌үɭ鐄붓波뉋裖Ꭰ".toCharArray(), (short)7889, 2, (short)1))) {
            ـс ـс;
            (ـс = new ـс()).ᐨẏ(new ᕁ(25, 0));
            "說塉楕".toCharArray()[1] = (char)("說塉楕".toCharArray()[1] ^ 0x591E);
            "弜?총뺅ꋥㄨ礢至郲蝏㹸삉잕‍햁㲁鴁莴쓌੷䦊ೋ".toCharArray()[13] = (char)("弜?총뺅ꋥㄨ礢至郲蝏㹸삉잕‍햁㲁鴁莴쓌੷䦊ೋ".toCharArray()[13] ^ 0x6D05);
            ـс.ᐨẏ(new ʾᔂ(184, ן, ᐝᵣ$ﾞﾇ.j("說塉楕".toCharArray(), (short)27662, 1, (short)1), ᐝᵣ$ﾞﾇ.j("弜?총뺅ꋥㄨ礢至郲蝏㹸삉잕‍햁㲁鴁莴쓌੷䦊ೋ".toCharArray(), (short)3218, 3, (short)5), false));
            paramᐧє.ˊ.ˊ(ـс);
          } 
        });
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ᴵয.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */