package yyds.sniarbtej;

import java.util.TreeSet;

final class ᐝᵛ implements ʿн<T> {
  ᐝᵛ(ˍʶ paramˍʶ) {}
  
  public final T ʿᵉ() {
    return (T)new TreeSet();
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ᐝᵛ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */