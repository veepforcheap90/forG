package yyds.sniarbtej;

public final class ٴᖟ extends ᴵƚ {
  private ᴵઽ ᐨẏ;
  
  private ٴᖟ(ᴵƚ paramᴵƚ, ᴵઽ paramᴵઽ) {
    this(589824, paramᴵƚ, paramᴵઽ);
  }
  
  protected ٴᖟ(int paramInt, ᴵƚ paramᴵƚ, ᴵઽ paramᴵઽ) {
    super(paramInt, paramᴵƚ);
    this.ᐨẏ = paramᴵઽ;
  }
  
  public final ᐨẏ ᐨẏ(String paramString, boolean paramBoolean) {
    ᐨẏ ᐨẏ;
    return ((ᐨẏ = super.ᐨẏ(this.ᐨẏ.ˊ(paramString), paramBoolean)) == null) ? null : ᐨẏ(paramString, ᐨẏ);
  }
  
  public final ᐨẏ ᐨẏ(int paramInt, ˏɪ paramˏɪ, String paramString, boolean paramBoolean) {
    ᐨẏ ᐨẏ;
    return ((ᐨẏ = super.ᐨẏ(paramInt, paramˏɪ, this.ᐨẏ.ˊ(paramString), paramBoolean)) == null) ? null : ᐨẏ(paramString, ᐨẏ);
  }
  
  @Deprecated
  private ᐨẏ ᐨẏ(ᐨẏ paramᐨẏ) {
    return new ʴ(this.ᐨẏ, null, paramᐨẏ, this.ᐨẏ);
  }
  
  private ᐨẏ ᐨẏ(String paramString, ᐨẏ paramᐨẏ) {
    return (new ʴ(this.ᐨẏ, paramString, paramᐨẏ, this.ᐨẏ)).ˊ(ᐨẏ(paramᐨẏ));
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ٴᖟ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */