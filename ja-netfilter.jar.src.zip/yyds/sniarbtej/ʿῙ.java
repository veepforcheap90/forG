package yyds.sniarbtej;

import ylt.pmn.zubdqvgt;

final class ʿῙ extends ٴۉ<Character> {
  private static Character ᐨẏ(יּ paramיּ) {
    if (zubdqvgt.G(paramיּ.ᐨẏ(), כ.ʽ)) {
      paramיּ.ۦ();
      return null;
    } 
    String str;
    if ((str = paramיּ.ٴӵ()).length() != 1) {
      "墺⯠Ĵḻ喁⊀⏂扠䱐⹦䲤娻켘㠵歒♇岷뱪巟읬妘뚓蒉㺟".toCharArray()[14] = (char)("墺⯠Ĵḻ喁⊀⏂扠䱐⹦䲤娻켘㠵歒♇岷뱪巟읬妘뚓蒉㺟".toCharArray()[14] ^ 0x6F7F);
      throw new ՙĩ(ˍɫ$יς.J("墺⯠Ĵḻ喁⊀⏂扠䱐⹦䲤娻켘㠵歒♇岷뱪巟읬妘뚓蒉㺟".toCharArray(), (short)8322, (short)3, (byte)2) + str);
    } 
    return Character.valueOf(str.charAt(0));
  }
  
  private static void ᐨẏ(Ⴡ paramჁ, Character paramCharacter) {
    paramჁ.ˊ((paramCharacter == null) ? null : String.valueOf(paramCharacter));
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ʿῙ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */