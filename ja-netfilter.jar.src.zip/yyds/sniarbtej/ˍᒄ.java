package yyds.sniarbtej;

import java.util.Map;

public final class ˍᒄ extends Ӏ {
  public String ˎᴗ;
  
  public int ỵ;
  
  public ˍᒄ(String paramString, int paramInt) {
    super(197);
    this.ˎᴗ = paramString;
    this.ỵ = paramInt;
  }
  
  public final int ﹳיִ() {
    return 13;
  }
  
  public final void ᐨẏ(ˉｓ paramˉｓ) {
    paramˉｓ.ˊ(this.ˎᴗ, this.ỵ);
    ˊ(paramˉｓ);
  }
  
  public final Ӏ ᐨẏ(Map<λ, λ> paramMap) {
    return (new ˍᒄ(this.ˎᴗ, this.ỵ)).ᐨẏ(this);
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ˍᒄ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */