package yyds.sniarbtej;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

final class ʼᓓ implements ʿн<T> {
  ʼᓓ(ˍʶ paramˍʶ, Constructor paramConstructor) {}
  
  public final T ʿᵉ() {
    try {
      Object[] arrayOfObject = null;
      return this.ᐨẏ.newInstance(arrayOfObject);
    } catch (InstantiationException instantiationException) {
      "豢釥啓幗黢憟ା萊觜穰?챾퓫ᙩ썴ǲ漯".toCharArray()[3] = (char)("豢釥啓幗黢憟ା萊觜穰?챾퓫ᙩ썴ǲ漯".toCharArray()[3] ^ 0x37C6);
      "굨遟裵?齐⹥㑙᥄퉏藼侳灶夣捩".toCharArray()[0] = (char)("굨遟裵?齐⹥㑙᥄퉏藼侳灶夣捩".toCharArray()[0] ^ 0x667B);
      throw new RuntimeException(ᐝᵣ$ﾞﾇ.j("豢釥啓幗黢憟ା萊觜穰?챾퓫ᙩ썴ǲ漯".toCharArray(), (short)19651, 4, (short)3) + this.ᐨẏ + ᐝᵣ$ﾞﾇ.j("굨遟裵?齐⹥㑙᥄퉏藼侳灶夣捩".toCharArray(), (short)12537, 2, (short)2), instantiationException);
    } catch (InvocationTargetException invocationTargetException) {
      "쭕튾匞캺傾ၳ쟔根ｗ䒸洲ݔ蝰㯓".toCharArray()[13] = (char)("쭕튾匞캺傾ၳ쟔根ｗ䒸洲ݔ蝰㯓".toCharArray()[13] ^ 0x1A59);
      "쑼텋쨷萇艫ྔ蝵놉䌵橇砅鲁秜".toCharArray()[9] = (char)("쑼텋쨷萇艫ྔ蝵놉䌵橇砅鲁秜".toCharArray()[9] ^ 0x1F31);
      throw new RuntimeException(ᐝᵣ$ﾞﾇ.j("쭕튾匞캺傾ၳ쟔根ｗ䒸洲ݔ蝰㯓".toCharArray(), (short)16107, 4, (short)4) + this.ᐨẏ + ᐝᵣ$ﾞﾇ.j("쑼텋쨷萇艫ྔ蝵놉䌵橇砅鲁秜".toCharArray(), (short)4466, 4, (short)3), invocationTargetException.getTargetException());
    } catch (IllegalAccessException illegalAccessException) {
      throw new AssertionError(illegalAccessException);
    } 
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ʼᓓ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */