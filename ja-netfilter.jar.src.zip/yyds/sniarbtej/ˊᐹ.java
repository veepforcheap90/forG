package yyds.sniarbtej;

import java.util.ConcurrentModificationException;
import java.util.Iterator;
import java.util.NoSuchElementException;
import ylt.pmn.zubdqvgt;

abstract class ˊᐹ<T> implements Iterator<T> {
  private ـᔭ<K, V> ﾞл = (ـᔭ<K, V>)((ـᔭ)this.ᐨẏ.ᐨẏ).ﾞл;
  
  private ـᔭ<K, V> ʿᵉ = null;
  
  private int יᵉ = this.ᐨẏ.יๆ;
  
  private ˊᐹ(ᐝᎫ paramᐝᎫ) {}
  
  public final boolean hasNext() {
    return !zubdqvgt.G(this.ﾞл, this.ᐨẏ.ᐨẏ);
  }
  
  final ـᔭ<K, V> ᴵʖ() {
    ـᔭ<K, V> ـᔭ1;
    if (zubdqvgt.G(ـᔭ1 = this.ﾞл, this.ᐨẏ.ᐨẏ))
      throw new NoSuchElementException(); 
    if (this.ᐨẏ.יๆ != this.יᵉ)
      throw new ConcurrentModificationException(); 
    this.ﾞл = (ـᔭ<K, V>)ـᔭ1.ﾞл;
    return this.ʿᵉ = ـᔭ1;
  }
  
  public final void remove() {
    if (this.ʿᵉ == null)
      throw new IllegalStateException(); 
    this.ᐨẏ.ᐨẏ(this.ʿᵉ, true);
    this.ʿᵉ = null;
    this.יᵉ = this.ᐨẏ.יๆ;
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ˊᐹ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */