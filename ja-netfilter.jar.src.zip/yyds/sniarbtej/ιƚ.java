package yyds.sniarbtej;

public final class ιƚ extends Exception {
  private static final long ᐨẏ = 3154190448018943333L;
  
  public final transient Ӏ ʹﮃ;
  
  public ιƚ(Ӏ paramӀ, String paramString) {
    super(paramString);
    this.ʹﮃ = paramӀ;
  }
  
  public ιƚ(Ӏ paramӀ, String paramString, Throwable paramThrowable) {
    super(paramString, paramThrowable);
    this.ʹﮃ = paramӀ;
  }
  
  public ιƚ(Ӏ paramӀ, String paramString, Object paramObject, ן paramן) {
    super(((paramString == null) ? ˏȓ$ᴵЃ.E("劽耩싖㈸᪀?ｖ￢0篢".toCharArray(), (short)10217, (short)0, (short)2) : (paramString + ˏȓ$ᴵЃ.E("ᔋ毴ꉾꖐℨ茯養 紕껎ẫ是".toCharArray(), (short)28528, (short)5, (short)4))) + paramObject + ˏȓ$ᴵЃ.E("汔ウ姺⇺ൢ䧁쉆酂ᒇ翢油".toCharArray(), (short)6514, (short)5, (short)4) + paramן);
    this.ʹﮃ = paramӀ;
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ιƚ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */