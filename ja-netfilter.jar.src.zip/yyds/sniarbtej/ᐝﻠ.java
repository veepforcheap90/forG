package yyds.sniarbtej;

public final class ᐝﻠ extends Exception {
  private static final long ᐨẏ = 1L;
  
  public ᐝﻠ() {}
  
  public ᐝﻠ(String paramString) {
    super(paramString);
  }
  
  private ᐝﻠ(String paramString, Throwable paramThrowable) {
    super(paramString, paramThrowable);
  }
  
  private ᐝﻠ(Throwable paramThrowable) {
    super(paramThrowable);
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ᐝﻠ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */