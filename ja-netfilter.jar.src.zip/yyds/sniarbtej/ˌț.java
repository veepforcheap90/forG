package yyds.sniarbtej;

import java.util.Arrays;
import java.util.List;

public class ˌț {
  private static boolean ˌᔹ = true;
  
  public λ ᴵʖ;
  
  public λ ﾞл;
  
  public λ ʹﮃ;
  
  public String ᐨẏ;
  
  public List<ʽ冫> ˍɫ;
  
  public List<ʽ冫> ʽ;
  
  public ˌț() {}
  
  private static void ʻล(String paramString) {
    System.out.println(paramString);
  }
  
  private static void ˊ(String paramString, Object paramObject) {
    ᐨẏ(paramString, paramObject, -1);
  }
  
  private static void ᐨẏ(String paramString, Object paramObject, int paramInt) {
    try {
      if (paramObject != null) {
        String str1 = paramObject.getClass().getName();
        "ኡ๚".toCharArray()[0] = (char)("ኡ๚".toCharArray()[0] ^ 0x21FF);
        "彟䂂".toCharArray()[0] = (char)("彟䂂".toCharArray()[0] ^ 0x138B);
        String str2 = paramString + ᐝᵣ$ﾞﾇ.j("ኡ๚".toCharArray(), (short)5826, 0, (short)4) + paramInt + ᐝᵣ$ﾞﾇ.j("彟䂂".toCharArray(), (short)13414, 3, (short)0);
        if (paramInt == -1)
          str2 = paramString; 
        paramString = paramObject.toString();
        if (paramObject instanceof Object[]) {
          ᐨẏ(str2, (Object[])paramObject);
          return;
        } 
        if (paramObject instanceof char[]) {
          str1 = Arrays.toString((char[])paramObject);
        } else if (paramObject instanceof byte[]) {
          "ࠩ㑡".toCharArray()[0] = (char)("ࠩ㑡".toCharArray()[0] ^ 0x6E31);
          str1 = ᐝᵣ$ﾞﾇ.j("ࠩ㑡".toCharArray(), (short)498, 3, (short)4) + Arrays.toString((byte[])paramObject);
        } else if (paramObject instanceof int[]) {
          "ꉑ庤".toCharArray()[0] = (char)("ꉑ庤".toCharArray()[0] ^ 0x4250);
          str1 = ᐝᵣ$ﾞﾇ.j("ꉑ庤".toCharArray(), (short)9761, 1, (short)3) + Arrays.toString((int[])paramObject);
        } else if (paramObject instanceof long[]) {
          "퓃悉".toCharArray()[0] = (char)("퓃悉".toCharArray()[0] ^ 0x1527);
          str1 = ᐝᵣ$ﾞﾇ.j("퓃悉".toCharArray(), (short)8298, 4, (short)1) + Arrays.toString((long[])paramObject);
        } else if (paramObject instanceof boolean[]) {
          "圇⥅".toCharArray()[0] = (char)("圇⥅".toCharArray()[0] ^ 0x538F);
          str1 = ᐝᵣ$ﾞﾇ.j("圇⥅".toCharArray(), (short)8409, 1, (short)5) + Arrays.toString((boolean[])paramObject);
        } else if (paramObject instanceof double[]) {
          "灃㰩".toCharArray()[0] = (char)("灃㰩".toCharArray()[0] ^ 0x304);
          str1 = ᐝᵣ$ﾞﾇ.j("灃㰩".toCharArray(), (short)18547, 1, (short)1) + Arrays.toString((double[])paramObject);
        } else if (paramObject instanceof float[]) {
          "㒽".toCharArray()[0] = (char)("㒽".toCharArray()[0] ^ 0x769);
          str1 = ᐝᵣ$ﾞﾇ.j("㒽".toCharArray(), (short)233, 1, (short)4) + Arrays.toString((float[])paramObject);
        } 
        "ᙰ澠".toCharArray()[0] = (char)("ᙰ澠".toCharArray()[0] ^ 0x1CB7);
        "ॐ竵".toCharArray()[0] = (char)("ॐ竵".toCharArray()[0] ^ 0x5944);
        "螑ᐁ".toCharArray()[0] = (char)("螑ᐁ".toCharArray()[0] ^ 0x2493);
        paramString = str2 + ᐝᵣ$ﾞﾇ.j("ᙰ澠".toCharArray(), (short)25600, 1, (short)4) + paramString + ᐝᵣ$ﾞﾇ.j("ॐ竵".toCharArray(), (short)25042, 0, (short)2) + str1 + ᐝᵣ$ﾞﾇ.j("螑ᐁ".toCharArray(), (short)7358, 2, (short)0);
        System.out.println(paramString);
      } else {
        "鴜怨ꇰّᾝ杍ﻸ䍩".toCharArray()[7] = (char)("鴜怨ꇰّᾝ杍ﻸ䍩".toCharArray()[7] ^ 0x6BD1);
        paramString = paramString + ᐝᵣ$ﾞﾇ.j("鴜怨ꇰّᾝ杍ﻸ䍩".toCharArray(), (short)31767, 2, (short)0);
        System.out.println(paramString);
        return;
      } 
    } catch (Throwable throwable2) {
      Throwable throwable1;
      (throwable1 = null).printStackTrace();
    } 
  }
  
  private static void ᐨẏ(String paramString, Object[] paramArrayOfObject) {
    if (paramArrayOfObject == null) {
      "錡꣄잩ꐾ䞟즙ꮍ貰讒൤⦼躌೭䋿?ˡ".toCharArray()[2] = (char)("錡꣄잩ꐾ䞟즙ꮍ貰讒൤⦼躌೭䋿?ˡ".toCharArray()[2] ^ 0x357C);
      paramString = paramString + ᐝᵣ$ﾞﾇ.j("錡꣄잩ꐾ䞟즙ꮍ貰讒൤⦼躌೭䋿?ˡ".toCharArray(), (short)25566, 3, (short)2) + paramArrayOfObject;
      System.out.println(paramString);
      return;
    } 
    if (paramArrayOfObject.length == 0) {
      "ᰕ㈔킩髯䳮ጐ㵦鑤鿮ૉൖ裞탈缉흔Ὁ렯ℯ鱸嫀ѫ".toCharArray()[17] = (char)("ᰕ㈔킩髯䳮ጐ㵦鑤鿮ૉൖ裞탈缉흔Ὁ렯ℯ鱸嫀ѫ".toCharArray()[17] ^ 0x59A2);
      paramString = paramString + ᐝᵣ$ﾞﾇ.j("ᰕ㈔킩髯䳮ጐ㵦鑤鿮ૉൖ裞탈缉흔Ὁ렯ℯ鱸嫀ѫ".toCharArray(), (short)7427, 5, (short)0) + paramArrayOfObject;
      System.out.println(paramString);
      return;
    } 
    for (byte b = 0; b < paramArrayOfObject.length; b++)
      ᐨẏ(paramString, paramArrayOfObject[b], b); 
  }
  
  private static void ˈے(String paramString) {
    StackTraceElement[] arrayOfStackTraceElement = Thread.currentThread().getStackTrace();
    byte b = 2;
    int i;
    if ((i = arrayOfStackTraceElement.length) > 20)
      i = 20; 
    if (i < 2)
      b = 0; 
    for (b = b; b < i; b++) {
      "ള蚀羟션艇편껥ꊁ菿웅菑䊵ᵼ".toCharArray()[7] = (char)("ള蚀羟션艇편껥ꊁ菿웅菑䊵ᵼ".toCharArray()[7] ^ 0xF35);
      "ꦈ㿚".toCharArray()[0] = (char)("ꦈ㿚".toCharArray()[0] ^ 0x2424);
      String str = paramString + ᐝᵣ$ﾞﾇ.j("ള蚀羟션艇편껥ꊁ菿웅菑䊵ᵼ".toCharArray(), (short)5273, 3, (short)0) + b + ᐝᵣ$ﾞﾇ.j("ꦈ㿚".toCharArray(), (short)23952, 4, (short)3) + arrayOfStackTraceElement[b];
      System.out.println(str);
    } 
  }
  
  public ˌț(λ paramλ1, λ paramλ2, λ paramλ3, String paramString) {
    this.ᴵʖ = paramλ1;
    this.ﾞл = paramλ2;
    this.ʹﮃ = paramλ3;
    this.ᐨẏ = paramString;
  }
  
  public void ᴵƚ(int paramInt) {
    paramInt = 0x42000000 | paramInt << 8;
    if (this.ˍɫ != null) {
      byte b = 0;
      int i = this.ˍɫ.size();
      while (b < i) {
        ((ʽ冫)this.ˍɫ.get(b)).ٱ = paramInt;
        b++;
      } 
    } 
    if (this.ʽ != null) {
      byte b = 0;
      int i = this.ʽ.size();
      while (b < i) {
        ((ʽ冫)this.ʽ.get(b)).ٱ = paramInt;
        b++;
      } 
    } 
  }
  
  public void ᐨẏ(ˉｓ paramˉｓ) {
    paramˉｓ.ᐨẏ(this.ᴵʖ.ﾞл(), this.ﾞл.ﾞл(), (this.ʹﮃ == null) ? null : this.ʹﮃ.ﾞл(), this.ᐨẏ);
    if (this.ˍɫ != null) {
      byte b = 0;
      int i = this.ˍɫ.size();
      while (b < i) {
        ʽ冫 ʽ冫;
        (ʽ冫 = this.ˍɫ.get(b)).ᐨẏ(paramˉｓ.ᴵʖ(ʽ冫.ٱ, ʽ冫.ˊ, ʽ冫.ˎᴗ, true));
        b++;
      } 
    } 
    if (this.ʽ != null) {
      byte b = 0;
      int i = this.ʽ.size();
      while (b < i) {
        ʽ冫 ʽ冫;
        (ʽ冫 = this.ʽ.get(b)).ᐨẏ(paramˉｓ.ᴵʖ(ʽ冫.ٱ, ʽ冫.ˊ, ʽ冫.ˎᴗ, false));
        b++;
      } 
    } 
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ˌț.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */