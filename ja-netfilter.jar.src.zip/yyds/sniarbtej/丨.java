package yyds.sniarbtej;

import java.net.URL;
import ylt.pmn.zubdqvgt;

final class 丨 extends ٴۉ<URL> {
  private static URL ᐨẏ(יּ paramיּ) {
    if (zubdqvgt.G(paramיּ.ᐨẏ(), כ.ʽ)) {
      paramיּ.ۦ();
      return null;
    } 
    String str = paramיּ.ٴӵ();
    "㽹慚᭞ꮯ䦐".toCharArray()[2] = (char)("㽹慚᭞ꮯ䦐".toCharArray()[2] ^ 0x515A);
    return ˉﻤ$ͺſ.v("㽹慚᭞ꮯ䦐".toCharArray(), (short)32658, 3, (short)4).equals(str) ? null : new URL(str);
  }
  
  private static void ᐨẏ(Ⴡ paramჁ, URL paramURL) {
    paramჁ.ˊ((paramURL == null) ? null : paramURL.toExternalForm());
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\丨.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */