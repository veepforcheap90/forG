package yyds.sniarbtej;

public final class ˈח extends RuntimeException {
  private static final long ᐨẏ = -3502347765891805831L;
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ˈח.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */