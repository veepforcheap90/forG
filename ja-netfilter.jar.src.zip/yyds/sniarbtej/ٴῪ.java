package yyds.sniarbtej;

import java.util.concurrent.ConcurrentHashMap;

final class ٴῪ implements ʿн<T> {
  ٴῪ(ˍʶ paramˍʶ) {}
  
  public final T ʿᵉ() {
    return (T)new ConcurrentHashMap<>();
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ٴῪ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */