package yyds.sniarbtej;

public final class ᴵϛ extends ͺᔮ {
  public final String ᔪ() {
    "⅞爫댨맷⯅鬇跙ࢹ鎶㑏昆꼚ʹᎁ㢕你≭驩烧렛눘丝ﯜ鬎藑䨈".toCharArray()[26] = (char)("⅞爫댨맷⯅鬇跙ࢹ鎶㑏昆꼚ʹᎁ㢕你≭驩烧렛눘丝ﯜ鬎藑䨈".toCharArray()[26] ^ 0x37D9);
    return ᐝᵣ$ﾞﾇ.j("⅞爫댨맷⯅鬇跙ࢹ鎶㑏昆꼚ʹᎁ㢕你≭驩烧렛눘丝ﯜ鬎藑䨈".toCharArray(), (short)6367, 4, (short)4);
  }
  
  public final byte[] ˍɫ(byte[] paramArrayOfbyte) {
    return ᐨẏ(paramArrayOfbyte, paramᐧє -> {
          "ﻑꋊ䐮ㆇ?ꚦ퐿石爢嶞".toCharArray()[9] = (char)("ﻑꋊ䐮ㆇ?ꚦ퐿石爢嶞".toCharArray()[9] ^ 0x336C);
          "䥀脂졡檉".toCharArray()[0] = (char)("䥀脂졡檉".toCharArray()[0] ^ 0x2F16);
          if (ᐨẏ$ᐝт.W("ﻑꋊ䐮ㆇ?ꚦ퐿石爢嶞".toCharArray(), (short)23462, (byte)5, (short)0).equals(paramᐧє.name) && ᐨẏ$ᐝт.W("䥀脂졡檉".toCharArray(), (short)29756, (byte)3, (short)4).equals(paramᐧє.ˎᴗ)) {
            ـс ـс;
            (ـс = new ـс()).ᐨẏ(new ᕁ(25, 0));
            "뛧௤嬵蒂ᦪ怎ᇈ䠇럎뿳瑵⻋ի᛻쑗尿킮깜ᅘ?곺㹼閿?瘥".toCharArray()[25] = (char)("뛧௤嬵蒂ᦪ怎ᇈ䠇럎뿳瑵⻋ի᛻쑗尿킮깜ᅘ?곺㹼閿?瘥".toCharArray()[25] ^ 0x7EC9);
            "둇術幤㞹".toCharArray()[1] = (char)("둇術幤㞹".toCharArray()[1] ^ 0x78E4);
            "㻍剹⑰િ㹶᢫털좋⅜ﲞ聠큃曽?⢇".toCharArray()[5] = (char)("㻍剹⑰િ㹶᢫털좋⅜ﲞ聠큃曽?⢇".toCharArray()[5] ^ 0x4581);
            ـс.ᐨẏ(new ˑܥ(180, ᐨẏ$ᐝт.W("뛧௤嬵蒂ᦪ怎ᇈ䠇럎뿳瑵⻋ի᛻쑗尿킮깜ᅘ?곺㹼閿?瘥".toCharArray(), (short)2026, (byte)1, (short)2), ᐨẏ$ᐝт.W("둇術幤㞹".toCharArray(), (short)3241, (byte)5, (short)2), ᐨẏ$ᐝт.W("㻍剹⑰િ㹶᢫털좋⅜ﲞ聠큃曽?⢇".toCharArray(), (short)5208, (byte)3, (short)1)));
            "⥎ᴸ".toCharArray()[1] = (char)("⥎ᴸ".toCharArray()[1] ^ 0x292F);
            "흷ஞ첤岴듐ᑿ៓纁㚈Ꮕ齢厙半碩鑋믝ｬョ粪绎벚窜覶묱开༼毥".toCharArray()[1] = (char)("흷ஞ첤岴듐ᑿ៓纁㚈Ꮕ齢厙半碩鑋믝ｬョ粪绎벚窜覶묱开༼毥".toCharArray()[1] ^ 0x209);
            ـс.ᐨẏ(new ʾᔂ(184, ן, ᐨẏ$ᐝт.W("⥎ᴸ".toCharArray(), (short)24004, (byte)3, (short)0), ᐨẏ$ᐝт.W("흷ஞ첤岴듐ᑿ៓纁㚈Ꮕ齢厙半碩鑋믝ｬョ粪绎벚窜覶묱开༼毥".toCharArray(), (short)644, (byte)4, (short)3), false));
            ـс.ᐨẏ(new ˏﾚ(87));
            paramᐧє.ˊ.ˊ(ـс);
          } 
        });
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ᴵϛ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */