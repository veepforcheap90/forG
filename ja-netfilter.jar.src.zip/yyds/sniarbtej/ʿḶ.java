package yyds.sniarbtej;

import java.util.Map;

public final class ʿḶ extends Ӏ {
  public int ᐨป;
  
  public ʿḶ(int paramInt1, int paramInt2) {
    super(paramInt1);
    this.ᐨป = paramInt2;
  }
  
  private void ٴӵ(int paramInt) {
    this.ՙঘ = paramInt;
  }
  
  public final int ﹳיִ() {
    return 1;
  }
  
  public final void ᐨẏ(ˉｓ paramˉｓ) {
    paramˉｓ.ˊ(this.ՙঘ, this.ᐨป);
    ˊ(paramˉｓ);
  }
  
  public final Ӏ ᐨẏ(Map<λ, λ> paramMap) {
    return (new ʿḶ(this.ՙঘ, this.ᐨป)).ᐨẏ(this);
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ʿḶ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */