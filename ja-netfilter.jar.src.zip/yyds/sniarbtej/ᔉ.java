package yyds.sniarbtej;

import java.util.Map;

public final class ᔉ extends Ӏ {
  public String ˎᴗ;
  
  public ᔉ(int paramInt, String paramString) {
    super(paramInt);
    this.ˎᴗ = paramString;
  }
  
  private void ٴӵ(int paramInt) {
    this.ՙঘ = paramInt;
  }
  
  public final int ﹳיִ() {
    return 3;
  }
  
  public final void ᐨẏ(ˉｓ paramˉｓ) {
    paramˉｓ.ᐨẏ(this.ՙঘ, this.ˎᴗ);
    ˊ(paramˉｓ);
  }
  
  public final Ӏ ᐨẏ(Map<λ, λ> paramMap) {
    return (new ᔉ(this.ՙঘ, this.ˎᴗ)).ᐨẏ(this);
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ᔉ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */