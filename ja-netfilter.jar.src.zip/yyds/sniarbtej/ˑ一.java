package yyds.sniarbtej;

import java.nio.charset.Charset;

public final class ˑ一 {
  public static final Charset ᐨẏ = Charset.forName(ˏȓ$ᴵЃ.E("ᾂ땫Ḝᑢ텠궑퇑敿".toCharArray(), (short)9147, (short)5, (short)1));
  
  public static final Charset ˊ = Charset.forName(ˏȓ$ᴵЃ.E("﷋奕탁䩹璌䢴甀琸".toCharArray(), (short)9638, (short)1, (short)4));
  
  public static final Charset ᴵʖ = Charset.forName(ˏȓ$ᴵЃ.E("馺㫄샢趚뉝闇眜".toCharArray(), (short)15346, (short)4, (short)5));
  
  public static final Charset ﾞл = Charset.forName(ˏȓ$ᴵЃ.E("ﭜᦝ裋䶄끎讌⦺ᰑ".toCharArray(), (short)25676, (short)3, (short)5));
  
  public static final Charset ʿᵉ = Charset.forName(ˏȓ$ᴵЃ.E("↱鍞荰ᕫ憔쟝?氤".toCharArray(), (short)1312, (short)3, (short)4));
  
  public static final Charset ʹﮃ = Charset.forName(ˏȓ$ᴵЃ.E("姍藫餧參䥇ǃ".toCharArray(), (short)30209, (short)2, (short)0));
  
  private static Charset ᐨẏ(Charset paramCharset) {
    return (paramCharset == null) ? Charset.defaultCharset() : paramCharset;
  }
  
  private static Charset ᐨẏ(String paramString) {
    return (paramString == null) ? Charset.defaultCharset() : Charset.forName(paramString);
  }
  
  static {
    "ᾂ땫Ḝᑢ텠궑퇑敿".toCharArray()[8] = (char)("ᾂ땫Ḝᑢ텠궑퇑敿".toCharArray()[8] ^ 0x304C);
  }
  
  static {
    "﷋奕탁䩹璌䢴甀琸".toCharArray()[5] = (char)("﷋奕탁䩹璌䢴甀琸".toCharArray()[5] ^ 0x4027);
  }
  
  static {
    "馺㫄샢趚뉝闇眜".toCharArray()[3] = (char)("馺㫄샢趚뉝闇眜".toCharArray()[3] ^ 0x7C3F);
  }
  
  static {
    "ﭜᦝ裋䶄끎讌⦺ᰑ".toCharArray()[5] = (char)("ﭜᦝ裋䶄끎讌⦺ᰑ".toCharArray()[5] ^ 0x3DC0);
  }
  
  static {
    "↱鍞荰ᕫ憔쟝?氤".toCharArray()[7] = (char)("↱鍞荰ᕫ憔쟝?氤".toCharArray()[7] ^ 0x1AD9);
  }
  
  static {
    "姍藫餧參䥇ǃ".toCharArray()[2] = (char)("姍藫餧參䥇ǃ".toCharArray()[2] ^ 0x6A22);
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ˑ一.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */