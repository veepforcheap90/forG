package yyds.sniarbtej;

import java.util.concurrent.atomic.AtomicInteger;

final class ـﾌ extends ٴۉ<AtomicInteger> {
  private static AtomicInteger ᐨẏ(יּ paramיּ) {
    try {
      return new AtomicInteger(paramיּ.ˊɼ());
    } catch (NumberFormatException numberFormatException) {
      throw new ՙĩ(numberFormatException);
    } 
  }
  
  private static void ᐨẏ(Ⴡ paramჁ, AtomicInteger paramAtomicInteger) {
    paramჁ.ᐨẏ(paramAtomicInteger.get());
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ـﾌ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */