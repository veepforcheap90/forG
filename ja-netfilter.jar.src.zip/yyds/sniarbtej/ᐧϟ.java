package yyds.sniarbtej;

import java.lang.reflect.Type;

final class ᐧϟ implements ˑﮊ {
  ᐧϟ(ˑĴ paramˑĴ) {}
  
  public final ᐧｴ ˊ(Object paramObject) {
    Object object = paramObject;
    paramObject = this.ᐨẏ;
    return (object == null) ? ڊ.ᐨẏ : paramObject.ᐨẏ(object, object.getClass());
  }
  
  public final ᐧｴ ˊ(Object paramObject, Type paramType) {
    return this.ᐨẏ.ᐨẏ(paramObject, paramType);
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ᐧϟ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */