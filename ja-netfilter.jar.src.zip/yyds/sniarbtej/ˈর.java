package yyds.sniarbtej;

import ylt.pmn.zubdqvgt;

final class ˈর extends ٴۉ<Number> {
  private static Number ᐨẏ(יּ paramיּ) {
    if (zubdqvgt.G(paramיּ.ᐨẏ(), כ.ʽ)) {
      paramיּ.ۦ();
      return null;
    } 
    return Float.valueOf((float)paramיּ.ᴵʖ());
  }
  
  private static void ᐨẏ(Ⴡ paramჁ, Number paramNumber) {
    paramჁ.ᐨẏ(paramNumber);
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ˈর.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */