package yyds.sniarbtej;

public abstract class ᐨẏ {
  protected final int ᐨẏ;
  
  protected ᐨẏ ᐨẏ;
  
  public ᐨẏ(int paramInt) {
    this(paramInt, null);
  }
  
  public ᐨẏ(int paramInt, ᐨẏ paramᐨẏ) {
    if (paramInt != 589824 && paramInt != 524288 && paramInt != 458752 && paramInt != 393216 && paramInt != 327680 && paramInt != 262144 && paramInt != 17432576) {
      "Ꮥ蔹鱾謄웲꫼䝪⑴縹ꨯ㓁ఏ₦".toCharArray()[0] = (char)("Ꮥ蔹鱾謄웲꫼䝪⑴縹ꨯ㓁ఏ₦".toCharArray()[0] ^ 0x133);
      throw new IllegalArgumentException(ˉﻤ$ͺſ.v("Ꮥ蔹鱾謄웲꫼䝪⑴縹ꨯ㓁ఏ₦".toCharArray(), (short)2207, 2, (short)5) + paramInt);
    } 
    if (paramInt == 17432576)
      ᐨم.ᐨẏ(this); 
    this.ᐨẏ = paramInt;
    this.ᐨẏ = paramᐨẏ;
  }
  
  private ᐨẏ ᐨẏ() {
    return this.ᐨẏ;
  }
  
  public void ᐨẏ(String paramString, Object paramObject) {
    if (this.ᐨẏ != null)
      this.ᐨẏ.ᐨẏ(paramString, paramObject); 
  }
  
  public void ᐨẏ(String paramString1, String paramString2, String paramString3) {
    if (this.ᐨẏ != null)
      this.ᐨẏ.ᐨẏ(paramString1, paramString2, paramString3); 
  }
  
  public ᐨẏ ᐨẏ(String paramString1, String paramString2) {
    return (this.ᐨẏ != null) ? this.ᐨẏ.ᐨẏ(paramString1, paramString2) : null;
  }
  
  public ᐨẏ ᐨẏ(String paramString) {
    return (this.ᐨẏ != null) ? this.ᐨẏ.ᐨẏ(paramString) : null;
  }
  
  public void ᐨẏ() {
    if (this.ᐨẏ != null)
      this.ᐨẏ.ᐨẏ(); 
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ᐨẏ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */