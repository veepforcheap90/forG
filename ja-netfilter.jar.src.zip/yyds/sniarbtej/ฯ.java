package yyds.sniarbtej;

import java.io.Writer;

final class ฯ extends Writer {
  public final void write(char[] paramArrayOfchar, int paramInt1, int paramInt2) {
    throw new AssertionError();
  }
  
  public final void flush() {
    throw new AssertionError();
  }
  
  public final void close() {
    throw new AssertionError();
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ฯ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */