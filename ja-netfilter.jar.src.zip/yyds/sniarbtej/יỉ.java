package yyds.sniarbtej;

import java.lang.reflect.Type;

public interface יỉ<T> {
  ᐧｴ ᐨẏ(T paramT, Type paramType, ˑﮊ paramˑﮊ);
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\יỉ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */