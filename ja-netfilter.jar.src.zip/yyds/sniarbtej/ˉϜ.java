package yyds.sniarbtej;

import ylt.pmn.zubdqvgt;

final class ˉϜ implements ˌ々 {
  public final <T> ٴۉ<T> ᐨẏ(ˑĴ paramˑĴ, ʸ<T> paramʸ) {
    return zubdqvgt.G((paramʸ = paramʸ).ᐨم, Object.class) ? new ˈﺬ(paramˑĴ, (byte)0) : null;
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ˉϜ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */