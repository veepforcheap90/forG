package yyds.sniarbtej;

import java.io.Reader;

final class ͺใ extends Reader {
  public final int read(char[] paramArrayOfchar, int paramInt1, int paramInt2) {
    throw new AssertionError();
  }
  
  public final void close() {
    throw new AssertionError();
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ͺใ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */