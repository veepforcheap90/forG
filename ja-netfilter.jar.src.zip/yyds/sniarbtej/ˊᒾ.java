package yyds.sniarbtej;

import java.sql.Date;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import ylt.pmn.zubdqvgt;

public final class ˊᒾ extends ٴۉ<Date> {
  private static ˌ々 ˊ;
  
  private final DateFormat ᴵʖ;
  
  public ˊᒾ() {
    "﮿띟퍘榔拁ם擎ꚿ䍱刭Γ".toCharArray()[8] = (char)("﮿띟퍘榔拁ם擎ꚿ䍱刭Γ".toCharArray()[8] ^ 0x3869);
    this.ᴵʖ = new SimpleDateFormat(ˉﻤ$ͺſ.v("﮿띟퍘榔拁ם擎ꚿ䍱刭Γ".toCharArray(), (short)12400, 5, (short)5));
  }
  
  private synchronized Date ᐨẏ(יּ paramיּ) {
    if (zubdqvgt.G(paramיּ.ᐨẏ(), כ.ʽ)) {
      paramיּ.ۦ();
      return null;
    } 
    try {
      long l = this.ᴵʖ.parse(paramיּ.ٴӵ()).getTime();
      return new Date(l);
    } catch (ParseException parseException) {
      throw new ՙĩ(parseException);
    } 
  }
  
  private synchronized void ᐨẏ(Ⴡ paramჁ, Date paramDate) {
    paramჁ.ˊ((paramDate == null) ? null : this.ᴵʖ.format(paramDate));
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ˊᒾ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */