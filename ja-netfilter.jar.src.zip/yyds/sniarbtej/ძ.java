package yyds.sniarbtej;

import java.io.PrintWriter;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import ylt.pmn.zubdqvgt;

public class ძ extends ᐨᘂ {
  private static final String ʾא = ˏȓ$ᴵЃ.E("담ⳍ袸侯缂댺챬拵黧驙䈰᪊綣憵蟍〈顰횮됗假셟징蚭៊蘌晬鬄䈾孔쳾䂹섄㊝绾殘ﭘ阫䞮?ࠈ䀬봼辬ᅋ경삐휿㮘쐾㭏ଖ苾◦ꄲ쿆賮Ղ쪢驞ȶூ෭衬퀗麙侚鎨㽄捫淮⯢叹㱊䢉컵裚ꢴ瓺⫵洶骀器큦금璄∝쯤?蕏숩ङ칞㛋管ᙗ䍼ᚊ헡菙ᄔﭱ氳渟ܵ靣Ỏ餗↳೶".toCharArray(), (short)10162, (short)2, (short)2).intern();
  
  private static int ـＩ = 0;
  
  private static int ٴЇ = 1;
  
  private static int ͺᵋ = 2;
  
  private static int ᔂ = 3;
  
  private static int ᐨʷ = 4;
  
  private static int ʽŸ = 5;
  
  private static int ͺﾗ = 9;
  
  private static final String ﹳڐ = ˏȓ$ᴵЃ.E("㼬鲸큅ᯪ众⶯ᒨ".toCharArray(), (short)7774, (short)2, (short)1).intern();
  
  private static final String ˍ;
  
  private static final String ˑܘ;
  
  private static final String ʾᔂ = ˏȓ$ᴵЃ.E("齏ܣ鲘鞏瓣߁텐䶼侪婛럣襗㵈矎៬".toCharArray(), (short)23827, (short)2, (short)5).intern();
  
  private static final List<String> ٴᖟ;
  
  private String ᐧє;
  
  private String ʹˉ;
  
  private String ٴḷ;
  
  private String ٴﾗ;
  
  private Map<ᔪ, String> ˍɫ;
  
  private int ᒬ;
  
  private int ﹳঽ;
  
  public ძ() {
    this(589824);
    if (!zubdqvgt.G(getClass(), ძ.class))
      throw new IllegalStateException(); 
  }
  
  private ძ(int paramInt) {
    super(paramInt);
    "晾Ƿ㲘".toCharArray()[1] = (char)("晾Ƿ㲘".toCharArray()[1] ^ 0x2CF1);
    this.ᐧє = ᐨẏ$ᐝт.W("晾Ƿ㲘".toCharArray(), (short)7429, (byte)1, (short)1);
    "鍪ឮΝ蟝獒".toCharArray()[0] = (char)("鍪ឮΝ蟝獒".toCharArray()[0] ^ 0x24E2);
    this.ʹˉ = ᐨẏ$ᐝт.W("鍪ឮΝ蟝獒".toCharArray(), (short)30943, (byte)3, (short)0);
    "趔徚䚉튮囫拭".toCharArray()[3] = (char)("趔徚䚉튮囫拭".toCharArray()[3] ^ 0x4EBD);
    this.ٴḷ = ᐨẏ$ᐝт.W("趔徚䚉튮囫拭".toCharArray(), (short)2615, (byte)4, (short)3);
    "齿錕婄".toCharArray()[2] = (char)("齿錕婄".toCharArray()[2] ^ 0x4CC0);
    this.ٴﾗ = ᐨẏ$ᐝт.W("齿錕婄".toCharArray(), (short)12977, (byte)4, (short)4);
  }
  
  private static void main(String[] paramArrayOfString) {
    PrintWriter printWriter2 = new PrintWriter(System.err, true);
    PrintWriter printWriter1 = new PrintWriter(System.out, true);
    "度쬷⧼푒巓뿘勽諕᭓᫲?Ţ咣᜹궿朽ꈮ乻ᥛ岎雎轈罠滰齶埵ज⬦뗲쩮퐥휅㖪?쳭껕穻얦믵黥솕ᖛ⹑銚杸帗픋❔蒡꧹掤襏ᴱ왞䌢濸娒䌓盖运좣蹲띙ᛘ烔鈽㶩吋擊䥴䕦ꨕٚ䴊짃嚙·㱘罠侖ꁍ醨瞹핱씌¿ꝴ?ꤨ끚Ά훱ຌ蔎ﶀ鎍侀Ćꊺ瘚뼾甉䆴".toCharArray()[1] = (char)("度쬷⧼푒巓뿘勽諕᭓᫲?Ţ咣᜹궿朽ꈮ乻ᥛ岎雎轈罠滰齶埵ज⬦뗲쩮퐥휅㖪?쳭껕穻얦믵黥솕ᖛ⹑銚杸帗픋❔蒡꧹掤襏ᴱ왞䌢濸娒䌓盖运좣蹲띙ᛘ烔鈽㶩吋擊䥴䕦ꨕٚ䴊짃嚙·㱘罠侖ꁍ醨瞹핱씌¿ꝴ?ꤨ끚Ά훱ຌ蔎ﶀ鎍侀Ćꊺ瘚뼾甉䆴".toCharArray()[1] ^ 0x51A0);
    ᐨẏ(paramArrayOfString = paramArrayOfString, ˍɫ$יς.J("度쬷⧼푒巓뿘勽諕᭓᫲?Ţ咣᜹궿朽ꈮ乻ᥛ岎雎轈罠滰齶埵ज⬦뗲쩮퐥휅㖪?쳭껕穻얦믵黥솕ᖛ⹑銚杸帗픋❔蒡꧹掤襏ᴱ왞䌢濸娒䌓盖运좣蹲띙ᛘ烔鈽㶩吋擊䥴䕦ꨕٚ䴊짃嚙·㱘罠侖ꁍ醨瞹핱씌¿ꝴ?ꤨ끚Ά훱ຌ蔎ﶀ鎍侀Ćꊺ瘚뼾甉䆴".toCharArray(), (short)858, (short)5, (byte)3).intern(), new ძ(), printWriter1, printWriter2);
  }
  
  private static void ᐨẏ(String[] paramArrayOfString, PrintWriter paramPrintWriter1, PrintWriter paramPrintWriter2) {
    "䑋ᾱ⛊※磈嵜雧䮎䮚ᝲ영ퟒ霫ẞ䑎옏ᖒ㝿ঃ㪞Ỻᖅꭞ?㩾⊳뭤ৠ潼젩樼㜸赊㉁䣩쬆佺๽໠兼嫴⚃꼂븆Ꙏ쫦️糀猖訵맘핰㺠࿙쯥䘰糸ﶦ嘵畐?徧蛌篭矴꯯ﱟ?戣剕᪾贇꒏䮔肨ⲵ떾曕꾓᪏䏭㕍纹꥓푚૽Կ竑?䯻휭昒쓇뙿㏮踯䔒?普﷙蘢낏ṿ㔥癭ꤝʖ漌㎛圯띃쫜ᱬ".toCharArray()[108] = (char)("䑋ᾱ⛊※磈嵜雧䮎䮚ᝲ영ퟒ霫ẞ䑎옏ᖒ㝿ঃ㪞Ỻᖅꭞ?㩾⊳뭤ৠ潼젩樼㜸赊㉁䣩쬆佺๽໠兼嫴⚃꼂븆Ꙏ쫦️糀猖訵맘핰㺠࿙쯥䘰糸ﶦ嘵畐?徧蛌篭矴꯯ﱟ?戣剕᪾贇꒏䮔肨ⲵ떾曕꾓᪏䏭㕍纹꥓푚૽Կ竑?䯻휭昒쓇뙿㏮踯䔒?普﷙蘢낏ṿ㔥癭ꤝʖ漌㎛圯띃쫜ᱬ".toCharArray()[108] ^ 0x677A);
    ᐨẏ(paramArrayOfString, ˍɫ$יς.J("䑋ᾱ⛊※磈嵜雧䮎䮚ᝲ영ퟒ霫ẞ䑎옏ᖒ㝿ঃ㪞Ỻᖅꭞ?㩾⊳뭤ৠ潼젩樼㜸赊㉁䣩쬆佺๽໠兼嫴⚃꼂븆Ꙏ쫦️糀猖訵맘핰㺠࿙쯥䘰糸ﶦ嘵畐?徧蛌篭矴꯯ﱟ?戣剕᪾贇꒏䮔肨ⲵ떾曕꾓᪏䏭㕍纹꥓푚૽Կ竑?䯻휭昒쓇뙿㏮踯䔒?普﷙蘢낏ṿ㔥癭ꤝʖ漌㎛圯띃쫜ᱬ".toCharArray(), (short)32294, (short)5, (byte)0).intern(), new ძ(), paramPrintWriter1, paramPrintWriter2);
  }
  
  public final void ᐨẏ(int paramInt1, int paramInt2, String paramString1, String paramString2, String paramString3, String[] paramArrayOfString) {
    if ((paramInt2 & 0x8000) != 0)
      return; 
    this.ᒬ = paramInt2;
    int i = paramInt1 & 0xFFFF;
    int j = paramInt1 >>> 16;
    this.ᐨẏ.setLength(0);
    "?렚䗙欔農㏱醸ൄ뜀蘒冖䡳".toCharArray()[11] = (char)("?렚䗙欔農㏱醸ൄ뜀蘒冖䡳".toCharArray()[11] ^ 0x4BE5);
    "맖?埌".toCharArray()[1] = (char)("맖?埌".toCharArray()[1] ^ 0xD2D);
    "п䓢ẉ".toCharArray()[1] = (char)("п䓢ẉ".toCharArray()[1] ^ 0x483B);
    this.ᐨẏ.append(ˉﻤ$ͺſ.v("?렚䗙欔農㏱醸ൄ뜀蘒冖䡳".toCharArray(), (short)4074, 0, (short)5)).append(i).append('.').append(j).append(ˉﻤ$ͺſ.v("맖?埌".toCharArray(), (short)26906, 3, (short)3)).append(paramInt1).append(ˉﻤ$ͺſ.v("п䓢ẉ".toCharArray(), (short)11251, 3, (short)3));
    if ((paramInt2 & 0x20000) != 0) {
      "ၯ?吐㶛ೡ繨緭躖컢ᘨ烽淹涀".toCharArray()[2] = (char)("ၯ?吐㶛ೡ繨緭躖컢ᘨ烽淹涀".toCharArray()[2] ^ 0x1E9);
      this.ᐨẏ.append(ˉﻤ$ͺſ.v("ၯ?吐㶛ೡ繨緭躖컢ᘨ烽淹涀".toCharArray(), (short)24723, 5, (short)0).intern());
    } 
    if ((paramInt2 & 0x10000) != 0) {
      "紧䭷湧ኩ⩞믡㪄읲ৰ".toCharArray()[8] = (char)("紧䭷湧ኩ⩞믡㪄읲ৰ".toCharArray()[8] ^ 0x4128);
      this.ᐨẏ.append(ˉﻤ$ͺſ.v("紧䭷湧ኩ⩞믡㪄읲ৰ".toCharArray(), (short)11532, 5, (short)3).intern());
    } 
    ˉｓ(paramInt2);
    ՙᗮ(5, paramString2);
    if (paramString2 != null)
      ﾞл(paramString1, paramString2); 
    ʿλ(paramInt2 & 0xFFFF7FDF);
    if ((paramInt2 & 0x2000) != 0) {
      "㿙䐎ꗨꅦ⵲਒䩤㹇⃱ꂾژ".toCharArray()[4] = (char)("㿙䐎ꗨꅦ⵲਒䩤㹇⃱ꂾژ".toCharArray()[4] ^ 0x317C);
      this.ᐨẏ.append(ˉﻤ$ͺſ.v("㿙䐎ꗨꅦ⵲਒䩤㹇⃱ꂾژ".toCharArray(), (short)2601, 1, (short)1));
    } else if ((paramInt2 & 0x200) != 0) {
      "겮綦傈滆⧪涆븮⃮".toCharArray()[6] = (char)("겮綦傈滆⧪涆븮⃮".toCharArray()[6] ^ 0x4437);
      this.ᐨẏ.append(ˉﻤ$ͺſ.v("겮綦傈滆⧪涆븮⃮".toCharArray(), (short)24941, 1, (short)3));
    } else if ((paramInt2 & 0x4000) == 0) {
      "ｕᖊ玽腃?⳥罕".toCharArray()[2] = (char)("ｕᖊ玽腃?⳥罕".toCharArray()[2] ^ 0x20B);
      this.ᐨẏ.append(ˉﻤ$ͺſ.v("ｕᖊ玽腃?⳥罕".toCharArray(), (short)32108, 0, (short)3));
    } 
    ՙᗮ(0, paramString1);
    "눃㺇ỵ숎嗥㔨郠縇ꚷ슴벼憭Ꮑ㢅踞䳕".toCharArray()[14] = (char)("눃㺇ỵ숎嗥㔨郠縇ꚷ슴벼憭Ꮑ㢅踞䳕".toCharArray()[14] ^ 0x20D9);
    if (paramString3 != null && !ˉﻤ$ͺſ.v("눃㺇ỵ숎嗥㔨郠縇ꚷ슴벼憭Ꮑ㢅踞䳕".toCharArray(), (short)21114, 5, (short)4).equals(paramString3)) {
      "៴氣麥╁ᗕ䔆ㆆဠ".toCharArray()[3] = (char)("៴氣麥╁ᗕ䔆ㆆဠ".toCharArray()[3] ^ 0x7423);
      this.ᐨẏ.append(ˉﻤ$ͺſ.v("៴氣麥╁ᗕ䔆ㆆဠ".toCharArray(), (short)7192, 2, (short)5));
      ՙᗮ(0, paramString3);
    } 
    if (paramArrayOfString != null && paramArrayOfString.length > 0) {
      "灰떯李緹?ꦋ剾ᶤꉍ䱓♁".toCharArray()[7] = (char)("灰떯李緹?ꦋ剾ᶤꉍ䱓♁".toCharArray()[7] ^ 0x7017);
      this.ᐨẏ.append(ˉﻤ$ͺſ.v("灰떯李緹?ꦋ剾ᶤꉍ䱓♁".toCharArray(), (short)1489, 3, (short)4));
      for (paramInt1 = 0; paramInt1 < paramArrayOfString.length; paramInt1++) {
        ՙᗮ(0, paramArrayOfString[paramInt1]);
        if (paramInt1 != paramArrayOfString.length - 1)
          this.ᐨẏ.append(' '); 
      } 
    } 
    "鋄錟䃂礭".toCharArray()[2] = (char)("鋄錟䃂礭".toCharArray()[2] ^ 0x29E2);
    this.ᐨẏ.append(ˉﻤ$ͺſ.v("鋄錟䃂礭".toCharArray(), (short)26464, 2, (short)5));
    this.ۥ.add(this.ᐨẏ.toString());
  }
  
  public final void ᐨẏ(String paramString1, String paramString2) {
    this.ᐨẏ.setLength(0);
    if (paramString1 != null) {
      "ꝕ圡ᶐﶌ曨鿧틄苀鴋ㆊల?⋉孤᥄⿼덚揙".toCharArray()[1] = (char)("ꝕ圡ᶐﶌ曨鿧틄苀鴋ㆊల?⋉孤᥄⿼덚揙".toCharArray()[1] ^ 0x4F48);
      this.ᐨẏ.append(this.ᐧє).append(ˉﻤ$ͺſ.v("ꝕ圡ᶐﶌ曨鿧틄苀鴋ㆊల?⋉孤᥄⿼덚揙".toCharArray(), (short)17164, 0, (short)4)).append(paramString1).append('\n');
    } 
    if (paramString2 != null) {
      "຿怱輨闊ꢱԒ㛽⿮誸↟៩㤥흤ࡳ㵃".toCharArray()[7] = (char)("຿怱輨闊ꢱԒ㛽⿮誸↟៩㤥흤ࡳ㵃".toCharArray()[7] ^ 0x24D9);
      this.ᐨẏ.append(this.ᐧє).append(ˉﻤ$ͺſ.v("຿怱輨闊ꢱԒ㛽⿮誸↟៩㤥흤ࡳ㵃".toCharArray(), (short)4467, 5, (short)1)).append(paramString2).append('\n');
    } 
    if (this.ᐨẏ.length() > 0)
      this.ۥ.add(this.ᐨẏ.toString()); 
  }
  
  public final ᐨᘂ ᐨẏ(String paramString1, int paramInt, String paramString2) {
    this.ᐨẏ.setLength(0);
    if ((paramInt & 0x20) != 0) {
      "菉뤣즑ꦓ갯တ".toCharArray()[4] = (char)("菉뤣즑ꦓ갯တ".toCharArray()[4] ^ 0x49E7);
      this.ᐨẏ.append(ˏȓ$ᴵЃ.E("菉뤣즑ꦓ갯တ".toCharArray(), (short)9616, (short)5, (short)5));
    } 
    "迓퓫篪끌喎耦譈ԅ".toCharArray()[0] = (char)("迓퓫篪끌喎耦譈ԅ".toCharArray()[0] ^ 0x1CE0);
    "꘹ꈐﾳ瘰".toCharArray()[2] = (char)("꘹ꈐﾳ瘰".toCharArray()[2] ^ 0x4AA4);
    "經⿡存仪".toCharArray()[2] = (char)("經⿡存仪".toCharArray()[2] ^ 0x280C);
    "䃲ṅ秵".toCharArray()[0] = (char)("䃲ṅ秵".toCharArray()[0] ^ 0x1627);
    this.ᐨẏ.append(ˏȓ$ᴵЃ.E("迓퓫篪끌喎耦譈ԅ".toCharArray(), (short)12012, (short)1, (short)4)).append(paramString1).append(ˏȓ$ᴵЃ.E("꘹ꈐﾳ瘰".toCharArray(), (short)13929, (short)0, (short)2)).append((paramString2 == null) ? "" : (ˏȓ$ᴵЃ.E("經⿡存仪".toCharArray(), (short)25607, (short)1, (short)5) + paramString2)).append(ˏȓ$ᴵЃ.E("䃲ṅ秵".toCharArray(), (short)18886, (short)3, (short)5));
    this.ۥ.add(this.ᐨẏ.toString());
    return ˊ((String)null);
  }
  
  public final void ᐨẏ(String paramString) {
    this.ᐨẏ.setLength(0);
    "妰줘儥밡ၘ鶊桭뒼墖".toCharArray()[7] = (char)("妰줘儥밡ၘ鶊桭뒼墖".toCharArray()[7] ^ 0x330);
    this.ᐨẏ.append(this.ᐧє).append(ᐝᵣ$ﾞﾇ.j("妰줘儥밡ၘ鶊桭뒼墖".toCharArray(), (short)20992, 1, (short)1));
    ՙᗮ(0, paramString);
    this.ᐨẏ.append('\n');
    this.ۥ.add(this.ᐨẏ.toString());
  }
  
  public final void ˊ(String paramString1, String paramString2, String paramString3) {
    this.ᐨẏ.setLength(0);
    "뗃璾慅䆳涖ꁔ豺䝷裛劽Ꭸʔ".toCharArray()[3] = (char)("뗃璾慅䆳涖ꁔ豺䝷裛劽Ꭸʔ".toCharArray()[3] ^ 0x14FC);
    this.ᐨẏ.append(this.ᐧє).append(ᐨẏ$ᐝт.W("뗃璾慅䆳涖ꁔ豺䝷裛劽Ꭸʔ".toCharArray(), (short)6427, (byte)4, (short)2));
    ՙᗮ(0, paramString1);
    this.ᐨẏ.append(' ');
    if (paramString2 != null)
      this.ᐨẏ.append(paramString2).append(' '); 
    ՙᗮ(3, paramString3);
    this.ᐨẏ.append('\n');
    this.ۥ.add(this.ᐨẏ.toString());
  }
  
  private ძ ᐨẏ(String paramString, boolean paramBoolean) {
    "낗⧋".toCharArray()[0] = (char)("낗⧋".toCharArray()[0] ^ 0x3AB5);
    this.ۥ.add(ᐝᵣ$ﾞﾇ.j("낗⧋".toCharArray(), (short)5497, 5, (short)5));
    return ʿᵉ(paramString, paramBoolean);
  }
  
  public final ᐨᘂ ʹﮃ(int paramInt, ˏɪ paramˏɪ, String paramString, boolean paramBoolean) {
    "소性".toCharArray()[0] = (char)("소性".toCharArray()[0] ^ 0x6487);
    this.ۥ.add(ᐝᵣ$ﾞﾇ.j("소性".toCharArray(), (short)10737, 1, (short)2));
    return ᐨẏ(paramInt, paramˏɪ, paramString, paramBoolean);
  }
  
  public final void ﾞл(ᴵʖ paramᴵʖ) {
    "熏℘".toCharArray()[0] = (char)("熏℘".toCharArray()[0] ^ 0x143C);
    this.ۥ.add(ˏȓ$ᴵЃ.E("熏℘".toCharArray(), (short)14602, (short)4, (short)5));
    ᴵʖ(paramᴵʖ);
  }
  
  public final void ˊ(String paramString) {
    this.ᐨẏ.setLength(0);
    "줯硶ͦ?ꀯ膢䐤꼼ｩ凫".toCharArray()[7] = (char)("줯硶ͦ?ꀯ膢䐤꼼ｩ凫".toCharArray()[7] ^ 0x7E2E);
    this.ᐨẏ.append(this.ᐧє).append(ˍɫ$יς.J("줯硶ͦ?ꀯ膢䐤꼼ｩ凫".toCharArray(), (short)19130, (short)4, (byte)2));
    ՙᗮ(0, paramString);
    this.ᐨẏ.append('\n');
    this.ۥ.add(this.ᐨẏ.toString());
  }
  
  public final void ᴵʖ(String paramString) {
    this.ᐨẏ.setLength(0);
    "ᰑ차⠋좦飂厏鎇鱞纄툝훊遲ဘ唚缀춪Ꮎ".toCharArray()[6] = (char)("ᰑ차⠋좦飂厏鎇鱞纄툝훊遲ဘ唚缀춪Ꮎ".toCharArray()[6] ^ 0x623B);
    this.ᐨẏ.append(this.ᐧє).append(ˍɫ$יς.J("ᰑ차⠋좦飂厏鎇鱞纄툝훊遲ဘ唚缀춪Ꮎ".toCharArray(), (short)18858, (short)1, (byte)4));
    ՙᗮ(0, paramString);
    this.ᐨẏ.append('\n');
    this.ۥ.add(this.ᐨẏ.toString());
  }
  
  public final void ᐨẏ(String paramString1, String paramString2, String paramString3, int paramInt) {
    this.ᐨẏ.setLength(0);
    this.ᐨẏ.append(this.ᐧє);
    ˉｓ(paramInt & 0xFFFFFFDF);
    this.ᐨẏ.append(this.ᐧє);
    ʿλ(paramInt);
    "쉤ϒ幹㬉⿶뛦㫷贪埫ҙ㡅".toCharArray()[4] = (char)("쉤ϒ幹㬉⿶뛦㫷贪埫ҙ㡅".toCharArray()[4] ^ 0x6570);
    this.ᐨẏ.append(ˍɫ$יς.J("쉤ϒ幹㬉⿶뛦㫷贪埫ҙ㡅".toCharArray(), (short)11965, (short)4, (byte)2));
    ՙᗮ(0, paramString1);
    this.ᐨẏ.append(' ');
    ՙᗮ(0, paramString2);
    this.ᐨẏ.append(' ');
    ՙᗮ(0, paramString3);
    this.ᐨẏ.append('\n');
    this.ۥ.add(this.ᐨẏ.toString());
  }
  
  public final ᐨᘂ ᐨẏ(String paramString1, String paramString2, String paramString3) {
    this.ᐨẏ.setLength(0);
    "쿈鰠邀둴デ럙窒눇瑠坆??栔퓈﵌쯘ᔓ".toCharArray()[0] = (char)("쿈鰠邀둴デ럙窒눇瑠坆??栔퓈﵌쯘ᔓ".toCharArray()[0] ^ 0x2D6);
    this.ᐨẏ.append(this.ᐧє).append(ᐝᵣ$ﾞﾇ.j("쿈鰠邀둴デ럙窒눇瑠坆??栔퓈﵌쯘ᔓ".toCharArray(), (short)11899, 0, (short)4));
    if (paramString3 != null) {
      this.ᐨẏ.append(this.ᐧє);
      ՙᗮ(2, paramString3);
      this.ᐨẏ.append(this.ᐧє);
      ﾞл(paramString1, paramString3);
    } 
    this.ᐨẏ.append(this.ᐧє);
    ՙᗮ(1, paramString2);
    this.ᐨẏ.append(' ').append(paramString1);
    this.ᐨẏ.append('\n');
    this.ۥ.add(this.ᐨẏ.toString());
    return ˊ((String)null);
  }
  
  private ძ ᐨẏ(int paramInt, String paramString1, String paramString2, String paramString3, Object paramObject) {
    this.ᐨẏ.setLength(0);
    this.ᐨẏ.append('\n');
    if ((paramInt & 0x20000) != 0) {
      "犮鳲煉쥊縚뫚⩯᱖ᒱݪ枡䕒ࢩ뚓䃬".toCharArray()[1] = (char)("犮鳲煉쥊縚뫚⩯᱖ᒱݪ枡䕒ࢩ뚓䃬".toCharArray()[1] ^ 0x71D6);
      this.ᐨẏ.append(this.ᐧє).append(ᐝᵣ$ﾞﾇ.j("犮鳲煉쥊縚뫚⩯᱖ᒱݪ枡䕒ࢩ뚓䃬".toCharArray(), (short)7670, 1, (short)4).intern());
    } 
    this.ᐨẏ.append(this.ᐧє);
    ˉｓ(paramInt);
    if (paramString3 != null) {
      this.ᐨẏ.append(this.ᐧє);
      ՙᗮ(2, paramString3);
      this.ᐨẏ.append(this.ᐧє);
      ﾞл(paramString1, paramString3);
    } 
    this.ᐨẏ.append(this.ᐧє);
    ʿλ(paramInt);
    ՙᗮ(1, paramString2);
    this.ᐨẏ.append(' ').append(paramString1);
    if (paramObject != null) {
      "⭐ꀆ?ਾ".toCharArray()[1] = (char)("⭐ꀆ?ਾ".toCharArray()[1] ^ 0x40E3);
      this.ᐨẏ.append(ᐝᵣ$ﾞﾇ.j("⭐ꀆ?ਾ".toCharArray(), (short)9734, 3, (short)5));
      if (paramObject instanceof String) {
        this.ᐨẏ.append('"').append(paramObject).append('"');
      } else {
        this.ᐨẏ.append(paramObject);
      } 
    } 
    this.ᐨẏ.append('\n');
    this.ۥ.add(this.ᐨẏ.toString());
    return ˊ((String)null);
  }
  
  private ძ ᐨẏ(int paramInt, String paramString1, String paramString2, String paramString3, String[] paramArrayOfString) {
    this.ᐨẏ.setLength(0);
    this.ᐨẏ.append('\n');
    if ((paramInt & 0x20000) != 0) {
      "썫捧줈㿓剭㠇圷遰ႚⷄ?룭䴎".toCharArray()[9] = (char)("썫捧줈㿓剭㠇圷遰ႚⷄ?룭䴎".toCharArray()[9] ^ 0x1B3A);
      this.ᐨẏ.append(this.ᐧє).append(ᐝᵣ$ﾞﾇ.j("썫捧줈㿓剭㠇圷遰ႚⷄ?룭䴎".toCharArray(), (short)13447, 0, (short)5).intern());
    } 
    this.ᐨẏ.append(this.ᐧє);
    ˉｓ(paramInt);
    if (paramString3 != null) {
      this.ᐨẏ.append(this.ᐧє);
      ՙᗮ(4, paramString3);
      this.ᐨẏ.append(this.ᐧє);
      ﾞл(paramString1, paramString3);
    } 
    this.ᐨẏ.append(this.ᐧє);
    ʿλ(paramInt & 0xFFFFFF3F);
    if ((paramInt & 0x100) != 0) {
      "ꮠ般驁⋃캜ᛌ鹤梴".toCharArray()[3] = (char)("ꮠ般驁⋃캜ᛌ鹤梴".toCharArray()[3] ^ 0x181A);
      this.ᐨẏ.append(ᐝᵣ$ﾞﾇ.j("ꮠ般驁⋃캜ᛌ鹤梴".toCharArray(), (short)18175, 1, (short)2));
    } 
    if ((paramInt & 0x80) != 0) {
      "뗖襋쫙刄푷㸻ឺ".toCharArray()[5] = (char)("뗖襋쫙刄푷㸻ឺ".toCharArray()[5] ^ 0x5A11);
      this.ᐨẏ.append(ᐝᵣ$ﾞﾇ.j("뗖襋쫙刄푷㸻ឺ".toCharArray(), (short)15564, 0, (short)2));
    } 
    if ((paramInt & 0x40) != 0) {
      "踡碈镱汴긻旐ꨡ፜".toCharArray()[5] = (char)("踡碈镱汴긻旐ꨡ፜".toCharArray()[5] ^ 0x6888);
      this.ᐨẏ.append(ᐝᵣ$ﾞﾇ.j("踡碈镱汴긻旐ꨡ፜".toCharArray(), (short)22087, 4, (short)2));
    } 
    if ((this.ᒬ & 0x200) != 0 && (paramInt & 0x408) == 0) {
      "먋菦謫➢챔艱륝졺ዽ".toCharArray()[2] = (char)("먋菦謫➢챔艱륝졺ዽ".toCharArray()[2] ^ 0x6348);
      this.ᐨẏ.append(ᐝᵣ$ﾞﾇ.j("먋菦謫➢챔艱륝졺ዽ".toCharArray(), (short)4618, 4, (short)1));
    } 
    this.ᐨẏ.append(paramString1);
    ՙᗮ(3, paramString2);
    if (paramArrayOfString != null && paramArrayOfString.length > 0) {
      "濱增ꐕ솑溊Փ".toCharArray()[6] = (char)("濱增ꐕ솑溊Փ".toCharArray()[6] ^ 0x1CF2);
      this.ᐨẏ.append(ᐝᵣ$ﾞﾇ.j("濱增ꐕ솑溊Փ".toCharArray(), (short)16282, 0, (short)5));
      String[] arrayOfString;
      int i = (arrayOfString = paramArrayOfString).length;
      for (byte b = 0; b < i; b++) {
        paramString3 = arrayOfString[b];
        this.ᐨẏ.append(' ');
        ՙᗮ(0, paramString3);
      } 
    } 
    this.ᐨẏ.append('\n');
    this.ۥ.add(this.ᐨẏ.toString());
    return ˊ((String)null);
  }
  
  public final void ˊﮈ() {
    "昛䌒ᱡ".toCharArray()[0] = (char)("昛䌒ᱡ".toCharArray()[0] ^ 0x1C0C);
    this.ۥ.add(ˍɫ$יς.J("昛䌒ᱡ".toCharArray(), (short)32212, (short)1, (byte)5));
  }
  
  public final void ʿᵉ(String paramString) {
    this.ᐨẏ.setLength(0);
    "イﳐ撗幾?魊銃湨䂡ⷸ뎯긚뮸庑は松".toCharArray()[1] = (char)("イﳐ撗幾?魊銃湨䂡ⷸ뎯긚뮸庑は松".toCharArray()[1] ^ 0x27D3);
    this.ᐨẏ.append(ᐨẏ$ᐝт.W("イﳐ撗幾?魊銃湨䂡ⷸ뎯긚뮸庑は松".toCharArray(), (short)580, (byte)0, (short)5)).append(paramString).append('\n');
    this.ۥ.add(this.ᐨẏ.toString());
  }
  
  public final void ʹﮃ(String paramString) {
    this.ᐨẏ.setLength(0);
    "竲䥵炕撆긊引倻䩎㹦?뤉ᜫ㇡".toCharArray()[12] = (char)("竲䥵炕撆긊引倻䩎㹦?뤉ᜫ㇡".toCharArray()[12] ^ 0x56DE);
    this.ᐨẏ.append(ᐨẏ$ᐝт.W("竲䥵炕撆긊引倻䩎㹦?뤉ᜫ㇡".toCharArray(), (short)24326, (byte)1, (short)4)).append(paramString).append('\n');
    this.ۥ.add(this.ᐨẏ.toString());
  }
  
  public final void ᐨẏ(String paramString1, int paramInt, String paramString2) {
    this.ᐨẏ.setLength(0);
    "ኆೣ癈Ɪ༦ᔴ筰㽦䔑短".toCharArray()[2] = (char)("ኆೣ癈Ɪ༦ᔴ筰㽦䔑短".toCharArray()[2] ^ 0x37E8);
    this.ᐨẏ.append(this.ᐧє).append(ˍɫ$יς.J("ኆೣ癈Ɪ༦ᔴ筰㽦䔑短".toCharArray(), (short)17084, (short)2, (byte)5));
    if ((paramInt & 0x20) != 0) {
      "쌲׸툏ケ?튛妗꺟蒊歨垦".toCharArray()[4] = (char)("쌲׸툏ケ?튛妗꺟蒊歨垦".toCharArray()[4] ^ 0xDFE);
      this.ᐨẏ.append(ˍɫ$יς.J("쌲׸툏ケ?튛妗꺟蒊歨垦".toCharArray(), (short)27929, (short)5, (byte)1));
    } 
    if ((paramInt & 0x40) != 0) {
      "畲Ⅾ浮ბ봲莇Ⰸ".toCharArray()[2] = (char)("畲Ⅾ浮ბ봲莇Ⰸ".toCharArray()[2] ^ 0x5ED3);
      this.ᐨẏ.append(ˍɫ$יς.J("畲Ⅾ浮ბ봲莇Ⰸ".toCharArray(), (short)21753, (short)3, (byte)2));
    } 
    this.ᐨẏ.append(paramString1).append(';');
    ˉｓ(paramInt);
    if (paramString2 != null) {
      "掸웚⃙罻△宵ꀥ᯦躁໗㱊﷮㆒句".toCharArray()[6] = (char)("掸웚⃙罻△宵ꀥ᯦躁໗㱊﷮㆒句".toCharArray()[6] ^ 0x48EB);
      this.ᐨẏ.append(ˍɫ$יς.J("掸웚⃙罻△宵ꀥ᯦躁໗㱊﷮㆒句".toCharArray(), (short)7234, (short)5, (byte)5)).append(paramString2).append('\n');
    } 
    this.ۥ.add(this.ᐨẏ.toString());
  }
  
  public final void ᐨẏ(String paramString, int paramInt, String... paramVarArgs) {
    "ﶹ⬞敩?ﭘ⹚侫졸൫".toCharArray()[5] = (char)("ﶹ⬞敩?ﭘ⹚侫졸൫".toCharArray()[5] ^ 0x26B4);
    ᐨẏ(ˏȓ$ᴵЃ.E("ﶹ⬞敩?ﭘ⹚侫졸൫".toCharArray(), (short)2434, (short)0, (short)0), paramString, paramInt, paramVarArgs);
  }
  
  public final void ˊ(String paramString, int paramInt, String... paramVarArgs) {
    "?᝷會瀺噍ᄔ".toCharArray()[4] = (char)("?᝷會瀺噍ᄔ".toCharArray()[4] ^ 0x1207);
    ᐨẏ(ˉﻤ$ͺſ.v("?᝷會瀺噍ᄔ".toCharArray(), (short)7172, 2, (short)3), paramString, paramInt, paramVarArgs);
  }
  
  private void ᐨẏ(String paramString1, String paramString2, int paramInt, String... paramVarArgs) {
    this.ᐨẏ.setLength(0);
    this.ᐨẏ.append(this.ᐧє).append(paramString1);
    this.ᐨẏ.append(paramString2);
    if (paramVarArgs != null && paramVarArgs.length > 0) {
      "擇靭䱸∾".toCharArray()[0] = (char)("擇靭䱸∾".toCharArray()[0] ^ 0x699D);
      this.ᐨẏ.append(ᐝᵣ$ﾞﾇ.j("擇靭䱸∾".toCharArray(), (short)15204, 1, (short)0));
    } else {
      this.ᐨẏ.append(';');
    } 
    ˉｓ(paramInt);
    if (paramVarArgs != null && paramVarArgs.length > 0)
      for (byte b = 0; b < paramVarArgs.length; b++) {
        this.ᐨẏ.append(this.ʹˉ).append(paramVarArgs[b]);
        "秂㷎⁴".toCharArray()[0] = (char)("秂㷎⁴".toCharArray()[0] ^ 0x1BD8);
        "흻⤷ே".toCharArray()[0] = (char)("흻⤷ே".toCharArray()[0] ^ 0x64E8);
        this.ᐨẏ.append((b != paramVarArgs.length - 1) ? ᐝᵣ$ﾞﾇ.j("秂㷎⁴".toCharArray(), (short)26489, 0, (short)1) : ᐝᵣ$ﾞﾇ.j("흻⤷ே".toCharArray(), (short)28370, 5, (short)2));
      }  
    this.ۥ.add(this.ᐨẏ.toString());
  }
  
  public final void ՙᗮ(String paramString) {
    this.ᐨẏ.setLength(0);
    "Ⲛ⬔ﾼ并湚".toCharArray()[4] = (char)("Ⲛ⬔ﾼ并湚".toCharArray()[4] ^ 0x7E03);
    this.ᐨẏ.append(this.ᐧє).append(ˍɫ$יς.J("Ⲛ⬔ﾼ并湚".toCharArray(), (short)28712, (short)5, (byte)2));
    ՙᗮ(0, paramString);
    "嚨봥᎔".toCharArray()[0] = (char)("嚨봥᎔".toCharArray()[0] ^ 0x4875);
    this.ᐨẏ.append(ˍɫ$יς.J("嚨봥᎔".toCharArray(), (short)30543, (short)3, (byte)3));
    this.ۥ.add(this.ᐨẏ.toString());
  }
  
  public final void ᐨẏ(String paramString, String... paramVarArgs) {
    this.ᐨẏ.setLength(0);
    "ūꣀ죐ῃ祓騊㚉Ⅷ".toCharArray()[2] = (char)("ūꣀ죐ῃ祓騊㚉Ⅷ".toCharArray()[2] ^ 0x3D0D);
    this.ᐨẏ.append(this.ᐧє).append(ᐝᵣ$ﾞﾇ.j("ūꣀ죐ῃ祓騊㚉Ⅷ".toCharArray(), (short)21511, 1, (short)5));
    ՙᗮ(0, paramString);
    "㢅蛋胚胢黥☊".toCharArray()[3] = (char)("㢅蛋胚胢黥☊".toCharArray()[3] ^ 0x3781);
    this.ᐨẏ.append(ᐝᵣ$ﾞﾇ.j("㢅蛋胚胢黥☊".toCharArray(), (short)9709, 4, (short)2));
    for (byte b = 0; b < paramVarArgs.length; b++) {
      this.ᐨẏ.append(this.ʹˉ);
      ՙᗮ(0, paramVarArgs[b]);
      "で뜚ⶖ".toCharArray()[0] = (char)("で뜚ⶖ".toCharArray()[0] ^ 0x4A1C);
      "ᢁḱާ".toCharArray()[0] = (char)("ᢁḱާ".toCharArray()[0] ^ 0x16BF);
      this.ᐨẏ.append((b != paramVarArgs.length - 1) ? ᐝᵣ$ﾞﾇ.j("で뜚ⶖ".toCharArray(), (short)16868, 3, (short)4) : ᐝᵣ$ﾞﾇ.j("ᢁḱާ".toCharArray(), (short)30733, 5, (short)5));
    } 
    this.ۥ.add(this.ᐨẏ.toString());
  }
  
  public final void ʼᐡ() {}
  
  public final void ᐨẏ(String paramString, Object paramObject) {
    ᔪ(paramString);
    if (paramObject instanceof String) {
      paramObject = paramObject;
      ძ ძ1;
      ᐨẏ((ძ1 = this).ᐨẏ, (String)paramObject);
    } else if (paramObject instanceof ˑܘ) {
      ʻւ((ˑܘ)paramObject);
    } else if (paramObject instanceof Byte) {
      ᐨẏ(((Byte)paramObject).byteValue());
    } else if (paramObject instanceof Boolean) {
      ᴵʖ(((Boolean)paramObject).booleanValue());
    } else if (paramObject instanceof Short) {
      ˊ(((Short)paramObject).shortValue());
    } else if (paramObject instanceof Character) {
      ˊ(((Character)paramObject).charValue());
    } else if (paramObject instanceof Integer) {
      ᔪ(((Integer)paramObject).intValue());
    } else if (paramObject instanceof Float) {
      ᴵʖ(((Float)paramObject).floatValue());
    } else if (paramObject instanceof Long) {
      ﾞл(((Long)paramObject).longValue());
    } else if (paramObject instanceof Double) {
      ᴵʖ(((Double)paramObject).doubleValue());
    } else if (paramObject.getClass().isArray()) {
      byte b;
      this.ᐨẏ.append('{');
      if (paramObject instanceof byte[]) {
        byte[] arrayOfByte = (byte[])paramObject;
        for (b = 0; b < arrayOfByte.length; b++) {
          ʿপ(b);
          ᐨẏ(arrayOfByte[b]);
        } 
      } else if (b instanceof boolean[]) {
        boolean[] arrayOfBoolean = (boolean[])b;
        for (b = 0; b < arrayOfBoolean.length; b++) {
          ʿপ(b);
          ᴵʖ(arrayOfBoolean[b]);
        } 
      } else if (b instanceof short[]) {
        short[] arrayOfShort = (short[])b;
        for (b = 0; b < arrayOfShort.length; b++) {
          ʿপ(b);
          ˊ(arrayOfShort[b]);
        } 
      } else if (b instanceof char[]) {
        char[] arrayOfChar = (char[])b;
        for (b = 0; b < arrayOfChar.length; b++) {
          ʿপ(b);
          ˊ(arrayOfChar[b]);
        } 
      } else if (b instanceof int[]) {
        int[] arrayOfInt = (int[])b;
        for (b = 0; b < arrayOfInt.length; b++) {
          ʿপ(b);
          ᔪ(arrayOfInt[b]);
        } 
      } else if (b instanceof long[]) {
        long[] arrayOfLong = (long[])b;
        for (b = 0; b < arrayOfLong.length; b++) {
          ʿপ(b);
          ﾞл(arrayOfLong[b]);
        } 
      } else if (b instanceof float[]) {
        float[] arrayOfFloat = (float[])b;
        for (b = 0; b < arrayOfFloat.length; b++) {
          ʿপ(b);
          ᴵʖ(arrayOfFloat[b]);
        } 
      } else if (b instanceof double[]) {
        double[] arrayOfDouble = (double[])b;
        for (b = 0; b < arrayOfDouble.length; b++) {
          ʿপ(b);
          ᴵʖ(arrayOfDouble[b]);
        } 
      } 
      this.ᐨẏ.append('}');
    } 
    this.ۥ.add(this.ᐨẏ.toString());
  }
  
  private void ᔪ(int paramInt) {
    this.ᐨẏ.append(paramInt);
  }
  
  private void ﾞл(long paramLong) {
    this.ᐨẏ.append(paramLong).append('L');
  }
  
  private void ᴵʖ(float paramFloat) {
    this.ᐨẏ.append(paramFloat).append('F');
  }
  
  private void ᴵʖ(double paramDouble) {
    this.ᐨẏ.append(paramDouble).append('D');
  }
  
  private void ˊ(char paramChar) {
    "䮤ᝲ೷⼃䁘".toCharArray()[4] = (char)("䮤ᝲ೷⼃䁘".toCharArray()[4] ^ 0x740A);
    this.ᐨẏ.append(ˍɫ$יς.J("䮤ᝲ೷⼃䁘".toCharArray(), (short)12367, (short)2, (byte)1)).append(paramChar);
  }
  
  private void ˊ(short paramShort) {
    "غ鏺凓䑟佔痑诵前".toCharArray()[6] = (char)("غ鏺凓䑟佔痑诵前".toCharArray()[6] ^ 0x7029);
    this.ᐨẏ.append(ˉﻤ$ͺſ.v("غ鏺凓䑟佔痑诵前".toCharArray(), (short)26939, 5, (short)5)).append(paramShort);
  }
  
  private void ᐨẏ(byte paramByte) {
    "⟖䉅皞ԉ".toCharArray()[5] = (char)("⟖䉅皞ԉ".toCharArray()[5] ^ 0xFC8);
    this.ᐨẏ.append(ˉﻤ$ͺſ.v("⟖䉅皞ԉ".toCharArray(), (short)29913, 5, (short)1)).append(paramByte);
  }
  
  private void ᴵʖ(boolean paramBoolean) {
    this.ᐨẏ.append(paramBoolean);
  }
  
  private void ᐝᵣ(String paramString) {
    ᐨẏ(this.ᐨẏ, paramString);
  }
  
  private void ʻւ(ˑܘ paramˑܘ) {
    "逯讧틬濃톅᥎".toCharArray()[4] = (char)("逯讧틬濃톅᥎".toCharArray()[4] ^ 0x7FC5);
    this.ᐨẏ.append(paramˑܘ.ᐨẏ()).append(ˍɫ$יς.J("逯讧틬濃톅᥎".toCharArray(), (short)10629, (short)1, (byte)2).intern());
  }
  
  public final void ᐨẏ(String paramString1, String paramString2, String paramString3) {
    ᔪ(paramString1);
    ՙᗮ(1, paramString2);
    this.ᐨẏ.append('.').append(paramString3);
    this.ۥ.add(this.ᐨẏ.toString());
  }
  
  private ძ ᐨẏ(String paramString1, String paramString2) {
    ᔪ(paramString1);
    this.ᐨẏ.append('@');
    ՙᗮ(1, paramString2);
    this.ᐨẏ.append('(');
    this.ۥ.add(this.ᐨẏ.toString());
    "뇹Ꮼ".toCharArray()[0] = (char)("뇹Ꮼ".toCharArray()[0] ^ 0x5CBE);
    return ˊ(ᐨẏ$ᐝт.W("뇹Ꮼ".toCharArray(), (short)24473, (byte)2, (short)0));
  }
  
  private ძ ᐨẏ(String paramString) {
    ᔪ(paramString);
    this.ᐨẏ.append('{');
    this.ۥ.add(this.ᐨẏ.toString());
    "惝䌠".toCharArray()[0] = (char)("惝䌠".toCharArray()[0] ^ 0x1A5A);
    return ˊ(ˏȓ$ᴵЃ.E("惝䌠".toCharArray(), (short)25232, (short)0, (short)5));
  }
  
  public final void ᴵઽ() {}
  
  private void ᔪ(String paramString) {
    this.ᐨẏ.setLength(0);
    ʿপ(this.ﹳঽ++);
    if (paramString != null)
      this.ᐨẏ.append(paramString).append('='); 
  }
  
  private ძ ˊ(String paramString, boolean paramBoolean) {
    return ʿᵉ(paramString, paramBoolean);
  }
  
  public final ᐨᘂ ʿᵉ(int paramInt, ˏɪ paramˏɪ, String paramString, boolean paramBoolean) {
    return ᐨẏ(paramInt, paramˏɪ, paramString, paramBoolean);
  }
  
  public final void ʿᵉ(ᴵʖ paramᴵʖ) {
    ᴵʖ(paramᴵʖ);
  }
  
  public final void ᐧṙ() {}
  
  private ძ ᴵʖ(String paramString, boolean paramBoolean) {
    return ʿᵉ(paramString, paramBoolean);
  }
  
  public final ᐨᘂ ﾞл(int paramInt, ˏɪ paramˏɪ, String paramString, boolean paramBoolean) {
    return ᐨẏ(paramInt, paramˏɪ, paramString, paramBoolean);
  }
  
  public final void ʹﮃ(ᴵʖ paramᴵʖ) {
    ᴵʖ(paramᴵʖ);
  }
  
  public final void ᐨר() {}
  
  public final void ᐨẏ(String paramString, int paramInt) {
    this.ᐨẏ.setLength(0);
    "⣨钸䭌ḿ㕰쟲諓☒덊ঝ굟꘡♘ⱼ".toCharArray()[11] = (char)("⣨钸䭌ḿ㕰쟲諓☒덊ঝ굟꘡♘ⱼ".toCharArray()[11] ^ 0x550B);
    this.ᐨẏ.append(this.ʹˉ).append(ᐝᵣ$ﾞﾇ.j("⣨钸䭌ḿ㕰쟲諓☒덊ঝ굟꘡♘ⱼ".toCharArray(), (short)3004, 3, (short)4));
    ʿλ(paramInt);
    "딴ᩘ衬琝蓘㿞鿍ሗ￪Ɂ".toCharArray()[6] = (char)("딴ᩘ衬琝蓘㿞鿍ሗ￪Ɂ".toCharArray()[6] ^ 0x44EE);
    this.ᐨẏ.append(' ').append((paramString == null) ? ᐝᵣ$ﾞﾇ.j("딴ᩘ衬琝蓘㿞鿍ሗ￪Ɂ".toCharArray(), (short)10495, 5, (short)5) : paramString).append('\n');
    this.ۥ.add(this.ᐨẏ.toString());
  }
  
  private ძ ᐨẏ() {
    "䮥棝뛽傤䨶ᯂ鬦궲!".toCharArray()[0] = (char)("䮥棝뛽傤䨶ᯂ鬦궲!".toCharArray()[0] ^ 0x6429);
    this.ۥ.add(this.ʹˉ + ᐨẏ$ᐝт.W("䮥棝뛽傤䨶ᯂ鬦궲!".toCharArray(), (short)25705, (byte)5, (short)2));
    "ฟ毰".toCharArray()[0] = (char)("ฟ毰".toCharArray()[0] ^ 0x6225);
    return ˊ(ᐨẏ$ᐝт.W("ฟ毰".toCharArray(), (short)3899, (byte)5, (short)4));
  }
  
  private ძ ﾞл(String paramString, boolean paramBoolean) {
    return ʿᵉ(paramString, paramBoolean);
  }
  
  public final ᐨᘂ ᴵʖ(int paramInt, ˏɪ paramˏɪ, String paramString, boolean paramBoolean) {
    return ᐨẏ(paramInt, paramˏɪ, paramString, paramBoolean);
  }
  
  private ძ ᐨẏ(int paramInt, boolean paramBoolean) {
    this.ᐨẏ.setLength(0);
    "ฝ꾅᩾趀ꥥ㔍౭䞶䋆묥蓼鲄◈ꗰ쓿☚庉ꜳ뜈衈㯂鼉☒쁰쥄殥蜕绿".toCharArray()[21] = (char)("ฝ꾅᩾趀ꥥ㔍౭䞶䋆묥蓼鲄◈ꗰ쓿☚庉ꜳ뜈衈㯂鼉☒쁰쥄殥蜕绿".toCharArray()[21] ^ 0x6215);
    this.ᐨẏ.append(this.ʹˉ).append(ᐨẏ$ᐝт.W("ฝ꾅᩾趀ꥥ㔍౭䞶䋆묥蓼鲄◈ꗰ쓿☚庉ꜳ뜈衈㯂鼉☒쁰쥄殥蜕绿".toCharArray(), (short)24798, (byte)1, (short)2));
    this.ᐨẏ.append(paramInt);
    "ײ❖▇ꭋⶕı䁶鴧짞姁➍".toCharArray()[8] = (char)("ײ❖▇ꭋⶕı䁶鴧짞姁➍".toCharArray()[8] ^ 0x417B);
    "?뵯¥汼ꪨ嚗汉菙讵﹛犯媏".toCharArray()[12] = (char)("?뵯¥汼ꪨ嚗汉菙讵﹛犯媏".toCharArray()[12] ^ 0x6949);
    this.ᐨẏ.append(paramBoolean ? ᐨẏ$ᐝт.W("ײ❖▇ꭋⶕı䁶鴧짞姁➍".toCharArray(), (short)25139, (byte)0, (short)0) : ᐨẏ$ᐝт.W("?뵯¥汼ꪨ嚗汉菙讵﹛犯媏".toCharArray(), (short)7215, (byte)5, (short)2));
    this.ۥ.add(this.ᐨẏ.toString());
    return this;
  }
  
  private ძ ᐨẏ(int paramInt, String paramString, boolean paramBoolean) {
    this.ᐨẏ.setLength(0);
    this.ᐨẏ.append(this.ʹˉ).append('@');
    ՙᗮ(1, paramString);
    this.ᐨẏ.append('(');
    this.ۥ.add(this.ᐨẏ.toString());
    this.ᐨẏ.setLength(0);
    "溏뾆㻨ᩥ̰?쬁ᮂݰᙏྦྷ飙뫧㉳춟眛".toCharArray()[6] = (char)("溏뾆㻨ᩥ̰?쬁ᮂݰᙏྦྷ飙뫧㉳춟眛".toCharArray()[6] ^ 0x56E7);
    "᭬雸ꭜ傰셦庻ഩ閼萷⹜矞蹑꒢胍孹썭旰豹ﾵ䃎먀⸴㻟".toCharArray()[17] = (char)("᭬雸ꭜ傰셦庻ഩ閼萷⹜矞蹑꒢胍孹썭旰豹ﾵ䃎먀⸴㻟".toCharArray()[17] ^ 0x1C67);
    this.ᐨẏ.append(paramBoolean ? ˍɫ$יς.J("溏뾆㻨ᩥ̰?쬁ᮂݰᙏྦྷ飙뫧㉳춟眛".toCharArray(), (short)29445, (short)1, (byte)2) : ˍɫ$יς.J("᭬雸ꭜ傰셦庻ഩ閼萷⹜矞蹑꒢胍孹썭旰豹ﾵ䃎먀⸴㻟".toCharArray(), (short)31234, (short)0, (byte)4)).append(paramInt).append('\n');
    return ˊ(this.ᐨẏ.toString());
  }
  
  public final void ՙᗮ(ᴵʖ paramᴵʖ) {
    ᴵʖ(paramᴵʖ);
  }
  
  public final void ᴵʖ() {}
  
  public final void ᐨẏ(int paramInt1, int paramInt2, Object[] paramArrayOfObject1, int paramInt3, Object[] paramArrayOfObject2) {
    this.ᐨẏ.setLength(0);
    this.ᐨẏ.append(this.ٴﾗ);
    "럦䈿㰯넘執䫰".toCharArray()[2] = (char)("럦䈿㰯넘執䫰".toCharArray()[2] ^ 0x530D);
    this.ᐨẏ.append(ˍɫ$יς.J("럦䈿㰯넘執䫰".toCharArray(), (short)330, (short)2, (byte)5));
    switch (paramInt1) {
      case -1:
      case 0:
        "琏ⷻꄉ췌?哢".toCharArray()[5] = (char)("琏ⷻꄉ췌?哢".toCharArray()[5] ^ 0x1711);
        this.ᐨẏ.append(ˍɫ$יς.J("琏ⷻꄉ췌?哢".toCharArray(), (short)18956, (short)2, (byte)4));
        ˊ(paramInt2, paramArrayOfObject1);
        "돈ﵥᦲ".toCharArray()[2] = (char)("돈ﵥᦲ".toCharArray()[2] ^ 0x7D68);
        this.ᐨẏ.append(ˍɫ$יς.J("돈ﵥᦲ".toCharArray(), (short)30029, (short)2, (byte)4));
        ˊ(paramInt3, paramArrayOfObject2);
        this.ᐨẏ.append(']');
        break;
      case 1:
        "畃摰ꏊᠨ킁ต춺砞".toCharArray()[2] = (char)("畃摰ꏊᠨ킁ต춺砞".toCharArray()[2] ^ 0x1533);
        this.ᐨẏ.append(ˍɫ$יς.J("畃摰ꏊᠨ킁ต춺砞".toCharArray(), (short)14672, (short)3, (byte)1));
        ˊ(paramInt2, paramArrayOfObject1);
        this.ᐨẏ.append(']');
        break;
      case 2:
        "跲祟蠀ꇳ懝⿿".toCharArray()[2] = (char)("跲祟蠀ꇳ懝⿿".toCharArray()[2] ^ 0x6915);
        this.ᐨẏ.append(ˍɫ$יς.J("跲祟蠀ꇳ懝⿿".toCharArray(), (short)3481, (short)2, (byte)5)).append(paramInt2);
        break;
      case 3:
        "棺淌᠝埉籯".toCharArray()[0] = (char)("棺淌᠝埉籯".toCharArray()[0] ^ 0x60C4);
        this.ᐨẏ.append(ˍɫ$יς.J("棺淌᠝埉籯".toCharArray(), (short)27756, (short)5, (byte)1));
        break;
      case 4:
        "烈἟珈ヮ乸㙌".toCharArray()[1] = (char)("烈἟珈ヮ乸㙌".toCharArray()[1] ^ 0x24DC);
        this.ᐨẏ.append(ˍɫ$יς.J("烈἟珈ヮ乸㙌".toCharArray(), (short)19835, (short)1, (byte)4));
        ˊ(1, paramArrayOfObject2);
        break;
      default:
        throw new IllegalArgumentException();
    } 
    this.ᐨẏ.append('\n');
    this.ۥ.add(this.ᐨẏ.toString());
  }
  
  public final void ʹﮃ(int paramInt) {
    this.ᐨẏ.setLength(0);
    this.ᐨẏ.append(this.ʹˉ).append(ᴵʖ[paramInt]).append('\n');
    this.ۥ.add(this.ᐨẏ.toString());
  }
  
  public final void ˊ(int paramInt1, int paramInt2) {
    this.ᐨẏ.setLength(0);
    this.ᐨẏ.append(this.ʹˉ).append(ᴵʖ[paramInt1]).append(' ').append((paramInt1 == 188) ? ﾞл[paramInt2] : Integer.toString(paramInt2)).append('\n');
    this.ۥ.add(this.ᐨẏ.toString());
  }
  
  public final void ᴵʖ(int paramInt1, int paramInt2) {
    this.ᐨẏ.setLength(0);
    this.ᐨẏ.append(this.ʹˉ).append(ᴵʖ[paramInt1]).append(' ').append(paramInt2).append('\n');
    this.ۥ.add(this.ᐨẏ.toString());
  }
  
  public final void ᐨẏ(int paramInt, String paramString) {
    this.ᐨẏ.setLength(0);
    this.ᐨẏ.append(this.ʹˉ).append(ᴵʖ[paramInt]).append(' ');
    ՙᗮ(0, paramString);
    this.ᐨẏ.append('\n');
    this.ۥ.add(this.ᐨẏ.toString());
  }
  
  public final void ᐨẏ(int paramInt, String paramString1, String paramString2, String paramString3) {
    this.ᐨẏ.setLength(0);
    this.ᐨẏ.append(this.ʹˉ).append(ᴵʖ[paramInt]).append(' ');
    ՙᗮ(0, paramString1);
    "懁뗂櫰".toCharArray()[1] = (char)("懁뗂櫰".toCharArray()[1] ^ 0x3879);
    this.ᐨẏ.append('.').append(paramString2).append(ˉﻤ$ͺſ.v("懁뗂櫰".toCharArray(), (short)7443, 0, (short)1));
    ՙᗮ(1, paramString3);
    this.ᐨẏ.append('\n');
    this.ۥ.add(this.ᐨẏ.toString());
  }
  
  public final void ᐨẏ(int paramInt, String paramString1, String paramString2, String paramString3, boolean paramBoolean) {
    this.ᐨẏ.setLength(0);
    this.ᐨẏ.append(this.ʹˉ).append(ᴵʖ[paramInt]).append(' ');
    ՙᗮ(0, paramString1);
    this.ᐨẏ.append('.').append(paramString2).append(' ');
    ՙᗮ(3, paramString3);
    if (paramBoolean) {
      "癶쒱鋆䞐ᐍ".toCharArray()[2] = (char)("癶쒱鋆䞐ᐍ".toCharArray()[2] ^ 0x5509);
      this.ᐨẏ.append(ᐨẏ$ᐝт.W("癶쒱鋆䞐ᐍ".toCharArray(), (short)21065, (byte)0, (short)0));
    } 
    this.ᐨẏ.append('\n');
    this.ۥ.add(this.ᐨẏ.toString());
  }
  
  public final void ᐨẏ(String paramString1, String paramString2, ʹō paramʹō, Object... paramVarArgs) {
    this.ᐨẏ.setLength(0);
    "ﶖ빖仞䱖ƹꙣ蕄럇둦ꋾ挸鶦뜊䮥".toCharArray()[9] = (char)("ﶖ빖仞䱖ƹꙣ蕄럇둦ꋾ挸鶦뜊䮥".toCharArray()[9] ^ 0x57A6);
    this.ᐨẏ.append(this.ʹˉ).append(ˏȓ$ᴵЃ.E("ﶖ빖仞䱖ƹꙣ蕄럇둦ꋾ挸鶦뜊䮥".toCharArray(), (short)25108, (short)2, (short)0));
    this.ᐨẏ.append(paramString1);
    ՙᗮ(3, paramString2);
    "ޕ컔ᕁ".toCharArray()[1] = (char)("ޕ컔ᕁ".toCharArray()[1] ^ 0x12D5);
    this.ᐨẏ.append(ˏȓ$ᴵЃ.E("ޕ컔ᕁ".toCharArray(), (short)20538, (short)0, (short)3));
    this.ᐨẏ.append('\n');
    this.ᐨẏ.append(this.ٴḷ);
    ᴵʖ(paramʹō);
    this.ᐨẏ.append('\n');
    "痙ꙉ黐릓ﲇ?흖䡓忍䖌슧?ೀ៱".toCharArray()[6] = (char)("痙ꙉ黐릓ﲇ?흖䡓忍䖌슧?ೀ៱".toCharArray()[6] ^ 0x47A9);
    this.ᐨẏ.append(this.ٴḷ).append(ˏȓ$ᴵЃ.E("痙ꙉ黐릓ﲇ?흖䡓忍䖌슧?ೀ៱".toCharArray(), (short)19926, (short)1, (short)0));
    if (paramVarArgs.length == 0) {
      "빂㴔氊ꢇ襧ᯞ".toCharArray()[3] = (char)("빂㴔氊ꢇ襧ᯞ".toCharArray()[3] ^ 0x20D5);
      this.ᐨẏ.append(ˏȓ$ᴵЃ.E("빂㴔氊ꢇ襧ᯞ".toCharArray(), (short)22779, (short)0, (short)2));
    } else {
      this.ᐨẏ.append('\n');
      Object[] arrayOfObject;
      int i = (arrayOfObject = paramVarArgs).length;
      for (byte b = 0; b < i; b++) {
        Object object = arrayOfObject[b];
        this.ᐨẏ.append(this.ٴḷ);
        if (object instanceof String) {
          ᐨẏ(this.ᐨẏ, (String)object);
        } else if (object instanceof ˑܘ) {
          if ((object = object).ˉｓ() == 11) {
            ՙᗮ(3, object.ᴵʖ());
          } else {
            ʻւ((ˑܘ)object);
          } 
        } else if (object instanceof ʹō) {
          ᴵʖ((ʹō)object);
        } else {
          this.ᐨẏ.append(object);
        } 
        "ꁞﮊ巚".toCharArray()[2] = (char)("ꁞﮊ巚".toCharArray()[2] ^ 0x15E3);
        this.ᐨẏ.append(ˏȓ$ᴵЃ.E("ꁞﮊ巚".toCharArray(), (short)12155, (short)0, (short)2));
      } 
      this.ᐨẏ.setLength(this.ᐨẏ.length() - 3);
    } 
    this.ᐨẏ.append('\n');
    "䢅裱瓝".toCharArray()[0] = (char)("䢅裱瓝".toCharArray()[0] ^ 0x1BEC);
    this.ᐨẏ.append(this.ʹˉ).append(ˏȓ$ᴵЃ.E("䢅裱瓝".toCharArray(), (short)29208, (short)0, (short)2));
    this.ۥ.add(this.ᐨẏ.toString());
  }
  
  public final void ᐨẏ(int paramInt, ᔪ paramᔪ) {
    this.ᐨẏ.setLength(0);
    this.ᐨẏ.append(this.ʹˉ).append(ᴵʖ[paramInt]).append(' ');
    ـﭔ(paramᔪ);
    this.ᐨẏ.append('\n');
    this.ۥ.add(this.ᐨẏ.toString());
  }
  
  public final void ˊ(ᔪ paramᔪ) {
    this.ᐨẏ.setLength(0);
    this.ᐨẏ.append(this.ٴﾗ);
    ـﭔ(paramᔪ);
    this.ᐨẏ.append('\n');
    this.ۥ.add(this.ᐨẏ.toString());
  }
  
  public final void ˊ(Object paramObject) {
    this.ᐨẏ.setLength(0);
    "ᄭ傍㖣틈䥗".toCharArray()[1] = (char)("ᄭ傍㖣틈䥗".toCharArray()[1] ^ 0x2787);
    this.ᐨẏ.append(this.ʹˉ).append(ˉﻤ$ͺſ.v("ᄭ傍㖣틈䥗".toCharArray(), (short)1957, 3, (short)4));
    if (paramObject instanceof String) {
      ᐨẏ(this.ᐨẏ, (String)paramObject);
    } else if (paramObject instanceof ˑܘ) {
      "埋˒粂㤝䝭⥦".toCharArray()[4] = (char)("埋˒粂㤝䝭⥦".toCharArray()[4] ^ 0x6EC4);
      this.ᐨẏ.append(((ˑܘ)paramObject).ᴵʖ()).append(ˉﻤ$ͺſ.v("埋˒粂㤝䝭⥦".toCharArray(), (short)2915, 4, (short)1).intern());
    } else {
      this.ᐨẏ.append(paramObject);
    } 
    this.ᐨẏ.append('\n');
    this.ۥ.add(this.ᐨẏ.toString());
  }
  
  public final void ﾞл(int paramInt1, int paramInt2) {
    this.ᐨẏ.setLength(0);
    "鿻뛑尕綘㣸".toCharArray()[2] = (char)("鿻뛑尕綘㣸".toCharArray()[2] ^ 0xF2);
    this.ᐨẏ.append(this.ʹˉ).append(ˍɫ$יς.J("鿻뛑尕綘㣸".toCharArray(), (short)10711, (short)4, (byte)5)).append(paramInt1).append(' ').append(paramInt2).append('\n');
    this.ۥ.add(this.ᐨẏ.toString());
  }
  
  public final void ᐨẏ(int paramInt1, int paramInt2, ᔪ paramᔪ, ᔪ... paramVarArgs) {
    this.ᐨẏ.setLength(0);
    "숫뢰療嬈㶐ᆋ铤虠㹽㸢㞨⎖".toCharArray()[9] = (char)("숫뢰療嬈㶐ᆋ铤虠㹽㸢㞨⎖".toCharArray()[9] ^ 0x12C9);
    this.ᐨẏ.append(this.ʹˉ).append(ˉﻤ$ͺſ.v("숫뢰療嬈㶐ᆋ铤虠㹽㸢㞨⎖".toCharArray(), (short)4924, 2, (short)5));
    for (paramInt2 = 0; paramInt2 < paramVarArgs.length; paramInt2++) {
      "뾉੖䍃".toCharArray()[1] = (char)("뾉੖䍃".toCharArray()[1] ^ 0x69D);
      this.ᐨẏ.append(this.ٴḷ).append(paramInt1 + paramInt2).append(ˉﻤ$ͺſ.v("뾉੖䍃".toCharArray(), (short)8286, 4, (short)4));
      ـﭔ(paramVarArgs[paramInt2]);
      this.ᐨẏ.append('\n');
    } 
    "㧍Ⴣ㮍睬宭啵Ɦ뛵㢵".toCharArray()[6] = (char)("㧍Ⴣ㮍睬宭啵Ɦ뛵㢵".toCharArray()[6] ^ 0x1AC7);
    this.ᐨẏ.append(this.ٴḷ).append(ˉﻤ$ͺſ.v("㧍Ⴣ㮍睬宭啵Ɦ뛵㢵".toCharArray(), (short)5802, 2, (short)1));
    ـﭔ(paramᔪ);
    this.ᐨẏ.append('\n');
    this.ۥ.add(this.ᐨẏ.toString());
  }
  
  public final void ᐨẏ(ᔪ paramᔪ, int[] paramArrayOfint, ᔪ[] paramArrayOfᔪ) {
    this.ᐨẏ.setLength(0);
    "豆ᓶ֑仛돩ⱻ맹픿麸絫끝➮࿆".toCharArray()[1] = (char)("豆ᓶ֑仛돩ⱻ맹픿麸絫끝➮࿆".toCharArray()[1] ^ 0x51B8);
    this.ᐨẏ.append(this.ʹˉ).append(ᐨẏ$ᐝт.W("豆ᓶ֑仛돩ⱻ맹픿麸絫끝➮࿆".toCharArray(), (short)4687, (byte)4, (short)0));
    for (byte b = 0; b < paramArrayOfᔪ.length; b++) {
      "㝝䤵".toCharArray()[1] = (char)("㝝䤵".toCharArray()[1] ^ 0x6DA0);
      this.ᐨẏ.append(this.ٴḷ).append(paramArrayOfint[b]).append(ᐨẏ$ᐝт.W("㝝䤵".toCharArray(), (short)17171, (byte)3, (short)2));
      ـﭔ(paramArrayOfᔪ[b]);
      this.ᐨẏ.append('\n');
    } 
    "ᰆ⹹ꭤ귽詨ᗚ௻￮ꛚ㤟".toCharArray()[3] = (char)("ᰆ⹹ꭤ귽詨ᗚ௻￮ꛚ㤟".toCharArray()[3] ^ 0x640B);
    this.ᐨẏ.append(this.ٴḷ).append(ᐨẏ$ᐝт.W("ᰆ⹹ꭤ귽詨ᗚ௻￮ꛚ㤟".toCharArray(), (short)27470, (byte)0, (short)3));
    ـﭔ(paramᔪ);
    this.ᐨẏ.append('\n');
    this.ۥ.add(this.ᐨẏ.toString());
  }
  
  public final void ˊ(String paramString, int paramInt) {
    this.ᐨẏ.setLength(0);
    "쏞ᶏ瑇澨楗ၭ∙홃抏뽹⛹锌ஆ⻻".toCharArray()[10] = (char)("쏞ᶏ瑇澨楗ၭ∙홃抏뽹⛹锌ஆ⻻".toCharArray()[10] ^ 0x11D4);
    this.ᐨẏ.append(this.ʹˉ).append(ˉﻤ$ͺſ.v("쏞ᶏ瑇澨楗ၭ∙홃抏뽹⛹锌ஆ⻻".toCharArray(), (short)4906, 3, (short)2));
    ՙᗮ(1, paramString);
    this.ᐨẏ.append(' ').append(paramInt).append('\n');
    this.ۥ.add(this.ᐨẏ.toString());
  }
  
  public final ᐨᘂ ˊ(int paramInt, ˏɪ paramˏɪ, String paramString, boolean paramBoolean) {
    return ᐨẏ(paramInt, paramˏɪ, paramString, paramBoolean);
  }
  
  public final void ᐨẏ(ᔪ paramᔪ1, ᔪ paramᔪ2, ᔪ paramᔪ3, String paramString) {
    this.ᐨẏ.setLength(0);
    "둗즚캧蛌쏶䛕끹鴡냀ై븒輳賉塳".toCharArray()[10] = (char)("둗즚캧蛌쏶䛕끹鴡냀ై븒輳賉塳".toCharArray()[10] ^ 0x4D3C);
    this.ᐨẏ.append(this.ʹˉ).append(ˉﻤ$ͺſ.v("둗즚캧蛌쏶䛕끹鴡냀ై븒輳賉塳".toCharArray(), (short)9084, 5, (short)1));
    ـﭔ(paramᔪ1);
    this.ᐨẏ.append(' ');
    ـﭔ(paramᔪ2);
    this.ᐨẏ.append(' ');
    ـﭔ(paramᔪ3);
    this.ᐨẏ.append(' ');
    ՙᗮ(0, paramString);
    this.ᐨẏ.append('\n');
    this.ۥ.add(this.ᐨẏ.toString());
  }
  
  public final ᐨᘂ ᐨẏ(int paramInt, ˏɪ paramˏɪ, String paramString, boolean paramBoolean) {
    this.ᐨẏ.setLength(0);
    "潛ͺ乨ᧃ慷䰲ꊷ롋暡퍠桱犯斐늒届".toCharArray()[4] = (char)("潛ͺ乨ᧃ慷䰲ꊷ롋暡퍠桱犯斐늒届".toCharArray()[4] ^ 0x7684);
    this.ᐨẏ.append(this.ʹˉ).append(ᐨẏ$ᐝт.W("潛ͺ乨ᧃ慷䰲ꊷ롋暡퍠桱犯斐늒届".toCharArray(), (short)22234, (byte)0, (short)2));
    ՙᗮ(1, paramString);
    this.ᐨẏ.append('(');
    this.ۥ.add(this.ᐨẏ.toString());
    this.ᐨẏ.setLength(0);
    "彔ᆩ尧".toCharArray()[2] = (char)("彔ᆩ尧".toCharArray()[2] ^ 0x458A);
    this.ᐨẏ.append(ᐨẏ$ᐝт.W("彔ᆩ尧".toCharArray(), (short)24317, (byte)5, (short)2));
    ʻล(paramInt);
    "辨䔞ネ".toCharArray()[1] = (char)("辨䔞ネ".toCharArray()[1] ^ 0x3214);
    this.ᐨẏ.append(ᐨẏ$ᐝт.W("辨䔞ネ".toCharArray(), (short)12344, (byte)1, (short)2)).append(paramˏɪ);
    "蕉୲".toCharArray()[0] = (char)("蕉୲".toCharArray()[0] ^ 0xB55);
    "併뢶뇕剒呒ꇔ?ᜊ쒛볾힊죑涧쵰䍢".toCharArray()[11] = (char)("併뢶뇕剒呒ꇔ?ᜊ쒛볾힊죑涧쵰䍢".toCharArray()[11] ^ 0x56C7);
    this.ᐨẏ.append(paramBoolean ? ᐨẏ$ᐝт.W("蕉୲".toCharArray(), (short)5741, (byte)3, (short)3) : ᐨẏ$ᐝт.W("併뢶뇕剒呒ꇔ?ᜊ쒛볾힊죑涧쵰䍢".toCharArray(), (short)20401, (byte)0, (short)4).intern());
    return ˊ(this.ᐨẏ.toString());
  }
  
  public final void ᐨẏ(String paramString1, String paramString2, String paramString3, ᔪ paramᔪ1, ᔪ paramᔪ2, int paramInt) {
    this.ᐨẏ.setLength(0);
    "隦䄑?蒌㠄ᄦ爄䆘龄?呶挺㛾".toCharArray()[6] = (char)("隦䄑?蒌㠄ᄦ爄䆘龄?呶挺㛾".toCharArray()[6] ^ 0x415D);
    this.ᐨẏ.append(this.ʹˉ).append(ᐨẏ$ᐝт.W("隦䄑?蒌㠄ᄦ爄䆘龄?呶挺㛾".toCharArray(), (short)4511, (byte)1, (short)1)).append(paramString1).append(' ');
    ՙᗮ(1, paramString2);
    this.ᐨẏ.append(' ');
    ـﭔ(paramᔪ1);
    this.ᐨẏ.append(' ');
    ـﭔ(paramᔪ2);
    this.ᐨẏ.append(' ').append(paramInt).append('\n');
    if (paramString3 != null) {
      this.ᐨẏ.append(this.ʹˉ);
      ՙᗮ(2, paramString3);
      this.ᐨẏ.append(this.ʹˉ);
      ﾞл(paramString1, paramString3);
    } 
    this.ۥ.add(this.ᐨẏ.toString());
  }
  
  public final ᐨᘂ ᐨẏ(int paramInt, ˏɪ paramˏɪ, ᔪ[] paramArrayOfᔪ1, ᔪ[] paramArrayOfᔪ2, int[] paramArrayOfint, String paramString, boolean paramBoolean) {
    this.ᐨẏ.setLength(0);
    "ྫྷ쪎ẁ뽪糊쑛廟䗁ჟ᛽眘뀉ਛ".toCharArray()[9] = (char)("ྫྷ쪎ẁ뽪糊쑛廟䗁ჟ᛽眘뀉ਛ".toCharArray()[9] ^ 0x2569);
    this.ᐨẏ.append(this.ʹˉ).append(ᐝᵣ$ﾞﾇ.j("ྫྷ쪎ẁ뽪糊쑛廟䗁ჟ᛽眘뀉ਛ".toCharArray(), (short)9913, 0, (short)3));
    ՙᗮ(1, paramString);
    this.ᐨẏ.append('(');
    this.ۥ.add(this.ᐨẏ.toString());
    this.ᐨẏ.setLength(0);
    "熱襺ᖴᑀ࣍".toCharArray()[0] = (char)("熱襺ᖴᑀ࣍".toCharArray()[0] ^ 0x7122);
    this.ᐨẏ.append(ᐝᵣ$ﾞﾇ.j("熱襺ᖴᑀ࣍".toCharArray(), (short)5305, 4, (short)4));
    ʻล(paramInt);
    "蟆篯⠀".toCharArray()[0] = (char)("蟆篯⠀".toCharArray()[0] ^ 0x4359);
    this.ᐨẏ.append(ᐝᵣ$ﾞﾇ.j("蟆篯⠀".toCharArray(), (short)3463, 4, (short)4)).append(paramˏɪ);
    for (paramInt = 0; paramInt < paramArrayOfᔪ1.length; paramInt++) {
      "홐픪胚準".toCharArray()[1] = (char)("홐픪胚準".toCharArray()[1] ^ 0x27B5);
      this.ᐨẏ.append(ᐝᵣ$ﾞﾇ.j("홐픪胚準".toCharArray(), (short)18254, 4, (short)4));
      ـﭔ(paramArrayOfᔪ1[paramInt]);
      "⃷㑚ྛ㏚".toCharArray()[1] = (char)("⃷㑚ྛ㏚".toCharArray()[1] ^ 0x7A10);
      this.ᐨẏ.append(ᐝᵣ$ﾞﾇ.j("⃷㑚ྛ㏚".toCharArray(), (short)5611, 1, (short)1));
      ـﭔ(paramArrayOfᔪ2[paramInt]);
      "厊뷱篺㷬".toCharArray()[1] = (char)("厊뷱篺㷬".toCharArray()[1] ^ 0x6C5D);
      "형בּ䰓".toCharArray()[1] = (char)("형בּ䰓".toCharArray()[1] ^ 0x3B1D);
      this.ᐨẏ.append(ᐝᵣ$ﾞﾇ.j("厊뷱篺㷬".toCharArray(), (short)4039, 1, (short)1)).append(paramArrayOfint[paramInt]).append(ᐝᵣ$ﾞﾇ.j("형בּ䰓".toCharArray(), (short)28892, 2, (short)1));
    } 
    "ד滨".toCharArray()[0] = (char)("ד滨".toCharArray()[0] ^ 0x13C8);
    "䳂⡹欗ᗻ骼ࢱ専䚏욗㩞䫉䁾뾨㬮".toCharArray()[10] = (char)("䳂⡹欗ᗻ骼ࢱ専䚏욗㩞䫉䁾뾨㬮".toCharArray()[10] ^ 0x5371);
    this.ᐨẏ.append(paramBoolean ? ᐝᵣ$ﾞﾇ.j("ד滨".toCharArray(), (short)21788, 1, (short)2) : ᐝᵣ$ﾞﾇ.j("䳂⡹欗ᗻ骼ࢱ専䚏욗㩞䫉䁾뾨㬮".toCharArray(), (short)26679, 2, (short)5).intern());
    return ˊ(this.ᐨẏ.toString());
  }
  
  public final void ˊ(int paramInt, ᔪ paramᔪ) {
    this.ᐨẏ.setLength(0);
    "ഫ䢎솵下㺸?Ყ眅뼬赸峬巊".toCharArray()[7] = (char)("ഫ䢎솵下㺸?Ყ眅뼬赸峬巊".toCharArray()[7] ^ 0x25BA);
    this.ᐨẏ.append(this.ʹˉ).append(ᐝᵣ$ﾞﾇ.j("ഫ䢎솵下㺸?Ყ眅뼬赸峬巊".toCharArray(), (short)30476, 4, (short)1)).append(paramInt).append(' ');
    ـﭔ(paramᔪ);
    this.ᐨẏ.append('\n');
    this.ۥ.add(this.ᐨẏ.toString());
  }
  
  public final void ʿᵉ(int paramInt1, int paramInt2) {
    this.ᐨẏ.setLength(0);
    "벎ଳꫣꊵ脤飒᧮௾哶".toCharArray()[6] = (char)("벎ଳꫣꊵ脤飒᧮௾哶".toCharArray()[6] ^ 0x52A);
    this.ᐨẏ.append(this.ʹˉ).append(ˍɫ$יς.J("벎ଳꫣꊵ脤飒᧮௾哶".toCharArray(), (short)3916, (short)5, (byte)0)).append(paramInt1).append('\n');
    this.ۥ.add(this.ᐨẏ.toString());
    this.ᐨẏ.setLength(0);
    "욞褰뒠䗱ꥃꏹ䁝≈瘥럯즼뷀烍".toCharArray()[11] = (char)("욞褰뒠䗱ꥃꏹ䁝≈瘥럯즼뷀烍".toCharArray()[11] ^ 0x48F);
    this.ᐨẏ.append(this.ʹˉ).append(ˍɫ$יς.J("욞褰뒠䗱ꥃꏹ䁝≈瘥럯즼뷀烍".toCharArray(), (short)31384, (short)4, (byte)4)).append(paramInt2).append('\n');
    this.ۥ.add(this.ᐨẏ.toString());
  }
  
  public final void ͺĹ() {}
  
  private ძ ʿᵉ(String paramString, boolean paramBoolean) {
    this.ᐨẏ.setLength(0);
    this.ᐨẏ.append(this.ᐧє).append('@');
    ՙᗮ(1, paramString);
    this.ᐨẏ.append('(');
    this.ۥ.add(this.ᐨẏ.toString());
    "璔෵".toCharArray()[0] = (char)("璔෵".toCharArray()[0] ^ 0x151F);
    "㑒侠驮ೇ㞁츂咳?ꮗꟌ盛䬲䄫␂䱢咳".toCharArray()[1] = (char)("㑒侠驮ೇ㞁츂咳?ꮗꟌ盛䬲䄫␂䱢咳".toCharArray()[1] ^ 0x2F56);
    return ˊ(paramBoolean ? ᐝᵣ$ﾞﾇ.j("璔෵".toCharArray(), (short)31680, 0, (short)3) : ᐝᵣ$ﾞﾇ.j("㑒侠驮ೇ㞁츂咳?ꮗꟌ盛䬲䄫␂䱢咳".toCharArray(), (short)18216, 3, (short)0));
  }
  
  private ძ ᐨẏ(int paramInt, ˏɪ paramˏɪ, String paramString, boolean paramBoolean) {
    this.ᐨẏ.setLength(0);
    this.ᐨẏ.append(this.ᐧє).append('@');
    ՙᗮ(1, paramString);
    this.ᐨẏ.append('(');
    this.ۥ.add(this.ᐨẏ.toString());
    this.ᐨẏ.setLength(0);
    "䫯푐暴抬Ᵽ".toCharArray()[2] = (char)("䫯푐暴抬Ᵽ".toCharArray()[2] ^ 0x162A);
    this.ᐨẏ.append(ˏȓ$ᴵЃ.E("䫯푐暴抬Ᵽ".toCharArray(), (short)17667, (short)0, (short)4));
    ʻล(paramInt);
    "㕘쏺瓞".toCharArray()[0] = (char)("㕘쏺瓞".toCharArray()[0] ^ 0x20CA);
    this.ᐨẏ.append(ˏȓ$ᴵЃ.E("㕘쏺瓞".toCharArray(), (short)20851, (short)5, (short)4)).append(paramˏɪ);
    "ꀦ䥲".toCharArray()[0] = (char)("ꀦ䥲".toCharArray()[0] ^ 0x4E43);
    "淴멐빓඼픘꣤紼픘彲楔聒䒄敿".toCharArray()[5] = (char)("淴멐빓඼픘꣤紼픘彲楔聒䒄敿".toCharArray()[5] ^ 0x483F);
    this.ᐨẏ.append(paramBoolean ? ˏȓ$ᴵЃ.E("ꀦ䥲".toCharArray(), (short)5313, (short)2, (short)2) : ˏȓ$ᴵЃ.E("淴멐빓඼픘꣤紼픘彲楔聒䒄敿".toCharArray(), (short)21162, (short)2, (short)2).intern());
    return ˊ(this.ᐨẏ.toString());
  }
  
  private void ᴵʖ(ᴵʖ paramᴵʖ) {
    this.ᐨẏ.setLength(0);
    "穠ஐ飌⊱붟㨢췙乧̊䈤".toCharArray()[9] = (char)("穠ஐ飌⊱붟㨢췙乧̊䈤".toCharArray()[9] ^ 0x2A6);
    this.ᐨẏ.append(this.ᐧє).append(ᐨẏ$ᐝт.W("穠ஐ飌⊱붟㨢췙乧̊䈤".toCharArray(), (short)4784, (byte)1, (short)2));
    ՙᗮ(-1, (String)paramᴵʖ.ᐨẏ);
    if (paramᴵʖ instanceof י丶) {
      if (this.ˍɫ == null)
        this.ˍɫ = new HashMap<>(); 
    } else {
      "磐ç㈝牯?ﰌ葶뻁펞灢ᡭ".toCharArray()[3] = (char)("磐ç㈝牯?ﰌ葶뻁펞灢ᡭ".toCharArray()[3] ^ 0x16CA);
      this.ᐨẏ.append(ᐨẏ$ᐝт.W("磐ç㈝牯?ﰌ葶뻁펞灢ᡭ".toCharArray(), (short)32134, (byte)5, (short)0));
    } 
    this.ۥ.add(this.ᐨẏ.toString());
  }
  
  private void ʿλ(int paramInt) {
    if ((paramInt & 0x1) != 0) {
      "鬦䥋齝霪㠣ૣ".toCharArray()[6] = (char)("鬦䥋齝霪㠣ૣ".toCharArray()[6] ^ 0x62FF);
      this.ᐨẏ.append(ˉﻤ$ͺſ.v("鬦䥋齝霪㠣ૣ".toCharArray(), (short)2773, 2, (short)1));
    } 
    if ((paramInt & 0x2) != 0) {
      "῎㎥㹍榬宫頾?櫭".toCharArray()[3] = (char)("῎㎥㹍榬宫頾?櫭".toCharArray()[3] ^ 0x1AEA);
      this.ᐨẏ.append(ˉﻤ$ͺſ.v("῎㎥㹍榬宫頾?櫭".toCharArray(), (short)2828, 1, (short)0));
    } 
    if ((paramInt & 0x4) != 0) {
      "ᑂ픓衮铰眮ಱ躾 ꣱瓠䔹".toCharArray()[1] = (char)("ᑂ픓衮铰眮ಱ躾 ꣱瓠䔹".toCharArray()[1] ^ 0x2319);
      this.ᐨẏ.append(ˉﻤ$ͺſ.v("ᑂ픓衮铰眮ಱ躾 ꣱瓠䔹".toCharArray(), (short)3617, 0, (short)4));
    } 
    if ((paramInt & 0x10) != 0) {
      "ἠ싰ꃎ韷푧୷".toCharArray()[4] = (char)("ἠ싰ꃎ韷푧୷".toCharArray()[4] ^ 0x5F64);
      this.ᐨẏ.append(ˉﻤ$ͺſ.v("ἠ싰ꃎ韷푧୷".toCharArray(), (short)17827, 1, (short)5));
    } 
    if ((paramInt & 0x8) != 0) {
      "锎⤳ᬳ擈휏ᡒ不椚".toCharArray()[6] = (char)("锎⤳ᬳ擈휏ᡒ不椚".toCharArray()[6] ^ 0x4AD4);
      this.ᐨẏ.append(ˉﻤ$ͺſ.v("锎⤳ᬳ擈휏ᡒ不椚".toCharArray(), (short)30050, 5, (short)0));
    } 
    if ((paramInt & 0x20) != 0) {
      "鶁坧⊙ឩ㧟芃裾䅤뮉ý鱅썘䨾".toCharArray()[9] = (char)("鶁坧⊙ឩ㧟芃裾䅤뮉ý鱅썘䨾".toCharArray()[9] ^ 0x4F9D);
      this.ᐨẏ.append(ˉﻤ$ͺſ.v("鶁坧⊙ឩ㧟芃裾䅤뮉ý鱅썘䨾".toCharArray(), (short)4624, 3, (short)1));
    } 
    if ((paramInt & 0x40) != 0) {
      "?㭨㖆ﶼ㐏?捋".toCharArray()[1] = (char)("?㭨㖆ﶼ㐏?捋".toCharArray()[1] ^ 0x60B8);
      this.ᐨẏ.append(ˉﻤ$ͺſ.v("?㭨㖆ﶼ㐏?捋".toCharArray(), (short)17631, 4, (short)1));
    } 
    if ((paramInt & 0x80) != 0) {
      "歸遜䁖?颚䀩▏ے䱙ꥢ粻".toCharArray()[3] = (char)("歸遜䁖?颚䀩▏ے䱙ꥢ粻".toCharArray()[3] ^ 0x6031);
      this.ᐨẏ.append(ˉﻤ$ͺſ.v("歸遜䁖?颚䀩▏ے䱙ꥢ粻".toCharArray(), (short)21013, 5, (short)3));
    } 
    if ((paramInt & 0x400) != 0) {
      "튍蠒䵃퍗?㵵Ⰶ賏ⓅЮ".toCharArray()[8] = (char)("튍蠒䵃퍗?㵵Ⰶ賏ⓅЮ".toCharArray()[8] ^ 0x4909);
      this.ᐨẏ.append(ˉﻤ$ͺſ.v("튍蠒䵃퍗?㵵Ⰶ賏ⓅЮ".toCharArray(), (short)24800, 0, (short)3));
    } 
    if ((paramInt & 0x800) != 0) {
      "鴞삞櫮妆䲯Ђ쓅蝝潲".toCharArray()[5] = (char)("鴞삞櫮妆䲯Ђ쓅蝝潲".toCharArray()[5] ^ 0x3022);
      this.ᐨẏ.append(ˉﻤ$ͺſ.v("鴞삞櫮妆䲯Ђ쓅蝝潲".toCharArray(), (short)18934, 1, (short)4));
    } 
    if ((paramInt & 0x1000) != 0) {
      "㽚苤蓷㐽ἧꮆਅ᏷䢗ຫ".toCharArray()[6] = (char)("㽚苤蓷㐽ἧꮆਅ᏷䢗ຫ".toCharArray()[6] ^ 0x673F);
      this.ᐨẏ.append(ˉﻤ$ͺſ.v("㽚苤蓷㐽ἧꮆਅ᏷䢗ຫ".toCharArray(), (short)20161, 3, (short)5));
    } 
    if ((paramInt & 0x8000) != 0) {
      "簠⧽勏ༀ꡻卲셲몆ϯ䆥".toCharArray()[7] = (char)("簠⧽勏ༀ꡻卲셲몆ϯ䆥".toCharArray()[7] ^ 0x34B7);
      this.ᐨẏ.append(ˉﻤ$ͺſ.v("簠⧽勏ༀ꡻卲셲몆ϯ䆥".toCharArray(), (short)22650, 0, (short)0));
    } 
    if ((paramInt & 0x4000) != 0) {
      "?폃至魺∢".toCharArray()[1] = (char)("?폃至魺∢".toCharArray()[1] ^ 0x34BC);
      this.ᐨẏ.append(ˉﻤ$ͺſ.v("?폃至魺∢".toCharArray(), (short)7589, 4, (short)4));
    } 
  }
  
  private void ˉｓ(int paramInt) {
    "⎓场⚱퇘?䮜쯐ཙ뀙䢶왰ᛮ暻覾ﾄ狉".toCharArray()[11] = (char)("⎓场⚱퇘?䮜쯐ཙ뀙䢶왰ᛮ暻覾ﾄ狉".toCharArray()[11] ^ 0x1D1D);
    this.ᐨẏ.append(ᐨẏ$ᐝт.W("⎓场⚱퇘?䮜쯐ཙ뀙䢶왰ᛮ暻覾ﾄ狉".toCharArray(), (short)24288, (byte)2, (short)3)).append(Integer.toHexString(paramInt).toUpperCase()).append('\n');
  }
  
  private void ՙᗮ(int paramInt, String paramString) {
    if (paramInt == 5 || paramInt == 2 || paramInt == 4) {
      if (paramString != null) {
        "쀷髀᭤?퍷붵该?㔲໚쪯ᔬ鰽␈".toCharArray()[3] = (char)("쀷髀᭤?퍷붵该?㔲໚쪯ᔬ鰽␈".toCharArray()[3] ^ 0x45D);
        this.ᐨẏ.append(ᐝᵣ$ﾞﾇ.j("쀷髀᭤?퍷붵该?㔲໚쪯ᔬ鰽␈".toCharArray(), (short)29023, 3, (short)1)).append(paramString).append('\n');
        return;
      } 
    } else {
      this.ᐨẏ.append(paramString);
    } 
  }
  
  private void ﾞл(String paramString1, String paramString2) {
    ـᐱ ـᐱ2 = new ـᐱ(this.ᒬ);
    (new ˉῚ(paramString2)).ᐨẏ(ـᐱ2);
    "﨤江玹㑼昲撩껲퀟塌갂铐㾶庾ꖂ䈨┥ⷄ".toCharArray()[15] = (char)("﨤江玹㑼昲撩껲퀟塌갂铐㾶庾ꖂ䈨┥ⷄ".toCharArray()[15] ^ 0xCA9);
    this.ᐨẏ.append(ᐝᵣ$ﾞﾇ.j("﨤江玹㑼昲撩껲퀟塌갂铐㾶庾ꖂ䈨┥ⷄ".toCharArray(), (short)29344, 2, (short)5));
    if (ـᐱ2.ʽ() != null) {
      this.ᐨẏ.append(ـᐱ2.ʽ());
      this.ᐨẏ.append(' ');
    } 
    this.ᐨẏ.append(paramString1);
    ـᐱ ـᐱ1;
    this.ᐨẏ.append((ـᐱ1 = ـᐱ2).ˊ.toString());
    if (ـᐱ2.ʾܪ() != null) {
      "僢樛뼴稴聾೻?羗".toCharArray()[4] = (char)("僢樛뼴稴聾೻?羗".toCharArray()[4] ^ 0x2F8B);
      this.ᐨẏ.append(ᐝᵣ$ﾞﾇ.j("僢樛뼴稴聾೻?羗".toCharArray(), (short)15489, 5, (short)0)).append(ـᐱ2.ʾܪ());
    } 
    this.ᐨẏ.append('\n');
  }
  
  private void ـﭔ(ᔪ paramᔪ) {
    if (this.ˍɫ == null)
      this.ˍɫ = new HashMap<>(); 
    String str;
    if ((str = this.ˍɫ.get(paramᔪ)) == null) {
      "ഌ".toCharArray()[0] = (char)("ഌ".toCharArray()[0] ^ 0x7C8E);
      str = ˉﻤ$ͺſ.v("ഌ".toCharArray(), (short)30170, 0, (short)0) + this.ˍɫ.size();
      this.ˍɫ.put(paramᔪ, str);
    } 
    this.ᐨẏ.append(str);
  }
  
  private void ᴵʖ(ʹō paramʹō) {
    ʹō ʹō2;
    int i = (ʹō2 = paramʹō).ᙆ;
    "㝻菝⬺䌊㤨綸㔸㻦헰뚀퓔㛟䷾䑰⇁".toCharArray()[12] = (char)("㝻菝⬺䌊㤨綸㔸㻦헰뚀퓔㛟䷾䑰⇁".toCharArray()[12] ^ 0x7524);
    "ꝃ獜ᰵ̡".toCharArray()[0] = (char)("ꝃ獜ᰵ̡".toCharArray()[0] ^ 0x46B);
    this.ᐨẏ.append(ᐨẏ$ᐝт.W("㝻菝⬺䌊㤨綸㔸㻦헰뚀퓔㛟䷾䑰⇁".toCharArray(), (short)30509, (byte)0, (short)1)).append(Integer.toHexString(i)).append(ᐨẏ$ᐝт.W("ꝃ獜ᰵ̡".toCharArray(), (short)16591, (byte)4, (short)0));
    boolean bool = false;
    switch (i) {
      case 1:
        "䵲婟몔巂屬ਞ䷯俹".toCharArray()[5] = (char)("䵲婟몔巂屬ਞ䷯俹".toCharArray()[5] ^ 0x7974);
        this.ᐨẏ.append(ᐨẏ$ᐝт.W("䵲婟몔巂屬ਞ䷯俹".toCharArray(), (short)2642, (byte)5, (short)0));
        break;
      case 2:
        "?׭෩킋ꈒ镓뛮糥".toCharArray()[7] = (char)("?׭෩킋ꈒ镓뛮糥".toCharArray()[7] ^ 0x5B69);
        this.ᐨẏ.append(ᐨẏ$ᐝт.W("?׭෩킋ꈒ镓뛮糥".toCharArray(), (short)31373, (byte)3, (short)4));
        break;
      case 3:
        "⮳ଊ뫫뱝დ핚ᒭ㦅".toCharArray()[6] = (char)("⮳ଊ뫫뱝დ핚ᒭ㦅".toCharArray()[6] ^ 0x73C9);
        this.ᐨẏ.append(ᐨẏ$ᐝт.W("⮳ଊ뫫뱝დ핚ᒭ㦅".toCharArray(), (short)400, (byte)5, (short)1));
        break;
      case 4:
        "䯛鰹碡邝ᆖ⣻伨≼ဢ".toCharArray()[7] = (char)("䯛鰹碡邝ᆖ⣻伨≼ဢ".toCharArray()[7] ^ 0x6F37);
        this.ᐨẏ.append(ᐨẏ$ᐝт.W("䯛鰹碡邝ᆖ⣻伨≼ဢ".toCharArray(), (short)12215, (byte)3, (short)5));
        break;
      case 9:
        "ǅꖿ蝌﯀䯍℅ၽ䏩메ڊ鼶졍湮✺⧉".toCharArray()[7] = (char)("ǅꖿ蝌﯀䯍℅ၽ䏩메ڊ鼶졍湮✺⧉".toCharArray()[7] ^ 0xD71);
        this.ᐨẏ.append(ᐨẏ$ᐝт.W("ǅꖿ蝌﯀䯍℅ၽ䏩메ڊ鼶졍湮✺⧉".toCharArray(), (short)605, (byte)3, (short)0));
        bool = true;
        break;
      case 7:
        "촛䍺惶崰ͣ聄ࢪץ䭵焜㻣㡧".toCharArray()[4] = (char)("촛䍺惶崰ͣ聄ࢪץ䭵焜㻣㡧".toCharArray()[4] ^ 0x658);
        this.ᐨẏ.append(ᐨẏ$ᐝт.W("촛䍺惶崰ͣ聄ࢪץ䭵焜㻣㡧".toCharArray(), (short)4488, (byte)1, (short)0));
        bool = true;
        break;
      case 6:
        "칚യ謂洅虺?ᮐ鈲궶○絟佂".toCharArray()[3] = (char)("칚യ謂洅虺?ᮐ鈲궶○絟佂".toCharArray()[3] ^ 0x6F9F);
        this.ᐨẏ.append(ᐨẏ$ᐝт.W("칚യ謂洅虺?ᮐ鈲궶○絟佂".toCharArray(), (short)12169, (byte)3, (short)4));
        bool = true;
        break;
      case 5:
        "놆㱳ꪓ옹퇽傧끳?佁갃䜠뚺∽".toCharArray()[12] = (char)("놆㱳ꪓ옹퇽傧끳?佁갃䜠뚺∽".toCharArray()[12] ^ 0x6A02);
        this.ᐨẏ.append(ᐨẏ$ᐝт.W("놆㱳ꪓ옹퇽傧끳?佁갃䜠뚺∽".toCharArray(), (short)25219, (byte)3, (short)1));
        bool = true;
        break;
      case 8:
        "터뇴䅃﹨듆零䆫Ⱪﳤ럄Ⱆ鞤攏⭇䅎䒒".toCharArray()[6] = (char)("터뇴䅃﹨듆零䆫Ⱪﳤ럄Ⱆ鞤攏⭇䅎䒒".toCharArray()[6] ^ 0xA65);
        this.ᐨẏ.append(ᐨẏ$ᐝт.W("터뇴䅃﹨듆零䆫Ⱪﳤ럄Ⱆ鞤攏⭇䅎䒒".toCharArray(), (short)11848, (byte)3, (short)3));
        bool = true;
        break;
      default:
        throw new IllegalArgumentException();
    } 
    this.ᐨẏ.append('\n');
    this.ᐨẏ.append(this.ٴḷ);
    ʹō ʹō1;
    ՙᗮ(0, (ʹō1 = paramʹō).ˈהּ);
    this.ᐨẏ.append('.');
    this.ᐨẏ.append((ʹō1 = paramʹō).name);
    if (!bool)
      this.ᐨẏ.append('('); 
    ՙᗮ(9, (ʹō1 = paramʹō).ᴵʖ);
    if (!bool)
      this.ᐨẏ.append(')'); 
    if ((ʹō1 = paramʹō).ˊ) {
      "ϸ躹?捋".toCharArray()[1] = (char)("ϸ躹?捋".toCharArray()[1] ^ 0xA3D);
      this.ᐨẏ.append(ᐨẏ$ᐝт.W("ϸ躹?捋".toCharArray(), (short)23133, (byte)2, (short)5));
    } 
  }
  
  private void ʿপ(int paramInt) {
    if (paramInt > 0) {
      "縁ḫ".toCharArray()[1] = (char)("縁ḫ".toCharArray()[1] ^ 0x2A4D);
      this.ᐨẏ.append(ᐝᵣ$ﾞﾇ.j("縁ḫ".toCharArray(), (short)15971, 0, (short)3));
    } 
  }
  
  private void ʻล(int paramInt) {
    ʾเ ʾเ;
    switch ((ʾเ = new ʾเ(paramInt)).ˉｓ()) {
      case 0:
        "큤䟹탠㤔蹌걊?꼄雤䝣鑎ꎼ⃣ゐح擼蓞લ淗궜彈".toCharArray()[18] = (char)("큤䟹탠㤔蹌걊?꼄雤䝣鑎ꎼ⃣ゐح擼蓞લ淗궜彈".toCharArray()[18] ^ 0x21CF);
        this.ᐨẏ.append(ᐝᵣ$ﾞﾇ.j("큤䟹탠㤔蹌걊?꼄雤䝣鑎ꎼ⃣ゐح擼蓞લ淗궜彈".toCharArray(), (short)13678, 3, (short)2)).append(ʾเ.ـﭔ());
        return;
      case 1:
        "qኾಿẜ⯸ퟍ촛쩕ᜁ븽幎鐔보ኆ₅㱭갛᧔濲椀鑉䞍".toCharArray()[5] = (char)("qኾಿẜ⯸ퟍ촛쩕ᜁ븽幎鐔보ኆ₅㱭갛᧔濲椀鑉䞍".toCharArray()[5] ^ 0xCCD);
        this.ᐨẏ.append(ᐝᵣ$ﾞﾇ.j("qኾಿẜ⯸ퟍ촛쩕ᜁ븽幎鐔보ኆ₅㱭갛᧔濲椀鑉䞍".toCharArray(), (short)7901, 0, (short)2)).append(ʾเ.ـﭔ());
        return;
      case 16:
        "騞銆ຽ⡋㠼杯ﵚ怋?ƌ๧".toCharArray()[7] = (char)("騞銆ຽ⡋㠼杯ﵚ怋?ƌ๧".toCharArray()[7] ^ 0x6466);
        this.ᐨẏ.append(ᐝᵣ$ﾞﾇ.j("騞銆ຽ⡋㠼杯ﵚ怋?ƌ๧".toCharArray(), (short)19995, 3, (short)5)).append(ʾเ.ﾞǰ());
        return;
      case 17:
        "᤺蒸쳽螅詏ቜ艷㋦塖㛸䊈짦霞祮믑鹿켻갋ᝋ樬隈耫ꆠᾘ".toCharArray()[9] = (char)("᤺蒸쳽螅詏ቜ艷㋦塖㛸䊈짦霞祮믑鹿켻갋ᝋ樬隈耫ꆠᾘ".toCharArray()[9] ^ 0x2CB2);
        "켪㯅僲".toCharArray()[1] = (char)("켪㯅僲".toCharArray()[1] ^ 0x68B5);
        this.ᐨẏ.append(ᐝᵣ$ﾞﾇ.j("᤺蒸쳽螅詏ቜ艷㋦塖㛸䊈짦霞祮믑鹿켻갋ᝋ樬隈耫ꆠᾘ".toCharArray(), (short)1143, 0, (short)1)).append(ʾเ.ـﭔ()).append(ᐝᵣ$ﾞﾇ.j("켪㯅僲".toCharArray(), (short)30260, 4, (short)5)).append(ʾเ.ʼᵖ());
        return;
      case 18:
        "蟼쏨뤨땻틽⋣쒹췧け럯ꆛ鉏ﾡ镞?푂ﾝধ䨥妊ꪣ䬢䈷씇䉬".toCharArray()[9] = (char)("蟼쏨뤨땻틽⋣쒹췧け럯ꆛ鉏ﾡ镞?푂ﾝধ䨥妊ꪣ䬢䈷씇䉬".toCharArray()[9] ^ 0x4863);
        "潦힡㌇".toCharArray()[0] = (char)("潦힡㌇".toCharArray()[0] ^ 0x5DF);
        this.ᐨẏ.append(ᐝᵣ$ﾞﾇ.j("蟼쏨뤨땻틽⋣쒹췧け럯ꆛ鉏ﾡ镞?푂ﾝধ䨥妊ꪣ䬢䈷씇䉬".toCharArray(), (short)12402, 4, (short)0)).append(ʾเ.ـﭔ()).append(ᐝᵣ$ﾞﾇ.j("潦힡㌇".toCharArray(), (short)26384, 1, (short)5)).append(ʾเ.ʼᵖ());
        return;
      case 19:
        "씞緬堏ꌧ拾唡".toCharArray()[4] = (char)("씞緬堏ꌧ拾唡".toCharArray()[4] ^ 0x35B7);
        this.ᐨẏ.append(ᐝᵣ$ﾞﾇ.j("씞緬堏ꌧ拾唡".toCharArray(), (short)15134, 3, (short)0));
        return;
      case 20:
        "៿㕵償扡컅嗂?ꉱ鴕Ⲷ麸殬ⷧ".toCharArray()[12] = (char)("៿㕵償扡컅嗂?ꉱ鴕Ⲷ麸殬ⷧ".toCharArray()[12] ^ 0x4695);
        this.ᐨẏ.append(ᐝᵣ$ﾞﾇ.j("៿㕵償扡컅嗂?ꉱ鴕Ⲷ麸殬ⷧ".toCharArray(), (short)23338, 4, (short)4));
        return;
      case 21:
        "퇐밓眯娾⢜⏁퉒ᬇ丂읿ᰜ䍂逪㺡ㅌ".toCharArray()[11] = (char)("퇐밓眯娾⢜⏁퉒ᬇ丂읿ᰜ䍂逪㺡ㅌ".toCharArray()[11] ^ 0x9DB);
        this.ᐨẏ.append(ᐝᵣ$ﾞﾇ.j("퇐밓眯娾⢜⏁퉒ᬇ丂읿ᰜ䍂逪㺡ㅌ".toCharArray(), (short)14504, 5, (short)5));
        return;
      case 22:
        "ﻴ?䴋䁂ា要愑濇䂰깥ອȽ銽㺮繗뫬掕꣭估㮯탆㕦竀".toCharArray()[21] = (char)("ﻴ?䴋䁂ា要愑濇䂰깥ອȽ銽㺮繗뫬掕꣭估㮯탆㕦竀".toCharArray()[21] ^ 0x3721);
        this.ᐨẏ.append(ᐝᵣ$ﾞﾇ.j("ﻴ?䴋䁂ា要愑濇䂰깥ອȽ銽㺮繗뫬掕꣭估㮯탆㕦竀".toCharArray(), (short)24056, 4, (short)4)).append(ʾเ.ˊᵃ());
        return;
      case 23:
        "癫믉쵂娠ꢪ胃釗Ⓚ".toCharArray()[6] = (char)("癫믉쵂娠ꢪ胃釗Ⓚ".toCharArray()[6] ^ 0x5AB4);
        this.ᐨẏ.append(ᐝᵣ$ﾞﾇ.j("癫믉쵂娠ꢪ胃釗Ⓚ".toCharArray(), (short)29241, 5, (short)0)).append(ʾเ.ˌх());
        return;
      case 64:
        "췶꜀ᰒឈꔟ⌚捧鎏䔢㛉괞♣凑".toCharArray()[0] = (char)("췶꜀ᰒឈꔟ⌚捧鎏䔢㛉괞♣凑".toCharArray()[0] ^ 0x268C);
        this.ᐨẏ.append(ᐝᵣ$ﾞﾇ.j("췶꜀ᰒឈꔟ⌚捧鎏䔢㛉괞♣凑".toCharArray(), (short)27856, 5, (short)1));
        return;
      case 65:
        "?ﴫ୅Ὂ쇨국賧薚쒢࿐놛荤헰苝ࡱᵐ◳".toCharArray()[4] = (char)("?ﴫ୅Ὂ쇨국賧薚쒢࿐놛荤헰苝ࡱᵐ◳".toCharArray()[4] ^ 0x5896);
        this.ᐨẏ.append(ᐝᵣ$ﾞﾇ.j("?ﴫ୅Ὂ쇨국賧薚쒢࿐놛荤헰苝ࡱᵐ◳".toCharArray(), (short)10591, 4, (short)2));
        return;
      case 66:
        "呟鱶렸牁죎䖃?Ⱝꬔ᭹璴엩할ꭻῳ╋匰".toCharArray()[4] = (char)("呟鱶렸牁죎䖃?Ⱝꬔ᭹璴엩할ꭻῳ╋匰".toCharArray()[4] ^ 0x27D1);
        this.ᐨẏ.append(ᐝᵣ$ﾞﾇ.j("呟鱶렸牁죎䖃?Ⱝꬔ᭹璴엩할ꭻῳ╋匰".toCharArray(), (short)4918, 4, (short)3)).append(ʾเ.ιﾌ());
        return;
      case 67:
        "紨밁暏鶽柴뜡礲㖹헖펥箞".toCharArray()[9] = (char)("紨밁暏鶽柴뜡礲㖹헖펥箞".toCharArray()[9] ^ 0x3E96);
        this.ᐨẏ.append(ᐝᵣ$ﾞﾇ.j("紨밁暏鶽柴뜡礲㖹헖펥箞".toCharArray(), (short)13836, 4, (short)2));
        return;
      case 68:
        "徬䩼癙᚟".toCharArray()[0] = (char)("徬䩼癙᚟".toCharArray()[0] ^ 0x7AEA);
        this.ᐨẏ.append(ᐝᵣ$ﾞﾇ.j("徬䩼癙᚟".toCharArray(), (short)24270, 4, (short)1));
        return;
      case 69:
        "╈垐竘揳䡼ዎ匼ו妹琑?麦궣?⺡뫑伳羊娼".toCharArray()[10] = (char)("╈垐竘揳䡼ዎ匼ו妹琑?麦궣?⺡뫑伳羊娼".toCharArray()[10] ^ 0x74F6);
        this.ᐨẏ.append(ᐝᵣ$ﾞﾇ.j("╈垐竘揳䡼ዎ匼ו妹琑?麦궣?⺡뫑伳羊娼".toCharArray(), (short)21006, 3, (short)2));
        return;
      case 70:
        "ፉ묄?鷡쀩⍅?圖尼빴䒄츖ﹽ몱恊␨ྍ".toCharArray()[10] = (char)("ፉ묄?鷡쀩⍅?圖尼빴䒄츖ﹽ몱恊␨ྍ".toCharArray()[10] ^ 0x54E6);
        this.ᐨẏ.append(ᐝᵣ$ﾞﾇ.j("ፉ묄?鷡쀩⍅?圖尼빴䒄츖ﹽ몱恊␨ྍ".toCharArray(), (short)10199, 1, (short)0));
        return;
      case 71:
        "⬖甤鿩풹㙕绗".toCharArray()[2] = (char)("⬖甤鿩풹㙕绗".toCharArray()[2] ^ 0x2247);
        this.ᐨẏ.append(ᐝᵣ$ﾞﾇ.j("⬖甤鿩풹㙕绗".toCharArray(), (short)29616, 0, (short)5)).append(ʾเ.ʻւ());
        return;
      case 72:
        "퐓䱎ॕ伻ￏ䳠裠ាﷄꫮᚦᐙ쯤繕?歱諒?嚩棐鶭톋嫺鶸㵽侀勼繇阮蓹놓ᒐ洸䜺晰".toCharArray()[30] = (char)("퐓䱎ॕ伻ￏ䳠裠ាﷄꫮᚦᐙ쯤繕?歱諒?嚩棐鶭톋嫺鶸㵽侀勼繇阮蓹놓ᒐ洸䜺晰".toCharArray()[30] ^ 0x2B1F);
        this.ᐨẏ.append(ᐝᵣ$ﾞﾇ.j("퐓䱎ॕ伻ￏ䳠裠ាﷄꫮᚦᐙ쯤繕?歱諒?嚩棐鶭톋嫺鶸㵽侀勼繇阮蓹놓ᒐ洸䜺晰".toCharArray(), (short)25554, 1, (short)1)).append(ʾเ.ʻւ());
        return;
      case 73:
        "節柺ꥻ딩碞좝ꉊ㬑㬮븜梍뮌䴜혽쪐韏蕴撼ﾝ같䷴ᮯ﬩簤䛽벳⌌ᐊ䜎".toCharArray()[23] = (char)("節柺ꥻ딩碞좝ꉊ㬑㬮븜梍뮌䴜혽쪐韏蕴撼ﾝ같䷴ᮯ﬩簤䛽벳⌌ᐊ䜎".toCharArray()[23] ^ 0x3EB7);
        this.ᐨẏ.append(ᐝᵣ$ﾞﾇ.j("節柺ꥻ딩碞좝ꉊ㬑㬮븜梍뮌䴜혽쪐韏蕴撼ﾝ같䷴ᮯ﬩簤䛽벳⌌ᐊ䜎".toCharArray(), (short)1968, 2, (short)5)).append(ʾเ.ʻւ());
        return;
      case 74:
        "ᑺ?姤饕덋Բ謔釶掍逷泺ꏲ䵳፵퀰䒝ꢡ屭?蛵꣖吢렀ΏႡ찮䠵䪛?錬唇㤸報ꮹ℮뫺畵".toCharArray()[20] = (char)("ᑺ?姤饕덋Բ謔釶掍逷泺ꏲ䵳፵퀰䒝ꢡ屭?蛵꣖吢렀ΏႡ찮䠵䪛?錬唇㤸報ꮹ℮뫺畵".toCharArray()[20] ^ 0x26AC);
        this.ᐨẏ.append(ᐝᵣ$ﾞﾇ.j("ᑺ?姤饕덋Բ謔釶掍逷泺ꏲ䵳፵퀰䒝ꢡ屭?蛵꣖吢렀ΏႡ찮䠵䪛?錬唇㤸報ꮹ℮뫺畵".toCharArray(), (short)32131, 3, (short)4)).append(ʾเ.ʻւ());
        return;
      case 75:
        "헃㜱∀敓ड़?ᖟ劘訶ﮇ櫧為９伦浹?㝫⢃Ʞ㸴멒餥⍎⳨聲ཌྷ⶞".toCharArray()[27] = (char)("헃㜱∀敓ड़?ᖟ劘訶ﮇ櫧為９伦浹?㝫⢃Ʞ㸴멒餥⍎⳨聲ཌྷ⶞".toCharArray()[27] ^ 0x6AE3);
        this.ᐨẏ.append(ᐝᵣ$ﾞﾇ.j("헃㜱∀敓ड़?ᖟ劘訶ﮇ櫧為９伦浹?㝫⢃Ʞ㸴멒餥⍎⳨聲ཌྷ⶞".toCharArray(), (short)2163, 2, (short)0)).append(ʾเ.ʻւ());
        return;
    } 
    throw new IllegalArgumentException();
  }
  
  private void ˊ(int paramInt, Object[] paramArrayOfObject) {
    for (byte b = 0; b < paramInt; b++) {
      if (b > 0)
        this.ᐨẏ.append(' '); 
      if (paramArrayOfObject[b] instanceof String) {
        String str;
        if ((str = (String)paramArrayOfObject[b]).charAt(0) == '[') {
          ՙᗮ(1, str);
        } else {
          ՙᗮ(0, str);
        } 
      } else if (paramArrayOfObject[b] instanceof Integer) {
        this.ᐨẏ.append(ٴᖟ.get(((Integer)paramArrayOfObject[b]).intValue()));
      } else {
        ـﭔ((ᔪ)paramArrayOfObject[b]);
      } 
    } 
  }
  
  private ძ ˊ(String paramString) {
    ძ ძ1 = ˊ();
    ძ ძ2;
    this.ۥ.add((ძ2 = ძ1).ۥ);
    if (paramString != null)
      this.ۥ.add(paramString); 
    return ძ1;
  }
  
  private ძ ˊ() {
    return new ძ(this.ᐨẏ);
  }
  
  static {
    "繪읧걡폴⑋壏酅迭찄剦".toCharArray()[6] = (char)("繪읧걡폴⑋壏酅迭찄剦".toCharArray()[6] ^ 0x6E12);
    ˑܘ = ˏȓ$ᴵЃ.E("繪읧걡폴⑋壏酅迭찄剦".toCharArray(), (short)14967, (short)1, (short)4).intern();
    "㵏볐缠側蹴窮鐪迁펚滥㖂".toCharArray()[13] = (char)("㵏볐缠側蹴窮鐪迁펚滥㖂".toCharArray()[13] ^ 0x321A);
    ˍ = ˏȓ$ᴵЃ.E("㵏볐缠側蹴窮鐪迁펚滥㖂".toCharArray(), (short)27771, (short)0, (short)0).intern();
    "궂ᘡ".toCharArray()[0] = (char)("궂ᘡ".toCharArray()[0] ^ 0x6ABF);
    (new String[7])[0] = ˏȓ$ᴵЃ.E("궂ᘡ".toCharArray(), (short)3881, (short)4, (short)0);
    "쭮䆆".toCharArray()[0] = (char)("쭮䆆".toCharArray()[0] ^ 0xE4D);
    (new String[7])[1] = ˏȓ$ᴵЃ.E("쭮䆆".toCharArray(), (short)31710, (short)0, (short)4);
    "漱罫".toCharArray()[0] = (char)("漱罫".toCharArray()[0] ^ 0x1960);
    (new String[7])[2] = ˏȓ$ᴵЃ.E("漱罫".toCharArray(), (short)5745, (short)0, (short)5);
    "วᤓ".toCharArray()[0] = (char)("วᤓ".toCharArray()[0] ^ 0x222E);
    (new String[7])[3] = ˏȓ$ᴵЃ.E("วᤓ".toCharArray(), (short)29506, (short)1, (short)3);
    "鄪㻆".toCharArray()[0] = (char)("鄪㻆".toCharArray()[0] ^ 0x542D);
    (new String[7])[4] = ˏȓ$ᴵЃ.E("鄪㻆".toCharArray(), (short)19361, (short)5, (short)5);
    "鈭؅".toCharArray()[0] = (char)("鈭؅".toCharArray()[0] ^ 0x3A9D);
    (new String[7])[5] = ˏȓ$ᴵЃ.E("鈭؅".toCharArray(), (short)27129, (short)0, (short)1);
    "᪙巬".toCharArray()[0] = (char)("᪙巬".toCharArray()[0] ^ 0x423A);
    ٴᖟ = Collections.unmodifiableList(Arrays.asList(new String[] { null, null, null, null, null, null, ˏȓ$ᴵЃ.E("᪙巬".toCharArray(), (short)17928, (short)0, (short)2) }));
  }
  
  static {
    "담ⳍ袸侯缂댺챬拵黧驙䈰᪊綣憵蟍〈顰횮됗假셟징蚭៊蘌晬鬄䈾孔쳾䂹섄㊝绾殘ﭘ阫䞮?ࠈ䀬봼辬ᅋ경삐휿㮘쐾㭏ଖ苾◦ꄲ쿆賮Ղ쪢驞ȶூ෭衬퀗麙侚鎨㽄捫淮⯢叹㱊䢉컵裚ꢴ瓺⫵洶骀器큦금璄∝쯤?蕏숩ङ칞㛋管ᙗ䍼ᚊ헡菙ᄔﭱ氳渟ܵ靣Ỏ餗↳೶".toCharArray()[100] = (char)("담ⳍ袸侯缂댺챬拵黧驙䈰᪊綣憵蟍〈顰횮됗假셟징蚭៊蘌晬鬄䈾孔쳾䂹섄㊝绾殘ﭘ阫䞮?ࠈ䀬봼辬ᅋ경삐휿㮘쐾㭏ଖ苾◦ꄲ쿆賮Ղ쪢驞ȶூ෭衬퀗麙侚鎨㽄捫淮⯢叹㱊䢉컵裚ꢴ瓺⫵洶骀器큦금璄∝쯤?蕏숩ङ칞㛋管ᙗ䍼ᚊ헡菙ᄔﭱ氳渟ܵ靣Ỏ餗↳೶".toCharArray()[100] ^ 0x50CA);
  }
  
  static {
    "㼬鲸큅ᯪ众⶯ᒨ".toCharArray()[1] = (char)("㼬鲸큅ᯪ众⶯ᒨ".toCharArray()[1] ^ 0x5C1E);
  }
  
  static {
    "齏ܣ鲘鞏瓣߁텐䶼侪婛럣襗㵈矎៬".toCharArray()[13] = (char)("齏ܣ鲘鞏瓣߁텐䶼侪婛럣襗㵈矎៬".toCharArray()[13] ^ 0x64C);
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ძ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */