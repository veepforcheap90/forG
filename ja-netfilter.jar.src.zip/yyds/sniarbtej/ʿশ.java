package yyds.sniarbtej;

import java.util.Map;

public final class ʿশ extends Ӏ {
  public λ ˊ;
  
  public ʿশ(int paramInt, λ paramλ) {
    super(paramInt);
    this.ˊ = paramλ;
  }
  
  private void ٴӵ(int paramInt) {
    this.ՙঘ = paramInt;
  }
  
  public final int ﹳיִ() {
    return 7;
  }
  
  public final void ᐨẏ(ˉｓ paramˉｓ) {
    paramˉｓ.ᐨẏ(this.ՙঘ, this.ˊ.ﾞл());
    ˊ(paramˉｓ);
  }
  
  public final Ӏ ᐨẏ(Map<λ, λ> paramMap) {
    return (new ʿশ(this.ՙঘ, ᐨẏ(this.ˊ, paramMap))).ᐨẏ(this);
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ʿশ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */