package yyds.sniarbtej;

public enum ｨ {
  ˊ, ᴵʖ;
  
  public abstract ᐧｴ ᐨẏ(Long paramLong);
  
  static {
    "㨬?歁ꠄꉃ朋孯".toCharArray()[6] = (char)("㨬?歁ꠄꉃ朋孯".toCharArray()[6] ^ 0x5A2B);
  }
  
  static {
    "瀊굃ఉ荼礜".toCharArray()[3] = (char)("瀊굃ఉ荼礜".toCharArray()[3] ^ 0x6F9C);
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ｨ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */