package yyds.sniarbtej;

import java.lang.reflect.Type;
import java.sql.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import ylt.pmn.zubdqvgt;

final class ˌᴉ implements ˊᴄ<Date>, יỉ<Date> {
  private final DateFormat ᐨẏ;
  
  private final DateFormat ˊ;
  
  ˌᴉ() {
    this(DateFormat.getDateTimeInstance(2, 2, Locale.US), DateFormat.getDateTimeInstance(2, 2));
  }
  
  ˌᴉ(String paramString) {
    this(new SimpleDateFormat(paramString, Locale.US), new SimpleDateFormat(paramString));
  }
  
  private ˌᴉ(int paramInt) {
    this(DateFormat.getDateInstance(paramInt, Locale.US), DateFormat.getDateInstance(paramInt));
  }
  
  public ˌᴉ(int paramInt1, int paramInt2) {
    this(DateFormat.getDateTimeInstance(paramInt1, paramInt2, Locale.US), DateFormat.getDateTimeInstance(paramInt1, paramInt2));
  }
  
  private ˌᴉ(DateFormat paramDateFormat1, DateFormat paramDateFormat2) {
    this.ᐨẏ = paramDateFormat1;
    this.ˊ = paramDateFormat2;
  }
  
  private ᐧｴ ᐨẏ(Date paramDate) {
    synchronized (this.ˊ) {
      String str = this.ᐨẏ.format(paramDate);
      return new ﭘ(str);
    } 
  }
  
  private Date ᐨẏ(ᐧｴ paramᐧｴ, Type paramType) {
    if (!(paramᐧｴ instanceof ﭘ)) {
      "⟓⠢쭟줰覒盤飋⯬䐂뙳ਇ｜?෢ꔙ岨쒆豯ᥡ枋ӛ⡅⠙?嫖㵂崸盕淡".toCharArray()[14] = (char)("⟓⠢쭟줰覒盤飋⯬䐂뙳ਇ｜?෢ꔙ岨쒆豯ᥡ枋ӛ⡅⠙?嫖㵂崸盕淡".toCharArray()[14] ^ 0x4E5);
      throw new ˑʖ(ˉﻤ$ͺſ.v("⟓⠢쭟줰覒盤飋⯬䐂뙳ਇ｜?෢ꔙ岨쒆豯ᥡ枋ӛ⡅⠙?嫖㵂崸盕淡".toCharArray(), (short)22266, 1, (short)4));
    } 
    Date date = ᐨẏ(paramᐧｴ);
    if (zubdqvgt.G(paramType, Date.class))
      return date; 
    if (zubdqvgt.G(paramType, Date.class))
      return new Date(date.getTime()); 
    "㨐䊥﵏ၕ쪾뎁?復碈㦥엂ᬕ惽⽴卡蜉䦊索澭쀔٭ₕ".toCharArray()[18] = (char)("㨐䊥﵏ၕ쪾뎁?復碈㦥엂ᬕ惽⽴卡蜉䦊索澭쀔٭ₕ".toCharArray()[18] ^ 0x4A44);
    throw new IllegalArgumentException(getClass() + ˉﻤ$ͺſ.v("㨐䊥﵏ၕ쪾뎁?復碈㦥엂ᬕ惽⽴卡蜉䦊索澭쀔٭ₕ".toCharArray(), (short)5032, 4, (short)3) + paramType);
  }
  
  private Date ᐨẏ(ᐧｴ paramᐧｴ) {
    synchronized (this.ˊ) {
      return this.ˊ.parse(paramᐧｴ.ᐨم());
    } 
  }
  
  public final String toString() {
    StringBuilder stringBuilder;
    (stringBuilder = new StringBuilder()).append(ˌᴉ.class.getSimpleName());
    stringBuilder.append('(').append(this.ˊ.getClass().getSimpleName()).append(')');
    return stringBuilder.toString();
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ˌᴉ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */