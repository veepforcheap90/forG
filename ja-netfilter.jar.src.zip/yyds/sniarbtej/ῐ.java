package yyds.sniarbtej;

import java.math.BigDecimal;
import ylt.pmn.zubdqvgt;

final class ῐ extends ٴۉ<BigDecimal> {
  private static BigDecimal ᐨẏ(יּ paramיּ) {
    if (zubdqvgt.G(paramיּ.ᐨẏ(), כ.ʽ)) {
      paramיּ.ۦ();
      return null;
    } 
    try {
      return new BigDecimal(paramיּ.ٴӵ());
    } catch (NumberFormatException numberFormatException) {
      throw new ՙĩ(numberFormatException);
    } 
  }
  
  private static void ᐨẏ(Ⴡ paramჁ, BigDecimal paramBigDecimal) {
    paramჁ.ᐨẏ(paramBigDecimal);
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ῐ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */