package yyds.sniarbtej;

import java.lang.reflect.Method;

final class ᐝİ extends ˋץ {
  ᐝİ(Method paramMethod) {}
  
  public final <T> T ᐨẏ(Class<T> paramClass) {
    return (T)this.ˊ.invoke(null, new Object[] { paramClass, Object.class });
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ᐝİ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */