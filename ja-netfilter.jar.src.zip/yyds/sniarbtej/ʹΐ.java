package yyds.sniarbtej;

import java.lang.reflect.Type;

final class ʹΐ implements ـﾗ {
  ʹΐ(ˑĴ paramˑĴ) {}
  
  public final <T> T ˊ(ᐧｴ paramᐧｴ, Type paramType) {
    return this.ᐨẏ.ᐨẏ(paramᐧｴ, paramType);
  }
}


/* Location:              C:\Users\kb\Downloads\ja-netfilter.jar!\yyds\sniarbtej\ʹΐ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */